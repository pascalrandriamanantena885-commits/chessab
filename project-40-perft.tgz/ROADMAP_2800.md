# Project 2800 — JORO

Tanjona: ~2800 Elo (UCI_Elo Stockfish, fotoana mitovy). Ny Elo dia tombantombana: ny calibrate no mamaritra.
Fitsipika: dingana iray isaky ny fotoana; tsy mandroso raha tsy mandalo ny fepetra. Patch tsirairay → SPRT.

## Fitaovana (efa ao)
| Rakitra | Asa |
|---|---|
| `tools/Bench.java` + `.github/workflows/bench.yml` | nps sy depth (nodes deterministic amin'ny depth raikitra) |
| `tools/sprt.py` + `.github/workflows/sprt.yml` | SPRT vaovao vs taloha (`project*.tgz` roa) |
| `tools/calibrate.py` + `.github/workflows/calibrate.yml` | Elo vs Stockfish UCI_Elo |

**Zava-dehibe:** ny rakitra `.github/workflows/*.yml` dia tsy maintsy ao amin'ny repo mivantana (commit),
tsy ao anatin'ny `.tgz` ihany, fa tsy hita ny workflow.

## Dingana 0 — Fototra
- [ ] calibrate (≥ 60 lalao/ambaratonga) → Elo fototra
- [ ] bench → nps/depth fototra (voarakitra eto ambany)
- [ ] SPRT mandeha (sitrana: dikan-teny = dikan-teny → H0/tsy vita, Elo ≈ 0)

Fototra: nps = ____ ; depth@60ms = ____ ; Elo = ____ (daty ____)

## Dingana 1 — Hafainganana (+100..250)
Bitboard/magic, eval incremental, TT bucket, tsy misy allocation. Fepetra: nps ≥ 2x, perft marina.

## Dingana 2 — Fikarohana (+100..200)
History/continuation/capture history, SEE, probcut, aspiration, SPSA. Fepetra: SPRT.

## Dingana 3 — Eval + data (+50..150)
Data tapitrisany toerana, Texel, king safety, passed pawn, endgame. Fepetra: SPRT.

## Dingana 4 — Calibrate indray
UCI_Elo 2400–3000, ovaina `OwnBot.profile` / `OWN_MAX_ELO`.

## Dingana 5 — NNUE (azo ahena)
Raha mijanona ny HCE. Fepetra: mihoatra ny HCE amin'ny SPRT, fotoana mitovy.

## Fanamarihana
- Bound SPRT: [0,10] ho an'ny fiovana lehibe (~1–3k lalao); [0,5] ho an'ny patch kely (~10k lalao, lafo).
- Ny nps amin'ny Actions dia miovaova (JIT, CPU zaraina): ampitahao amin'ny bench mitovy runner ihany.
