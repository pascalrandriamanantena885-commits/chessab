package mg.chess.offline.own;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/** UCI fohy ho an'ny fandrefesana (tools/calibrate.py). Tsy ampiasain'ny app. */
public class OwnUci {
    public static void main(String[] args) throws Exception {
        Search s = new Search(new Eval(50, 50, 50, 50, 50));
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        String line;
        while ((line = in.readLine()) != null) {
            line = line.trim();
            if (line.equals("uci")) { System.out.println("id name JORO"); System.out.println("uciok"); }
            else if (line.equals("isready")) System.out.println("readyok");
            else if (line.equals("ucinewgame")) s.clear();
            else if (line.startsWith("position")) {
                String[] t = line.split("\\s+");
                int i = 1;
                if (t[i].equals("startpos")) { s.pos.setFen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"); i++; }
                else { StringBuilder f = new StringBuilder(); i++; while (i < t.length && !t[i].equals("moves")) f.append(t[i++]).append(' '); s.pos.setFen(f.toString().trim()); }
                if (i < t.length && t[i].equals("moves")) for (i++; i < t.length; i++) s.pos.make(s.pos.parseMove(t[i]));
            } else if (line.startsWith("go")) {
                long ms = 1000;
                String[] t = line.split("\\s+");
                for (int i = 0; i < t.length - 1; i++) if (t[i].equals("movetime")) ms = Long.parseLong(t[i + 1]);
                Search.Result r = s.think(64, ms);
                System.out.println("info depth " + r.depth + " score cp " + r.score + " nodes " + r.nodes);
                System.out.println("bestmove " + (r.move == 0 ? "0000" : Pos.moveStr(r.move)));
            } else if (line.equals("quit")) break;
            System.out.flush();
        }
    }
}
