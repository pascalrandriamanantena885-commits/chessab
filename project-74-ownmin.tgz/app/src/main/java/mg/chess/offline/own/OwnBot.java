package mg.chess.offline.own;

import java.util.List;
import java.util.Random;

/**
 * Bot mahaleo tena (tsy miankina amin'ny Stockfish). Ny Elo dia mamaritra ny depth/tabataba (fanombanana vonjimaika,
 * mila fanitsiana amin'ny lalao tena izy); ny toetra (a,s,d,q,t) dia ao amin'ny evaluation.
 */
public final class OwnBot {
    private static Search search;
    private static String sig = "";
    private static final Random RND = new Random();

    private OwnBot() {}

    /** {depth, noiseCp}; depth >= 64 = tsy voafetra (fotoana ihany). */
    public static int[] profile(int elo) {
        if (elo <= 500) return new int[]{1, 220};
        if (elo <= 700) return new int[]{1, 140};
        if (elo <= 900) return new int[]{2, 110};
        if (elo <= 1100) return new int[]{2, 70};
        if (elo <= 1300) return new int[]{3, 55};
        if (elo <= 1500) return new int[]{3, 25};
        if (elo <= 1700) return new int[]{4, 12};
        if (elo <= 1850) return new int[]{5, 0};
        if (elo <= 1950) return new int[]{6, 0};
        if (elo <= 2050) return new int[]{8, 0};
        if (elo <= 2150) return new int[]{10, 0};
        if (elo <= 2250) return new int[]{12, 0};
        if (elo <= 2350) return new int[]{14, 0};
        if (elo <= 2450) return new int[]{16, 0};
        // > 2450: hery feno (fotoana ihany). Voatombana amin'ny Stockfish UCI_Elo: JORO feno ~ 2690 +-59 (calibrate 1500 ms/hetsika, project-72; taloha 2518 +-60)
        return new int[]{64, 0};
    }

    public static synchronized void newGame() {
        if (search != null) search.clear();
    }

    /** Miverina hetsika UCI (na null raha tsy misy hetsika / FEN diso). */
    public static synchronized String bestMove(String fen, List<String> history, int elo, int movetimeMs,
                                               int a, int s, int d, int q, int t) {
        String nsig = a + "," + s + "," + d + "," + q + "," + t;
        if (search == null || !nsig.equals(sig)) {
            search = new Search(new Eval(a, s, d, q, t));
            sig = nsig;
        }
        try {
            search.pos.setFenWithHistory(fen, history);
        } catch (Exception e) {
            return null;
        }
        int[] pf = profile(elo);
        // Book gambit (fomba JORO): ho an'ny bot matanjaka ihany, raha Params.JORO_BOOK = 1
        if (Params.JORO_BOOK.val != 0 && pf[1] == 0 && history != null && history.size() <= 24
                && GambitBook.fromStart(search.pos, history)) {
            String bm = GambitBook.pick(history, RND);
            if (bm != null) {
                int mv = search.pos.parseMove(bm);
                if (mv != 0 && search.pos.make(mv)) { search.pos.unmake(); return bm; }
            }
        }
        Search.Result r = thinkFor(search, pf, elo, movetimeMs);
        if (r.move == 0) return null;
        return Pos.moveStr(r.move);
    }

    /** Mpieritreritra araka ny profile (ampiasain'ny bestMove sy tools/OwnUci ho an'ny calibrate profile). */
    public static Search.Result thinkFor(Search search, int[] pf, int elo, long movetimeMs) {
        if (pf[1] > 0) return search.thinkWeak(pf[0], pf[1], Math.max(300, movetimeMs), RND);
        // Elo 2200..2450 (depth voafetra): fotoana bebe kokoa mba hahatratra ny depth. Hery feno (pf[0] >= 64): x1 araka ny calibrate
        long ms = Math.max(100, movetimeMs);
        if (elo > 2200 && pf[0] < 64) ms = ms * (400 + Math.min(400, elo - 2200)) / 400;
        return search.think(pf[0], ms);
    }
}
