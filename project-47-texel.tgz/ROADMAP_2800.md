# Project 2800 — JORO

Tanjona: ~2800 Elo (UCI_Elo Stockfish, fotoana mitovy). Ny Elo dia tombantombana: ny calibrate no mamaritra.
Fitsipika: dingana iray isaky ny fotoana; tsy mandroso raha tsy mandalo ny fepetra. Patch tsirairay → SPRT.

## Fitaovana (efa ao)
| Rakitra | Asa |
|---|---|
| `tools/Bench.java` + `.github/workflows/bench.yml` | nps sy depth (nodes deterministic amin'ny depth raikitra) |
| `tools/sprt.py` + `.github/workflows/sprt.yml` | SPRT vaovao vs taloha (`project*.tgz` roa) |
| `tools/calibrate.py` + `.github/workflows/calibrate.yml` | Elo vs Stockfish UCI_Elo |

**Zava-dehibe:** ny rakitra `.github/workflows/*.yml` dia tsy maintsy ao amin'ny repo mivantana (commit),
tsy ao anatin'ny `.tgz` ihany, fa tsy hita ny workflow.

## Dingana 0 — Fototra
- [x] calibrate → Elo fototra
- [x] bench → nps/depth fototra
- [x] SPRT mandeha (taloha=vaovao: 1200 lalao, +389 =406 -405, Elo -4.6 ±16, LLR -1.45)

Fototra: Elo ≈ 2450 (2400→2391 ±101, 2600→2556 ±95; ny 2000/2200 dia saturated, tsy tokoina)
Fanamarihana: mitovy tanteraka ny andalana 2000 sy 2200 (+30 =2 -8) → jereo ny log; ampitomboy ho ~100 lalao/ambaratonga.

## Dingana 1 — Hafainganana (+100..250)
Bitboard/magic, eval incremental, TT bucket, tsy misy allocation. Fepetra: nps ≥ 2x, perft marina.

## Dingana 2 — Fikarohana (+100..200)
History/continuation/capture history, SEE, probcut, aspiration, SPSA. Fepetra: SPRT.

## Dingana 3 — Eval + data (+50..150)
Data tapitrisany toerana, Texel, king safety, passed pawn, endgame. Fepetra: SPRT.

## Dingana 4 — Calibrate indray
UCI_Elo 2400–3000, ovaina `OwnBot.profile` / `OWN_MAX_ELO`.

## Dingana 5 — NNUE (azo ahena)
Raha mijanona ny HCE. Fepetra: mihoatra ny HCE amin'ny SPRT, fotoana mitovy.

## Fanamarihana
- Bound SPRT: [0,10] ho an'ny fiovana lehibe (~1–3k lalao); [0,5] ho an'ny patch kely (~10k lalao, lafo).
- Ny nps amin'ny Actions dia miovaova (JIT, CPU zaraina): ampitahao amin'ny bench mitovy runner ihany.

## Dingana 2 — vokatra (project-46): ProbCut -5.2±16, ContHist +2.3±16, CaptHist +3.5±16 (1200 lalao [0,10]) → tsy misy fahasamihafana; mijanona OFF (default 0)

## Dingana 2 — SPRT ny safidy (project-46)
`sprt.yml` manaiky `variants` (lisitra JSON): variant tsirairay = SPRT misaraka (shards miaraka) amin'ny tgz mitovy,
`opts_new` samy hafa. Default: `["ProbCut=1","CaptHist=1","ContHist=1"]`, [0,10].
- Voalohany: 4 shards x 300 lalao = 1200 lalao/variant. Raha "TSY MBOLA MAZAVA": ampiasao `start_game` sy `prior` (variant IRAY ihany).
- Raiso ny mandresy; avy eo SPRT ny fitambaran'izy ireo (ohatra `["ProbCut=1,CaptHist=1"]`).

## Data ho an'ny Dingana 3 (Texel)
Ny shard tsirairay dia mamoaka `games-<variant>-<shard>.txt`; ny job `collect` dia manangona azy ho
artifact `texel-data` (`texel-positions.txt.gz`). Andalana: `FEN;valiny_fotsy` (1.0 / 0.5 / 0.0),
toerana milamina ihany (tsy check, tsy hetsika fakana, ply ≥ 10, ~1/2 no voatahiry).
Fandrefesana: ny lalao 100 ms, ~2450 Elo: valiny mikorotsaka; ampiasao miaraka amin'ny label Stockfish raha azo atao.

## Dingana 3 — Texel (project-47)
Ny Eval dia efa voatombana tamin'ny ~53k toerana (Tuner taloha). Izao: data self-play be kokoa, mivantana amin'ny Java.
1. `texel.yml`: `gen` (SelfPlay, shards miaraka; ~0.4 s/lalao/core amin'ny depth 6; default 8×4000 lalao ≈ 1.5M toerana)
   → `tune` (Texel.java: coordinate descent, K fit, validation ~10% amin'ny bloc 256; miverina amin'ny tsara indrindra raha miakatra ny validation).
2. Artifact `texel-tuned`: `Eval.java` efa voapetraka (ny block "Lanja voatombana" ihany no niova), `tuned.txt`, `texel.log`.
3. Soloy ny `Eval.java` ao amin'ny tetikasa → tgz vaovao → SPRT [0,10] vs taloha (`base_tgz=prev`, `variants=[""]`).
4. Dingana: `groups=val,pass,w` aloha (~50 parameter, haingana), dia `groups=pst` (~770, lava; mila data be).
Fanamarihana: ny validation no mpitsara; raha tsy mihena, tsy misy fiovana. Ny SPRT ihany no mamaritra ny Elo.
