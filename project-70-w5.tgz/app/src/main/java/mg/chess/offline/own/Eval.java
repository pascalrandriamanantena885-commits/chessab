package mg.chess.offline.own;

/**
 * Evaluation manokana (centipawn, araka ny mpilalao ho avy). Misy toetra (personalité):
 * a=fanafihana, s=sacrifice, d=fiarovana, q=queen, t=fifanakalozana (0..100, 50 = mahazatra).
 */
public final class Eval {
    static final int[] V_MG = {0, 100, 320, 330, 500, 900, 0};
    static final int[] V_EG = {0, 115, 320, 340, 520, 950, 0};
    static final int[] PH = {0, 0, 1, 1, 2, 4, 0};
    static final int[][] PST_MG = new int[16][128];
    static final int[][] PST_EG = new int[16][128];
    static final int[] PASS_MG = {0, 0, 5, 10, 20, 35, 60, 0};
    static final int[] PASS_EG = {0, 0, 10, 20, 40, 70, 120, 0};
    static final int[] ATT_W = {0, 0, 2, 2, 3, 5, 0};
    // Lanja scalar azo tuning-na (Texel). Jereo W_* ho an'ny index.
    static final int W_DBL_MG = 0, W_DBL_EG = 1, W_ISO_MG = 2, W_ISO_EG = 3, W_SUP_MG = 4, W_SUP_EG = 5,
        W_NMOB_MG = 6, W_NMOB_EG = 7, W_BMOB_MG = 8, W_BMOB_EG = 9, W_RMOB_MG = 10, W_RMOB_EG = 11,
        W_ROPEN_MG = 12, W_ROPEN_EG = 13, W_RSEMI_MG = 14, W_RSEMI_EG = 15, W_R7_MG = 16, W_R7_EG = 17,
        W_QMOB_EG = 18, W_BPAIR_MG = 19, W_BPAIR_EG = 20, W_OUTP_MG = 21, W_OUTP_EG = 22, W_OUTPU_MG = 23,
        W_THR_MG = 24, W_THR_EG = 25, W_PKPROX = 26, W_PBLOCK = 27, W_TEMPO = 28, W_QMOB_MG = 29;
    static final int[] W = {8, 12, 12, 12, 5, 5, 4, 4, 3, 4, 1, 3, 20, 10, 10, 8, 15, 20, 2, 30, 45, 18, 10, 8, 25, 15, 3, 50, 10, 1};
    // Toetra vaovao (Eval2=1): fanamboarana piyon, tafio-drivotra, tsy misy ratsy fanaovana. Azo tuning-na (group w2).
    static final int W2_PHAL_MG = 0, W2_PHAL_EG = 1, W2_BACK_MG = 2, W2_BACK_EG = 3, W2_STORM = 4, W2_NOQ = 5, W2_FREE = 6;
    static final int[] W2 = {8, 6, 8, 10, 5, 50, 6};
    // Toetra fanafihana (Eval3=1). Azo tuning-na (group w3).
    static final int W3_OPENF = 0, W3_SEMIF = 1, W3_TROPQ = 2, W3_TROPN = 3, W3_COUNTER = 4, W3_SAC = 5, W3_SACMAX = 6,
        W3_THRATK = 7, W3_CKING = 8, W3_OPPS = 9, W3_KEXP = 10;
    static final int[] W3 = {12, 6, 3, 3, 15, 25, 60, 50, 10, 4, 4};
    // Toetra vaovao (Eval4=1): bishop ratsy, knight/rook araka ny isan'ny piyon, rook voasakana, scaling endgame. Azo tuning-na (group w4).
    static final int W4_BADB_MG = 0, W4_BADB_EG = 1, W4_NPAWN = 2, W4_RPAWN = 3, W4_TRAPR = 4, W4_OCB = 5, W4_NOPAWN = 6;
    static final int[] W4 = {3, 4, 2, 2, 25, 40, 24};
    // Toetra vaovao (Eval5=1): rook ao ambadiky ny passer, king safety (toerana handosirana + mpiaro akaiky), space, passer tsy azo atsahatra (fitsipika ny efamira), scaling rook endgame, rook mifandray. Azo tuning-na (group w5).
    static final int W5_RBP = 0, W5_KFLIGHT = 1, W5_DEFPC = 2, W5_SPACE = 3, W5_UNSTOP = 4, W5_RSCALE = 5, W5_CONNR = 6;
    static final int[] W5 = {6, 20, 8, 2, 25, 56, 8};
    static final int[][] TMG = new int[7][64], TEG = new int[7][64]; // [type][rr*8+f]

    static {
        for (int c = 0; c < 2; c++) {
            for (int sq = 0; sq < 128; sq++) {
                if ((sq & 0x88) != 0) continue;
                int f = sq & 7, r = sq >> 4;
                int rr = c == 0 ? r : 7 - r; // ambaratonga relative
                int d = Math.max(Math.abs(2 * f - 7), Math.abs(2 * r - 7));
                int cf = Math.abs(2 * f - 7);
                int pc = c << 3;
                // piyon
                int pmg = new int[]{0, -5, -5, 0, 10, 25, 40, 0}[rr];
                if (rr >= 1 && rr <= 4 && (f == 3 || f == 4)) pmg += 8 + 2 * rr;
                if (rr == 1 && (f == 0 || f == 7)) pmg -= 3;
                int peg = new int[]{0, 0, 3, 8, 18, 35, 50, 0}[rr];
                PST_MG[Pos.P | pc][sq] = pmg; PST_EG[Pos.P | pc][sq] = peg;
                PST_MG[Pos.N | pc][sq] = (7 - d) * 5 - 20; PST_EG[Pos.N | pc][sq] = (7 - d) * 4 - 16;
                PST_MG[Pos.B | pc][sq] = (7 - d) * 2 - 6;  PST_EG[Pos.B | pc][sq] = (7 - d) * 2 - 6;
                PST_MG[Pos.R | pc][sq] = (cf <= 3 ? 3 : 0); PST_EG[Pos.R | pc][sq] = 0;
                PST_MG[Pos.Q | pc][sq] = (7 - d) - 3;       PST_EG[Pos.Q | pc][sq] = (7 - d) * 2 - 6;
                PST_MG[Pos.K | pc][sq] = cf * 3 - 14 * rr;  PST_EG[Pos.K | pc][sq] = (7 - d) * 8 - 24;
                if (c == 0) for (int ty = 1; ty <= 6; ty++) {
                    TMG[ty][r * 8 + f] = PST_MG[ty][sq]; TEG[ty][r * 8 + f] = PST_EG[ty][sq];
                }
            }
        }
    }

    /** Fenoy ny PST avy amin'ny TMG/TEG (mitovy amin'ny fisaka ho an'ny mainty). */
    public static void rebuildPst() {
        for (int c = 0; c < 2; c++) for (int sq = 0; sq < 128; sq++) {
            if ((sq & 0x88) != 0) continue;
            int f = sq & 7, r = sq >> 4, rr = c == 0 ? r : 7 - r;
            for (int ty = 1; ty <= 6; ty++) {
                PST_MG[ty | (c << 3)][sq] = TMG[ty][rr * 8 + f];
                PST_EG[ty | (c << 3)][sq] = TEG[ty][rr * 8 + f];
            }
        }
    }

    // ---- Lanja voatombana (Texel) - novolavolain'ny Tuner ----
    static {
        int[] vmg = {0, 100, 375, 375, 552, 1126, 0}; int[] veg = {0, 103, 316, 355, 563, 1056, 0};
        int[] w = {6, 8, 18, 10, 10, 7, 2, 7, 4, 6, 3, 3, 46, 0, 23, 18, 37, 17, 1, 73, 37, 50, 20, 26, 46, 32, 36, 39, 7, 1};
        int[] w2 = {8, 6, 8, 10, 5, 50, 6};
        int[] w3 = {12, 6, 2, 5, 56, 0, 60, 50, 21, 0, 4};
        int[] w4 = {1, 0, 5, 0, 7, 17, 0};
        int[] w5 = {21, 0, 18, 0, 100, 51, 9};
        int[] pmg = {0, 0, -9, 3, 26, 98, 228, 0}; int[] peg = {0, 0, 18, 57, 97, 128, 167, 0};
        int[] tmg1 = {0, 0, 0, 0, 0, 0, 0, 0, -17, -1, -9, -22, -22, 8, 3, -17, -6, -9, 1, -16, -9, -4, 4, -9, -10, -7, 6, 17, 16, 13, -13, -18, 4, 17, 14, 17, 26, 14, 4, -11, 2, 24, 6, 27, 16, 55, -4, 31, 73, 39, 18, 54, 50, -25, 17, 44, 0, 0, 0, 0, 0, 0, 0, 0};
        int[] teg1 = {0, 0, 0, 0, 0, 0, 0, 0, 16, 17, 17, 10, 17, 7, 4, 7, 8, 15, 8, 5, 6, 7, -3, -1, 14, 16, 4, -8, -9, -1, 13, 6, 25, 24, 12, 1, 1, -3, 13, 20, 46, 40, 40, 18, 29, 19, 22, 24, 41, 53, 55, 62, 42, 28, 63, 24, 0, 0, 0, 0, 0, 0, 0, 0};
        int[] tmg2 = {-55, -17, -13, -10, 9, 5, -7, -31, -10, 18, 9, 8, 15, 20, -4, -35, -22, 6, 2, 20, 23, 15, 24, -12, -5, 7, 5, -3, 2, 1, -37, -10, 26, -16, 21, 6, -3, 12, -13, 19, -2, -1, 5, 15, -1, -3, -12, -29, -87, -80, 1, 10, -31, 40, -80, -17, -150, -34, -41, -31, 4, -73, -22, -100};
        int[] teg2 = {-11, -30, -14, -3, -10, -15, -27, -24, 3, -9, -14, 1, -9, -9, 7, -40, -23, -4, 1, 5, 5, 2, -4, -19, -2, -2, 6, 13, 13, 7, 7, -6, 10, 9, 2, 5, 20, 8, 1, -9, -3, 3, -1, 8, -5, -5, 15, -22, 9, 1, 4, 22, 19, -7, 5, -24, -18, 1, 8, -13, -9, 17, -5, -45};
        int[] tmg3 = {-21, 14, -6, -13, 1, -13, -3, -7, 6, 14, 15, 7, 8, 11, 26, 27, -4, 31, 14, -6, -4, 20, 13, -8, 24, 2, -8, -1, 10, -10, -10, 16, 2, -3, -8, 1, 16, 9, -11, -14, -6, -22, -9, 16, 14, 7, -8, -41, -25, -10, -5, -20, -50, -19, -26, -38, -46, 33, -21, -22, -83, -41, -141, -17};
        int[] teg3 = {-12, -38, -21, -17, -23, -5, -2, -13, 1, -13, -19, -3, -8, -37, -11, -48, -13, -8, 7, 1, 2, -12, 4, -5, -23, 12, 8, 13, -2, 12, -9, -13, -3, 14, 18, 9, 7, 3, 21, -11, -1, 31, 18, 7, -1, 24, 17, 39, 7, 14, 4, -2, 42, 6, 31, -27, 3, 6, 21, 19, 35, 22, 52, -4};
        int[] tmg4 = {6, 5, -2, 5, 12, 26, -7, 5, -4, 5, -12, -5, -17, 11, -16, -38, -3, -1, -26, -31, -11, -15, -15, -5, -12, -15, -17, -8, -17, -25, -20, -8, 0, 9, 1, 32, -20, -5, -7, -3, 16, 23, 36, 29, 9, 38, 14, 16, 10, 15, 39, 23, 33, 22, -1, 1, 83, 45, 42, 75, 50, 71, 93, 61};
        int[] teg4 = {-3, 1, 9, -9, -20, -19, -6, -11, -20, -12, -6, -13, -13, -28, -24, -11, -2, -3, -1, -4, -17, -24, -29, -19, 5, 9, 10, 7, 10, 11, 10, 0, 11, 17, 16, 8, 15, 13, 9, 17, 14, 5, 5, 1, 9, 11, 7, 7, 18, 21, 14, 17, 22, 13, 14, 16, 18, 20, 15, -4, 26, 2, 3, 12};
        int[] tmg5 = {5, 15, 4, 14, 12, -12, 8, 8, 1, -6, 18, 15, 12, 22, 14, 7, 3, 5, -1, 2, 10, -7, 4, -28, -6, -18, -15, -13, -10, -5, -13, -16, -26, -13, -5, -19, -12, -4, -8, -1, -15, -1, 9, 36, 29, 38, 2, 35, -21, -20, -10, 38, 26, 21, 10, -6, -11, 4, 23, 20, 46, 45, -15, -14};
        int[] teg5 = {-14, -24, -65, -32, -54, -27, -20, -76, -34, 11, -36, -29, -12, -15, -37, -11, -8, 2, 3, -1, 2, 7, 5, -7, -8, 11, 22, 38, 33, 1, 8, 11, 28, 3, 21, 45, 46, 26, 27, 14, -12, 8, 6, 2, 20, 15, 6, -3, 10, 8, 24, 4, 17, 10, -17, -3, -23, -11, -31, -2, -4, -3, -8, -7};
        int[] tmg6 = {-24, 13, 28, -7, 12, -13, 15, -6, 27, 24, 17, 15, 5, 18, 13, 5, -18, 17, -14, -16, -23, -12, 11, 24, -29, -25, -54, -63, -59, -18, -4, -49, -46, -55, -69, -54, -54, -55, -31, -50, -150, -127, -80, -132, -150, -61, -81, -124, -149, -149, -148, -128, -150, -150, -146, -150, -150, -148, -132, -95, -89, -131, -42, -150};
        int[] teg6 = {14, -14, -22, -14, -23, -10, -15, -21, -29, -3, -6, -4, 3, 5, 1, -11, -14, -8, 3, 1, 7, 12, -3, -24, -35, -13, 3, 10, 10, 7, -8, -31, -49, -13, 3, 0, 13, 11, 3, -43, -35, -6, 1, 21, 15, 15, 17, -33, -120, -107, -16, -10, -10, -62, -19, -73, -150, -101, -85, -107, -96, -93, -46, -150};
        System.arraycopy(vmg, 0, V_MG, 0, vmg.length); System.arraycopy(veg, 0, V_EG, 0, veg.length);
        System.arraycopy(w, 0, W, 0, w.length);
        System.arraycopy(w2, 0, W2, 0, w2.length);
        System.arraycopy(w3, 0, W3, 0, w3.length);
        System.arraycopy(w4, 0, W4, 0, w4.length);
        System.arraycopy(w5, 0, W5, 0, w5.length);
        System.arraycopy(pmg, 0, PASS_MG, 0, pmg.length); System.arraycopy(peg, 0, PASS_EG, 0, peg.length);
        int[][] tm = {null, tmg1, tmg2, tmg3, tmg4, tmg5, tmg6}, te = {null, teg1, teg2, teg3, teg4, teg5, teg6};
        for (int ty = 1; ty <= 6; ty++) { System.arraycopy(tm[ty], 0, TMG[ty], 0, 64); System.arraycopy(te[ty], 0, TEG[ty], 0, 64); }
        rebuildPst();
    }
    // ---- farany ----

    /** Rook gambit: manana rook mifanakaiky (contact) na amin'ny line misokatra mankany amin'ny mpanjaka mpifanandrina ve ny c? */
    public static boolean rookContact(Pos p, int c) {
        final int[] b = p.b;
        final int ks = p.ksq[c ^ 1];
        final int rook = Pos.R | (c << 3);
        for (int sq = 0; sq < 128; sq++) {
            if ((sq & 0x88) != 0) { sq += 7; continue; }
            if (b[sq] != rook) continue;
            int df = (sq & 7) - (ks & 7), dr = (sq >> 4) - (ks >> 4);
            if (df != 0 && dr != 0) continue;
            int step = df == 0 ? (dr > 0 ? 16 : -16) : (df > 0 ? 1 : -1);
            boolean clear = true;
            for (int t = ks + step; t != sq; t += step) if (b[t] != 0) { clear = false; break; }
            if (clear) return true;
        }
        return false;
    }

    private static final int[] KDIR = {1, -1, 16, -16, 15, -15, 17, -17};
    private static final int[] UNDEV = {0x01, 0x02, 0x05, 0x06}; // b,c,f,g (rank 1 / +0x70 = rank 8)

    private static int cheb(int a, int b) {
        return Math.max(Math.abs((a & 7) - (b & 7)), Math.abs((a >> 4) - (b >> 4)));
    }

    // personalité (pct)
    final int matPct, attPct, defPct, queenAct, tradeTf;

    public Eval(int a, int s, int d, int q, int t) {
        matPct = 100 - (s - 50) / 5;                 // sacrifice: 90..110
        int ap = 70 + (a * 60) / 100;                  // 70..130
        attPct = ap * (100 + (s - 50) / 2) / 100;      // sacrifice mampitombo ny fanafihana
        defPct = 60 + (d * 80) / 100;                  // 60..140
        queenAct = q - 50 + (q - 50);                  // -100..+100
        tradeTf = (t - 50) * 15 / 50;                  // -15..+15 (%)
    }

    private final int[][] cnt = new int[2][10];
    private final int[][] hi = new int[2][10];
    private final int[][] lo = new int[2][10];
    private final int[] mg = new int[2], eg = new int[2];
    private final boolean[][] zone = new boolean[2][128];
    private final int[] units = new int[2], atk = new int[2];
    private final int[] nb = new int[2];
    private final int[] bishops = new int[2];
    private final int[] pawnsN = new int[2];
    private final int[] mat = new int[2];
    private final int[][] pawnCol = new int[2][2];   // piyon isaky ny loko square (Eval4)
    private final int[] bishCol = new int[2];
    private final int[][] rkSq = new int[2][10];      // toerana rook (Eval5)
    private final int[] rkN = new int[2];
    private final int[][] passRR = new int[2][8];     // ambaratonga relative ambony indrindra an'ny piyon passed isaky ny rakitra (-1 = tsy misy)
    private final int[] defN = new int[2];            // piece mpiaro akaiky ny mpanjaka (<= 2 square)
    private final int[] qn = new int[2];
    private final int[][] rqf = new int[2][8];  // isan'ny rook/queen isaky ny rakitra (Eval3)
    private final int[] occSq = new int[40];   // toerana misy piece (<= 32)

    /** Mitovy amin'ny zone[c][t] taloha: 3x3 manodidina ny mpanjaka + andalana 2 eo aloha (3 rakitra). */
    private static boolean inZone(int kr, int kf, int c, int t) {
        int dr = (t >> 4) - kr, df = (t & 7) - kf;
        if (df < -1 || df > 1) return false;
        return (dr >= -1 && dr <= 1) || dr == (c == 0 ? 2 : -2);
    }

    @SuppressWarnings("unused")
    private void mark(Pos p, int c) {
        boolean[] z = zone[c];
        java.util.Arrays.fill(z, false);
        int k = p.ksq[c];
        int fwd = c == 0 ? 16 : -16;
        for (int dr = -1; dr <= 1; dr++) for (int df = -1; df <= 1; df++) {
            int s = k + dr * 16 + df;
            if ((s & 0x88) == 0) z[s] = true;
        }
        for (int df = -1; df <= 1; df++) {
            int s = k + 2 * fwd + df;
            if ((s & 0x88) == 0) z[s] = true;
        }
    }

    // ---- Eval cache (hash araka ny pos.key): mitahiry ny valiny mitovy tanteraka, ka tsy manova ny node ----
    private static final int EC_BITS = 17;
    private final long[] ecKey = new long[1 << EC_BITS];
    private final int[] ecVal = new int[1 << EC_BITS];

    /** Fafao rehefa miova ny Eval.W / PST (ohatra rehefa Texel tuning). */
    public void clearCache() { java.util.Arrays.fill(ecKey, 0L); }

    /** Score araka ny mpilalao ho avy (misy cache). */
    public int eval(Pos p) {
        final long k = p.key;
        final int i = (int) (k ^ (k >>> 32)) & ((1 << EC_BITS) - 1);
        if (ecKey[i] == k) return ecVal[i];
        final int v = evalRaw(p);
        ecKey[i] = k; ecVal[i] = v;
        return v;
    }

    /** Fanisana tsy misy cache. */
    public int evalRaw(Pos p) {
        final int[] b = p.b;
        for (int c = 0; c < 2; c++) {
            java.util.Arrays.fill(cnt[c], 0);
            java.util.Arrays.fill(hi[c], -1);
            java.util.Arrays.fill(lo[c], 8);
            mg[c] = 0; eg[c] = 0; units[c] = 0; atk[c] = 0; nb[c] = 0; bishops[c] = 0; pawnsN[c] = 0; mat[c] = 0; qn[c] = 0; pawnCol[c][0] = 0; pawnCol[c][1] = 0; bishCol[c] = -1; rkN[c] = 0; defN[c] = 0; java.util.Arrays.fill(passRR[c], -1);
        }
        int phaseTot = 0, minors = 0, majors = 0;
        // pass 1: piyon + material (tahirizina ny toerana misy piece ho an'ny pass 2)
        int no = 0;
        final int[] occ = occSq;
        for (int s = 0; s < 128; s++) {
            if ((s & 0x88) != 0) { s += 7; continue; }
            int pc = b[s];
            if (pc == 0) continue;
            occ[no++] = s;
            int c = pc >> 3, ty = pc & 7;
            if (ty == Pos.P) {
                int f = s & 7, r = s >> 4;
                cnt[c][f + 1]++;
                if (r > hi[c][f + 1]) hi[c][f + 1] = r;
                if (r < lo[c][f + 1]) lo[c][f + 1] = r;
                pawnsN[c]++;
                pawnCol[c][((s & 7) + (r)) & 1]++;
            } else if (ty != Pos.K) {
                phaseTot += PH[ty];
                nb[c]++;
                if (ty == Pos.N || ty == Pos.B) minors++; else majors++;
                if (ty == Pos.B) { bishops[c]++; bishCol[c] = ((s & 7) + (s >> 4)) & 1; }
                if (ty == Pos.Q) qn[c]++;
                if (ty == Pos.R && rkN[c] < 10) rkSq[c][rkN[c]++] = s;
                if (ty == Pos.R || ty == Pos.Q) rqf[c][s & 7]++;
            }
        }
        if (pawnsN[0] + pawnsN[1] == 0 && majors == 0 && minors <= 1) return 0; // draw: material tsy ampy
        final boolean ev2 = Params.EVAL2.val != 0, ev3 = Params.EVAL3.val != 0;
        final boolean joro = ev3 && Params.JORO_STYLE.val != 0;
        final boolean hunt = ev3 && Params.JORO_HUNT.val != 0;
        final boolean rookG = ev3 && Params.JORO_ROOK.val != 0;
        final boolean ev4 = Params.EVAL4.val != 0;
        final boolean ev5 = Params.EVAL5.val != 0;
        if (ev3) { java.util.Arrays.fill(rqf[0], 0); java.util.Arrays.fill(rqf[1], 0); }
        final int kr0 = p.ksq[0] >> 4, kf0 = p.ksq[0] & 7, kr1 = p.ksq[1] >> 4, kf1 = p.ksq[1] & 7;
        for (int oi = 0; oi < no; oi++) {
            final int s = occ[oi];
            int pc = b[s];
            int c = pc >> 3, ty = pc & 7, o = c ^ 1;
            int f = s & 7, r = s >> 4, rr = c == 0 ? r : 7 - r;
            final int zkr = o == 0 ? kr0 : kr1, zkf = o == 0 ? kf0 : kf1;
            mg[c] += V_MG[ty] * matPct / 100 + PST_MG[pc][s];
            eg[c] += V_EG[ty] * matPct / 100 + PST_EG[pc][s];
            mat[c] += V_MG[ty];
            boolean hitK = false;
            switch (ty) {
                case Pos.P: {
                    if (cnt[c][f + 1] > 1) { mg[c] -= W[W_DBL_MG]; eg[c] -= W[W_DBL_EG]; }
                    if (cnt[c][f] == 0 && cnt[c][f + 2] == 0) { mg[c] -= W[W_ISO_MG]; eg[c] -= W[W_ISO_EG]; }
                    boolean passed = true;
                    for (int ff = f; ff <= f + 2 && passed; ff++) {
                        if (c == 0) { if (hi[1][ff] > r) passed = false; }
                        else { if (lo[0][ff] < r) passed = false; }
                    }
                    if (passed) {
                        int pm = PASS_MG[rr], pe = PASS_EG[rr];
                        int stop = s + (c == 0 ? 16 : -16);
                        if ((stop & 0x88) == 0) {
                            if (b[stop] != 0 && (b[stop] >> 3) != c) { pm -= pm * W[W_PBLOCK] / 100; pe -= pe * W[W_PBLOCK] / 100; }
                            eg[c] += (cheb(p.ksq[o], stop) - cheb(p.ksq[c], stop)) * W[W_PKPROX] * rr / 6;
                        }
                        mg[c] += pm; eg[c] += pe;
                        if (ev5) {
                            if (rr > passRR[c][f]) passRR[c][f] = rr;
                            if (nb[o] == 0) {
                                // fitsipika ny efamira: ny mpanjaka mpifanandrina tsy mahatratra ny piyon
                                int steps = 7 - rr - (rr == 1 ? 1 : 0);
                                int dk = cheb(p.ksq[o], (c == 0 ? 0x70 : 0) + f);
                                int margin = dk - steps - (p.side == c ? 0 : 1);
                                if (margin > 0) eg[c] += W5[W5_UNSTOP] * Math.min(margin, 4);
                            }
                        }
                        if (ev2) {
                            int fw = c == 0 ? 16 : -16, q = s + fw;
                            boolean free = true;
                            while ((q & 0x88) == 0) { if (b[q] != 0) { free = false; break; } q += fw; }
                            if (free) eg[c] += W2[W2_FREE] * rr / 2;
                        }
                    }
                    if (ev2) {
                        final int me3 = Pos.P | (c << 3);
                        final int rn = s + 1;
                        if ((rn & 0x88) == 0 && b[rn] == me3) { mg[c] += W2[W2_PHAL_MG] * rr / 4; eg[c] += W2[W2_PHAL_EG] * rr / 4; }
                        if (!passed && cnt[c][f] + cnt[c][f + 2] > 0) {
                            boolean behind = c == 0 ? (lo[c][f] <= r || lo[c][f + 2] <= r) : (hi[c][f] >= r || hi[c][f + 2] >= r);
                            if (!behind) {
                                int st = s + (c == 0 ? 16 : -16);
                                int ep3 = Pos.P | (o << 3), a1 = st + (c == 0 ? 15 : -15), a2 = st + (c == 0 ? 17 : -17);
                                if (((a1 & 0x88) == 0 && b[a1] == ep3) || ((a2 & 0x88) == 0 && b[a2] == ep3)) {
                                    mg[c] -= W2[W2_BACK_MG]; eg[c] -= W2[W2_BACK_EG];
                                }
                            }
                        }
                    }
                    if (ev3) {
                        final int okf = o == 0 ? kf0 : kf1, mkf = o == 0 ? kf1 : kf0;
                        if (Math.abs(okf - mkf) >= 3 && Math.abs(f - okf) <= 2 && rr >= 3) mg[c] += W3[W3_OPPS] * (rr - 2);
                    }
                    int sup = c == 0 ? -15 : 15;
                    int s1 = s + sup, s2 = s + (c == 0 ? -17 : 17);
                    int me = Pos.P | (c << 3);
                    if (((s1 & 0x88) == 0 && b[s1] == me) || ((s2 & 0x88) == 0 && b[s2] == me)) { mg[c] += W[W_SUP_MG]; eg[c] += W[W_SUP_EG]; }
                    break;
                }
                case Pos.N: {
                    int m = 0; boolean hit = false;
                    for (int d : Pos.KN) {
                        int t = s + d;
                        if ((t & 0x88) != 0) continue;
                        int tp = b[t];
                        if (tp != 0 && (tp >> 3) == c) continue;
                        m++;
                        if (!hit && inZone(zkr, zkf, o, t)) hit = true;
                    }
                    mg[c] += (m - 4) * W[W_NMOB_MG]; eg[c] += (m - 4) * W[W_NMOB_EG];
                    if (ev4) { int dp = (pawnsN[0] + pawnsN[1] - 8) * W4[W4_NPAWN]; mg[c] += dp / 2; eg[c] += dp; }
                    if (rr >= 3 && rr <= 5 && f >= 1 && f <= 6) {
                        boolean safe = c == 0 ? (hi[1][f] <= r && hi[1][f + 2] <= r) : (lo[0][f] >= r && lo[0][f + 2] >= r);
                        if (safe) {
                            int me2 = Pos.P | (c << 3);
                            int a1 = s + (c == 0 ? -15 : 15), a2 = s + (c == 0 ? -17 : 17);
                            boolean sup = ((a1 & 0x88) == 0 && b[a1] == me2) || ((a2 & 0x88) == 0 && b[a2] == me2);
                            mg[c] += sup ? W[W_OUTP_MG] : W[W_OUTPU_MG]; eg[c] += sup ? W[W_OUTP_EG] : W[W_OUTP_EG] / 2;
                        }
                    }
                    if (hit) { units[c] += ATT_W[ty]; atk[c]++; hitK = true; }
                    if (ev3) mg[c] += W3[W3_TROPN] * (7 - cheb(s, p.ksq[o]));
                    break;
                }
                case Pos.B: case Pos.R: case Pos.Q: {
                    int m = 0; boolean hit = false;
                    for (int di = 0; di < 8; di++) {
                        int d;
                        if (di < 4) { if (ty == Pos.B) continue; d = Pos.RD[di]; }
                        else { if (ty == Pos.R) continue; d = Pos.BD[di - 4]; }
                        int t = s + d;
                        while ((t & 0x88) == 0) {
                            int tp = b[t];
                            if (tp != 0 && (tp >> 3) == c) break;
                            m++;
                            if (!hit && inZone(zkr, zkf, o, t)) hit = true;
                            if (tp != 0) break;
                            t += d;
                        }
                    }
                    if (ty == Pos.B) {
                        mg[c] += (m - 6) * W[W_BMOB_MG]; eg[c] += (m - 6) * W[W_BMOB_EG];
                        if (ev4) { int same = pawnCol[c][((s & 7) + (s >> 4)) & 1] - 3; mg[c] -= same * W4[W4_BADB_MG]; eg[c] -= same * W4[W4_BADB_EG]; }
                    }
                    else if (ty == Pos.R) {
                        mg[c] += (m - 7) * W[W_RMOB_MG]; eg[c] += (m - 7) * W[W_RMOB_EG];
                        if (ev4) {
                            int dp = -(pawnsN[0] + pawnsN[1] - 8) * W4[W4_RPAWN]; mg[c] += dp / 2; eg[c] += dp;
                            if (rr == 0 && (p.ksq[c] >> 4) == (c == 0 ? 0 : 7) && m <= 3) {
                                int kf2 = p.ksq[c] & 7;
                                if ((f > kf2 && kf2 >= 4) || (f < kf2 && kf2 <= 3)) mg[c] -= W4[W4_TRAPR];
                            }
                        }
                        if (cnt[c][f + 1] == 0) {
                            if (cnt[o][f + 1] == 0) { mg[c] += W[W_ROPEN_MG]; eg[c] += W[W_ROPEN_EG]; } else { mg[c] += W[W_RSEMI_MG]; eg[c] += W[W_RSEMI_EG]; }
                        }
                        if (rr == 6 && (p.ksq[o] >> 4 == (c == 0 ? 7 : 0))) { mg[c] += W[W_R7_MG]; eg[c] += W[W_R7_EG]; }
                    } else {
                        mg[c] += (m - 14) * (100 + queenAct) / 100 * W[W_QMOB_MG]; eg[c] += (m - 14) * W[W_QMOB_EG];
                        if (rr > 0 && queenAct > 0) mg[c] += queenAct * 12 / 100;
                    }
                    if (hit) { units[c] += ATT_W[ty]; atk[c]++; hitK = true; }
                    if (ev3 && ty == Pos.Q) mg[c] += W3[W3_TROPQ] * (7 - cheb(s, p.ksq[o]));
                    break;
                }
                default: break;
            }
            if (ev5 && ty >= Pos.N && ty <= Pos.Q && cheb(s, p.ksq[c]) <= 2) defN[c]++;
            if (ty >= Pos.N && ty <= Pos.Q) {
                int e1 = s + (c == 0 ? 15 : -15), e2 = s + (c == 0 ? 17 : -17);
                int ep2 = Pos.P | (o << 3);
                if (((e1 & 0x88) == 0 && b[e1] == ep2) || ((e2 & 0x88) == 0 && b[e2] == ep2)) {
                    int tm = W[W_THR_MG], te2 = W[W_THR_EG];
                    if (ev3 && hitK) { tm = tm * (100 - W3[W3_THRATK]) / 100; te2 = te2 * (100 - W3[W3_THRATK]) / 100; }
                    mg[c] -= tm; eg[c] -= te2;
                }
            }
        }
        if (ev5) {
            for (int c = 0; c < 2; c++) {
                final int o5 = c ^ 1;
                for (int k5 = 0; k5 < rkN[c]; k5++) {
                    int s5 = rkSq[c][k5], f5 = s5 & 7, r5 = s5 >> 4;
                    int rrC = c == 0 ? r5 : 7 - r5, rrO = o5 == 0 ? r5 : 7 - r5;
                    if (passRR[c][f5] > rrC) eg[c] += W5[W5_RBP] * (passRR[c][f5] + 1) / 4;     // rook ao ambadiky ny passer
                    if (passRR[o5][f5] > rrO) eg[c] += W5[W5_RBP] * (passRR[o5][f5] + 1) / 4;   // rook ao ambadiky ny passer mpifanandrina
                }
                if (rkN[c] >= 2) {
                    int a5 = rkSq[c][0], b5 = rkSq[c][1];
                    boolean conn = false;
                    if ((a5 >> 4) == (b5 >> 4)) {
                        conn = true; int st = a5 < b5 ? 1 : -1;
                        for (int t5 = a5 + st; t5 != b5; t5 += st) if (b[t5] != 0) { conn = false; break; }
                    } else if ((a5 & 7) == (b5 & 7)) {
                        conn = true; int st = a5 < b5 ? 16 : -16;
                        for (int t5 = a5 + st; t5 != b5; t5 += st) if (b[t5] != 0) { conn = false; break; }
                    }
                    if (conn) { mg[c] += W5[W5_CONNR]; eg[c] += W5[W5_CONNR] / 2; }
                }
                // space: square azo antoka eo afovoany (rakitra c-f, ambaratonga 2-4) tsy misy piyon ny tenany ary tsy tafiditry ny piyon mpifanandrina
                int safe = 0;
                final int myP = Pos.P | (c << 3), enP = Pos.P | (o5 << 3);
                for (int ff = 2; ff <= 5; ff++) for (int rp = 1; rp <= 3; rp++) {
                    int sq = (c == 0 ? rp : 7 - rp) * 16 + ff;
                    if (b[sq] == myP) continue;
                    int a1 = sq + (c == 0 ? 15 : -15), a2 = sq + (c == 0 ? 17 : -17);
                    if (((a1 & 0x88) == 0 && b[a1] == enP) || ((a2 & 0x88) == 0 && b[a2] == enP)) continue;
                    safe++;
                }
                mg[c] += safe * Math.min(nb[c], 5) * W5[W5_SPACE] / 4;
            }
        }
        for (int c = 0; c < 2; c++) {
            if (bishops[c] >= 2) { mg[c] += W[W_BPAIR_MG]; eg[c] += W[W_BPAIR_EG]; }
            int o = c ^ 1;
            // fiarovana mpanjaka (pawn shield) - mg ihany
            int k = p.ksq[c];
            int kf = k & 7, kr = k >> 4, krr = c == 0 ? kr : 7 - kr;
            if (krr <= 1) {
                int shield = 0;
                int fwd = c == 0 ? 16 : -16;
                int me = Pos.P | (c << 3);
                for (int ff = Math.max(0, kf - 1); ff <= Math.min(7, kf + 1); ff++) {
                    int s1 = (kr * 16 + ff) + fwd, s2 = s1 + fwd;
                    if ((s1 & 0x88) == 0 && b[s1] == me) shield += 10;
                    else if ((s2 & 0x88) == 0 && b[s2] == me) shield += 6;
                    else if (cnt[c][ff + 1] == 0) shield -= 15;
                    else shield -= 5;
                }
                mg[c] += shield * defPct / 100;
                if (ev2) {
                    int storm = 0;
                    for (int ff = Math.max(0, kf - 1); ff <= Math.min(7, kf + 1); ff++) {
                        if (cnt[o][ff + 1] == 0) continue;
                        int adv = o == 0 ? hi[o][ff + 1] : 7 - lo[o][ff + 1];
                        if (adv >= 3) storm += adv - 2;
                    }
                    mg[c] -= storm * W2[W2_STORM];
                }
            }
            if (ev3 && nb[o] > 2) {
                // rakitra misokatra manoloana ny mpanjaka + rook/queen mpifanandrina
                for (int ff = Math.max(0, kf - 1); ff <= Math.min(7, kf + 1); ff++) {
                    if (cnt[c][ff + 1] != 0 || rqf[o][ff] == 0) continue;
                    mg[c] -= cnt[o][ff + 1] == 0 ? W3[W3_OPENF] : W3[W3_SEMIF];
                }
                // mpanjaka tsy niaro eo afovoany raha mbola misy queen mpifanandrina
                if (qn[o] > 0 && krr <= 2 && kf >= 2 && kf <= 5) {
                    int missing = (cnt[c][4] == 0 ? 1 : 0) + (cnt[c][5] == 0 ? 1 : 0);
                    mg[c] -= W3[W3_CKING] * (1 + missing);
                }
            }
            // loza amin'ny mpanjaka (attackers an'ny mpifanandrina)
            if (atk[o] >= 2) {
                int danger = Math.min(350, units[o] * units[o] * 2);
                if (ev5) {
                    // king safety: toerana handosirana ny mpanjaka sy mpiaro akaiky
                    int ks5 = p.ksq[c], fl5 = 0;
                    for (int kd = 0; kd < 8; kd++) {
                        int sq5 = ks5 + KDIR[kd];
                        if ((sq5 & 0x88) != 0) continue;
                        int pc5 = b[sq5];
                        if (pc5 != 0 && (pc5 >> 3) == c) continue;
                        if (p.attacked(sq5, o)) continue;
                        fl5++;
                    }
                    int extra5 = fl5 <= 2 ? (3 - fl5) * W5[W5_KFLIGHT] : 0;
                    danger = Math.min(450, danger + extra5) * (100 - Math.min(3, defN[c]) * W5[W5_DEFPC]) / 100;
                }
                if (ev2 && qn[o] == 0) danger = danger * W2[W2_NOQ] / 100;
                if (ev3) {
                    // fanafihana vs fanafihana: raha mamely ihany koa ny c dia mihena ny loza
                    if (atk[c] >= 2) danger = danger * (100 - W3[W3_COUNTER]) / 100;
                    // sacrifice: ny mpanafika very material nefa mahery ny fanafihana dia mahazo onitra
                    int deficit = mat[c] - mat[o];
                    if (joro) {
                        // JORO: mahafoy sacrifice kokoa (atk >= 2, bonus x JoroSac%)
                        if (atk[o] >= 2 && deficit >= 100 && deficit <= 500) {
                            final int js = Params.JORO_SAC.val;
                            mg[o] += Math.min(W3[W3_SACMAX] * js / 100, danger * W3[W3_SAC] / 100 * js / 100);
                        }
                    } else if (atk[o] >= 3 && deficit >= 100 && deficit <= 500)
                        mg[o] += Math.min(W3[W3_SACMAX], danger * W3[W3_SAC] / 100);
                }
                if (hunt && qn[o] + atk[o] >= 3) {
                    // Gambit JORO: ny mpanafika very material (50..700 cp) dia mahazo onitra raha simba ny fiarovana
                    // (file tsy misy piyon manodidina ny mpanjaka) ary kely ny toerana handosirana ny mpanjaka (mating net)
                    int defH = mat[c] - mat[o];
                    if (defH >= 50 && defH <= 700) {
                        int holes = 0;
                        for (int ff = Math.max(0, kf - 1); ff <= Math.min(7, kf + 1); ff++) if (cnt[c][ff + 1] == 0) holes++;
                        int ks = p.ksq[c], fl = 0;
                        for (int kd = 0; kd < 8; kd++) {
                            int sq = ks + KDIR[kd];
                            if ((sq & 0x88) != 0) continue;
                            int pcs = b[sq];
                            if (pcs != 0 && (pcs >> 3) == c) continue;
                            if (p.attacked(sq, o)) continue;
                            fl++;
                        }
                        int bonus = holes * Params.JORO_HUNT_HOLE.val + (fl <= 2 ? (3 - fl) * Params.JORO_HUNT_FLIGHT.val : 0);
                        mg[o] += Math.min(Params.JORO_HUNT_MAX.val, bonus);
                    }
                }
                if (rookG) {
                    // Rook gambit JORO: very material 50..700 cp ny mpanafika fa mifanakaiky (contact) na misokatra ny line mankany amin'ny mpanjaka
                    int defR = mat[c] - mat[o];
                    if (defR >= 50 && defR <= 700) {
                        final int ks2 = p.ksq[c];
                        final int rook = Pos.R | (o << 3);
                        int rb = 0;
                        for (int sq = 0; sq < 128; sq++) {
                            if ((sq & 0x88) != 0) { sq += 7; continue; }
                            if (b[sq] != rook) continue;
                            int df = (sq & 7) - (ks2 & 7), dr = (sq >> 4) - (ks2 >> 4);
                            if (df != 0 && dr != 0) continue;
                            int step = df == 0 ? (dr > 0 ? 16 : -16) : (df > 0 ? 1 : -1);
                            boolean clear = true;
                            for (int t = ks2 + step; t != sq; t += step) if (b[t] != 0) { clear = false; break; }
                            if (!clear) continue;
                            int dist = Math.max(Math.abs(df), Math.abs(dr));
                            if (dist == 1) rb += p.attacked(sq, o) ? Params.JORO_ROOK_CONTACT.val : Params.JORO_ROOK_CONTACT.val / 2;
                            else rb += Params.JORO_ROOK_OPEN.val;
                        }
                        mg[o] += Math.min(Params.JORO_ROOK_MAX.val, rb);
                    }
                }
                mg[c] -= danger * attPct / 100 * defPct / 100;
            }
        }
        if (joro && Params.JORO_DEV.val != 0) {
            // Gambit: ny miaramila very material (50..400 cp) dia mahazo onitra raha mbola tsy nivoaka ny kapiteny mpifanandrina
            for (int x = 0; x < 2; x++) {
                int def = mat[1 - x] - mat[x];
                if (def < 50 || def > 400) continue;
                int base = (1 - x) == 0 ? 0 : 0x70;
                int und = 0;
                for (int k = 0; k < 4; k++) {
                    int sq = base + UNDEV[k];
                    int pc = b[sq];
                    if (pc != 0 && (pc >> 3) == (1 - x) && ((pc & 7) == Pos.N || (pc & 7) == Pos.B)) und++;
                }
                mg[x] += und * Params.JORO_DEV.val;
            }
        }
        int phase = Math.min(24, phaseTot);
        int mgS = mg[0] - mg[1], egS = eg[0] - eg[1];
        if (ev4 && egS != 0) {
            final int win = egS > 0 ? 0 : 1, lose = win ^ 1;
            int sf = 64;
            if (pawnsN[win] == 0) {
                int lead = (mat[win] - V_MG[Pos.P] * pawnsN[win]) - (mat[lose] - V_MG[Pos.P] * pawnsN[lose]);
                if (lead < 400) sf = Math.min(sf, W4[W4_NOPAWN]);
            }
            if (nb[0] == 1 && nb[1] == 1 && bishops[0] == 1 && bishops[1] == 1 && bishCol[0] != bishCol[1]) sf = Math.min(sf, W4[W4_OCB]);
            if (sf < 64) egS = egS * sf / 64;
        }
        if (ev5 && egS != 0 && rkN[0] == 1 && rkN[1] == 1 && nb[0] == 1 && nb[1] == 1 && Math.abs(pawnsN[0] - pawnsN[1]) <= 1)
            egS = egS * W5[W5_RSCALE] / 64;   // rook endgame: matetika draw
        int score = (mgS * phase + egS * (24 - phase)) / 24;
        // fifanakalozana: raha mitarika ny bot dia tia manafoana piece (araka ny toetra)
        score += (mat[0] - mat[1]) * tradeTf / 100 * (24 - phase) / 24;
        // mop-up: mahomby ny fandresena amin'ny endgame tsotra
        int diff = mat[0] - mat[1];
        if (phase <= 8 && Math.abs(diff) >= 300) {
            int win = diff > 0 ? 0 : 1, lose = win ^ 1;
            if (pawnsN[lose] == 0) {
                int wk = p.ksq[win], lk = p.ksq[lose];
                int cd = Math.max(Math.abs(2 * (lk & 7) - 7), Math.abs(2 * (lk >> 4) - 7));
                int dist = Math.abs((wk & 7) - (lk & 7)) + Math.abs((wk >> 4) - (lk >> 4));
                int bonus = cd * 8 + (14 - dist) * 6;
                score += win == 0 ? bonus : -bonus;
            }
        }
        score += p.side == 0 ? W[W_TEMPO] : -W[W_TEMPO];
        return p.side == 0 ? score : -score;
    }
}
