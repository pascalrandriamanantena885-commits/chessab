package mg.chess.offline.own;

/**
 * Evaluation manokana (centipawn, araka ny mpilalao ho avy). Misy toetra (personalité):
 * a=fanafihana, s=sacrifice, d=fiarovana, q=queen, t=fifanakalozana (0..100, 50 = mahazatra).
 */
public final class Eval {
    static final int[] V_MG = {0, 100, 320, 330, 500, 900, 0};
    static final int[] V_EG = {0, 115, 320, 340, 520, 950, 0};
    static final int[] PH = {0, 0, 1, 1, 2, 4, 0};
    static final int[][] PST_MG = new int[16][128];
    static final int[][] PST_EG = new int[16][128];
    static final int[] PASS_MG = {0, 0, 5, 10, 20, 35, 60, 0};
    static final int[] PASS_EG = {0, 0, 10, 20, 40, 70, 120, 0};
    static final int[] ATT_W = {0, 0, 2, 2, 3, 5, 0};

    static {
        for (int c = 0; c < 2; c++) {
            for (int sq = 0; sq < 128; sq++) {
                if ((sq & 0x88) != 0) continue;
                int f = sq & 7, r = sq >> 4;
                int rr = c == 0 ? r : 7 - r; // ambaratonga relative
                int d = Math.max(Math.abs(2 * f - 7), Math.abs(2 * r - 7));
                int cf = Math.abs(2 * f - 7);
                int pc = c << 3;
                // piyon
                int pmg = new int[]{0, -5, -5, 0, 10, 25, 40, 0}[rr];
                if (rr >= 1 && rr <= 4 && (f == 3 || f == 4)) pmg += 8 + 2 * rr;
                if (rr == 1 && (f == 0 || f == 7)) pmg -= 3;
                int peg = new int[]{0, 0, 3, 8, 18, 35, 50, 0}[rr];
                PST_MG[Pos.P | pc][sq] = pmg; PST_EG[Pos.P | pc][sq] = peg;
                PST_MG[Pos.N | pc][sq] = (7 - d) * 5 - 20; PST_EG[Pos.N | pc][sq] = (7 - d) * 4 - 16;
                PST_MG[Pos.B | pc][sq] = (7 - d) * 2 - 6;  PST_EG[Pos.B | pc][sq] = (7 - d) * 2 - 6;
                PST_MG[Pos.R | pc][sq] = (cf <= 3 ? 3 : 0); PST_EG[Pos.R | pc][sq] = 0;
                PST_MG[Pos.Q | pc][sq] = (7 - d) - 3;       PST_EG[Pos.Q | pc][sq] = (7 - d) * 2 - 6;
                PST_MG[Pos.K | pc][sq] = cf * 3 - 14 * rr;  PST_EG[Pos.K | pc][sq] = (7 - d) * 8 - 24;
            }
        }
    }

    // personalité (pct)
    final int matPct, attPct, defPct, queenAct, tradeTf;

    public Eval(int a, int s, int d, int q, int t) {
        matPct = 100 - (s - 50) / 5;                 // sacrifice: 90..110
        int ap = 70 + (a * 60) / 100;                  // 70..130
        attPct = ap * (100 + (s - 50) / 2) / 100;      // sacrifice mampitombo ny fanafihana
        defPct = 60 + (d * 80) / 100;                  // 60..140
        queenAct = q - 50 + (q - 50);                  // -100..+100
        tradeTf = (t - 50) * 15 / 50;                  // -15..+15 (%)
    }

    private final int[][] cnt = new int[2][10];
    private final int[][] hi = new int[2][10];
    private final int[][] lo = new int[2][10];
    private final int[] mg = new int[2], eg = new int[2];
    private final boolean[][] zone = new boolean[2][128];
    private final int[] units = new int[2], atk = new int[2];
    private final int[] nb = new int[2];
    private final int[] bishops = new int[2];
    private final int[] pawnsN = new int[2];
    private final int[] mat = new int[2];

    private void mark(Pos p, int c) {
        boolean[] z = zone[c];
        java.util.Arrays.fill(z, false);
        int k = p.ksq[c];
        int fwd = c == 0 ? 16 : -16;
        for (int dr = -1; dr <= 1; dr++) for (int df = -1; df <= 1; df++) {
            int s = k + dr * 16 + df;
            if ((s & 0x88) == 0) z[s] = true;
        }
        for (int df = -1; df <= 1; df++) {
            int s = k + 2 * fwd + df;
            if ((s & 0x88) == 0) z[s] = true;
        }
    }

    /** Score araka ny mpilalao ho avy. */
    public int eval(Pos p) {
        final int[] b = p.b;
        for (int c = 0; c < 2; c++) {
            java.util.Arrays.fill(cnt[c], 0);
            java.util.Arrays.fill(hi[c], -1);
            java.util.Arrays.fill(lo[c], 8);
            mg[c] = 0; eg[c] = 0; units[c] = 0; atk[c] = 0; nb[c] = 0; bishops[c] = 0; pawnsN[c] = 0; mat[c] = 0;
        }
        int phaseTot = 0, minors = 0, majors = 0;
        // pass 1: piyon + material
        for (int s = 0; s < 128; s++) {
            if ((s & 0x88) != 0) { s += 7; continue; }
            int pc = b[s];
            if (pc == 0) continue;
            int c = pc >> 3, ty = pc & 7;
            if (ty == Pos.P) {
                int f = s & 7, r = s >> 4;
                cnt[c][f + 1]++;
                if (r > hi[c][f + 1]) hi[c][f + 1] = r;
                if (r < lo[c][f + 1]) lo[c][f + 1] = r;
                pawnsN[c]++;
            } else if (ty != Pos.K) {
                phaseTot += PH[ty];
                nb[c]++;
                if (ty == Pos.N || ty == Pos.B) minors++; else majors++;
                if (ty == Pos.B) bishops[c]++;
            }
        }
        if (pawnsN[0] + pawnsN[1] == 0 && majors == 0 && minors <= 1) return 0; // draw: material tsy ampy
        mark(p, 0); mark(p, 1);
        for (int s = 0; s < 128; s++) {
            if ((s & 0x88) != 0) { s += 7; continue; }
            int pc = b[s];
            if (pc == 0) continue;
            int c = pc >> 3, ty = pc & 7, o = c ^ 1;
            int f = s & 7, r = s >> 4, rr = c == 0 ? r : 7 - r;
            mg[c] += V_MG[ty] * matPct / 100 + PST_MG[pc][s];
            eg[c] += V_EG[ty] * matPct / 100 + PST_EG[pc][s];
            mat[c] += V_MG[ty];
            switch (ty) {
                case Pos.P: {
                    if (cnt[c][f + 1] > 1) { mg[c] -= 8; eg[c] -= 12; }
                    if (cnt[c][f] == 0 && cnt[c][f + 2] == 0) { mg[c] -= 12; eg[c] -= 12; }
                    boolean passed = true;
                    for (int ff = f; ff <= f + 2 && passed; ff++) {
                        if (c == 0) { if (hi[1][ff] > r) passed = false; }
                        else { if (lo[0][ff] < r) passed = false; }
                    }
                    if (passed) { mg[c] += PASS_MG[rr]; eg[c] += PASS_EG[rr]; }
                    int sup = c == 0 ? -15 : 15;
                    int s1 = s + sup, s2 = s + (c == 0 ? -17 : 17);
                    int me = Pos.P | (c << 3);
                    if (((s1 & 0x88) == 0 && b[s1] == me) || ((s2 & 0x88) == 0 && b[s2] == me)) { mg[c] += 5; eg[c] += 5; }
                    break;
                }
                case Pos.N: {
                    int m = 0; boolean hit = false;
                    for (int d : Pos.KN) {
                        int t = s + d;
                        if ((t & 0x88) != 0) continue;
                        int tp = b[t];
                        if (tp != 0 && (tp >> 3) == c) continue;
                        m++;
                        if (zone[o][t]) hit = true;
                    }
                    mg[c] += (m - 4) * 4; eg[c] += (m - 4) * 4;
                    if (hit) { units[c] += ATT_W[ty]; atk[c]++; }
                    break;
                }
                case Pos.B: case Pos.R: case Pos.Q: {
                    int m = 0; boolean hit = false;
                    for (int di = 0; di < 8; di++) {
                        int d;
                        if (di < 4) { if (ty == Pos.B) continue; d = Pos.RD[di]; }
                        else { if (ty == Pos.R) continue; d = Pos.BD[di - 4]; }
                        int t = s + d;
                        while ((t & 0x88) == 0) {
                            int tp = b[t];
                            if (tp != 0 && (tp >> 3) == c) break;
                            m++;
                            if (zone[o][t]) hit = true;
                            if (tp != 0) break;
                            t += d;
                        }
                    }
                    if (ty == Pos.B) { mg[c] += (m - 6) * 3; eg[c] += (m - 6) * 4; }
                    else if (ty == Pos.R) {
                        mg[c] += (m - 7); eg[c] += (m - 7) * 3;
                        if (cnt[c][f + 1] == 0) {
                            if (cnt[o][f + 1] == 0) { mg[c] += 20; eg[c] += 10; } else { mg[c] += 10; eg[c] += 8; }
                        }
                        if (rr == 6 && (p.ksq[o] >> 4 == (c == 0 ? 7 : 0))) { mg[c] += 15; eg[c] += 20; }
                    } else {
                        mg[c] += (m - 14) * (100 + queenAct) / 100; eg[c] += (m - 14) * 2;
                        if (rr > 0 && queenAct > 0) mg[c] += queenAct * 12 / 100;
                    }
                    if (hit) { units[c] += ATT_W[ty]; atk[c]++; }
                    break;
                }
                default: break;
            }
        }
        for (int c = 0; c < 2; c++) {
            if (bishops[c] >= 2) { mg[c] += 30; eg[c] += 45; }
            int o = c ^ 1;
            // fiarovana mpanjaka (pawn shield) - mg ihany
            int k = p.ksq[c];
            int kf = k & 7, kr = k >> 4, krr = c == 0 ? kr : 7 - kr;
            if (krr <= 1) {
                int shield = 0;
                int fwd = c == 0 ? 16 : -16;
                int me = Pos.P | (c << 3);
                for (int ff = Math.max(0, kf - 1); ff <= Math.min(7, kf + 1); ff++) {
                    int s1 = (kr * 16 + ff) + fwd, s2 = s1 + fwd;
                    if ((s1 & 0x88) == 0 && b[s1] == me) shield += 10;
                    else if ((s2 & 0x88) == 0 && b[s2] == me) shield += 6;
                    else if (cnt[c][ff + 1] == 0) shield -= 15;
                    else shield -= 5;
                }
                mg[c] += shield * defPct / 100;
            }
            // loza amin'ny mpanjaka (attackers an'ny mpifanandrina)
            if (atk[o] >= 2) {
                int danger = Math.min(350, units[o] * units[o] * 2);
                mg[c] -= danger * attPct / 100 * defPct / 100;
            }
        }
        int phase = Math.min(24, phaseTot);
        int mgS = mg[0] - mg[1], egS = eg[0] - eg[1];
        int score = (mgS * phase + egS * (24 - phase)) / 24;
        // fifanakalozana: raha mitarika ny bot dia tia manafoana piece (araka ny toetra)
        score += (mat[0] - mat[1]) * tradeTf / 100 * (24 - phase) / 24;
        // mop-up: mahomby ny fandresena amin'ny endgame tsotra
        int diff = mat[0] - mat[1];
        if (phase <= 8 && Math.abs(diff) >= 300) {
            int win = diff > 0 ? 0 : 1, lose = win ^ 1;
            if (pawnsN[lose] == 0) {
                int wk = p.ksq[win], lk = p.ksq[lose];
                int cd = Math.max(Math.abs(2 * (lk & 7) - 7), Math.abs(2 * (lk >> 4) - 7));
                int dist = Math.abs((wk & 7) - (lk & 7)) + Math.abs((wk >> 4) - (lk >> 4));
                int bonus = cd * 8 + (14 - dist) * 6;
                score += win == 0 ? bonus : -bonus;
            }
        }
        score += p.side == 0 ? 10 : -10;
        return p.side == 0 ? score : -score;
    }
}
