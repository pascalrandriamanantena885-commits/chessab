package mg.chess.offline

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs

/**
 * Bot = Elo tena izy. Ny Stockfish 19 no mampihatra ny fetra (UCI_LimitStrength + UCI_Elo, 1320-3190).
 * Ambanin'ny 1320 dia ampiana fikarohana voafetra + safidy hetsika tsy tonga lafatra (jereo Engine.kt).
 * movetimeMs = fotoana fisainana ambony indrindra isaky ny hetsika.
 */
data class Bot(
    val id: String, val name: String, val elo: Int, val bio: String,
    val movetimeMs: Int, val color: Long,
    val custom: Boolean = false, val rev: Long = 0L,
    /** id ao amin'ny OPENINGS: repertoire (Italian, French, King's Gambit...). */
    val openings: List<String> = emptyList(),
    /** Andalana manokana avy amin'ny lalao ("W|e2e4 e7e5 ..." na "B|..."). */
    val lines: List<String> = emptyList(),
    /** Fomba filalaovana (sacrifice, defense, queen aloha...). */
    val style: Style = Style()
)

const val SF_MIN_ELO = 1320
const val SF_MAX_ELO = 3190
/** Elo ambony indrindra azon'ny bot tratrarina aorian'ny fifaninanana (> 3200 = Stockfish feno + depth lalina kokoa). */
const val ELO_CEIL = 3600

/** Motera manokana (Java, ao amin'ny package own): ampiasaina ho an'ny bot hatramin'ny OWN_MAX_ELO. false = Stockfish foana. */
const val OWN_ENGINE = true
const val OWN_MAX_ELO = 2200

/** Fanitsiana: Elo ampiasain'ny motera = Elo bot + CALIB. 0 = mivantana araka ny kajy Stockfish (CCRL). */
const val ELO_CALIB = 0

fun movetimeForElo(elo: Int): Int = when {
    // > 3190: Stockfish hery feno; arakaraky ny Elo no lalina kokoa ny fikarohana (fotoana bebe kokoa => depth ambony kokoa)
    elo > SF_MAX_ELO -> (3000 + (elo - 3200).coerceAtLeast(0) * 6).coerceIn(3000, 7500)
    else -> (250 + elo / 2).coerceIn(300, 1500)
}

// Elo dia tena Elo ampiasain'ny Stockfish 19 (UCI_Elo) ary amin'ny fikarohana voafetra ho an'ny < 1320.
val BOTS = listOf(
    Bot("ravao", "Ravao", 400, "Vao mianatra milalao. Mora diso.", movetimeForElo(400), 0xFFE57373),
    Bot("rakoto", "Rakoto", 700, "Mazoto fa tsy mijery lavitra. Mamoaka queen aloha.", movetimeForElo(700), 0xFFFFB74D,
        style = Style(aggression = 70, queen = 95)),
    Bot("soa", "Soa", 1000, "Milalao tsara fa mety hadino ny fandrika.", movetimeForElo(1000), 0xFFFFD54F,
        openings = listOf("italian", "e5")),
    Bot("tojo", "Tojo", 1300, "Mahay tactic fohy ary tia London.", movetimeForElo(1300), 0xFF81C784,
        openings = listOf("london", "caro"), style = Style(defense = 70)),
    Bot("mialy", "Mialy", 1500, "Mpiaro mafy: French sy fiarovana tsara.", movetimeForElo(1500), 0xFFF06292,
        openings = listOf("french", "london", "caro"), style = Style(aggression = 25, defense = 95, trades = 70)),
    Bot("fara", "Fara", 1600, "Mpilalao club matanjaka.", movetimeForElo(1600), 0xFF4DB6AC,
        openings = listOf("qgambit", "slav", "qgd"), style = Style(trades = 65)),
    Bot("zandry", "Zandry", 2000, "Mpanafika: Scandinavian sy Sicilian.", movetimeForElo(2000), 0xFFA1887F,
        openings = listOf("english", "scandi", "najdorf", "dragon"), style = Style(aggression = 85)),
    Bot("hery", "Hery", 1900, "Mahay mijery lavitra ary tsy mora diso.", movetimeForElo(1900), 0xFF64B5F6,
        openings = listOf("ruy", "wsicilian", "qgambit", "nimzo", "kid")),
    Bot("andry", "Andry", 2300, "Mpanao sacrifice: tia gambit sy fanafihana.", movetimeForElo(2300), 0xFF9575CD,
        openings = listOf("kingsgambit", "evans", "morra", "danish", "dragon", "budapest", "albin"),
        style = Style(aggression = 90, sacrifice = 95, defense = 20, trades = 25)),
    Bot("mamy", "Mamy", 2450, "Master: tsy mivadika, mifanakalozana tsara.", movetimeForElo(2450), 0xFFBA68C8,
        openings = listOf("ruy", "scotch", "caro", "qgd"), style = Style(trades = 70, defense = 65)),
    Bot("rado", "Rado", 2650, "Grandmaster: fanafihana mivoatra sy fanomanana lalina.", movetimeForElo(2650), 0xFFEF5350,
        openings = listOf("qgambit", "najdorf", "nimzo", "english"), style = Style(aggression = 65, sacrifice = 60)),
    Bot("tiana", "Tiana", 2900, "Grandmaster ambony: saika tsy diso mihitsy.", movetimeForElo(2900), 0xFFFF7043,
        openings = listOf("ruy", "wsicilian", "grunfeld", "petroff")),
    Bot("max", "Stockfish", 3200, "Hery feno an'ny Stockfish 19.", movetimeForElo(3200), 0xFF455A64),
)

private val PALETTE = listOf(
    0xFFE57373, 0xFFFFB74D, 0xFFFFD54F, 0xFF81C784, 0xFF4DB6AC,
    0xFF64B5F6, 0xFF9575CD, 0xFFF06292, 0xFFA1887F, 0xFF90A4AE
)

fun Bot.toJson(): JSONObject {
    val o = JSONObject()
    o.put("id", id); o.put("name", name); o.put("elo", elo); o.put("bio", bio)
    o.put("mt", movetimeMs)
    o.put("color", color); o.put("custom", custom); o.put("rev", rev)
    o.put("openings", JSONArray(openings))
    o.put("lines", JSONArray(lines))
    val st = JSONObject()
    st.put("a", style.aggression); st.put("s", style.sacrifice); st.put("d", style.defense)
    st.put("q", style.queen); st.put("t", style.trades)
    o.put("style", st)
    return o
}

private fun strList(a: JSONArray?): List<String> = if (a == null) emptyList() else List(a.length()) { a.getString(it) }

fun botFromJson(o: JSONObject): Bot {
    val st = o.optJSONObject("style")
    val style = if (st == null) Style() else Style(
        st.optInt("a", 50), st.optInt("s", 50), st.optInt("d", 50), st.optInt("q", 50), st.optInt("t", 50)
    )
    return Bot(
        o.getString("id"), o.getString("name"), o.getInt("elo"), o.optString("bio", ""),
        movetimeForElo(o.getInt("elo")), o.getLong("color"),
        o.optBoolean("custom", false), o.optLong("rev", 0L),
        strList(o.optJSONArray("openings")), strList(o.optJSONArray("lines")), style
    )
}

/** Sary boribory 256x256 avy amin'ny Uri (kare afovoany). */
fun decodeAvatar(ctx: Context, uri: Uri): Bitmap? {
    try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 512 && bounds.outHeight / (sample * 2) >= 512) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return null
        val side = minOf(bmp.width, bmp.height)
        val sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
        return Bitmap.createScaledBitmap(sq, 256, 256, true)
    } catch (e: Exception) {
        return null
    }
}

/** Sary boribory 256x256 avy amin'ny byte (rakitra .kbot); null raha simba na lehibe loatra. */
fun avatarFromBytes(data: ByteArray): Bitmap? {
    try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0 || bounds.outWidth > 8000 || bounds.outHeight > 8000) return null
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 512 && bounds.outHeight / (sample * 2) >= 512) sample *= 2
        val bmp = BitmapFactory.decodeByteArray(data, 0, data.size, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: return null
        val side = minOf(bmp.width, bmp.height)
        val sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
        return Bitmap.createScaledBitmap(sq, 256, 256, true)
    } catch (e: Exception) {
        return null
    }
}

/** Lisitry ny bot: default (azo afenina) + ireo nataon'ny mpampiasa (tehirizina ao amin'ny filesDir). */
object BotRegistry {
    var custom by mutableStateOf<List<Bot>>(emptyList())
        private set
    var hidden by mutableStateOf<Set<String>>(emptySet())
        private set
    private var loaded = false

    val visible: List<Bot>
        get() = (BOTS.filter { it.id !in hidden } + custom).map { BotProgress.apply(it) }.sortedBy { it.elo }

    fun find(id: String?): Bot? = if (id == null) null else (BOTS + custom).firstOrNull { it.id == id }?.let { BotProgress.apply(it) }

    /** Averina vakiana avy ao amin'ny findainao (aorian'ny restore). */
    fun reload(ctx: Context) {
        loaded = false
        custom = emptyList()
        load(ctx)
        BotProgress.load(ctx)
    }

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        BotProgress.load(ctx)
        try {
            val f = File(ctx.filesDir, "custom_bots.json")
            if (f.exists()) {
                val a = JSONArray(f.readText())
                custom = List(a.length()) { botFromJson(a.getJSONObject(it)) }
            }
        } catch (e: Exception) { /* tsy mandika */ }
        val set = ctx.getSharedPreferences("chess_prefs", Context.MODE_PRIVATE).getStringSet("hidden", null)
        hidden = set?.toSet() ?: emptySet()
    }

    private fun persist(ctx: Context) {
        try {
            val a = JSONArray()
            for (b in custom) a.put(b.toJson())
            File(ctx.filesDir, "custom_bots.json").writeText(a.toString())
        } catch (e: Exception) { /* tsy mandika */ }
    }

    private fun persistHidden(ctx: Context) {
        ctx.getSharedPreferences("chess_prefs", Context.MODE_PRIVATE)
            .edit().putStringSet("hidden", hidden.toSet()).apply()
    }

    fun save(
        ctx: Context, existing: Bot?, name: String, elo: Int, avatar: Bitmap?,
        openings: List<String> = existing?.openings ?: emptyList(),
        lines: List<String> = existing?.lines ?: emptyList(),
        style: Style = existing?.style ?: Style(),
        color: Long? = null,
        bio: String? = null
    ) {
        val e = elo.coerceIn(100, 3200)
        // id tokana (import maromaro mandeha mifanesy dia tsy tokony hifanindry id)
        var newId = "c" + System.currentTimeMillis()
        while (custom.any { it.id == newId } || BOTS.any { it.id == newId }) newId += "x"
        val id = existing?.id ?: newId
        val clean = name.trim().ifEmpty { "Bot" }
        val tmp = Bot(
            id, clean, e, "", movetimeForElo(e),
            existing?.color ?: color ?: PALETTE[abs(clean.hashCode()) % PALETTE.size],
            true, System.currentTimeMillis(), openings, lines, style
        )
        val spec = tmp.specialty()
        val b = tmp.copy(bio = bio?.trim()?.take(200)?.takeIf { it.isNotEmpty() } ?: if (spec.isEmpty()) "Bot nataonao (Elo $e)" else spec)
        if (avatar != null) {
            try {
                val dir = File(ctx.filesDir, "avatars").apply { mkdirs() }
                File(dir, "$id.png").outputStream().use { avatar.compress(Bitmap.CompressFormat.PNG, 100, it) }
            } catch (ex: Exception) { /* tsy mandika */ }
        }
        custom = if (existing != null) custom.map { if (it.id == id) b else it } else custom + b
        persist(ctx)
    }

    fun delete(ctx: Context, b: Bot) {
        if (b.custom) {
            custom = custom.filter { it.id != b.id }
            try { File(File(ctx.filesDir, "avatars"), "${b.id}.png").delete() } catch (_: Exception) {}
            persist(ctx)
        } else {
            hidden = hidden + b.id
            persistHidden(ctx)
        }
    }

    /** Bot default afenina (azo averina). */
    fun hiddenBots(): List<Bot> = BOTS.filter { it.id in hidden }

    fun restore(ctx: Context, id: String) {
        hidden = hidden - id
        persistHidden(ctx)
    }

    fun restoreDefaults(ctx: Context) {
        hidden = emptySet()
        persistHidden(ctx)
    }
}

/** Ny Stockfish MAX (tsy miova Elo); ny bot hafa dia mety hihoatra ny 3200 aorian'ny fifaninanana. */
val Bot.isMax: Boolean get() = id == "max"
