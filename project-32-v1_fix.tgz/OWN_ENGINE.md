# Motera manokana (tsy miankina amin'ny Stockfish)

Toerana: `app/src/main/java/mg/chess/offline/own/` (Java madio, tsy mampiasa Android na chesslib).

- `Pos.java`   : board 0x88, hetsika marina, make/unmake, zobrist, repetition (perft voamarina).
- `Eval.java`  : evaluation (material, PST, piyon, mobility, fiarovana mpanjaka, fanafihana) + TOETRA: a/s/d/q/t.
- `Search.java`: iterative deepening, PVS, TT, null move, LMR, futility, quiescence; `thinkWeak` ho an'ny Elo ambany.
- `OwnBot.java`: API ho an'ny app + `profile(elo)` = {depth, tabataba cp}.

Fampiasana: `Engine.bestMove` -> opening book (Personality) -> OwnBot raha `OWN_ENGINE && elo <= OWN_MAX_ELO` (Bots.kt).
Ny Stockfish dia mijanona ho an'ny Review / Why / analyze sy ny bot > OWN_MAX_ELO.
Hanajanona: `const val OWN_ENGINE = false` ao amin'ny Bots.kt.

Fanamarihana: ny Elo ao `OwnBot.profile` dia vonjimaika. Tsy maintsy tombanana amin'ny Stockfish `UCI_Elo`
(lalao 200+) ary ovaina ny depth/tabataba mba hitovy ny Elo ao amin'ny app.
