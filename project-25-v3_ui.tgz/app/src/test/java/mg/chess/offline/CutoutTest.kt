package mg.chess.offline

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CutoutTest {
    private fun rgb(r: Int, g: Int, b: Int) = (0xFF shl 24) or (r shl 16) or (g shl 8) or b

    /** Background gradient + loha boribory + vatana mikasika ny ambany. */
    private fun portrait(w: Int, h: Int): IntArray {
        val px = IntArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            var c = rgb(200 - y * 3 / 10, 220 - y / 5, 235)
            val dx = x - w / 2; val dy = y - 70
            if (dx * dx + dy * dy < 30 * 30) c = rgb(230, 180, 150)
            if (y >= 110 && kotlin.math.abs(x - w / 2) < 55) c = rgb(40, 60, 160)
            px[y * w + x] = c
        }
        return px
    }

    @Test fun removesBackgroundKeepsSubject() {
        val r = BgRemover.removeBackground(portrait(200, 200), 200, 200)
        assertNotNull(r)
        r!!
        // Tapahina: lehibe kokoa noho ny lohahevitra, kely kokoa noho ny sary manontolo
        assertTrue(r.w in 100..140)
        assertTrue(r.h in 120..160)
        // Ny zoro (background) dia transparent, ny afovoany tsy transparent
        assertEquals(0, r.px[0] ushr 24)
        assertEquals(255, r.px[(r.h - 5) * r.w + r.w / 2] ushr 24)
    }

    @Test fun uniformImageIsNotReliable() {
        val px = IntArray(100 * 100) { rgb(10, 200, 10) }
        assertNull(BgRemover.removeBackground(px, 100, 100))
    }

    @Test fun alreadyTransparentIsOnlyCropped() {
        val w = 100; val h = 100
        val px = IntArray(w * h)
        for (y in 30 until 90) for (x in 20 until 80) px[y * w + x] = rgb(200, 0, 0)
        val r = BgRemover.removeBackground(px, w, h)
        assertNotNull(r)
        assertEquals(60, r!!.w)
        assertEquals(60, r.h)
    }
}
