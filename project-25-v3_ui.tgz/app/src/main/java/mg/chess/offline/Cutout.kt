package mg.chess.offline

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min

/** Sary vita (pixel ARGB) aorian'ny fanesorana background sy fanapahana manodidina ny lohahevitra. */
class CutoutPixels(val px: IntArray, val w: Int, val h: Int)

/**
 * Fanesorana background AUTOMATIKA, tsy mila internet na maodely IA (mandeha offline, haingana: ms vitsy amin'ny 384px).
 *  1) Alaina ny loko background avy amin'ny so-drafitra (zoro).
 *  2) Flood-fill avy amin'ny sisiny: ny pixel mitovy loko (na miova moramora = gradient) dia background.
 *  3) Tazonina ny faritra lehibe indrindra (lohahevitra); esorina ny pasika kely.
 *  4) Erosion 1px + blur 3x3 => sisiny malefaka (tsy misy halo).
 *  5) Tapahina manodidina ny lohahevitra (mba hipetraka eo ambany ny sary).
 * Raha tsy azo antoka (background misavoritaka, lohahevitra mitovy loko amin'ny background...) dia mamerina null
 * ary ny UI mampiasa ny sary tondraka (tile boribory) toy ny teo aloha.
 */
object BgRemover {
    const val MAX_SIDE = 384
    private const val TIGHT2 = 28 * 28        // tena akaiky ny loko background
    private const val LOOSE2 = 60 * 60        // fetra ambony ho an'ny gradient
    private const val STEP2 = 14 * 14         // fiovana farafahakeliny eo anelanelan'ny pixel mifanakaiky
    private const val CORNER_LINK2 = 70 * 70  // zoro ambany mifandray amin'ny zoro ambony (gradient)

    private fun d2(a: Int, b: Int): Int {
        val dr = ((a shr 16) and 255) - ((b shr 16) and 255)
        val dg = ((a shr 8) and 255) - ((b shr 8) and 255)
        val db = (a and 255) - (b and 255)
        return dr * dr + dg * dg + db * db
    }

    private fun patch(px: IntArray, w: Int, x0: Int, y0: Int, s: Int): Int {
        var r = 0; var g = 0; var b = 0; var c = 0
        for (y in y0 until y0 + s) for (x in x0 until x0 + s) {
            val p = px[y * w + x]
            r += (p shr 16) and 255; g += (p shr 8) and 255; b += p and 255; c++
        }
        return (0xFF shl 24) or ((r / c) shl 16) or ((g / c) shl 8) or (b / c)
    }

    private fun finish(px: IntArray, w: Int, h: Int): CutoutPixels? {
        var x0 = w; var y0 = h; var x1 = -1; var y1 = -1
        for (y in 0 until h) for (x in 0 until w) {
            if ((px[y * w + x] ushr 24) > 24) {
                if (x < x0) x0 = x
                if (x > x1) x1 = x
                if (y < y0) y0 = y
                if (y > y1) y1 = y
            }
        }
        if (x1 < 0) return null
        val cw = x1 - x0 + 1
        val ch = y1 - y0 + 1
        if (cw < w / 5 || ch < h / 5) return null
        val o = IntArray(cw * ch)
        for (y in 0 until ch) System.arraycopy(px, (y0 + y) * w + x0, o, y * cw, cw)
        return CutoutPixels(o, cw, ch)
    }

    fun removeBackground(src: IntArray, w: Int, h: Int): CutoutPixels? {
        if (w < 16 || h < 16 || src.size < w * h) return null
        val n = w * h

        // Efa transparent ny sisiny? => tapahina fotsiny
        var border = 0; var clear = 0
        for (x in 0 until w) {
            border += 2
            if ((src[x] ushr 24) < 128) clear++
            if ((src[(h - 1) * w + x] ushr 24) < 128) clear++
        }
        for (y in 1 until h - 1) {
            border += 2
            if ((src[y * w] ushr 24) < 128) clear++
            if ((src[y * w + w - 1] ushr 24) < 128) clear++
        }
        if (clear * 2 > border) return finish(src.copyOf(), w, h)

        // 1) Loko background (zoro). Ny zoro ambony foana; ny zoro ambany raha mitovy amin'ny ambony (tsy akanjo/lohahevitra)
        val s = max(3, min(w, h) / 40)
        val tl = patch(src, w, 0, 0, s)
        val tr = patch(src, w, w - s, 0, s)
        val refs = ArrayList<Int>(4)
        refs.add(tl); refs.add(tr)
        for (c in intArrayOf(patch(src, w, 0, h - s, s), patch(src, w, w - s, h - s, s))) {
            if (d2(c, tl) <= CORNER_LINK2 || d2(c, tr) <= CORNER_LINK2) refs.add(c)
        }

        // 2) Flood-fill avy amin'ny sisiny
        val bg = BooleanArray(n)
        val queue = IntArray(n)
        var qh = 0
        var qt = 0
        fun near(p: Int, lim: Int): Boolean {
            for (r in refs) if (d2(p, r) <= lim) return true
            return false
        }
        fun seed(i: Int) {
            if (bg[i]) return
            val p = src[i]
            if ((p ushr 24) < 128 || near(p, LOOSE2)) { bg[i] = true; queue[qt++] = i }
        }
        fun grow(j: Int, from: Int) {
            if (bg[j]) return
            val q = src[j]
            if ((q ushr 24) < 128 || near(q, TIGHT2) || (d2(q, from) <= STEP2 && near(q, LOOSE2))) {
                bg[j] = true; queue[qt++] = j
            }
        }
        for (x in 0 until w) { seed(x); seed((h - 1) * w + x) }
        for (y in 0 until h) { seed(y * w); seed(y * w + w - 1) }
        while (qh < qt) {
            val i = queue[qh++]
            val x = i % w
            val y = i / w
            val p = src[i]
            if (x > 0) grow(i - 1, p)
            if (x < w - 1) grow(i + 1, p)
            if (y > 0) grow(i - w, p)
            if (y < h - 1) grow(i + w, p)
        }
        val frac = qt.toFloat() / n
        if (frac < 0.10f || frac > 0.88f) return null          // tsy azo antoka
        if (bg[(h / 2) * w + w / 2]) return null               // ny afovoany tsy tokony ho background

        // 3) Tazonina ny faritra lehibe (esorina ny pasika kely)
        val lab = IntArray(n)
        val sizes = ArrayList<Int>()
        sizes.add(0)
        for (i in 0 until n) {
            if (bg[i] || lab[i] != 0) continue
            val id = sizes.size
            qh = 0; qt = 0
            queue[qt++] = i; lab[i] = id
            while (qh < qt) {
                val c = queue[qh++]
                val x = c % w
                val y = c / w
                if (x > 0 && !bg[c - 1] && lab[c - 1] == 0) { lab[c - 1] = id; queue[qt++] = c - 1 }
                if (x < w - 1 && !bg[c + 1] && lab[c + 1] == 0) { lab[c + 1] = id; queue[qt++] = c + 1 }
                if (y > 0 && !bg[c - w] && lab[c - w] == 0) { lab[c - w] = id; queue[qt++] = c - w }
                if (y < h - 1 && !bg[c + w] && lab[c + w] == 0) { lab[c + w] = id; queue[qt++] = c + w }
            }
            sizes.add(qt)
        }
        var maxSize = 0
        for (sz in sizes) if (sz > maxSize) maxSize = sz
        val minKeep = max(30, maxSize / 20)
        val keep = BooleanArray(n)
        for (i in 0 until n) {
            val l = lab[i]
            if (l != 0 && sizes[l] >= minKeep) keep[i] = true
        }

        // 4) Erosion 1px (tsy mikasika ny sisin'ny sary) + blur 3x3 => sisiny malefaka
        val er = BooleanArray(n)
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            if (!keep[i]) continue
            er[i] = (x == 0 || keep[i - 1]) && (x == w - 1 || keep[i + 1]) &&
                (y == 0 || keep[i - w]) && (y == h - 1 || keep[i + w])
        }
        val out = IntArray(n)
        for (y in 0 until h) for (x in 0 until w) {
            var sum = 0
            for (dy in -1..1) {
                val yy = (y + dy).coerceIn(0, h - 1)
                for (dx in -1..1) {
                    val xx = (x + dx).coerceIn(0, w - 1)
                    if (er[yy * w + xx]) sum++
                }
            }
            val i = y * w + x
            val a = ((sum * 255 + 4) / 9) * (src[i] ushr 24) / 255
            out[i] = if (a <= 0) 0 else (a shl 24) or (src[i] and 0xFFFFFF)
        }

        // 5) Tapaho manodidina ny lohahevitra
        return finish(out, w, h)
    }

    /** Bitmap -> Bitmap transparent (null raha tsy azo antoka). Antsoina ao amin'ny thread Default. */
    fun cutout(src: Bitmap): Bitmap? {
        val longSide = max(src.width, src.height)
        val scaled = if (longSide > MAX_SIDE) {
            val k = MAX_SIDE.toFloat() / longSide
            Bitmap.createScaledBitmap(src, max(1, (src.width * k).toInt()), max(1, (src.height * k).toInt()), true)
        } else src
        val w = scaled.width
        val h = scaled.height
        val px = IntArray(w * h)
        scaled.getPixels(px, 0, w, 0, 0, w, h)
        val r = removeBackground(px, w, h) ?: return null
        val out = Bitmap.createBitmap(r.w, r.h, Bitmap.Config.ARGB_8888)
        out.setPixels(r.px, 0, r.w, 0, 0, r.w, r.h)
        return out
    }
}

/** Cache (LRU 24) ny sary bot efa nesorina ny background; manokana isaky ny (id, rev). null = tsy nahomby (ampiasaina ny tile). */
object Cutout {
    private val cache = object : LinkedHashMap<String, ImageBitmap?>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, ImageBitmap?>?): Boolean = size > 24
    }

    private fun key(b: Bot) = "${b.id}:${b.rev}"

    /** Valiny avy hatrany (tsy manakana). null raha mbola tsy voakajy na tsy nahomby. */
    fun peek(b: Bot): ImageBitmap? = synchronized(cache) { cache[key(b)] }

    /** Kajy aloha (thread Default) mba hiseho avy hatrany ny sary rehefa manomboka ny animation. */
    suspend fun load(ctx: Context, b: Bot) {
        val k = key(b)
        if (synchronized(cache) { cache.containsKey(k) }) return
        val res: ImageBitmap? = withContext(Dispatchers.Default) {
            try {
                Sprites.avatar(ctx, b)?.asAndroidBitmap()?.let { BgRemover.cutout(it) }?.asImageBitmap()
            } catch (e: Throwable) { null }
        }
        synchronized(cache) { cache[k] = res }
    }
}
