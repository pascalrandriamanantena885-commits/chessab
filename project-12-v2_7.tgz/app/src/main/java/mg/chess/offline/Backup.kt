package mg.chess.offline

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Backup / restore: rakitra .zip iray misy ny Elo-nao + statistika (stats.json), ny bot nataonao (+ sary),
 * ny profile mpilalao, ny lalao voatahiry, ny fifaninanana ary ny settings.
 * Azo averina ao amin'ny findaina vaovao.
 */
object BackupManager {
    private const val VERSION = 1
    private const val PREFS = "chess_prefs"

    private val DIRS = listOf("games", "tournaments", "avatars")
    private val FILES = listOf("stats.json", "custom_bots.json", "player.png")

    fun suggestedName(): String =
        "kajy-backup-" + SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date()) + ".zip"

    private fun prefsToJson(ctx: Context): JSONObject {
        val o = JSONObject()
        for ((k, v) in ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).all) {
            val e = JSONObject()
            when (v) {
                is Boolean -> { e.put("t", "b"); e.put("v", v) }
                is Int -> { e.put("t", "i"); e.put("v", v) }
                is Long -> { e.put("t", "l"); e.put("v", v) }
                is Float -> { e.put("t", "f"); e.put("v", v.toDouble()) }
                is String -> { e.put("t", "s"); e.put("v", v) }
                is Set<*> -> { e.put("t", "ss"); e.put("v", JSONArray(v.map { it.toString() })) }
                else -> continue
            }
            o.put(k, e)
        }
        return o
    }

    private fun prefsFromJson(ctx: Context, o: JSONObject) {
        val ed = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        ed.clear()
        for (k in o.keys()) {
            val e = o.getJSONObject(k)
            when (e.getString("t")) {
                "b" -> ed.putBoolean(k, e.getBoolean("v"))
                "i" -> ed.putInt(k, e.getInt("v"))
                "l" -> ed.putLong(k, e.getLong("v"))
                "f" -> ed.putFloat(k, e.getDouble("v").toFloat())
                "s" -> ed.putString(k, e.getString("v"))
                "ss" -> {
                    val a = e.getJSONArray("v")
                    ed.putStringSet(k, HashSet(List(a.length()) { a.getString(it) }))
                }
            }
        }
        ed.commit()
    }

    private fun ZipOutputStream.addBytes(name: String, bytes: ByteArray) {
        putNextEntry(ZipEntry(name)); write(bytes); closeEntry()
    }

    private fun ZipOutputStream.addFile(name: String, f: File) {
        if (f.isFile) addBytes(name, f.readBytes())
    }

    /** Soratana ao amin'ny [uri] (misafidy rakitra ny mpampiasa). Mamerina hafatra ho an'ny mpampiasa. */
    fun export(ctx: Context, uri: Uri): String = try {
        var n = 0
        ctx.contentResolver.openOutputStream(uri)!!.use { os ->
            ZipOutputStream(os.buffered()).use { z ->
                val meta = JSONObject().put("app", "KAJY").put("version", VERSION).put("time", System.currentTimeMillis())
                z.addBytes("meta.json", meta.toString().toByteArray())
                z.addBytes("prefs.json", prefsToJson(ctx).toString().toByteArray())
                for (f in FILES) z.addFile(f, File(ctx.filesDir, f))
                for (d in DIRS) {
                    File(ctx.filesDir, d).listFiles()?.forEach { f -> if (f.isFile && !f.name.endsWith(".tmp")) { z.addFile("$d/${f.name}", f); n++ } }
                }
            }
        }
        "Voatahiry ny backup ($n rakitra + stats + bot + settings)."
    } catch (e: Exception) {
        "Tsy lasa ny backup: " + (e.message ?: "hadisoana")
    }

    private fun safeName(n: String): Boolean = n.isNotEmpty() && !n.contains("..") && !n.contains('/') && !n.contains('\\')

    /**
     * Averina avy amin'ny [uri]. Alaina any amin'ny toerana vonjimaika aloha, ary tsy misy fahavoazana
     * raha tsy mety ny rakitra. Mamerina null raha tafita, na hafatra diso.
     */
    fun restore(ctx: Context, uri: Uri): String? {
        val tmp = File(ctx.cacheDir, "restore").apply { deleteRecursively(); mkdirs() }
        try {
            var hasMeta = false
            ctx.contentResolver.openInputStream(uri)!!.use { ins ->
                ZipInputStream(ins.buffered()).use { z ->
                    while (true) {
                        val e = z.nextEntry ?: break
                        if (e.isDirectory) continue
                        val parts = e.name.split("/")
                        val ok = when (parts.size) {
                            1 -> parts[0] == "meta.json" || parts[0] == "prefs.json" || parts[0] in FILES
                            2 -> parts[0] in DIRS && safeName(parts[1])
                            else -> false
                        }
                        if (!ok) continue
                        val out = File(tmp, e.name)
                        out.parentFile?.mkdirs()
                        out.outputStream().use { z.copyTo(it) }
                        if (e.name == "meta.json") hasMeta = true
                    }
                }
            }
            if (!hasMeta) return "Tsy backup KAJY io rakitra io."
            val meta = JSONObject(File(tmp, "meta.json").readText())
            if (meta.optString("app") != "KAJY") return "Tsy backup KAJY io rakitra io."
            // Hamarino aloha fa mety ny JSON
            File(tmp, "stats.json").takeIf { it.exists() }?.let { JSONObject(it.readText()) }
            File(tmp, "custom_bots.json").takeIf { it.exists() }?.let { JSONArray(it.readText()) }
            val prefsJson = File(tmp, "prefs.json").takeIf { it.exists() }?.let { JSONObject(it.readText()) }

            // Ampiharo
            for (f in FILES) {
                val dst = File(ctx.filesDir, f)
                val src = File(tmp, f)
                if (src.exists()) src.copyTo(dst, overwrite = true) else dst.delete()
            }
            for (d in DIRS) {
                val dst = File(ctx.filesDir, d)
                dst.deleteRecursively(); dst.mkdirs()
                File(tmp, d).listFiles()?.forEach { it.copyTo(File(dst, it.name), overwrite = true) }
            }
            if (prefsJson != null) prefsFromJson(ctx, prefsJson)
            return null
        } catch (e: Exception) {
            return "Tsy mety ny backup: " + (e.message ?: "hadisoana")
        } finally {
            tmp.deleteRecursively()
        }
    }
}

/** Card ao amin'ny Settings: Backup / Restore. */
@Composable
fun BackupCard(vm: ChessViewModel) {
    val ctx = LocalContext.current
    var msg by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf<Uri?>(null) }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri: Uri? ->
        if (uri != null) msg = BackupManager.export(ctx, uri)
    }
    val opener = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) pending = uri
    }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Backup / Restore", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(
                "Tehirizo ao anaty rakitra .zip ny Elo-nao, ny statistika, ny bot nataonao, ny lalao, ny fifaninanana ary ny settings, mba tsy ho very rehefa manova findaina.",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ saver.launch(BackupManager.suggestedName()) }) { Text("Backup") }
                OutlinedButton({ opener.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }) { Text("Restore") }
            }
            if (msg.isNotEmpty()) Text(msg, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
        }
    }
    val u = pending
    if (u != null) {
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("Haverina ny backup?") },
            text = { Text("Hosoloina ny Elo, statistika, bot, lalao, fifaninanana ary settings ankehitriny amin'ny ao amin'ny backup.") },
            confirmButton = {
                Button({
                    pending = null
                    val err = BackupManager.restore(ctx, u)
                    if (err == null) { vm.reloadAfterRestore(); msg = "Voaverina ny backup." } else msg = err
                }) { Text("Averina") }
            },
            dismissButton = { TextButton({ pending = null }) { Text("Foano") } }
        )
    }
}
