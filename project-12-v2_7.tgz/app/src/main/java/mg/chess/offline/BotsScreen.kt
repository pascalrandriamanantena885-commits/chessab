package mg.chess.offline

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

private const val F_ALL = -1
private const val F_CUSTOM = 6

@Composable
fun BotsScreen(vm: ChessViewModel) {
    BackHandler { vm.toMenu() }
    var choice by remember { mutableIntStateOf(0) }
    var filter by remember { mutableIntStateOf(F_ALL) }
    var selectedId by remember { mutableStateOf<String?>(null) }
    // Filaharana: Elo miakatra (BotRegistry.visible efa voasivana araka ny Elo), tsy misy lohateny sokajy
    val all = BotRegistry.visible
    val shown = when (filter) {
        F_ALL -> all
        F_CUSTOM -> all.filter { it.custom }
        else -> all.filter { tierOf(it.elo).ordinal == filter }
    }
    val selected = shown.firstOrNull { it.id == selectedId }

    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 8.dp)) {
        ScreenTitle("Fidio ny bot", onBack = { vm.toMenu() }) {
            OutlinedButton({ vm.toPgn() }) { Text("PGN → Bot") }
        }
        Row(Modifier.padding(bottom = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Loko: ")
            FilterChip(choice == 0, { choice = 0 }, { Text("Fotsy") })
            FilterChip(choice == 1, { choice = 1 }, { Text("Mainty") })
            FilterChip(choice == 2, { choice = 2 }, { Text("Kisendrasendra") })
        }
        TimeControlPicker(vm)
        Spacer(Modifier.height(6.dp))
        // Sivana araka ny sokajy
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(filter == F_ALL, { filter = F_ALL }, { Text("Rehetra (${all.size})") })
            for (t in BotTier.values()) {
                val n = all.count { tierOf(it.elo) == t }
                FilterChip(filter == t.ordinal, { filter = t.ordinal }, { Text("${t.label} ($n)") })
            }
            FilterChip(filter == F_CUSTOM, { filter = F_CUSTOM }, { Text("Nataoko (${all.count { it.custom }})") })
        }
        Spacer(Modifier.height(8.dp))
        if (shown.isEmpty()) {
            Text("Tsy misy bot amin'ity sokajy ity. Azonao atao ny mamorona avy amin'ny PGN.", Modifier.padding(top = 12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(
            "Tsindrio ny bot hijery ny Elo-ny, avy eo \"Milalao\".",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 6.dp)
        )
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(shown, key = { it.id }) { b ->
                BotTile(b, selected = b.id == selectedId) {
                    selectedId = if (selectedId == b.id) null else b.id
                }
            }
        }
        // Antsipiriany: miseho rehefa voatsindry ny card
        AnimatedVisibility(selected != null) {
            if (selected != null) {
                SelectedBotPanel(selected) {
                    val white = when (choice) { 0 -> true; 1 -> false; else -> Random.nextBoolean() }
                    vm.startBotGame(selected, white)
                }
            }
        }
    }
}

/** Card kely: sary + anarana ihany. Ny Elo dia miseho eo ambonin'ny sary rehefa voatsindry. */
@Composable
private fun BotTile(b: Bot, selected: Boolean, onClick: () -> Unit) {
    val tier = tierOf(b.elo)
    val accent = Color(tier.color)
    Card(
        Modifier.fillMaxWidth().clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
        border = if (selected) BorderStroke(2.5.dp, accent) else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(10.dp))) {
                BotPortrait(b)
                if (selected) {
                    Box(
                        Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                            .background(accent.copy(alpha = 0.92f)).padding(vertical = 3.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            if (b.elo > SF_MAX_ELO) "MAX" else "Elo ${b.elo}",
                            color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            Spacer(Modifier.height(5.dp))
            Text(
                b.name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

/** Sary kare miolakolaka; raha tsy misy sary dia loko + litera voalohany. */
@Composable
private fun BotPortrait(b: Bot) {
    val ctx = LocalContext.current
    val img = remember(b.id, b.rev) { Sprites.avatar(ctx, b) }
    if (img != null) {
        Image(img, b.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    } else {
        Box(Modifier.fillMaxSize().background(Color(b.color)), contentAlignment = Alignment.Center) {
            Text(b.name.take(1), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 34.sp)
        }
    }
}

@Composable
private fun SelectedBotPanel(b: Bot, onPlay: () -> Unit) {
    val tier = tierOf(b.elo)
    Card(
        Modifier.fillMaxWidth().padding(top = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
        border = BorderStroke(1.dp, Color(tier.color).copy(alpha = 0.5f))
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(b.name, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (b.elo > SF_MAX_ELO) "MAX" else "${b.elo}",
                        fontWeight = FontWeight.Bold, color = Color(tier.color)
                    )
                    Spacer(Modifier.width(8.dp))
                    TierChip(tier)
                }
                Text(b.bio, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                val spec = b.specialty()
                if (spec.isNotEmpty() && spec != b.bio) {
                    Text(spec, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                }
            }
            Spacer(Modifier.width(10.dp))
            Button(onPlay) { Text("Milalao") }
        }
    }
}
