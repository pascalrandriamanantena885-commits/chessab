package mg.chess.offline

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

private fun pts(p: Double): String = if (p % 1.0 == 0.0) "${p.toInt()}" else "$p"

/** 🥇 ho an'ny tompon-daka, 🥈 ho an'ny faharoa (finaliste resy). */
fun medalOf(t: Tournament, id: String?): String {
    val pd = t.podium() ?: return ""
    return when (id) {
        pd.first -> "🥇"
        pd.second -> "🥈"
        else -> ""
    }
}

// ---------------- PODIUM ----------------

@Composable
fun PodiumCard(t: Tournament) {
    val pd = t.podium() ?: return
    val gold = t.player(pd.first)
    val silver = t.player(pd.second)
    Card(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🥇", fontSize = 28.sp)
                Spacer(Modifier.width(8.dp))
                if (gold?.bot != null) { BotAvatar(gold.bot, 40.dp); Spacer(Modifier.width(8.dp)) }
                Column {
                    Text(gold?.name ?: "—", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Medaille d'or - tompon-daka", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (silver != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🥈", fontSize = 28.sp)
                    Spacer(Modifier.width(8.dp))
                    if (silver.bot != null) { BotAvatar(silver.bot, 36.dp); Spacer(Modifier.width(8.dp)) }
                    Column {
                        Text(silver.name, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text("Medaille d'argent - finaliste", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

// ---------------- SCHEMA CUP ----------------

private fun roundTitle(r: Int): String = stageLabel("KO$r")

@Composable
fun TourSchemaTab(vm: ChessViewModel, t: Tournament, modifier: Modifier) {
    val rounds = t.bracket()
    if (rounds.isEmpty()) { Text("Tsy misy schema.", modifier); return }
    val cs = MaterialTheme.colorScheme
    val cardW = 160.dp
    val cardH = 60.dp
    val gapX = 30.dp
    val pitch = 72.dp
    val head = 26.dp
    val first = rounds.first()
    val totalH = pitch * first.size + head
    val totalW = (cardW + gapX) * rounds.size
    val line = cs.outline
    val champId = t.champion

    Column(modifier.verticalScroll(rememberScrollState())) {
        Box(Modifier.horizontalScroll(rememberScrollState())) {
            Box(Modifier.size(totalW, totalH)) {
                Canvas(Modifier.size(totalW, totalH)) {
                    val cw = cardW.toPx(); val ch = cardH.toPx(); val gx = gapX.toPx()
                    val pt = pitch.toPx(); val hd = head.toPx()
                    fun cy(r: Int, i: Int): Float {
                        val span = (1 shl r).toFloat()
                        return hd + pt * (i * span + span / 2f)
                    }
                    for (r in 0 until rounds.size - 1) {
                        val x0 = r * (cw + gx) + cw
                        val xm = x0 + gx / 2f
                        val x1 = (r + 1) * (cw + gx)
                        for (i in rounds[r].indices) {
                            val y = cy(r, i)
                            val py = cy(r + 1, i / 2)
                            drawLine(line, Offset(x0, y), Offset(xm, y), 3f)
                            drawLine(line, Offset(xm, y), Offset(xm, py), 3f)
                            drawLine(line, Offset(xm, py), Offset(x1, py), 3f)
                        }
                    }
                }
                rounds.forEachIndexed { r, list ->
                    Text(
                        roundTitle(list.first().round),
                        fontWeight = FontWeight.Bold, fontSize = 13.sp, color = cs.primary,
                        modifier = Modifier.offset(x = (cardW + gapX) * r, y = 2.dp).width(cardW)
                    )
                    list.forEachIndexed { i, bm ->
                        val span = (1 shl r).toFloat()
                        val centre = head + pitch * (i * span + span / 2f)
                        val played = bm.matches.firstOrNull { it.result != null && it.result != "bye" && it.moves.isNotEmpty() }
                        val isFinal = bm.round == 2
                        Column(
                            Modifier
                                .offset(x = (cardW + gapX) * r, y = centre - cardH / 2)
                                .size(cardW, cardH)
                                .background(cs.surfaceContainer, RoundedCornerShape(10.dp))
                                .border(1.dp, if (isFinal) cs.tertiary else cs.outline.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                                .clickable(enabled = played != null) { played?.let { vm.reviewTourMatch(it) } }
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalArrangement = Arrangement.SpaceEvenly
                        ) {
                            BracketRow(bm.whiteLabel, bm.whiteId != null && bm.winnerId == bm.whiteId, medalOf(t, bm.whiteId))
                            BracketRow(bm.blackLabel, bm.blackId != null && bm.winnerId == bm.blackId, medalOf(t, bm.blackId))
                        }
                        if (bm.scoreText.isNotEmpty()) {
                            Text(
                                bm.scoreText, fontSize = 10.sp, color = cs.onSurfaceVariant, maxLines = 1,
                                modifier = Modifier.offset(x = (cardW + gapX) * r + 6.dp, y = centre + cardH / 2 - 1.dp)
                            )
                        }
                    }
                }
                if (champId != null) {
                    val r = rounds.size - 1
                    val centre = head + pitch * ((1 shl r) / 2f)
                    Text(
                        "🏆", fontSize = 26.sp,
                        modifier = Modifier.offset(x = (cardW + gapX) * r + cardW / 2 - 14.dp, y = centre - cardH / 2 - 34.dp)
                    )
                }
            }
        }
        if (t.groups.isNotEmpty() && t.stage == "G") {
            Text(
                "Ny anarana \"1er / 2e Poule\" dia hovaina ho mpilalao rehefa vita ny phase de poule.",
                fontSize = 12.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

@Composable
private fun BracketRow(label: String, winner: Boolean, medal: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            (if (medal.isNotEmpty()) "$medal " else "") + label,
            fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            fontWeight = if (winner) FontWeight.Bold else FontWeight.Normal,
            color = if (winner) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
        if (winner) Text("✓", fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
    }
}

// ---------------- CLASSEMENT MPILALAO ----------------

private enum class LBoard { BRILLIANT, GREAT, ACC, PTS, ARCHIVE }

@Composable
fun TourLeadersTab(vm: ChessViewModel, t: Tournament, modifier: Modifier) {
    vm.tourVersion
    var board by remember { mutableIntStateOf(0) }
    val cs = MaterialTheme.colorScheme
    val lines = t.playerLines()
    val kind = LBoard.values()[board]
    val played = t.playedCount()
    val done = t.analysedCount()

    Column(modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Analyse: $done/$played lalao", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (vm.analysisPending > 0) "Mandeha ao ambadika (${vm.analysisPending} mbola ho analysena)..." else "Ny classement dia avy amin'ny analyse Stockfish.",
                    fontSize = 11.sp, color = cs.onSurfaceVariant
                )
            }
            Switch(vm.analysisOn, { vm.toggleAnalysis(it) })
        }
        if (vm.analysisOn && done < played && vm.analysisPending == 0) {
            OutlinedButton({ vm.analyseAllPending() }, Modifier.fillMaxWidth()) { Text("Alefaso ny analyse (${played - done})") }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(board == 0, { board = 0 }, { Text("✨ Brilliant !!") })
            FilterChip(board == 1, { board = 1 }, { Text("⭐ Great !") })
            FilterChip(board == 2, { board = 2 }, { Text("🎖 Précision") })
            FilterChip(board == 3, { board = 3 }, { Text("🏅 Points") })
            FilterChip(board == 4, { board = 4 }, { Text("📚 Archive !!") })
        }
        if (kind == LBoard.ARCHIVE) {
            BrilliantArchiveList(vm, t, Modifier.weight(1f))
        } else {
            val sorted = when (kind) {
                LBoard.BRILLIANT -> lines.sortedWith(compareByDescending<PlayerLine> { it.brilliant }.thenByDescending { it.great }.thenByDescending { it.accuracy ?: 0.0 })
                LBoard.GREAT -> lines.sortedWith(compareByDescending<PlayerLine> { it.great }.thenByDescending { it.brilliant }.thenByDescending { it.accuracy ?: 0.0 })
                LBoard.ACC -> lines.filter { it.accuracy != null }.sortedByDescending { it.accuracy ?: 0.0 }
                else -> lines.sortedWith(compareByDescending<PlayerLine> { it.pts }.thenByDescending { it.w }.thenBy { it.l })
            }
            val title = when (kind) {
                LBoard.BRILLIANT -> "Brilliant moves (!!) betsaka indrindra"
                LBoard.GREAT -> "Great moves (!) betsaka indrindra"
                LBoard.ACC -> "Précision antonony ambony indrindra"
                else -> "Points (fandresena 1, draw ½)"
            }
            Text(title, fontSize = 12.sp, color = cs.onSurfaceVariant)
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(sorted, key = { it.id }) { pl ->
                    val p = t.player(pl.id)
                    val rank = sorted.indexOf(pl) + 1
                    val value = when (kind) {
                        LBoard.BRILLIANT -> "${pl.brilliant}"
                        LBoard.GREAT -> "${pl.great}"
                        LBoard.ACC -> pl.accuracy?.let { "${it.roundToInt()}%" } ?: "-"
                        else -> pts(pl.pts)
                    }
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = cs.surfaceContainer)) {
                        Row(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("$rank", Modifier.width(26.dp), fontWeight = FontWeight.Bold,
                                color = if (rank == 1) cs.tertiary else cs.onSurface)
                            if (p?.bot != null) { BotAvatar(p.bot, 30.dp); Spacer(Modifier.width(8.dp)) }
                            Column(Modifier.weight(1f)) {
                                Text(
                                    (medalOf(t, pl.id).let { if (it.isEmpty()) "" else "$it " }) + (p?.name ?: "—"),
                                    fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    "${pl.played} lalao - ${pl.w}V ${pl.d}N ${pl.l}D" +
                                        (if (pl.analysed > 0) " - !! ${pl.brilliant} - ! ${pl.great} - ?? ${pl.blunder}" else ""),
                                    fontSize = 11.sp, color = cs.onSurfaceVariant
                                )
                            }
                            Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = cs.primary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BrilliantArchiveList(vm: ChessViewModel, t: Tournament, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val list = t.brilliantArchive()
    if (list.isEmpty()) {
        Text("Mbola tsy misy hetsika brilliant voarakitra. Mila analyse ny lalao aloha (na tsy hitan'ny Stockfish ho sacrifice mahafinaritra).", modifier, fontSize = 13.sp)
        return
    }
    LazyColumn(modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        items(list, key = { "${it.first.id}:${it.second.ply}" }) { (m, b) ->
            val pid = if (b.white) m.whiteId else m.blackId
            val oid = if (b.white) m.blackId else m.whiteId
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = cs.surfaceContainer)) {
                Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("!! ${b.san}  -  ${t.name(pid)}", fontWeight = FontWeight.Bold)
                        Text(
                            "vs ${t.name(oid)} - " + stageLabel(m.stage) + (if (m.stage == "G") " " + groupName(m.group) else "") +
                                " - hetsika ${(b.ply + 1) / 2}",
                            fontSize = 11.sp, color = cs.onSurfaceVariant
                        )
                    }
                    OutlinedButton({ vm.reviewTourMatch(m, b.ply) }) { Text("Jereo") }
                }
            }
        }
    }
}

// ---------------- ARCHIVE (fifaninanana rehetra) ----------------

private data class MedalRow(val key: String, val name: String, val bot: Bot?, var gold: Int, var silver: Int)

@Composable
fun ArchiveScreen(vm: ChessViewModel) {
    BackHandler { vm.toTourList() }
    vm.tourVersion
    val cs = MaterialTheme.colorScheme
    val done = vm.tournaments.filter { it.champion != null }.sortedByDescending { it.updated }
    val table = LinkedHashMap<String, MedalRow>()
    for (t in done) {
        val pd = t.podium() ?: continue
        fun add(id: String?, g: Int, s: Int) {
            val p = t.player(id) ?: return
            val r = table.getOrPut(p.key()) { MedalRow(p.key(), p.name, p.bot, 0, 0) }
            r.gold += g; r.silver += s
        }
        add(pd.first, 1, 0); add(pd.second, 0, 1)
    }
    val medals = table.values.sortedWith(compareByDescending<MedalRow> { it.gold }.thenByDescending { it.silver })
    val hall = done.flatMap { t -> t.brilliantArchive().map { Triple(t, it.first, it.second) } }.take(40)

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { ScreenTitle("Archive fifaninanana", onBack = { vm.toTourList() }) }
        if (done.isEmpty()) item { Text("Mbola tsy misy fifaninanana vita.") }
        if (medals.isNotEmpty()) {
            item { Text("🏅 Tabilao medaille", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            items(medals, key = { it.key }) { r ->
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = cs.surfaceContainer)) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (r.bot != null) { BotAvatar(r.bot, 34.dp); Spacer(Modifier.width(8.dp)) }
                        Text(r.name, Modifier.weight(1f), fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("🥇 ${r.gold}   🥈 ${r.silver}", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        if (done.isNotEmpty()) item { Text("Isaky ny fifaninanana", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        items(done, key = { it.id }) { t ->
            val pd = t.podium()
            val lines = t.playerLines()
            val topB = lines.filter { it.brilliant > 0 }.maxByOrNull { it.brilliant }
            val topG = lines.filter { it.great > 0 }.maxByOrNull { it.great }
            val topA = lines.filter { it.accuracy != null && it.played >= 2 }.maxByOrNull { it.accuracy ?: 0.0 }
            Card(Modifier.fillMaxWidth().clickable { vm.openTour(t) }, colors = CardDefaults.cardColors(containerColor = cs.surfaceContainer)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(t.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("${t.players.size} mpilalao - " + t.analysedCount() + "/" + t.playedCount() + " lalao voanalyse", fontSize = 11.sp, color = cs.onSurfaceVariant)
                    if (pd != null) {
                        Text("🥇 ${t.name(pd.first)}" + (pd.second?.let { "     🥈 ${t.name(it)}" } ?: ""))
                    }
                    if (topB != null) Text("✨ Brilliant (!!): ${t.name(topB.id)} - ${topB.brilliant}", fontSize = 13.sp)
                    if (topG != null) Text("⭐ Great (!): ${t.name(topG.id)} - ${topG.great}", fontSize = 13.sp)
                    if (topA != null) Text("🎖 Précision: ${t.name(topA.id)} - ${(topA.accuracy ?: 0.0).roundToInt()}%", fontSize = 13.sp)
                }
            }
        }
        if (hall.isNotEmpty()) {
            item { Text("✨ Hall of fame: brilliant moves", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            items(hall, key = { "h${it.first.id}:${it.second.id}:${it.third.ply}" }) { (t, m, b) ->
                val pid = if (b.white) m.whiteId else m.blackId
                val oid = if (b.white) m.blackId else m.whiteId
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = cs.surfaceContainer)) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("!! ${b.san}  -  ${t.name(pid)}", fontWeight = FontWeight.Bold)
                            Text("vs ${t.name(oid)} - ${t.name}", fontSize = 11.sp, color = cs.onSurfaceVariant)
                        }
                        OutlinedButton({ vm.openTour(t); vm.reviewTourMatch(m, b.ply) }) { Text("Jereo") }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}
