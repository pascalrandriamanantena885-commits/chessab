package mg.chess.offline

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.border
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.LaunchedEffect
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.PieceType
import com.github.bhlangonijr.chesslib.Rank
import com.github.bhlangonijr.chesslib.Square
import com.github.bhlangonijr.chesslib.move.MoveList
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Side
import kotlin.random.Random
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.rounded.Analytics
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.AlertDialog
import androidx.compose.ui.text.font.FontFamily
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

@Composable
fun BotAvatar(bot: Bot, size: Dp) {
    val ctx = LocalContext.current
    val img = remember(bot.id, bot.rev) { Sprites.avatar(ctx, bot) }
    if (img != null) {
        Image(img, null, Modifier.size(size).clip(CircleShape), contentScale = ContentScale.Crop)
    } else {
        Box(Modifier.size(size).clip(CircleShape).background(Color(bot.color)), contentAlignment = Alignment.Center) {
            Text(bot.name.take(1), color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.45f).sp)
        }
    }
}

private fun tcLabel(base: Long, inc: Long) = if (base <= 0) "Tsy misy ora" else "${base / 60000}+${inc / 1000}"

fun fmtClock(ms: Long): String {
    val t = max(0L, ms)
    val s = t / 1000
    val m = s / 60
    return if (t < 20_000) String.format(Locale.US, "%d:%02d.%d", m, s % 60, (t % 1000) / 100)
    else String.format(Locale.US, "%d:%02d", m, s % 60)
}

@Composable
fun TimeControlPicker(vm: ChessViewModel) {
    Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
        Text("Ora: ")
        for (t in TIME_CONTROLS) {
            FilterChip(vm.tc == t, { vm.tc = t }, { Text(t.label) })
            Spacer(Modifier.width(6.dp))
        }
    }
}

@Composable
fun ClockBox(ms: Long, active: Boolean) {
    val bg = when {
        !active -> Color(0xFF444444)
        ms < 20_000 -> Color(0xFFCA3431)
        else -> Color(0xFF2E7D32)
    }
    Box(Modifier.clip(RoundedCornerShape(8.dp)).background(bg).padding(horizontal = 12.dp, vertical = 6.dp)) {
        Text(fmtClock(ms), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun ScreenTitle(title: String, onBack: (() -> Unit)? = null, trailing: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Miverina") }
        }
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (trailing != null) trailing()
    }
}

@Composable
fun ModeCard(title: String, sub: String, accent: Boolean, icon: ImageVector, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(
        Modifier.fillMaxWidth().clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = if (accent) cs.primary else cs.surfaceContainer)
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(52.dp).clip(CircleShape)
                    .background(if (accent) Color(0x33FFFFFF) else cs.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, null, tint = if (accent) cs.onPrimary else cs.onPrimaryContainer, modifier = Modifier.size(30.dp))
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = if (accent) cs.onPrimary else cs.onSurface)
                Text(sub, fontSize = 13.sp, color = if (accent) cs.onPrimary.copy(alpha = 0.85f) else cs.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun MenuScreen(vm: ChessViewModel) {
    val unfinished = vm.saved.firstOrNull { it.result == null }
    val unfinishedBot = unfinished?.let { BotRegistry.find(it.botId) }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 12.dp),
        Arrangement.spacedBy(14.dp), Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            val kn = Sprites.pieces["wn"]
            if (kn != null) Image(kn, null, Modifier.size(64.dp))
            Spacer(Modifier.width(10.dp))
            Text(
                "KAJY", fontSize = 44.sp, fontWeight = FontWeight.Black, letterSpacing = 6.sp,
                color = MaterialTheme.colorScheme.primary
            )
        }
        Text("Chess tsy mila internet - Stockfish 19", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Ora", fontWeight = FontWeight.Bold)
                TimeControlPicker(vm)
            }
        }
        ModeCard("Milalao amin'ny Bot", "Fidio ny Elo: 400 hatramin'ny Stockfish", true, Icons.Rounded.SmartToy) { vm.toBots() }
        ModeCard("Olona vs Olona", "Lalao roa mpilalao amin'ny findainao iray", false, Icons.Rounded.Group) { vm.startHumanGame() }
        ModeCard("Bot avy amin'ny PGN", "Stockfish mandinika ny lalao PGN dia mamorona bot", false, Icons.Rounded.Analytics) { vm.toPgn() }
        if (unfinished != null) {
            ModeCard(
                "Tohizo ny lalao farany",
                (if (unfinishedBot != null) "vs ${unfinishedBot.name}" else "Olona vs Olona") + " - ${unfinished.moves.size} hetsika",
                false, Icons.Rounded.PlayArrow
            ) { vm.loadGame(unfinished) }
        }
        Spacer(Modifier.height(8.dp))
    }
}

/** Piece nalain'ny mpilalao (side) + tombony material, avy amin'ny board. */
private fun capturedOf(board: Board, side: Side): Pair<List<Piece>, Int> {
    val start = mapOf(PieceType.PAWN to 8, PieceType.KNIGHT to 2, PieceType.BISHOP to 2, PieceType.ROOK to 2, PieceType.QUEEN to 1)
    val cnt = HashMap<Pair<Side, PieceType>, Int>()
    var wm = 0; var bm = 0
    for (r in 0..7) for (f in 0..7) {
        val sq = Square.encode(Rank.allRanks[r], com.github.bhlangonijr.chesslib.File.allFiles[f])
        val p = board.getPiece(sq)
        if (p == Piece.NONE || p.pieceType == PieceType.KING) continue
        val k = p.pieceSide to p.pieceType
        cnt[k] = (cnt[k] ?: 0) + 1
        if (p.pieceSide == Side.WHITE) wm += pv(p) else bm += pv(p)
    }
    val enemy = if (side == Side.WHITE) Side.BLACK else Side.WHITE
    val out = ArrayList<Piece>()
    for (t in listOf(PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT, PieceType.PAWN)) {
        val missing = ((start[t] ?: 0) - (cnt[enemy to t] ?: 0)).coerceAtLeast(0)
        val piece = Piece.make(enemy, t)
        repeat(missing) { out.add(piece) }
    }
    val diff = if (side == Side.WHITE) wm - bm else bm - wm
    return out to diff
}

@Composable
fun PlayerBar(vm: ChessViewModel, side: Side, bot: Bot?, you: Boolean, label: String? = null, shown: Board? = null) {
    val active = !vm.over && vm.board.sideToMove == side
    val tier = bot?.let { tierOf(it.elo) }
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(14.dp))
            .background(cs.surfaceContainer)
            .border(if (active) 2.dp else 1.dp, if (active) cs.primary else Color(0x22888888), RoundedCornerShape(14.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val c = if (side == Side.WHITE) "Fotsy" else "Mainty"
        val name: String
        val sub: String
        if (bot != null) {
            BotAvatar(bot, 40.dp)
            name = bot.name
            sub = if (bot.elo > SF_MAX_ELO) "Stockfish 19" else "Elo ${bot.elo}"
        } else {
            val nm = label ?: if (you) PlayerProfile.name else c
            PlayerAvatar(nm, you, 40.dp)
            name = nm
            sub = if (you) "$c · Elo ${PlayerStats.ratingInt}" else c
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(name, fontWeight = FontWeight.Bold, maxLines = 1)
                if (tier != null) { Spacer(Modifier.width(6.dp)); TierChip(tier) }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(sub, fontSize = 12.sp, color = cs.onSurfaceVariant)
                if (shown != null) {
                    val (caps, diff) = remember(vm.version, vm.viewPly) { capturedOf(shown, side) }
                    if (caps.isNotEmpty()) {
                        Spacer(Modifier.width(8.dp))
                        for (p in caps.take(12)) PieceIcon(p, 13.dp)
                        if (diff > 0) Text(" +$diff", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = cs.primary)
                    }
                }
            }
        }
        if (active && !vm.clockOn) {
            Box(Modifier.size(9.dp).clip(CircleShape).background(cs.primary))
            Spacer(Modifier.width(8.dp))
        }
        if (vm.clockOn) {
            ClockBox(if (side == Side.WHITE) vm.whiteMs else vm.blackMs, active)
        }
    }
}

/** Lisitry ny hetsika (SAN) mihodina mitsivalana; manaraka ny hetsika farany. */
@Composable
fun MoveStrip(vm: ChessViewModel) {
    vm.version
    val n = vm.played.size
    val sans = remember(n, vm.version) {
        try {
            val ml = MoveList(START_FEN)
            for (m in vm.played) ml.add(m)
            ml.toSanArray().toList()
        } catch (e: Exception) { emptyList<String>() }
    }
    val state = rememberLazyListState()
    LaunchedEffect(sans.size) { if (sans.isNotEmpty()) state.animateScrollToItem(sans.size - 1) }
    val cs = MaterialTheme.colorScheme
    val cur = if (vm.viewPly >= 0) vm.viewPly else sans.size
    LazyRow(state = state, modifier = Modifier.fillMaxWidth().height(26.dp), verticalAlignment = Alignment.CenterVertically) {
        itemsIndexed(sans) { i, san ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (i % 2 == 0) Text("${i / 2 + 1}.", fontSize = 12.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(start = 6.dp, end = 2.dp))
                Text(
                    san, fontSize = 13.sp, fontWeight = if (i + 1 == cur) FontWeight.Bold else FontWeight.Normal,
                    color = if (i + 1 == cur) cs.onPrimaryContainer else cs.onSurface,
                    modifier = Modifier.clip(RoundedCornerShape(5.dp))
                        .background(if (i + 1 == cur) cs.primaryContainer else Color.Transparent)
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                )
            }
        }
    }
}

@Composable
private fun ActionBtn(
    icon: ImageVector?, label: String, enabled: Boolean = true, glyph: String? = null, onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        FilledTonalIconButton(onClick, enabled = enabled, modifier = Modifier.size(46.dp)) {
            if (icon != null) Icon(icon, label) else Text(glyph ?: "", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun NavIcon(enabled: Boolean, onClick: () -> Unit, content: @Composable () -> Unit) {
    IconButton(onClick, enabled = enabled, modifier = Modifier.size(42.dp)) { content() }
}

@Composable
fun GameScreen(vm: ChessViewModel) {
    Box(Modifier.fillMaxSize()) {
        GameContent(vm)
        val info = vm.matchInfo
        if (vm.introShown && info != null) MatchIntroOverlay(info) { vm.dismissIntro() }
    }
}

@Composable
private fun GameContent(vm: ChessViewModel) {
    BackHandler { vm.toMenu() }
    vm.version
    val flip = (vm.vsBot && !vm.humanWhite) != vm.flipped
    val board = vm.board
    val viewing = vm.viewPly >= 0
    val viewBoard = remember(vm.viewPly, vm.version) { if (vm.viewPly >= 0) vm.boardAtPly(vm.viewPly) else null }
    val shown = viewBoard ?: board
    val targets = if (viewing) emptyList() else (vm.selected?.let { s -> vm.legalFrom(s).map { it.to } } ?: emptyList())
    val lastMove = if (viewing) vm.played.getOrNull(vm.viewPly - 1) else vm.played.lastOrNull()
    val last = lastMove?.let { it.from to it.to }
    val topSide = if (flip) Side.WHITE else Side.BLACK
    val bottomSide = if (flip) Side.BLACK else Side.WHITE
    val b = vm.bot
    val total = vm.played.size
    val cur = if (viewing) vm.viewPly else total

    var exporting by remember { mutableStateOf(false) }
    val pend = if (viewing) null else vm.pendingMove
    val pm = vm.promoMoves
    if (pm != null) {
        AlertDialog(
            onDismissRequest = { vm.cancelPromotion() },
            confirmButton = {},
            title = { Text("Fidio ny piece") },
            text = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (m in pm) {
                        Box(
                            Modifier.size(64.dp).clip(RoundedCornerShape(8.dp))
                                .background(Color(0x33888888)).clickable { vm.choosePromotion(m) },
                            contentAlignment = Alignment.Center
                        ) { PieceIcon(m.promotion, 56.dp) }
                    }
                }
            }
        )
    }
    if (vm.drawDialog) {
        AlertDialog(
            onDismissRequest = { vm.answerDraw(false) },
            title = { Text("Tolo-pitenenana draw") },
            text = { Text("Ny mpilalao iray dia manolo draw. Manaiky ve ny mpilalao faharoa?") },
            confirmButton = { Button({ vm.answerDraw(true) }) { Text("Manaiky") } },
            dismissButton = { TextButton({ vm.answerDraw(false) }) { Text("Tsia") } }
        )
    }
    if (exporting) {
        val pgn = remember { vm.exportPgn() }
        val fen = remember { vm.exportFen() }
        ExportDialog("Export lalao", pgn, fen) { exporting = false }
    }
    if (vm.resignDialog) {
        AlertDialog(
            onDismissRequest = { vm.resignDialog = false },
            title = { Text("Hiala ve?") },
            text = { Text("Resy ianao raha miala.") },
            confirmButton = { Button({ vm.resign() }) { Text("Miala") } },
            dismissButton = { TextButton({ vm.resignDialog = false }) { Text("Tsia") } }
        )
    }

    Column(Modifier.fillMaxSize().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        val tp = if (vm.tourMatch != null) vm.tourPlayer(topSide) else null
        val bp = if (vm.tourMatch != null) vm.tourPlayer(bottomSide) else null
        val botSide = if (vm.vsBot) (if (vm.humanWhite) Side.BLACK else Side.WHITE) else null
        vm.matchInfo?.let { MatchRibbon(it) }
        if (vm.tourMatch != null) PlayerBar(vm, topSide, tp?.bot, false, tp?.name, shown)
        else PlayerBar(vm, topSide, if (topSide == botSide) b else null, vm.vsBot && topSide != botSide, null, shown)
        BoardView(
            pieceAt = { sq ->
                when {
                    pend != null && sq == pend.from -> Piece.NONE
                    pend != null && sq == pend.to ->
                        if (pend.promotion != Piece.NONE) pend.promotion else shown.getPiece(pend.from)
                    else -> shown.getPiece(sq)
                }
            },
            flip = flip,
            modifier = Modifier.clip(RoundedCornerShape(8.dp))
                .border(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.55f), RoundedCornerShape(8.dp)),
            selected = if (viewing) null else vm.selected, targets = targets, last = last,
            premove = if (viewing) null else vm.premove,
            pending = pend?.let { it.from to it.to },
            onSquare = { vm.onSquare(it) },
            onDragStart = { vm.dragStart(it) },
            onDrop = { f, t -> vm.dragDrop(f, t) }
        )
        if (vm.tourMatch != null) PlayerBar(vm, bottomSide, bp?.bot, false, bp?.name, shown)
        else PlayerBar(vm, bottomSide, if (bottomSide == botSide) b else null, vm.vsBot && bottomSide != botSide, null, shown)
        MoveStrip(vm)
        CommentaryBar(vm)
        Spacer(Modifier.weight(1f))
        if (pend != null) {
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ vm.confirmPending() }, Modifier.weight(1f)) {
                    Icon(Icons.Rounded.Check, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Ekena " + pend.from.toString().lowercase() + "-" + pend.to.toString().lowercase())
                }
                OutlinedButton({ vm.cancelPending() }, Modifier.weight(1f)) {
                    Icon(Icons.Rounded.Close, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Foano")
                }
            }
        }
        val alert = vm.over || vm.message.isNotEmpty()
        Text(
            when {
                viewing -> "Mijery hetsika $cur/$total - tsindrio ny board hiverina"
                vm.message.isNotEmpty() ->
                    vm.message + (if (vm.over && vm.ratingNote.isNotEmpty()) "\n" + vm.ratingNote else "")
                vm.thinking -> "${b?.name ?: "Stockfish"} mieritreritra..." +
                    (vm.premove?.let { "\nPremove: " + it.first.toString().lowercase() + "-" + it.second.toString().lowercase() } ?: "")
                pend != null -> "Hamafiso ny hetsika"
                board.sideToMove == Side.WHITE -> "Fotsy no mihetsika"
                else -> "Mainty no mihetsika"
            },
            color = if (alert && !viewing) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Bold, fontSize = 16.sp,
            modifier = Modifier.padding(vertical = 4.dp)
        )
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceContainer).padding(vertical = 2.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            NavIcon(cur > 0, { vm.navFirst() }) { Text("«", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
            NavIcon(cur > 0, { vm.navPrev() }) { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowLeft, "Hetsika aloha", Modifier.size(30.dp)) }
            NavIcon(true, { vm.flipBoard() }) { Icon(Icons.Rounded.SwapVert, "Flip board") }
            NavIcon(vm.played.isNotEmpty(), { exporting = true }) { Icon(Icons.Rounded.Share, "Export PGN / FEN") }
            NavIcon(viewing, { vm.navNext() }) { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, "Hetsika manaraka", Modifier.size(30.dp)) }
            NavIcon(viewing, { vm.navLast() }) { Text("»", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            if (vm.tourMatch == null) {
                ActionBtn(Icons.AutoMirrored.Rounded.Undo, "Undo") { vm.undo() }
                ActionBtn(Icons.Rounded.Refresh, "Vaovao") { vm.restart() }
            }
            ActionBtn(null, "Draw", enabled = vm.canOfferDraw, glyph = "\u00BD") { vm.offerDraw() }
            ActionBtn(Icons.Rounded.Flag, "Miala", enabled = vm.canResign) { vm.resignDialog = true }
            ActionBtn(Icons.Rounded.Analytics, "Review", enabled = vm.played.isNotEmpty()) { vm.startReview() }
            ActionBtn(
                if (vm.tourMatch != null) Icons.Rounded.EmojiEvents else Icons.Rounded.Home,
                if (vm.tourMatch != null) "Tour" else "Menu"
            ) { vm.toMenu() }
        }
        }
    }
}

@Composable
private fun resultInfo(g: GameRecord, bot: Bot?): Pair<String, Color> {
    val r = g.result ?: return "Mitohy" to MaterialTheme.colorScheme.tertiary
    if (r == "1/2-1/2") return "Draw" to MaterialTheme.colorScheme.outline
    if (bot == null) return r to MaterialTheme.colorScheme.outline
    val whiteWon = r == "1-0"
    return if (whiteWon == g.humanWhite) "Nahazo" to MaterialTheme.colorScheme.primary else "Resy" to MaterialTheme.colorScheme.error
}

@Composable
fun HistoryScreen(vm: ChessViewModel) {
    BackHandler { vm.toMenu() }
    val fmt = remember { SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()) }
    var exportRec by remember { mutableStateOf<GameRecord?>(null) }
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 8.dp)) {
        ScreenTitle("Tantaran'ny lalao (${vm.saved.size})")
        StatsSummaryCard { vm.toStats() }
        if (vm.saved.isEmpty()) Text("Mbola tsy misy lalao voatahiry.", Modifier.padding(top = 16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(vm.saved, key = { it.id }) { g ->
                val bot = BotRegistry.find(g.botId)
                val (resText, resColor) = resultInfo(g, bot)
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (bot != null) { BotAvatar(bot, 42.dp); Spacer(Modifier.width(10.dp)) }
                            Column(Modifier.weight(1f)) {
                                Text(if (bot != null) "Olona vs ${bot.name} (${bot.elo})" else "Olona vs Olona", fontWeight = FontWeight.Bold)
                                Text("${fmt.format(Date(g.updated))} - ${g.moves.size} hetsika - ${tcLabel(g.baseMs, g.incMs)}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(resText, color = resColor, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Button({ vm.loadGame(g, true) }, contentPadding = PaddingValues(horizontal = 14.dp)) { Text("Review") }
                            if (g.result == null) Button({ vm.loadGame(g) }, contentPadding = PaddingValues(horizontal = 14.dp)) { Text("Tohizo") }
                            Spacer(Modifier.weight(1f))
                            IconButton({ exportRec = g }) { Icon(Icons.Rounded.Share, "Export PGN / FEN") }
                            IconButton({ vm.deleteGame(g.id) }) { Icon(Icons.Rounded.Delete, "Fafao", tint = MaterialTheme.colorScheme.error) }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(8.dp)) }
        }
        exportRec?.let { g -> ExportDialog("Export lalao", pgnOfRecord(g), fenAfter(g.moves)) { exportRec = null } }
    }
}

// ---------------- REVIEW ----------------

@Composable
fun ReviewScreen(vm: ChessViewModel) {
    BackHandler { vm.leaveReview() }
    val r = vm.review
    val err = vm.reviewError
    when {
        err != null -> Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            Text("Hadisoana: $err", color = MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(16.dp))
            Button({ vm.leaveReview() }) { Text("Miverina") }
        }
        r == null -> Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            Text("Mandinika ny lalao (Stockfish 19, depth ${vm.reviewDepth})...", fontSize = 18.sp)
            Spacer(Modifier.height(16.dp))
            LinearProgressIndicator(progress = { vm.reviewProgress }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Text("${(vm.reviewProgress * 100).toInt()}%")
        }
        else -> ReviewContent(vm, r)
    }
}

@Composable
fun ClsDot(c: Cls, size: Dp = 20.dp) {
    Box(Modifier.size(size).clip(CircleShape).background(Color(c.color)), contentAlignment = Alignment.Center) {
        Text(c.sym, color = Color.White, fontSize = (size.value * 0.5f).sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SideCard(title: String, s: SideSummary, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text("${"%.1f".format(s.accuracy)}%", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Accuracy", fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            Text("Game rating ~${s.rating}", fontSize = 14.sp)
            Text("ACPL ${s.acpl}", fontSize = 12.sp)
        }
    }
}

@Composable
fun EvalBar(cp: Int) {
    val w = (winPct(cp) / 100.0).toFloat().coerceIn(0.03f, 0.97f)
    Row(Modifier.fillMaxWidth().height(18.dp).clip(RoundedCornerShape(4.dp))) {
        Box(Modifier.weight(w).fillMaxHeight().background(Color.White))
        Box(Modifier.weight(1f - w).fillMaxHeight().background(Color(0xFF333333)))
    }
}

@Composable
fun EvalGraph(evals: List<Int>, ply: Int) {
    Canvas(Modifier.fillMaxWidth().height(70.dp).background(Color(0xFF2B2B2B))) {
        val n = evals.size
        if (n < 2) return@Canvas
        val dx = size.width / (n - 1)
        fun y(cp: Int): Float = size.height * (1f - (winPct(cp) / 100.0).toFloat())
        drawLine(Color(0x55FFFFFF), Offset(0f, size.height / 2), Offset(size.width, size.height / 2), 1f)
        for (i in 0 until n - 1) {
            drawLine(Color.White, Offset(i * dx, y(evals[i])), Offset((i + 1) * dx, y(evals[i + 1])), 3f)
        }
        drawLine(Color(0xFFCA3431), Offset(ply * dx, 0f), Offset(ply * dx, size.height), 2f)
    }
}

@Composable
fun MoveChip(m: MoveReview, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier.clip(RoundedCornerShape(6.dp))
            .background(if (selected) Color(0x33888888) else Color.Transparent)
            .clickable { onClick() }.padding(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ClsDot(m.cls, 20.dp)
        Spacer(Modifier.width(6.dp))
        Text(m.san, fontSize = 15.sp)
    }
}

@Composable
fun ReviewContent(vm: ChessViewModel, r: ReviewResult) {
    val ply = vm.reviewPly
    var flipView by remember { mutableStateOf(false) }
    var showBot by remember { mutableStateOf(false) }
    val flip = (vm.vsBot && !vm.humanWhite) != flipView
    val board = remember(ply, r) { Board().also { it.loadFromFen(r.fens[ply]) } }
    if (showBot) BotFromGameDialog(vm, r) { showBot = false }
    val last = if (ply > 0) r.squares[ply - 1] else null
    val hint = uciSquares(r.bestUci[ply])
    val mv = if (ply > 0) r.moves[ply - 1] else null
    val pairCount = (r.moves.size + 1) / 2

    LazyColumn(Modifier.fillMaxSize().padding(8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Column {
                Text("Game Review", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Stockfish 19 - depth ${vm.reviewDepth}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SideCard("Fotsy", r.white, Modifier.weight(1f))
                SideCard("Mainty", r.black, Modifier.weight(1f))
            }
        }
        item {
            Button({ showBot = true }, Modifier.fillMaxWidth(), enabled = r.moves.size >= 4) {
                Icon(Icons.Rounded.SmartToy, null)
                Spacer(Modifier.width(8.dp))
                Text("Mamorona bot avy amin'ity lalao ity")
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row {
                        Spacer(Modifier.weight(2f))
                        Text("Fotsy", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                        Text("Mainty", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    }
                    for (c in Cls.values()) {
                        val w = r.white.counts[c] ?: 0
                        val bl = r.black.counts[c] ?: 0
                        if (w > 0 || bl > 0) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Row(Modifier.weight(2f), verticalAlignment = Alignment.CenterVertically) {
                                    ClsDot(c, 18.dp); Spacer(Modifier.width(8.dp)); Text(c.label)
                                }
                                Text("$w", Modifier.weight(1f))
                                Text("$bl", Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }
        item {
            Column {
                EvalBar(r.evalsWhite[ply])
                Spacer(Modifier.height(6.dp))
                BoardView(pieceAt = { board.getPiece(it) }, flip = flip, last = last, hint = hint)
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Button({ vm.reviewPly = 0 }) { Text("|<") }
                Button({ if (ply > 0) vm.reviewPly = ply - 1 }) { Text("<") }
                Button({ flipView = !flipView }) { Icon(Icons.Rounded.SwapVert, "Flip board") }
                Button({ if (ply < r.moves.size) vm.reviewPly = ply + 1 }) { Text(">") }
                Button({ vm.reviewPly = r.moves.size }) { Text(">|") }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (mv != null) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            ClsDot(mv.cls, 24.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("${mv.san} - ${mv.cls.label}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }
                        val bestBefore = r.bestSan[ply - 1]
                        if (bestBefore != null && mv.loss > 5) Text("Tsara kokoa: $bestBefore")
                    } else {
                        Text("Toerana fanombohana", fontWeight = FontWeight.Bold)
                    }
                    Text("Eval: ${r.evalTexts[ply]}")
                    val nxt = r.bestSan[ply]
                    if (nxt != null) Text("Stockfish manoro: $nxt")
                }
            }
        }
        item { EvalGraph(r.evalsWhite, ply) }
        items(pairCount) { i ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${i + 1}.", Modifier.width(32.dp), color = Color.Gray)
                MoveChip(r.moves[2 * i], ply == 2 * i + 1, Modifier.weight(1f)) { vm.reviewPly = 2 * i + 1 }
                if (2 * i + 1 < r.moves.size) {
                    MoveChip(r.moves[2 * i + 1], ply == 2 * i + 2, Modifier.weight(1f)) { vm.reviewPly = 2 * i + 2 }
                } else Spacer(Modifier.weight(1f))
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
