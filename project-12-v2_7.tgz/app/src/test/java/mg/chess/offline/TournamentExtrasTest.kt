package mg.chess.offline

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TournamentExtrasTest {
    private fun humans(n: Int) = List(n) { Participant("h$it", "P$it", 1000 + it, null) }

    private fun sa(br: Int, gr: Int, acc: Double) = SideAn(20, acc, 30, br, gr, 0, 0)

    @Test fun bracketHasAllRoundsEvenBeforePlay() {
        val t = Tournament.create(1L, "T", humans(8), 0L, 0L, false)
        val rounds = t.bracket()
        assertEquals(listOf(4, 2, 1), rounds.map { it.size })
        assertEquals("Mpandresy 1", rounds[1][0].whiteLabel)
    }

    @Test fun bracketWithGroupsShowsPlaceholders() {
        val t = Tournament.create(2L, "T", humans(12), 0L, 0L, true)
        val rounds = t.bracket()
        assertEquals(t.groups.size * 2, t.firstKoSize())
        assertTrue(rounds[0][0].whiteLabel.startsWith("1er"))
    }

    @Test fun podiumGivesGoldAndSilver() {
        val t = Tournament.create(3L, "T", humans(2), 0L, 0L, false)
        assertNull(t.podium())
        val m = t.matches.first { it.stage == "KO2" }
        t.recordResult(m, "1-0")
        t.advance()
        val pd = t.podium()
        assertNotNull(pd)
        assertEquals(m.whiteId, pd!!.first)
        assertEquals(m.blackId, pd.second)
    }

    @Test fun playerLinesSumBrilliantAndAccuracy() {
        val t = Tournament.create(4L, "T", humans(2), 0L, 0L, false)
        val m = t.matches.first { it.stage == "KO2" }
        m.moves = listOf("e2e4", "e7e5", "g1f3", "b8c6")
        t.recordResult(m, "1-0")
        m.analysis = MatchAnalysis(sa(2, 1, 90.0), sa(0, 3, 70.0), listOf(BrilliantMove(5, true, "Nxe5", "f3e5", "x")))
        val lines = t.playerLines().associateBy { it.id }
        assertEquals(2, lines[m.whiteId]!!.brilliant)
        assertEquals(3, lines[m.blackId]!!.great)
        assertEquals(90.0, lines[m.whiteId]!!.accuracy!!, 1e-9)
        assertEquals(1, t.brilliantArchive().size)
        assertEquals(1, t.analysedCount())
    }
}
