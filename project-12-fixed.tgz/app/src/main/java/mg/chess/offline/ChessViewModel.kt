package mg.chess.offline

import android.app.Application
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.PieceType
import com.github.bhlangonijr.chesslib.Side
import com.github.bhlangonijr.chesslib.Square
import com.github.bhlangonijr.chesslib.move.Move
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

enum class Screen { MENU, BOTS, GAME, REVIEW, HISTORY, SETTINGS, TOUR_LIST, TOUR_NEW, TOURNAMENT, WATCH, PGN }

/** Lalao bot vs bot mandeha (simulation) - azo arahina live. */
class SimState(val matchId: Int, val board: Board, w: Long, b: Long) {
    var version by mutableIntStateOf(0)
    var whiteMs by mutableLongStateOf(w)
    var blackMs by mutableLongStateOf(b)
    var thinkStart by mutableLongStateOf(0L)
    var thinkingWhite by mutableStateOf(true)
    var last by mutableStateOf<Pair<Square, Square>?>(null)
    var plies by mutableIntStateOf(0)
    var result by mutableStateOf<String?>(null)
}

private val PROMO_ORDER = listOf(PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT)

class ChessViewModel(app: Application) : AndroidViewModel(app) {
    private val engine = Engine(app)
    private val store = GameStore(app)
    private val tourStore = TournamentStore(app)
    private val prefs = app.getSharedPreferences("chess_prefs", 0)

    // Settings
    var darkMode by mutableStateOf(true); private set
    /** Halalin'ny fanadihadiana (Stockfish depth): 12 haingana, 16 antonony, 20 lalina. */
    var reviewDepth by mutableIntStateOf(16); private set

    // Fifaninanana
    var tournaments by mutableStateOf<List<Tournament>>(emptyList()); private set
    var tour by mutableStateOf<Tournament?>(null); private set
    var tourVersion by mutableIntStateOf(0); private set
    var tourMatch by mutableStateOf<TMatch?>(null); private set
    var sim by mutableStateOf<SimState?>(null); private set
    var watchId by mutableIntStateOf(-1)
    var watchDelay by mutableLongStateOf(600L)
    var simRunningId by mutableIntStateOf(-1); private set
    var autoMode by mutableStateOf(false); private set
    private val simQueue = ArrayDeque<Int>()
    private var simJob: Job? = null
    private var reviewReturn = Screen.GAME

    var board = Board(); private set
    var version by mutableIntStateOf(0); private set
    var screen by mutableStateOf(Screen.MENU)
    var bot by mutableStateOf<Bot?>(null); private set
    var vsBot by mutableStateOf(false); private set
    var humanWhite by mutableStateOf(true); private set
    var selected by mutableStateOf<Square?>(null)
    var thinking by mutableStateOf(false); private set
    var message by mutableStateOf("")
    var over by mutableStateOf(false); private set
    val played = mutableStateListOf<Move>()

    // Fijerena tantara (hetsika aloha / manaraka) sy flip board
    /** -1 = zava-misy ankehitriny; 0..n = fijerena ny toerana aorian'ny hetsika faha-n. */
    var viewPly by mutableIntStateOf(-1); private set
    var flipped by mutableStateOf(false); private set

    // Draw / fanapahana
    var drawDialog by mutableStateOf(false)
    var resignDialog by mutableStateOf(false)
    private var forced: String? = null
    private var forcedMsg = ""

    // Promotion
    var promoMoves by mutableStateOf<List<Move>?>(null); private set

    // Clock
    var tc by mutableStateOf(TIME_CONTROLS[0])
    var clockOn by mutableStateOf(false); private set
    var whiteMs by mutableLongStateOf(0L); private set
    var blackMs by mutableLongStateOf(0L); private set
    private var baseMs = 0L
    private var incMs = 0L
    private var flagged: Side? = null
    private var paused = false
    private var tickJob: Job? = null

    // Fitehirizana
    var saved by mutableStateOf<List<GameRecord>>(emptyList()); private set
    private var gameId = 0L
    private var result: String? = null

    // Review
    var review by mutableStateOf<ReviewResult?>(null); private set
    var reviewProgress by mutableStateOf(0f); private set
    var reviewError by mutableStateOf<String?>(null); private set
    var reviewPly by mutableIntStateOf(0)

    private var botJob: Job? = null
    private var reviewJob: Job? = null
    private var pgnJob: Job? = null

    // Commentaire live (peo lahy + vavy, anglisy)
    val commentator = Commentator(app)
    var commentaryOn by mutableStateOf(true); private set
    var commentaryLevel by mutableIntStateOf(2); private set
    private var gameBrain: CommentaryBrain? = null
    private var simBrain: CommentaryBrain? = null
    private var simBrainId = -1
    private var gameResultSaid = true
    private var lastMoveAt = SystemClock.elapsedRealtime()

    // Fampidirana ny match (VS) sy evenement
    var matchInfo by mutableStateOf<MatchIntroData?>(null); private set
    var introShown by mutableStateOf(false); private set
    private var pendingBotMove = false

    // PGN -> bot
    var pgnGames by mutableStateOf<List<PgnGame>>(emptyList()); private set
    var pgnProgress by mutableStateOf<Float?>(null); private set
    var pgnError by mutableStateOf<String?>(null)
    var pgnDraft by mutableStateOf<PgnBotDraft?>(null)

    init {
        BotRegistry.load(app)
        saved = store.list()
        tournaments = tourStore.list()
        darkMode = prefs.getBoolean("dark", true)
        reviewDepth = prefs.getInt("review_depth", 16)
        commentaryOn = prefs.getBoolean("commentary", true)
        commentaryLevel = prefs.getInt("commentary_level", 2)
        commentator.enabled = commentaryOn
        startCommentaryLoop()
    }

    fun setDark(b: Boolean) { darkMode = b; prefs.edit().putBoolean("dark", b).apply() }
    fun chooseReviewDepth(d: Int) { reviewDepth = d; prefs.edit().putInt("review_depth", d).apply() }
    fun toSettings() { screen = Screen.SETTINGS }

    fun setCommentary(on: Boolean) {
        commentaryOn = on
        commentator.enabled = on
        prefs.edit().putBoolean("commentary", on).apply()
        if (!on) commentator.stop()
    }

    fun testCommentary() {
        if (!commentaryOn) setCommentary(true)
        commentator.stop()
        commentator.say(listOf(
            CLine(Voice.FEMALE, "Welcome, everyone, to this special moment! Koto versus Fara, the grand final!", Mood.EXCITED, 3),
            CLine(Voice.MALE, "Oh my God, what a blunder! Oh wait, he sacrifices the rook, that's a brilliant move!", Mood.SHOCKED, 3),
            CLine(Voice.FEMALE, "Maybe Koto can survive at this position, or his road is going to stop here.", Mood.THOUGHTFUL, 3)
        ))
    }

    @JvmName("updateCommentaryLevel")
    fun setCommentaryLevel(l: Int) {
        commentaryLevel = l
        prefs.edit().putInt("commentary_level", l).apply()
        gameBrain?.level = l
        simBrain?.level = l
    }

    /** Bouton nav: 0 play, 1 competition, 2 game history, 3 settings. */
    fun goTab(i: Int) {
        when (i) {
            0 -> if (screen != Screen.MENU) { botJob?.cancel(); screen = Screen.MENU }
            1 -> if (tabOf(screen) != 1) toTourList()
            2 -> toHistory()
            3 -> screen = Screen.SETTINGS
        }
    }

    // ---------- Fanombohana lalao ----------
    fun startHumanGame() = startGame(null, true)
    fun startBotGame(b: Bot, white: Boolean) = startGame(b, white)
    fun restart() {
        if (tourMatch != null) return
        TIME_CONTROLS.firstOrNull { it.baseMin * 60_000L == baseMs && it.incSec * 1000L == incMs }?.let { tc = it }
        startGame(bot, humanWhite, showIntro = false)
    }
    fun toBots() { screen = Screen.BOTS }
    fun toHistory() { saved = store.list(); screen = Screen.HISTORY }

    private fun startGame(b: Bot?, white: Boolean, showIntro: Boolean = true) {
        botJob?.cancel(); reviewJob?.cancel(); pgnJob?.cancel(); pgnProgress = null
        engine.newGame()
        board = Board()
        tourMatch = null
        played.clear(); review = null; reviewError = null; promoMoves = null
        forced = null; forcedMsg = ""; viewPly = -1; flipped = false; drawDialog = false; resignDialog = false
        bot = b; vsBot = b != null; humanWhite = white
        selected = null; thinking = false; flagged = null
        gameId = System.currentTimeMillis()
        baseMs = tc.baseMin * 60_000L; incMs = tc.incSec * 1000L
        clockOn = baseMs > 0; whiteMs = baseMs; blackMs = baseMs
        screen = Screen.GAME
        matchInfo = friendlyInfo(b, white)
        introShown = showIntro
        pendingBotMove = false
        resetCommentary()
        refresh(); startTicker()
        if (!introShown) startGameCommentary(false)
        if (vsBot && !humanWhite) { if (introShown) pendingBotMove = true else botMove() }
    }

    private fun clockText(): String = if (baseMs <= 0) "Tsy misy" else "${baseMs / 60000}+${incMs / 1000}"

    private fun friendlyInfo(b: Bot?, white: Boolean): MatchIntroData {
        val me = IntroSide(PlayerProfile.name, null, null, true, white)
        if (b == null) {
            return MatchIntroData(
                "Match amicale", "Olona vs Olona",
                me.copy(white = true), IntroSide("Mpilalao 2", null, null, false, false), clockText()
            )
        }
        val opp = IntroSide(b.name, b.elo, b, false, !white)
        val l = if (white) me else opp
        val r = if (white) opp else me
        return MatchIntroData("Match amicale", "vs Bot ${tierOf(b.elo).label}", l, r, clockText())
    }

    /** Alefaso ny lalao aorian'ny pejy fampidirana. */
    fun dismissIntro() {
        introShown = false
        startGameCommentary(played.isNotEmpty())
        if (pendingBotMove) {
            pendingBotMove = false
            if (vsBot && !humanTurn() && !over && !thinking) botMove()
        }
    }

    fun loadGame(rec: GameRecord, thenReview: Boolean = false) {
        botJob?.cancel(); reviewJob?.cancel()
        val b = Board()
        val list = ArrayList<Move>()
        for (u in rec.moves) {
            val m = b.legalMoves().firstOrNull { it.toString().equals(u, true) } ?: break
            b.doMove(m); list.add(m)
        }
        board = b
        played.clear(); played.addAll(list)
        review = null; reviewError = null; promoMoves = null
        forced = null; forcedMsg = ""; viewPly = -1; flipped = false; drawDialog = false; resignDialog = false
        gameId = rec.id
        tourMatch = null
        bot = BotRegistry.find(rec.botId)
        vsBot = bot != null; humanWhite = rec.humanWhite
        baseMs = rec.baseMs; incMs = rec.incMs
        clockOn = baseMs > 0; whiteMs = rec.whiteMs; blackMs = rec.blackMs
        flagged = when {
            clockOn && whiteMs <= 0L -> Side.WHITE
            clockOn && blackMs <= 0L -> Side.BLACK
            else -> null
        }
        selected = null; thinking = false
        screen = Screen.GAME
        val natural = naturalResult(b)
        if (rec.result != null && natural == null && flagged == null) {
            forced = rec.result
            forcedMsg = forcedText(rec.result)
        }
        matchInfo = friendlyInfo(bot, humanWhite); introShown = false; pendingBotMove = false
        resetCommentary()
        refresh(); startTicker()
        if (thenReview) startReview()
        else if (vsBot && !humanTurn() && !over) botMove()
    }

    fun deleteGame(id: Long) { store.delete(id); saved = store.list() }

    fun saveGame() {
        if (played.isEmpty() || gameId == 0L) return
        store.save(
            GameRecord(
                gameId, bot?.id, humanWhite, baseMs, incMs,
                played.map { it.toString() }, whiteMs, blackMs, result, System.currentTimeMillis()
            )
        )
        saved = store.list()
    }

    fun toMenu() {
        botJob?.cancel(); reviewJob?.cancel()
        thinking = false
        introShown = false; pendingBotMove = false
        if (tourMatch != null) {
            tourMatch = null
            tourVersion++
            screen = Screen.TOURNAMENT
            return
        }
        saveGame()
        screen = Screen.MENU
    }

    // ---------- Clock ----------
    fun setPaused(p: Boolean) { paused = p; if (p) commentator.stop() }

    private fun startTicker() {
        tickJob?.cancel()
        if (!clockOn) return
        var last = SystemClock.elapsedRealtime()
        tickJob = viewModelScope.launch {
            while (true) {
                delay(100)
                val now = SystemClock.elapsedRealtime()
                val dt = now - last
                last = now
                if (paused || screen != Screen.GAME || played.isEmpty() || over) continue
                if (board.sideToMove == Side.WHITE) {
                    whiteMs = max(0L, whiteMs - dt)
                    if (whiteMs == 0L) flag(Side.WHITE)
                } else {
                    blackMs = max(0L, blackMs - dt)
                    if (blackMs == 0L) flag(Side.BLACK)
                }
            }
        }
    }

    private fun flag(s: Side) {
        flagged = s
        refresh()
        saveGame()
        syncTour()
        cResultGame("timeout")
    }

    // ---------- Lalao ----------
    private fun humanTurn() = !vsBot || (board.sideToMove == Side.WHITE) == humanWhite

    fun legalFrom(sq: Square): List<Move> = board.legalMoves().filter { it.from == sq }

    fun onSquare(sq: Square) {
        if (viewPly >= 0) { viewPly = -1; return }
        if (thinking || over || promoMoves != null || !humanTurn()) return
        val sel = selected
        val piece = board.getPiece(sq)
        val own = piece != Piece.NONE && piece.pieceSide == board.sideToMove
        if (sel == null || own) {
            selected = if (own) sq else null
            return
        }
        val cands = legalFrom(sel).filter { it.to == sq }
        if (cands.isEmpty()) { selected = null; return }
        val promos = cands.filter { it.promotion != Piece.NONE }
        if (promos.isNotEmpty()) {
            promoMoves = promos.sortedBy { PROMO_ORDER.indexOf(it.promotion.pieceType) }
            return
        }
        selected = null
        applyMove(cands[0])
        if (vsBot && !over) botMove()
    }

    fun choosePromotion(m: Move) {
        promoMoves = null
        applyMove(m)
        if (vsBot && !over) botMove()
    }

    fun cancelPromotion() { promoMoves = null; selected = null }

    private fun applyMove(mv: Move) {
        val mover = board.sideToMove
        val preFen = board.fen
        board.doMove(mv)
        played.add(mv)
        if (clockOn) {
            if (mover == Side.WHITE) whiteMs += incMs else blackMs += incMs
        }
        selected = null
        viewPly = -1
        refresh()
        saveGame()
        syncTour()
        cMoveGame(preFen, mv)
    }

    private fun botMove() {
        val b = bot ?: return
        thinking = true
        botJob?.cancel()
        botJob = viewModelScope.launch {
            val remaining = if (board.sideToMove == Side.WHITE) whiteMs else blackMs
            val mt = if (clockOn) min(b.movetimeMs.toLong(), max(50L, remaining / 25)).toInt() else b.movetimeMs
            val uci = engine.bestMove(board.fen, b.copy(movetimeMs = mt), played.map { it.toString() })
            thinking = false
            if (over) return@launch
            val mv = board.legalMoves().firstOrNull { it.toString().equals(uci, true) }
            if (mv != null) applyMove(mv) else message = "Stockfish tsy namaly"
        }
    }

    fun undo() {
        if (tourMatch != null) return
        if (thinking || played.isEmpty() || flagged != null || forced != null) return
        viewPly = -1
        board.undoMove(); played.removeAt(played.lastIndex)
        if (vsBot && !humanTurn() && played.isNotEmpty()) {
            board.undoMove(); played.removeAt(played.lastIndex)
        }
        selected = null; promoMoves = null
        refresh()
        saveGame()
        if (vsBot && !humanTurn() && !over) botMove()
    }

    private fun insufficientMaterial(b: Board): Boolean {
        val placement = b.fen.substringBefore(" ")
        if (placement.any { it in "pPrRqQ" }) return false
        val minors = placement.count { it in "nNbB" }
        return minors <= 1
    }

    /** Valiny voajanahary: checkmate, stalemate, draw (repetition / 50 hetsika / material tsy ampy). */
    private fun naturalResult(b: Board): String? {
        if (b.isMated) return if (b.sideToMove == Side.WHITE) "0-1" else "1-0"
        if (b.legalMoves().isEmpty() || b.isDraw) return "1/2-1/2"
        return null
    }

    private fun sideName(s: Side) = if (s == Side.WHITE) "Fotsy" else "Mainty"

    private fun forcedText(r: String): String = when (r) {
        "1/2-1/2" -> "Draw - nifanaiky"
        "1-0" -> "Fotsy no nahazo (nitsoaka ny Mainty)"
        else -> "Mainty no nahazo (nitsoaka ny Fotsy)"
    }

    private fun refresh() {
        val noMoves = board.legalMoves().isEmpty()
        val mated = board.isMated
        val stalemate = !mated && noMoves && !board.isKingAttacked
        val natural = naturalResult(board)
        val f = flagged
        val fr = forced
        result = when {
            f == Side.WHITE -> "0-1"
            f == Side.BLACK -> "1-0"
            fr != null -> fr
            else -> natural
        }
        over = result != null
        message = when {
            f != null -> "Lany ora ny " + sideName(f) + " - " + sideName(if (f == Side.WHITE) Side.BLACK else Side.WHITE) + " no nahazo"
            fr != null -> forcedMsg
            mated -> "Checkmate! " + (if (board.sideToMove == Side.WHITE) "Mainty" else "Fotsy") + " no nahazo"
            stalemate -> "Stalemate - Draw (tsy afaka mihetsika ny " + sideName(board.sideToMove) + " fa tsy check)"
            natural != null && insufficientMaterial(board) -> "Draw - material tsy ampy hanao checkmate"
            natural != null && (board.fen.split(" ").getOrNull(4)?.toIntOrNull() ?: 0) >= 100 -> "Draw - fitsipika 50 hetsika"
            natural != null -> "Draw - fanamarihana (repetition intelo)"
            board.isKingAttacked -> "Check!"
            else -> ""
        }
        version++
    }

    // ---------- Hetsika aloha / manaraka, flip ----------
    fun flipBoard() { flipped = !flipped }

    fun navPrev() {
        val cur = if (viewPly < 0) played.size else viewPly
        if (cur > 0) viewPly = cur - 1
    }

    fun navNext() {
        if (viewPly < 0) return
        val n = viewPly + 1
        viewPly = if (n >= played.size) -1 else n
    }

    fun navFirst() { if (played.isNotEmpty()) viewPly = 0 }
    fun navLast() { viewPly = -1 }

    /** Toe-javatra aorian'ny hetsika faha-n (ho an'ny fijerena). */
    fun boardAtPly(n: Int): Board {
        val b = Board()
        for (i in 0 until minOf(n, played.size)) b.doMove(played[i])
        return b
    }

    // ---------- Draw / Resign ----------
    val canOfferDraw: Boolean
        get() = !over && played.size >= 2 && !thinking && promoMoves == null && (!vsBot || humanTurn())

    val canResign: Boolean get() = !over && played.isNotEmpty() && !thinking

    private fun finishForced(r: String, msg: String) {
        forced = r; forcedMsg = msg
        botJob?.cancel(); thinking = false
        drawDialog = false; resignDialog = false
        selected = null; viewPly = -1
        refresh()
        saveGame()
        syncTour()
        cResultGame(if (r == "1/2-1/2") "agreed" else "resign")
    }

    fun offerDraw() {
        if (!canOfferDraw) return
        val b = bot
        if (vsBot && b != null) {
            thinking = true
            message = b.name + " mandinika ny tolo-pitenenana draw..."
            botJob?.cancel()
            botJob = viewModelScope.launch {
                val ls = engine.analyze(board.fen, 12, 2500, 1)
                thinking = false
                // cp = araka ny mpilalao mihetsika (olona); ny bot = mifanohitra
                val botCp = -(ls.firstOrNull()?.stmCp() ?: 0)
                val accept = botCp <= -30 || (botCp <= 30 && played.size >= 60)
                if (accept) finishForced("1/2-1/2", "Draw - nankatoavin'i ${b.name}")
                else message = b.name + " tsy manaiky draw"
            }
        } else {
            drawDialog = true
        }
    }

    fun answerDraw(accept: Boolean) {
        drawDialog = false
        if (accept) finishForced("1/2-1/2", "Draw - nifanaiky ny roa tonta")
        else message = "Tsy nanaiky ny draw ny mpilalao faharoa"
    }

    fun resign() {
        resignDialog = false
        if (!canResign) return
        val s = if (vsBot) (if (humanWhite) Side.WHITE else Side.BLACK) else board.sideToMove
        val winner = if (s == Side.WHITE) Side.BLACK else Side.WHITE
        finishForced(if (s == Side.WHITE) "0-1" else "1-0", sideName(s) + " nitsoaka - " + sideName(winner) + " no nahazo")
    }

    // ---------- Review / Analyse ----------
    fun startReview() {
        if (played.isEmpty()) return
        botJob?.cancel(); reviewJob?.cancel()
        thinking = false
        screen = Screen.REVIEW
        review = null; reviewError = null; reviewProgress = 0f
        val moves = played.toList()
        reviewJob = viewModelScope.launch {
            try {
                val r = runReview(engine, START_FEN, moves, reviewDepth) { i, n -> reviewProgress = i.toFloat() / n }
                review = r
                reviewPly = moves.size
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                reviewError = e.message ?: "Hadisoana"
            }
        }
    }

    fun leaveReview() {
        reviewJob?.cancel()
        if (reviewReturn == Screen.TOURNAMENT) {
            reviewReturn = Screen.GAME
            screen = Screen.TOURNAMENT
            return
        }
        screen = Screen.GAME
        if (vsBot && !humanTurn() && !over && !thinking) botMove()
    }

    // ================= PGN -> BOT =================

    fun toPgn() { botJob?.cancel(); screen = Screen.PGN }

    fun cancelPgn() { pgnJob?.cancel(); pgnProgress = null }

    fun loadPgn(text: String) {
        pgnDraft = null
        val g = try { Pgn.parse(text) } catch (e: Exception) { emptyList() }
        pgnGames = g
        pgnError = if (g.isEmpty()) "Tsy nahita lalao azo vakiana ao amin'ny PGN (hetsika 3 farafahakeliny)." else null
    }

    /** Mandinika ny lalao nilalaovan'ny mpilalao amin'ny Stockfish, avy eo mamorona drafitra bot. */
    fun analyzePgnPlayer(player: String) {
        val mine = pgnGames.filter {
            it.moves.size >= 8 && (it.white.equals(player, true) || it.black.equals(player, true))
        }.take(5)
        if (mine.isEmpty()) { pgnError = "Tsy ampy hetsika ny lalao (8 farafahakeliny)."; return }
        botJob?.cancel(); reviewJob?.cancel(); pgnJob?.cancel()
        pgnError = null; pgnDraft = null; pgnProgress = 0f
        pgnJob = viewModelScope.launch {
            try {
                engine.newGame()
                val depth = min(reviewDepth, 14)
                val ratings = ArrayList<Int>(); val accs = ArrayList<Double>()
                val tally = HashMap<String, Int>(); val lines = ArrayList<String>()
                val styles = ArrayList<Style>(); val tagElos = ArrayList<Int>()
                for ((gi, g) in mine.withIndex()) {
                    val white = g.white.equals(player, true)
                    val uci = g.moves.take(80)
                    val b = Board(); val ml = ArrayList<Move>()
                    for (u in uci) {
                        val m = b.legalMoves().firstOrNull { it.toString().equals(u, true) } ?: break
                        b.doMove(m); ml.add(m)
                    }
                    val r = runReview(engine, START_FEN, ml, depth) { i, n -> pgnProgress = (gi + i.toFloat() / n) / mine.size }
                    val side = if (white) r.white else r.black
                    ratings.add(side.rating); accs.add(side.accuracy)
                    (if (white) g.whiteElo else g.blackElo)?.let { tagElos.add(it) }
                    for (o in Personality.detectOpenings(uci, white)) tally[o] = (tally[o] ?: 0) + 1
                    val line = Personality.gameLine(uci, white)
                    if (line !in lines) lines.add(line)
                    styles.add(Personality.deriveStyle(uci, white))
                }
                val rating = ratings.average().roundToInt()
                val tag = if (tagElos.isEmpty()) null else tagElos.average().roundToInt()
                val est = if (tag != null) (rating + tag) / 2 else rating
                val elo = ((est / 50.0).roundToInt() * 50).coerceIn(100, 3200)
                fun avg(f: (Style) -> Int) = styles.map(f).average().roundToInt()
                val style = Style(avg { it.aggression }, avg { it.sacrifice }, avg { it.defense }, avg { it.queen }, avg { it.trades })
                pgnDraft = PgnBotDraft(
                    player, mine.size, rating, tag, accs.average(), elo,
                    tally.entries.sortedByDescending { it.value }.take(3).map { it.key },
                    lines.take(6), style
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                pgnError = e.message ?: "Hadisoana tamin'ny fandinihana"
            } finally {
                pgnProgress = null
            }
        }
    }

    // ================= COMMENTAIRE LIVE =================

    private fun watching(id: Int) = commentaryOn && screen == Screen.WATCH && watchId == id

    private fun resetCommentary() {
        commentator.stop()
        gameBrain = null
        gameResultSaid = true
    }

    private fun cPlayerOf(name: String, elo: Int?, bot: Bot?): CPlayer = CPlayer(
        name, bot?.elo ?: elo, bot?.let { tierOf(it.elo).label }, bot != null,
        bot?.style?.aggression ?: 50, bot?.style?.sacrifice ?: 50, bot?.style?.defense ?: 50
    )

    private fun commentCtx(t: Tournament, m: TMatch): CMatch {
        val wp = t.player(m.whiteId)
        val bp = t.player(m.blackId)
        return CMatch(
            cPlayerOf(wp?.name ?: "White", wp?.elo, wp?.bot),
            cPlayerOf(bp?.name ?: "Black", bp?.elo, bp?.bot),
            m.stage, if (m.stage == "G") "Group " + ('A' + m.group) else null, t.name,
            t.baseMs, t.incMs, tourFacts(t, m), m.game
        )
    }

    private fun gameCtx(): CMatch? {
        val tm = tourMatch
        val t = tour
        if (tm != null && t != null) return commentCtx(t, tm)
        val info = matchInfo ?: return null
        val facts = ArrayList<String>()
        val b = bot
        if (b != null) {
            val gs = saved.filter { it.botId == b.id && it.result != null && it.result != "1/2-1/2" }
            if (gs.isNotEmpty()) {
                val won = gs.count { (it.result == "1-0") == it.humanWhite }
                facts += "In their previous games against ${b.name}, ${PlayerProfile.name} won $won and lost ${gs.size - won}."
            }
        }
        return CMatch(
            cPlayerOf(info.left.name, info.left.elo, info.left.bot),
            cPlayerOf(info.right.name, info.right.elo, info.right.bot),
            "", null, null, baseMs, incMs, facts
        )
    }

    /** Anaran'ny opening hita avy amin'ny hetsika (katalaogy OPENINGS), na null. */
    private fun openingNameOf(h: List<String>): String? {
        var best: Opening? = null
        var bestK = 0
        for (o in OPENINGS) for (l in o.lines) {
            var k = 0
            while (k < l.size && k < h.size && l[k].equals(h[k], true)) k++
            if (k > bestK) { bestK = k; best = o }
        }
        return if (bestK >= 5) best?.name else null
    }

    /** Zava-misy momba ny fifaninanana: ho lazain'ny mpanao commentaire rehefa mangina ny lalao. */
    private fun tourFacts(t: Tournament, m: TMatch): List<String> {
        val f = ArrayList<String>()
        val wn = t.name(m.whiteId)
        val bn = t.name(m.blackId)
        val alive = when (m.stage) { "KO16" -> 16; "KO8" -> 8; "KO4" -> 4; "KO2" -> 2; else -> 0 }
        if (alive > 0) f += "Only $alive players are still alive in ${t.name}."
        f += "${t.players.size} players entered ${t.name}."
        val top = t.players.maxByOrNull { it.elo }
        if (top != null && (top.name == wn || top.name == bn)) f += "${top.name} is the top seed of this tournament."
        // mpandresy teo aloha
        for (o in tournaments.filter { it.id != t.id && it.champion != null }.take(2)) {
            val champ = o.name(o.champion)
            f += if (champ == wn || champ == bn) "$champ arrives as the reigning champion of ${o.name}."
            else "Earlier, $champ lifted the trophy at ${o.name}."
        }
        // lalao vita ao amin'ity fifaninanana ity
        val done = t.matches.filter { it.id != m.id && (it.result == "1-0" || it.result == "0-1" || it.result == "1/2-1/2") }
        val quick = done.filter { it.result != "1/2-1/2" && it.moves.isNotEmpty() && it.moves.size <= 40 }
            .sortedBy { it.moves.size }.take(2)
        for (q in quick) {
            val w = if (q.result == "1-0") t.name(q.whiteId) else t.name(q.blackId)
            val l = if (q.result == "1-0") t.name(q.blackId) else t.name(q.whiteId)
            f += "$w beat $l in just ${(q.moves.size + 1) / 2} moves in the ${stageEnglish(q.stage, q.group)}."
        }
        for (id in listOfNotNull(m.whiteId, m.blackId)) {
            val mine = done.filter { it.whiteId == id || it.blackId == id }
            if (mine.size < 2) continue
            val wins = mine.count { (it.result == "1-0" && it.whiteId == id) || (it.result == "0-1" && it.blackId == id) }
            val losses = mine.count { (it.result == "0-1" && it.whiteId == id) || (it.result == "1-0" && it.blackId == id) }
            val name = t.name(id)
            f += if (losses == 0) "$name is still unbeaten in this tournament, with $wins wins from ${mine.size} games."
            else "$name has won $wins of ${mine.size} games so far in this tournament."
        }
        val h2h = done.filter {
            (it.whiteId == m.whiteId && it.blackId == m.blackId) || (it.whiteId == m.blackId && it.blackId == m.whiteId)
        }.firstOrNull()
        if (h2h != null) {
            f += when (h2h.result) {
                "1/2-1/2" -> "These two have already met in the ${stageEnglish(h2h.stage, h2h.group)}, and it ended in a draw."
                "1-0" -> "These two have already met in the ${stageEnglish(h2h.stage, h2h.group)}, and ${t.name(h2h.whiteId)} won."
                else -> "These two have already met in the ${stageEnglish(h2h.stage, h2h.group)}, and ${t.name(h2h.blackId)} won."
            }
        }
        return f
    }

    private fun startGameCommentary(resume: Boolean) {
        val ctx = gameCtx() ?: return
        val br = CommentaryBrain(ctx, { h -> openingNameOf(h) })
        br.level = commentaryLevel
        gameBrain = br
        gameResultSaid = over
        lastMoveAt = SystemClock.elapsedRealtime()
        if (!commentaryOn || over) return
        commentator.stop()
        commentator.say(if (resume) br.join(played.size) else br.intro().filter { it.pri >= 2 })
    }

    private fun cMoveGame(preFen: String, mv: Move) {
        lastMoveAt = SystemClock.elapsedRealtime()
        val br = gameBrain ?: return
        if (!commentaryOn || screen != Screen.GAME) return
        commentator.say(br.onMove(preFen, mv.toString(), played.map { it.toString() }, whiteMs, blackMs))
        if (over) cResultGame("")
    }

    private fun cResultGame(hint: String) {
        val br = gameBrain ?: return
        if (gameResultSaid || !commentaryOn) return
        val r = result ?: return
        gameResultSaid = true
        commentator.say(br.onResult(r, board.fen, played.size, if (flagged != null) "timeout" else hint))
    }

    /** Fotoana mangina: mitantara zavatra ny mpanao commentaire fa tsy mijanona fotsiny. */
    private fun idleLines(): List<CLine>? {
        val now = SystemClock.elapsedRealtime()
        if (screen == Screen.GAME) {
            val br = gameBrain ?: return null
            if (introShown || over || promoMoves != null) return null
            return br.idle(LiveSnap(board.fen, played.size, whiteMs, blackMs, clockOn, now - lastMoveAt))
        }
        if (screen == Screen.WATCH) {
            val st = sim ?: return null
            val br = simBrain ?: return null
            if (st.matchId != watchId || simBrainId != watchId || simRunningId != watchId || st.result != null) return null
            val think = if (st.thinkStart > 0L) now - st.thinkStart else 0L
            return br.idle(LiveSnap(st.board.fen, st.plies, st.whiteMs, st.blackMs, (tour?.baseMs ?: 0L) > 0L, think))
        }
        return null
    }

    private fun startCommentaryLoop() {
        viewModelScope.launch {
            var gap = 8_000L
            while (true) {
                delay(500)
                val live = screen == Screen.GAME || screen == Screen.WATCH
                if (!live || !commentaryOn || paused) {
                    if (commentator.busy || commentator.caption != null) commentator.stop()
                    continue
                }
                if (commentator.silentMs() < gap || commentator.pending() > 0) continue
                val ls = try { idleLines() } catch (e: Exception) { null } ?: continue
                commentator.say(ls)
                gap = if (commentaryLevel >= 2) 6_000L + (0..4_000).random() else 16_000L + (0..8_000).random()
            }
        }
    }

    override fun onCleared() { saveGame(); simJob?.cancel(); engine.stop(); commentator.shutdown() }

    // ================= FIFANINANANA =================

    fun toTourList() {
        botJob?.cancel()
        tourMatch = null
        screen = Screen.TOUR_LIST
    }
    fun toTourNew() { screen = Screen.TOUR_NEW }

    fun openTour(t: Tournament) {
        if (tour?.id != t.id) stopSim()
        tour = t; tourVersion++
        screen = Screen.TOURNAMENT
    }

    fun deleteTour(t: Tournament) {
        if (tour?.id == t.id) { stopSim(); tour = null }
        tourStore.delete(t.id)
        tournaments = tournaments.filter { it.id != t.id }
    }

    fun createTour(name: String, players: List<Participant>, baseMs: Long, incMs: Long, wantGroups: Boolean) {
        stopSim()
        val t = Tournament.create(System.currentTimeMillis(), name, players, baseMs, incMs, wantGroups)
        tourStore.save(t)
        tournaments = listOf(t) + tournaments
        openTour(t)
    }

    private fun tourSave() {
        val t = tour ?: return
        t.updated = System.currentTimeMillis()
        tourStore.save(t)
        tourVersion++
    }

    fun isBotMatch(m: TMatch): Boolean {
        val t = tour ?: return false
        return t.player(m.whiteId)?.bot != null && t.player(m.blackId)?.bot != null
    }

    fun tourPlayer(side: Side): Participant? {
        val m = tourMatch ?: return null
        return tour?.player(if (side == Side.WHITE) m.whiteId else m.blackId)
    }

    fun advanceTour() {
        val t = tour ?: return
        if (t.advance()) tourSave()
    }

    // ---------- Lalao olona ao anaty fifaninanana ----------
    fun playTourMatch(m: TMatch) {
        val t = tour ?: return
        if (m.result != null) return
        val wp = t.player(m.whiteId) ?: return
        val bp = t.player(m.blackId) ?: return
        if (wp.bot != null && bp.bot != null) return
        botJob?.cancel(); reviewJob?.cancel()
        val b = Board()
        played.clear()
        for (u in m.moves) {
            val mv = b.legalMoves().firstOrNull { it.toString().equals(u, true) } ?: break
            b.doMove(mv); played.add(mv)
        }
        board = b
        review = null; reviewError = null; promoMoves = null
        forced = null; forcedMsg = ""; viewPly = -1; flipped = false; drawDialog = false; resignDialog = false
        tourMatch = m
        bot = wp.bot ?: bp.bot
        vsBot = bot != null
        humanWhite = wp.bot == null
        baseMs = t.baseMs; incMs = t.incMs
        clockOn = baseMs > 0
        whiteMs = if (played.isEmpty()) baseMs else m.whiteMs
        blackMs = if (played.isEmpty()) baseMs else m.blackMs
        flagged = when {
            clockOn && played.isNotEmpty() && whiteMs <= 0L -> Side.WHITE
            clockOn && played.isNotEmpty() && blackMs <= 0L -> Side.BLACK
            else -> null
        }
        result = null
        selected = null; thinking = false
        gameId = 0L
        reviewReturn = Screen.GAME
        screen = Screen.GAME
        refresh(); startTicker()
        syncTour()
        val label = stageLabel(m.stage) + (if (m.stage == "G") " · " + groupName(m.group) else "")
        val sub = t.name + (if (m.game > 0) " · Lalao fanampiny ${m.game}" else "")
        matchInfo = MatchIntroData(
            label, sub,
            IntroSide(wp.name, wp.elo, wp.bot, wp.bot == null, true),
            IntroSide(bp.name, bp.elo, bp.bot, bp.bot == null, false),
            clockText()
        )
        pendingBotMove = false
        introShown = m.moves.isEmpty()
        resetCommentary()
        if (!introShown) startGameCommentary(true)
        if (vsBot && !humanTurn() && !over) { if (introShown) pendingBotMove = true else botMove() }
    }

    private fun syncTour() {
        val m = tourMatch ?: return
        val t = tour ?: return
        m.moves = played.map { it.toString() }
        m.whiteMs = whiteMs; m.blackMs = blackMs
        val r = result
        if (over && r != null && m.result == null) t.recordResult(m, r)
        tourSave()
    }

    // ---------- Simulation bot vs bot ----------
    private fun queuePending(t: Tournament) {
        for (m in t.stageMatches()) {
            if (m.result == null && isBotMatch(m) && m.id != simRunningId && m.id !in simQueue) simQueue.addLast(m.id)
        }
    }

    fun simOne(m: TMatch, watch: Boolean) {
        if (m.result != null || !isBotMatch(m)) return
        if (m.id != simRunningId) { simQueue.remove(m.id); simQueue.addFirst(m.id) }
        if (watch) {
            watchId = m.id; screen = Screen.WATCH
            val sb = simBrain
            if (commentaryOn && sb != null && simBrainId == m.id && simRunningId == m.id) {
                commentator.stop()
                commentator.say(sb.join(sim?.plies ?: m.moves.size))
            }
        }
        ensureSimLoop()
    }

    fun simAllPending() {
        val t = tour ?: return
        queuePending(t)
        ensureSimLoop()
    }

    fun runAuto() {
        val t = tour ?: return
        autoMode = true
        queuePending(t)
        ensureSimLoop()
    }

    fun stopSim() {
        simQueue.clear()
        autoMode = false
        simJob?.cancel()
        simRunningId = -1
        tourSave()
    }

    fun leaveWatch() { screen = Screen.TOURNAMENT }

    private fun ensureSimLoop() {
        if (simJob?.isActive == true) return
        simJob = viewModelScope.launch {
            try {
                while (true) {
                    val t = tour ?: break
                    if (simQueue.isEmpty()) {
                        if (!autoMode) break
                        if (t.champion != null) break
                        if (t.stageComplete()) { t.advance(); tourSave() }
                        if (t.champion != null) break
                        queuePending(t)
                        if (simQueue.isEmpty()) break
                    }
                    val id = simQueue.removeFirst()
                    val m = t.matches.firstOrNull { it.id == id } ?: continue
                    if (m.result != null) continue
                    simRunningId = id
                    try {
                        runSim(t, m)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        tourMsg = "Hadisoana: " + (e.message ?: "")
                    }
                    simRunningId = -1
                }
            } finally {
                simRunningId = -1
                autoMode = false
            }
        }
    }

    var tourMsg by mutableStateOf("")

    private suspend fun runSim(t: Tournament, m: TMatch) {
        val wb = t.player(m.whiteId)?.bot ?: return
        val bb = t.player(m.blackId)?.bot ?: return
        val b = Board()
        val moves = ArrayList<String>()
        for (u in m.moves) {
            val mv = b.legalMoves().firstOrNull { it.toString().equals(u, true) } ?: break
            b.doMove(mv); moves.add(u)
        }
        val clock = t.baseMs > 0
        var wMs = if (moves.isEmpty() || !clock) t.baseMs else m.whiteMs
        var bMs = if (moves.isEmpty() || !clock) t.baseMs else m.blackMs
        val st = SimState(m.id, b, wMs, bMs)
        st.plies = moves.size
        sim = st
        val brain = CommentaryBrain(commentCtx(t, m), { h -> openingNameOf(h) })
        brain.level = commentaryLevel
        simBrain = brain; simBrainId = m.id
        if (watching(m.id)) {
            commentator.stop()
            commentator.say(if (moves.isEmpty()) brain.intro() else brain.join(moves.size))
            commentator.awaitCatchUp(45_000L, 0)
        }
        var reason = ""
        var res: String? = null
        while (res == null) {
            res = gameResult(b)
            if (res != null) break
            if (moves.size >= 500) { res = "1/2-1/2"; break }
            val white = b.sideToMove == Side.WHITE
            val pb = if (white) wb else bb
            val remaining = if (white) wMs else bMs
            val mt = if (clock) min(pb.movetimeMs.toLong(), max(50L, remaining / 25)).toInt() else pb.movetimeMs
            val t0 = SystemClock.elapsedRealtime()
            st.thinkingWhite = white
            st.thinkStart = t0
            val uci = engine.bestMove(b.fen, pb.copy(movetimeMs = mt), moves)
            val spent = SystemClock.elapsedRealtime() - t0
            st.thinkStart = 0L
            if (clock) {
                if (white) wMs = max(0L, wMs - spent) else bMs = max(0L, bMs - spent)
                if ((white && wMs <= 0L) || (!white && bMs <= 0L)) {
                    st.whiteMs = wMs; st.blackMs = bMs
                    res = if (white) "0-1" else "1-0"
                    reason = "timeout"
                    break
                }
            }
            val legal = b.legalMoves()
            val mv = legal.firstOrNull { it.toString().equals(uci, true) } ?: legal.random()
            val preFen = b.fen
            b.doMove(mv)
            moves.add(mv.toString())
            if (clock) { if (white) wMs += t.incMs else bMs += t.incMs }
            st.whiteMs = wMs; st.blackMs = bMs
            st.last = mv.from to mv.to
            st.plies = moves.size
            st.version++
            m.moves = moves.toList(); m.whiteMs = wMs; m.blackMs = bMs
            if (moves.size % 12 == 0) tourSave()
            if (watching(m.id)) {
                if (res == null && gameResult(b) == null) {
                    commentator.say(brain.onMove(preFen, mv.toString(), moves, wMs, bMs))
                    commentator.awaitCatchUp(4_000L, 1)
                }
                delay(watchDelay)
            }
        }
        m.moves = moves.toList(); m.whiteMs = wMs; m.blackMs = bMs
        st.result = res
        st.version++
        if (watching(m.id)) {
            commentator.say(brain.onResult(res ?: "1/2-1/2", b.fen, moves.size, reason))
            commentator.awaitCatchUp(10_000L, 0)
        }
        simBrain = null; simBrainId = -1
        t.recordResult(m, res ?: "1/2-1/2")
        tourSave()
    }

    // ---------- Review lalao fifaninanana ----------
    fun reviewTourMatch(m: TMatch) {
        if (m.moves.isEmpty()) return
        botJob?.cancel(); reviewJob?.cancel()
        val b = Board()
        val list = ArrayList<Move>()
        for (u in m.moves) {
            val mv = b.legalMoves().firstOrNull { it.toString().equals(u, true) } ?: break
            b.doMove(mv); list.add(mv)
        }
        board = b
        played.clear(); played.addAll(list)
        tourMatch = null
        bot = null; vsBot = false; humanWhite = true
        gameId = 0L
        resetCommentary()
        reviewReturn = Screen.TOURNAMENT
        startReview()
    }
}
