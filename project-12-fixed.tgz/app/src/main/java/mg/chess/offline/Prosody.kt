package mg.chess.offline

import kotlin.random.Random

/** Phrase kely iray amin'ny andalana: samy manana rate/pitch/volume sy fiatoana aorian'izay. */
data class Phrase(val text: String, val rate: Float, val pitch: Float, val volume: Float, val pauseAfterMs: Long)

/**
 * Mamadika andalana iray ho phrase maromaro mba hanana rythme toy ny mpanao commentaire sport:
 * - "!" = avo kokoa sy mafy kokoa, "?" = miakatra, "..." = miadana sy miandry, "." farany = midina
 * - TENSE mihafainganana, DRAMATIC miadana sy mietry, SHOCKED manao fihetsika voalohany
 * - teny miverimberina ("No, no, no!") mihamitombo isaky ny miverina
 */
object Prosody {
    private val splitRe = Regex("(?<=[,;:.!?…])\\s+")

    private fun key(s: String) = s.lowercase().filter { it.isLetter() }

    fun plan(l: CLine, rnd: Random = Random.Default): List<Phrase> {
        val parts = l.text.trim().split(splitRe).map { it.trim() }.filter { it.isNotEmpty() }
        if (parts.isEmpty()) return emptyList()
        val n = parts.size
        val out = ArrayList<Phrase>(n)
        var repeats = 0
        for ((i, p) in parts.withIndex()) {
            val last = p.last()
            val ell = p.endsWith("...") || p.endsWith("…")
            val prog = if (n > 1) i / (n - 1f) else 1f
            val words = p.split(' ').count { it.isNotBlank() }
            var rate = l.mood.rate
            var pitch = l.mood.pitch
            var vol = 0.9f
            var pause = when {
                ell -> 300L
                last == '.' -> 170L
                last == '?' -> 190L
                last == '!' -> 120L
                last == ',' || last == ';' || last == ':' -> 60L
                else -> 100L
            }
            when (l.mood) {
                Mood.TENSE -> { rate *= 1f + 0.10f * prog; pitch *= 1f + 0.05f * prog; pause = (pause * 0.8f).toLong() }
                Mood.EXCITED -> { rate *= 1f + 0.04f * prog; pitch *= 1f + 0.06f * prog; vol = 1f }
                Mood.SHOCKED -> {
                    pitch *= 1.05f; vol = 1f
                    if (i == 0) { rate *= 0.92f; pitch *= 1.06f }
                }
                Mood.DRAMATIC -> { rate *= 1f - 0.05f * prog; pitch *= 1f - 0.05f * prog; pause = (pause * 1.3f).toLong() }
                Mood.THOUGHTFUL -> pause = (pause * 1.2f).toLong()
                Mood.PLAYFUL -> pitch *= if (i % 2 == 0) 1.03f else 0.98f
                else -> {}
            }
            when {
                last == '!' -> { rate *= 1.04f; pitch *= 1.06f; vol = 1f }
                last == '?' -> { pitch *= 1.07f; rate *= 0.97f }
                ell -> { rate *= 0.88f; pitch *= 0.95f }
                i == n - 1 && last == '.' -> { pitch *= 0.96f; rate *= 0.96f }
            }
            if (words == 1 && last == '!') { pitch *= 1.06f; rate *= 0.9f; pause += 60L }
            if (i > 0 && key(parts[i - 1]) == key(p)) {
                repeats++
                pitch *= 1f + 0.05f * repeats
                rate *= 1.03f
                vol = 1f
            } else repeats = 0
            if (l.pri >= 3 && i == n - 1) { rate *= 0.97f }
            // fiovaovana kely kisendrasendra mba tsy ho robot loatra
            rate *= 1f + (rnd.nextFloat() - 0.5f) * 0.05f
            pitch *= 1f + (rnd.nextFloat() - 0.5f) * 0.05f
            out += Phrase(p, rate, pitch, vol, pause)
        }
        return out
    }
}
