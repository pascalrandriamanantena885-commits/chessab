package mg.chess.offline

import android.content.Context
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import android.os.Bundle
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Mpanao commentaire amin'ny peo: peo roa (lahy + vavy) avy amin'ny TextToSpeech an'ny Android (offline,
 * anglisy). Ny andalana dia lasa miandalana ary miresaka mifandimby. Raha tsy misy peo anglisy dia
 * mbola miseho ho soratra (caption) ny resaka.
 */
class Commentator(context: Context) {
    private val app = context.applicationContext

    /** Alefa / atsahatra. */
    var enabled by mutableStateOf(true)

    /** Feo vahoaka sy stinger (gasp, cheer, drumroll...). */
    val fx = CrowdFx(context)
    var fxEnabled by mutableStateOf(true)
        private set

    fun setFx(on: Boolean) {
        fxEnabled = on
        if (!on) fx.stopAmbient()
    }

    /** Andalana lazaina ankehitriny (ho an'ny soratra eo amin'ny efijery). */
    var caption by mutableStateOf<CLine?>(null)
        private set

    /** Hafatra raha tsy mandeha ny peo (ohatra: tsy misy peo anglisy napetraka). */
    var status by mutableStateOf("")
        private set

    private class Eng {
        @Volatile var tts: TextToSpeech? = null
        @Volatile var ready = false
        @Volatile var failed = false
        @Volatile var basePitch = 1f
        @Volatile var voiceName = ""
    }

    private class Item(val line: CLine, val at: Long)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val engines = HashMap<Voice, Eng>()
    private val waiters = ConcurrentHashMap<String, CompletableDeferred<Unit>>()
    private val queue = ArrayDeque<Item>()
    private var runner: Job? = null
    private var captionJob: Job? = null
    private var current: CLine? = null
    private var seq = 0
    private var lastActivity = SystemClock.elapsedRealtime()
    private var initDone = false
    @Volatile private var lineToken = 0
    private var lastCueAt = 0L
    private var ambientJob: Job? = null
    private var exciteJob: Job? = null
    private var excitement = 0f

    /** Marina rehefa Stockfish (LiveEval) no mitsara ny hetsika: tsy mampiasa ny teny ho an'ny gasp/cheer. */
    @Volatile var evalDriven = false

    // ---------- fanombohana ----------
    private fun ensureInit() {
        if (initDone) return
        initDone = true
        initVoice(Voice.FEMALE)
        initVoice(Voice.MALE)
    }

    private fun initVoice(who: Voice) {
        val eng = Eng()
        engines[who] = eng
        val holder = arrayOfNulls<TextToSpeech>(1)
        try {
            holder[0] = TextToSpeech(app) { st ->
                val t = holder[0]
                if (st != TextToSpeech.SUCCESS || t == null) {
                    eng.failed = true
                    status = "Tsy mandeha ny peo (TextToSpeech tsy hita). Soratra ihany no miseho."
                } else {
                    configure(t, who, eng)
                }
            }
        } catch (e: Exception) {
            eng.failed = true
            status = "Tsy mandeha ny peo (TextToSpeech tsy hita). Soratra ihany no miseho."
        }
    }

    private fun maleByName(n: String) = n.contains("male") && !n.contains("female")
    private fun femaleByName(n: String) = n.contains("female")

    private fun configure(t: TextToSpeech, who: Voice, eng: Eng) {
        val lr = try { t.setLanguage(Locale.US) } catch (e: Exception) { TextToSpeech.LANG_NOT_SUPPORTED }
        if (lr == TextToSpeech.LANG_MISSING_DATA || lr == TextToSpeech.LANG_NOT_SUPPORTED) {
            eng.failed = true
            status = "Tsy misy peo anglisy napetraka ao amin'ny findainao. Apetraho ny \"English\" ao amin'ny Settings > Text-to-speech. Soratra ihany no miseho."
            return
        }
        eng.tts = t
        eng.basePitch = if (who == Voice.FEMALE) 1.14f else 0.84f
        try {
            val all = (t.voices ?: emptySet()).filter {
                it.locale.language == "en" && !it.features.contains("notInstalled")
            }.sortedWith(
                compareBy({ it.isNetworkConnectionRequired }, { it.locale != Locale.US }, { -it.quality })
            )
            val other = engines[if (who == Voice.FEMALE) Voice.MALE else Voice.FEMALE]?.voiceName ?: ""
            val named = all.firstOrNull {
                val n = it.name.lowercase()
                it.name != other && (if (who == Voice.FEMALE) femaleByName(n) else maleByName(n))
            }
            val pick = named ?: all.firstOrNull { it.name != other }
            if (pick != null) {
                t.voice = pick
                eng.voiceName = pick.name
                // raha mazava ny lahy/vavy avy amin'ny anarana dia kely ny fanovana peo; raha tsy izany, lehibe kokoa
                eng.basePitch = when {
                    named != null -> if (who == Voice.FEMALE) 1.04f else 0.94f
                    else -> eng.basePitch
                }
            }
        } catch (e: Exception) { /* mbola mety ny peo default */ }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { finish(utteranceId) }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { finish(utteranceId) }
            override fun onError(utteranceId: String?, errorCode: Int) { finish(utteranceId) }
            override fun onStop(utteranceId: String?, interrupted: Boolean) { finish(utteranceId) }
        })
        eng.ready = true
        if (engines.values.any { it.ready }) status = ""
    }

    private fun finish(id: String?) { if (id != null) waiters.remove(id)?.complete(Unit) }

    // ---------- fampiasana ----------
    val busy: Boolean get() = current != null || queue.isNotEmpty()

    fun pending(): Int = queue.size + (if (current != null) 1 else 0)

    /** Ora nandalovan'ny fotoana mangina (ms) hatramin'ny farany nandehanan'ny peo. */
    fun silentMs(): Long = if (busy) 0L else SystemClock.elapsedRealtime() - lastActivity

    fun say(lines: List<CLine>) {
        if (!enabled || lines.isEmpty()) return
        ensureInit()
        if (fxEnabled) { ambientJob?.cancel(); fx.startAmbient() }
        val now = SystemClock.elapsedRealtime()
        val top = lines.maxOf { it.pri }
        if (top >= 3) {
            queue.removeAll { it.line.pri <= 1 }
            if ((current?.pri ?: 9) <= 1) interrupt()
        } else if (top == 2) {
            queue.removeAll { it.line.pri <= 1 && now - it.at > 4_000L }
        }
        for (l in lines) queue.addLast(Item(l, now))
        while (queue.size > 8) {
            val i = queue.indexOfFirst { it.line.pri <= 1 }
            if (i < 0) break
            queue.removeAt(i)
        }
        lastActivity = now
        startRunner()
    }

    /** Miandry mandra ny lalao raha mbola miresaka ny mpanao commentaire (ho an'ny Watch). */
    suspend fun awaitCatchUp(maxMs: Long, maxPending: Int = 0) {
        if (!enabled) return
        var w = 0L
        while (pending() > maxPending && w < maxMs) { delay(80); w += 80 }
    }

    fun stop() {
        queue.clear()
        runner?.cancel(); runner = null
        interruptAll()
        current = null
        captionJob?.cancel()
        caption = null
        lastActivity = SystemClock.elapsedRealtime()
    }

    fun shutdown() {
        stop()
        for (e in engines.values) { try { e.tts?.shutdown() } catch (_: Exception) {} }
        engines.clear()
        exciteJob?.cancel()
        fx.release()
        scope.cancel()
    }

    /** Antsoina rehefa miala amin'ny app (onStop): atsahatra ny peo sy ny feo vahoaka. */
    fun onBackground() {
        stop()
        fx.stopAmbient()
    }

    private fun interrupt() {
        lineToken++
        val c = current ?: return
        try { engines[c.who]?.tts?.stop() } catch (_: Exception) {}
    }

    private fun interruptAll() {
        lineToken++
        for (e in engines.values) { try { e.tts?.stop() } catch (_: Exception) {} }
        for (d in waiters.values) d.complete(Unit)
        waiters.clear()
    }

    private fun startRunner() {
        if (runner?.isActive == true) return
        runner = scope.launch {
            try {
                while (isActive) {
                    val it = queue.removeFirstOrNull() ?: break
                    val age = SystemClock.elapsedRealtime() - it.at
                    if (it.line.pri <= 1 && age > 12_000L) continue
                    speak(it.line)
                }
            } finally {
                current = null
                lastActivity = SystemClock.elapsedRealtime()
                scheduleCaptionClear()
                scheduleAmbientStop()
            }
        }
    }

    private fun scheduleCaptionClear() {
        captionJob?.cancel()
        captionJob = scope.launch {
            delay(2800)
            if (!busy) caption = null
        }
    }

    private fun scheduleAmbientStop() {
        ambientJob?.cancel()
        ambientJob = scope.launch {
            delay(25_000L)
            if (!busy) fx.stopAmbient()
        }
    }

    /** Alefa ny feo mifanaraka amin'ny andalana. Mamerina ny fiandrasana (ms) alohan'ny hanombohan'ny peo. */
    private fun playCue(l: CLine): Long {
        if (!fxEnabled) return 0L
        val now = SystemClock.elapsedRealtime()
        val gap = if (l.pri >= 3) 1_500L else 6_000L
        if (now - lastCueAt < gap) return 0L
        val cues = CueMap.forLine(l, evalDriven)
        if (cues.isEmpty()) return 0L
        lastCueAt = now
        excite(if (l.pri >= 3) 0.8f else 0.5f)
        for (c in cues) {
            scope.launch {
                if (c.delayMs > 0) delay(c.delayMs)
                fx.play(c.name, c.vol)
            }
        }
        val first = cues.first().name
        return if (first == "crowd_gasp" || first == "crowd_groan" || first == "impact") 220L else 0L
    }

    /** Mampitombo ny hafanan'ny vahoaka (feo eo ambadika), mihena tsikelikely. */
    fun excite(level: Float) {
        if (!fxEnabled) return
        excitement = maxOf(excitement, level.coerceIn(0f, 1f))
        fx.setExcitement(excitement)
        if (exciteJob?.isActive == true) return
        exciteJob = scope.launch {
            while (excitement > 0.001f) {
                delay(400)
                excitement = maxOf(0f, excitement - 0.025f)
                fx.setExcitement(excitement)
            }
        }
    }

    /** Famaliana vahoaka avy amin'ny eval (Stockfish) an'ny hetsika vao natao. */
    fun react(r: Reaction) {
        if (!enabled || !fxEnabled) return
        val now = SystemClock.elapsedRealtime()
        val strong = r.kind == ReactKind.BLUNDER || r.kind == ReactKind.BRILLIANT
        if (now - lastCueAt < (if (strong) 1_200L else 3_000L)) return
        lastCueAt = now
        fx.startAmbient()
        when (r.kind) {
            ReactKind.BLUNDER -> {
                fx.play("crowd_gasp", 1f)
                if (r.delta <= -40.0) scope.launch { delay(120); fx.play("impact", 0.8f) }
                excite(1f)
            }
            ReactKind.MISTAKE -> { fx.play("crowd_groan", 0.7f); excite(0.6f) }
            ReactKind.BRILLIANT -> {
                fx.play("crowd_cheer_big", 0.85f)
                scope.launch { delay(350); fx.play("applause_short", 0.5f) }
                excite(1f)
            }
            ReactKind.FIND -> { fx.play("crowd_cheer_small", 0.7f); excite(0.7f) }
            ReactKind.MATE_ALERT -> { fx.play("riser", 0.6f); excite(0.85f) }
        }
    }

    private fun readMs(l: CLine) = 700L + l.text.length * 55L

    private suspend fun speak(l: CLine) {
        current = l
        captionJob?.cancel()
        caption = l
        if (l.pauseMs > 0) delay(l.pauseMs.toLong())
        val lead = playCue(l)
        if (lead > 0) delay(lead)
        // miandry ny fanombohan'ny peo (hatramin'ny 2.5 s)
        var waited = 0
        while (waited < 2500) {
            val e = engines[l.who]
            if (e == null || e.ready || e.failed) break
            delay(100); waited += 100
        }
        val e = engines[l.who]
        val t = e?.tts
        if (e != null && e.ready && t != null) {
            val tok = lineToken
            try {
                val phrases = Prosody.plan(l)
                for ((i, p) in phrases.withIndex()) {
                    if (tok != lineToken) break
                    speakPhrase(t, e, p)
                    if (tok != lineToken) break
                    if (i < phrases.lastIndex && p.pauseAfterMs > 0) delay(p.pauseAfterMs)
                }
            } catch (ex: CancellationException) {
                throw ex
            } catch (ex: Exception) {
                delay(readMs(l))
            }
        } else {
            delay(readMs(l))
        }
        // fiatoana kely voajanahary arakaraka ny fihetseham-po
        delay(if (l.mood == Mood.EXCITED || l.mood == Mood.SHOCKED || l.mood == Mood.TENSE) 90L else 230L)
        lastActivity = SystemClock.elapsedRealtime()
    }

    /** Mamaky phrase iray amin'ny rate/pitch/volume azy, ary miandry ny faran'ny peo. */
    private suspend fun speakPhrase(t: TextToSpeech, e: Eng, p: Phrase) {
        t.setSpeechRate(p.rate.coerceIn(0.5f, 2f))
        t.setPitch((p.pitch * e.basePitch).coerceIn(0.5f, 2f))
        val id = "c" + (++seq)
        val d = CompletableDeferred<Unit>()
        waiters[id] = d
        val params = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, p.volume.coerceIn(0.1f, 1f)) }
        val ok = t.speak(p.text, TextToSpeech.QUEUE_FLUSH, params, id) == TextToSpeech.SUCCESS
        if (ok) withTimeoutOrNull(3000L + p.text.length * 130L) { d.await() } else delay(700L + p.text.length * 55L)
        waiters.remove(id)
    }
}
