package mg.chess.offline

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Mpilalao iray ao amin'ny pejy fampidirana. bot = null raha olona. */
data class IntroSide(val name: String, val elo: Int?, val bot: Bot?, val you: Boolean, val white: Boolean)

/** event = "Demi-finale", "8ème de finale", "Phase de poule - Poule A", "Match amicale"... */
data class MatchIntroData(val event: String, val subtitle: String, val left: IntroSide, val right: IntroSide, val clock: String)

private val Gold = Color(0xFFFFD54F)

@Composable
fun MatchIntroOverlay(d: MatchIntroData, onStart: () -> Unit) {
    var go by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { go = true }
    val a by animateFloatAsState(if (go) 1f else 0f, tween(750), label = "slide")
    val vs by animateFloatAsState(if (go) 1f else 0f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow), label = "vs")
    val ev by animateFloatAsState(if (go) 1f else 0f, tween(500), label = "event")

    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0B130D), Color(0xFF1B2A17), Color(0xFF0B0B0B))))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
    ) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Hetsika / evenement
            Column(Modifier.graphicsLayer { alpha = ev; translationY = -(1f - ev) * 60f }, horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Rounded.EmojiEvents, null, tint = Gold, modifier = Modifier.size(44.dp))
                Spacer(Modifier.height(6.dp))
                Text(d.event.uppercase(), color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp, textAlign = TextAlign.Center)
                if (d.subtitle.isNotEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    Text(d.subtitle, color = Color(0xFFCFD8CF), fontSize = 14.sp, textAlign = TextAlign.Center)
                }
            }

            // Mpilalao roa
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Box(Modifier.weight(1f).graphicsLayer { alpha = a; translationX = -(1f - a) * 420f }, contentAlignment = Alignment.Center) { Fighter(d.left) }
                Text(
                    "VS", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp,
                    modifier = Modifier.padding(horizontal = 4.dp).graphicsLayer { scaleX = vs; scaleY = vs; alpha = vs.coerceIn(0f, 1f) }
                )
                Box(Modifier.weight(1f).graphicsLayer { alpha = a; translationX = (1f - a) * 420f }, contentAlignment = Alignment.Center) { Fighter(d.right) }
            }

            // Farany
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0x22FFFFFF)).padding(horizontal = 16.dp, vertical = 6.dp)) {
                    Text("Ora: ${d.clock}", color = Color.White, fontSize = 13.sp)
                }
                Button(onStart, Modifier.fillMaxWidth().height(54.dp)) {
                    Icon(Icons.Rounded.PlayArrow, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Hanomboka", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun Fighter(s: IntroSide) {
    val tier = s.bot?.let { tierOf(it.elo) }
    val ring = if (tier != null) Color(tier.color) else Color(0xFFB0BEC5)
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(Modifier.border(BorderStroke(3.dp, ring), CircleShape).padding(5.dp)) {
            if (s.bot != null) BotAvatar(s.bot, 104.dp) else PlayerAvatar(s.name, s.you, 104.dp)
        }
        Text(s.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 2)
        val sub = when {
            s.bot != null && s.bot.elo > SF_MAX_ELO -> "Stockfish 17.1"
            s.elo != null -> "Elo ${s.elo}"
            else -> "Mpilalao"
        }
        Text(sub, color = Color(0xFFCFD8CF), fontSize = 13.sp)
        if (tier != null) TierChip(tier)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(Modifier.size(12.dp).clip(CircleShape).background(if (s.white) Color.White else Color(0xFF222222)).border(1.dp, Color.Gray, CircleShape))
            Text(if (s.white) "Fotsy" else "Mainty", color = Color(0xFFCFD8CF), fontSize = 12.sp)
        }
    }
}

/** Andalana kely eo ambonin'ny board: evenement ao anaty lalao. */
@Composable
fun MatchRibbon(d: MatchIntroData) {
    Row(Modifier.fillMaxWidth().padding(bottom = 2.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        Icon(Icons.Rounded.EmojiEvents, null, tint = Gold, modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(5.dp))
        Text(
            d.event + (if (d.subtitle.isNotEmpty()) " · " + d.subtitle else ""),
            fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Gold, maxLines = 1
        )
    }
}
