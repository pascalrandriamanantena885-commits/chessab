package mg.chess.offline

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import kotlin.math.roundToInt
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(vm: ChessViewModel) {
    BackHandler { vm.toMenu() }
    val ctx = LocalContext.current
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Bot?>(null) }
    var copying by remember { mutableStateOf<Bot?>(null) }
    var deleting by remember { mutableStateOf<Bot?>(null) }
    val all = BotRegistry.visible
    var bgMsg by remember { mutableStateOf("") }
    // Photo picker = mamoha ny gallerie mivantana (tsy mila alalana)
    val bgPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) bgMsg = if (AppBackground.set(ctx, uri)) "Voasoloka ny sary aloha." else "Tsy azo vakiana io sary io."
    }
    val cardColors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { ScreenTitle("Settings") }
        item { PlayerProfileCard() }
        item {
            Card(Modifier.fillMaxWidth(), colors = cardColors) {
              Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Sary aloha (Background)", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                val bgImg = AppBackground.image
                if (bgImg != null) {
                    Image(
                        bgImg, null,
                        Modifier.fillMaxWidth().height(110.dp).clip(RoundedCornerShape(12.dp)),
                        contentScale = ContentScale.Crop
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button({ bgPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                        Text(if (bgImg == null) "Fidio sary (gallerie)" else "Ovay ny sary")
                    }
                    if (bgImg != null) OutlinedButton({ AppBackground.clear(ctx); bgMsg = "Nesorina ny sary aloha." }) { Text("Esory") }
                }
                if (bgImg != null) {
                    Text("Hamafin'ny fanaronana (ho an'ny fahitana ny soratra)", fontSize = 12.sp)
                    Slider(AppBackground.dim, { AppBackground.setDim(ctx, it) }, valueRange = 0.3f..0.95f)
                }
                if (bgMsg.isNotEmpty()) Text(bgMsg, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
              }
            }
        }
        item {
            Card(Modifier.fillMaxWidth(), colors = cardColors) {
              Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Fanadihadiana lalao (Stockfish 17.1)", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(vm.reviewDepth == 12, { vm.chooseReviewDepth(12) }, { Text("Haingana") })
                    FilterChip(vm.reviewDepth == 16, { vm.chooseReviewDepth(16) }, { Text("Antonony") })
                    FilterChip(vm.reviewDepth == 20, { vm.chooseReviewDepth(20) }, { Text("Lalina") })
                }
                Text("Depth ${vm.reviewDepth}: arakaraka ny halalina no mihamatotra ny review sy ny game rating, saingy lava kokoa.", fontSize = 12.sp)
              }
            }
        }
        item { GameplayCard(vm) }
        item { StyleCard() }
        item {
            Card(Modifier.fillMaxWidth(), colors = cardColors) {
              Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Commentaire live (peo)", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(vm.commentaryOn, { vm.setCommentary(true) }, { Text("Alefa") })
                    FilterChip(!vm.commentaryOn, { vm.setCommentary(false) }, { Text("Atsahatra") })
                }
                if (vm.commentaryOn) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(vm.commentaryLevel == 1, { vm.setCommentaryLevel(1) }, { Text("Zava-dehibe") })
                        FilterChip(vm.commentaryLevel == 2, { vm.setCommentaryLevel(2) }, { Text("Be resaka") })
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Feo vahoaka:", fontSize = 14.sp)
                        FilterChip(vm.crowdOn, { vm.setCrowd(true) }, { Text("Alefa") })
                        FilterChip(!vm.crowdOn, { vm.setCrowd(false) }, { Text("Atsahatra") })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Feo hetsika:", fontSize = 14.sp)
                    FilterChip(vm.moveSoundOn, { vm.setMoveSound(true) }, { Text("Alefa") })
                    FilterChip(!vm.moveSoundOn, { vm.setMoveSound(false) }, { Text("Atsahatra") })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Haptic:", fontSize = 14.sp)
                    FilterChip(vm.hapticOn, { vm.setHaptic(true) }, { Text("Alefa") })
                    FilterChip(!vm.hapticOn, { vm.setHaptic(false) }, { Text("Atsahatra") })
                }
                Text(
                    "Mpanao commentaire iray (Faly, lahy) amin'ny teny anglisy, toy ny lalao live: fampidirana, sacrifice, blunder, ora, tantara ary fampahalalana momba ny fifaninanana. Mandeha offline amin'ny peo anglisy napetraka ao amin'ny findainao (Settings > Text-to-speech).",
                    fontSize = 12.sp
                )
                OutlinedButton({ vm.testCommentary() }) { Text("Henoy ny peo") }
                val st = vm.commentator.status
                if (st.isNotEmpty()) Text(st, fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
              }
            }
        }
        item {
            Card(Modifier.fillMaxWidth(), colors = cardColors) {
              Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Endrika (theme)", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    FilterChip(!vm.darkMode, { vm.setDark(false) }, { Text("Mazava (Light)") })
                    Spacer(Modifier.width(8.dp))
                    FilterChip(vm.darkMode, { vm.setDark(true) }, { Text("Maizina (Dark)") })
                }
                Text("Tsy manaraka ny theme an'ny findainao ny app: ity safidy ity ihany no manapaka.", fontSize = 12.sp)
              }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Bot (${all.size})", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Button({ adding = true }) { Text("+ Bot vaovao") }
            }
        }
        items(all, key = { it.id }) { b ->
            Card(Modifier.fillMaxWidth(), colors = cardColors) {
                Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    BotAvatar(b, 44.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(b.name, fontWeight = FontWeight.Bold)
                        Text((if (b.elo > SF_MAX_ELO) "Stockfish 17.1 (hery feno)" else "Elo ${b.elo}") + if (b.custom) " - nataonao" else "", fontSize = 12.sp)
                        val spec = b.specialty()
                        if (spec.isNotEmpty()) Text(spec, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                    }
                    if (b.custom) {
                        TextButton({ editing = b }) { Text("Ovay") }
                    } else {
                        TextButton({ copying = b }) { Text("Kopia") }
                    }
                    OutlinedButton({ deleting = b }) { Text("Fafao") }
                }
            }
        }
        if (BotRegistry.hidden.isNotEmpty()) {
            item {
                OutlinedButton({ BotRegistry.restoreDefaults(ctx) }, Modifier.fillMaxWidth()) {
                    Text("Averina ny bot default voafafa (${BotRegistry.hidden.size})")
                }
            }
        }
    }

    if (adding) BotEditDialog(null) { adding = false }
    val ed = editing
    if (ed != null) BotEditDialog(ed) { editing = null }
    val cp = copying
    if (cp != null) BotEditDialog(cp, asCopy = true) { copying = null }
    val del = deleting
    if (del != null) {
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Fafana ny ${del.name}?") },
            text = { Text("Tsy fafana ny lalao efa voatahiry sy ny fifaninanana efa nisy azy, fa tsy ho hita intsony ao amin'ny lisitra.") },
            confirmButton = { Button({ BotRegistry.delete(ctx, del); deleting = null }) { Text("Fafao") } },
            dismissButton = { TextButton({ deleting = null }) { Text("Foano") } }
        )
    }
}

@Composable
private fun StyleSlider(label: String, low: String, high: String, value: Int, onChange: (Int) -> Unit) {
    Column {
        Row {
            Text(label, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text("$value", fontSize = 13.sp)
        }
        Slider(value.toFloat(), { onChange(it.roundToInt()) }, valueRange = 0f..100f)
        Row {
            Text(low, fontSize = 10.sp, modifier = Modifier.weight(1f))
            Text(high, fontSize = 10.sp)
        }
    }
}

private val STYLE_PRESETS = listOf(
    "Mpanao sacrifice" to Style(aggression = 85, sacrifice = 100, defense = 25, queen = 60, trades = 30),
    "Mpiaro" to Style(aggression = 20, sacrifice = 10, defense = 100, queen = 30, trades = 65),
    "Queen aloha" to Style(aggression = 65, queen = 100),
    "Mpanafika" to Style(aggression = 95, sacrifice = 65, defense = 30, trades = 35),
    "Positional" to Style(aggression = 35, sacrifice = 15, defense = 60, queen = 25, trades = 60),
    "Mahazatra" to Style(),
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BotEditDialog(existing: Bot?, asCopy: Boolean = false, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val target = if (asCopy) null else existing
    var name by remember { mutableStateOf(if (asCopy) (existing?.name ?: "") + " 2" else existing?.name ?: "") }
    var eloText by remember { mutableStateOf((existing?.elo ?: 1200).toString()) }
    var avatar by remember { mutableStateOf<Bitmap?>(null) }
    var openings by remember { mutableStateOf(existing?.openings ?: emptyList()) }
    var lines by remember { mutableStateOf(existing?.lines ?: emptyList()) }
    var style by remember { mutableStateOf(existing?.style ?: Style()) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) avatar = decodeAvatar(ctx, uri)
    }
    val elo = eloText.toIntOrNull()
    val valid = name.isNotBlank() && elo != null && elo in 100..3200
    val av = avatar

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (asCopy) "Kopia an'ny bot" else if (existing == null) "Bot vaovao" else "Ovay ny bot") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (av != null) {
                        Image(av.asImageBitmap(), null, Modifier.size(64.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                    } else if (existing != null) {
                        BotAvatar(existing, 64.dp)
                    } else {
                        Box(Modifier.size(64.dp).clip(CircleShape).background(Color(0xFF90A4AE)), contentAlignment = Alignment.Center) {
                            Text("?", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    OutlinedButton({ picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text("Fidio sary (gallerie)") }
                }
                OutlinedTextField(
                    name, { name = it.take(20) }, label = { Text("Anarana") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    eloText, { eloText = it.filter { c -> c.isDigit() }.take(4) },
                    label = { Text("Elo (100-3200)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Stockfish 17.1 no mampihatra ny Elo (UCI_Elo 1320-3190). Ambanin'ny 1320: fikarohana voafetra + hadisoana mitovy amin'ny olona. 3200 = hery feno.", fontSize = 12.sp)

                Text("Fomba filalaovana", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for ((label, st) in STYLE_PRESETS) {
                        FilterChip(style == st, { style = st }, { Text(label, fontSize = 12.sp) })
                    }
                }
                StyleSlider("Fanafihana", "milamina", "mpanafika", style.aggression) { style = style.copy(aggression = it) }
                StyleSlider("Sacrifice (gambit)", "tsy manao", "tia be", style.sacrifice) { style = style.copy(sacrifice = it) }
                StyleSlider("Fiarovana", "tsy miaro", "tia midefendre", style.defense) { style = style.copy(defense = it) }
                StyleSlider("Queen aloha", "tsy mamoaka", "mamoaka aloha", style.queen) { style = style.copy(queen = it) }
                StyleSlider("Fifanakalozana", "misoroka", "tia", style.trades) { style = style.copy(trades = it) }

                Text("Opening (repertoire)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("Fotsy", fontSize = 13.sp)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (o in OPENINGS.filter { it.white }) {
                        FilterChip(o.id in openings, {
                            openings = if (o.id in openings) openings - o.id else openings + o.id
                        }, { Text(o.name, fontSize = 12.sp) })
                    }
                }
                Text("Mainty", fontSize = 13.sp)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (o in OPENINGS.filter { !it.white }) {
                        FilterChip(o.id in openings, {
                            openings = if (o.id in openings) openings - o.id else openings + o.id
                        }, { Text(o.name, fontSize = 12.sp) })
                    }
                }
                if (lines.isNotEmpty()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Opening avy amin'ny lalao: ${lines.size}", fontSize = 13.sp, modifier = Modifier.weight(1f))
                        TextButton({ lines = emptyList() }) { Text("Esory") }
                    }
                }
                Text("Ny Stockfish ihany no misafidy ny hetsika; ny opening sy ny fomba no manosika azy hisafidy hetsika mitovy lanja, ka tsy simba ny Elo.", fontSize = 11.sp)
            }
        },
        confirmButton = {
            Button(
                onClick = { BotRegistry.save(ctx, target, name, elo ?: 1200, avatar, openings, lines, style); onDismiss() },
                enabled = valid
            ) { Text("Tehirizo") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Foano") } }
    )
}
