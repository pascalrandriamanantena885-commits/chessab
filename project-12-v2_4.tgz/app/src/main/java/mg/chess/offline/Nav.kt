package mg.chess.offline

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector

private data class Tab(val icon: ImageVector, val desc: String)

private val TABS = listOf(
    Tab(Icons.Rounded.PlayArrow, "Milalao"),
    Tab(Icons.Rounded.EmojiEvents, "Fifaninanana"),
    Tab(Icons.Rounded.History, "Tantaran'ny lalao"),
    Tab(Icons.Rounded.Settings, "Settings"),
)

val NAV_SCREENS = setOf(
    Screen.MENU, Screen.BOTS, Screen.TOUR_LIST, Screen.TOUR_NEW,
    Screen.TOURNAMENT, Screen.HISTORY, Screen.SETTINGS, Screen.PGN, Screen.STATS
)

fun tabOf(s: Screen): Int = when (s) {
    Screen.MENU, Screen.BOTS, Screen.PGN -> 0
    Screen.TOUR_LIST, Screen.TOUR_NEW, Screen.TOURNAMENT -> 1
    Screen.HISTORY, Screen.STATS -> 2
    Screen.SETTINGS -> 3
    else -> -1
}

/** Bouton nav 4: play, competition, game history, settings (icon fotsiny). */
@Composable
fun BottomNav(vm: ChessViewModel) {
    val sel = tabOf(vm.screen)
    NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
        TABS.forEachIndexed { i, t ->
            NavigationBarItem(
                selected = sel == i,
                onClick = { vm.goTab(i) },
                icon = { Icon(t.icon, contentDescription = t.desc) },
                alwaysShowLabel = false,
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
        }
    }
}
