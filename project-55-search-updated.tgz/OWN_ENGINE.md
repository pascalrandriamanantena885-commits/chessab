# JORO — motera manokana (own engine)

# Motera manokana (tsy miankina amin'ny Stockfish)

Toerana: `app/src/main/java/mg/chess/offline/own/` (Java madio, tsy mampiasa Android na chesslib).

- `Pos.java`   : board 0x88, hetsika marina, make/unmake, zobrist, repetition (perft voamarina).
- `Eval.java`  : evaluation (material, PST, piyon, mobility, fiarovana mpanjaka, fanafihana) + TOETRA: a/s/d/q/t.
- `Search.java`: iterative deepening, PVS, TT, null move, LMR, futility, quiescence; `thinkWeak` ho an'ny Elo ambany.
- `OwnBot.java`: API ho an'ny app + `profile(elo)` = {depth, tabataba cp}.

Fampiasana: `Engine.bestMove` -> opening book (Personality) -> OwnBot raha `OWN_ENGINE && elo <= OWN_MAX_ELO` (Bots.kt).
Ny Stockfish dia mijanona ho an'ny Review / Why / analyze sy ny bot > OWN_MAX_ELO.
Hanajanona: `const val OWN_ENGINE = false` ao amin'ny Bots.kt.

## Bot avy amin'ny PGN (`PgnBot.java`)
Ny motera manokana no mamorona bot avy amin'ny PGN, tsy mila Stockfish (ChessViewModel.analyzePgnPlayerOwn, raha `OWN_ENGINE`):
- **Book / opening favorite**: ny hetsika tena nataon'ilay mpilalao tamin'ny lalao ROHY (hatramin'ny 300), 24 ply voalohany, voarakitra amin'ny hash an'ny toerana (mahafantatra transposition). Lanja: fandresena 1.5, nul 1.2, resy 1.0; safidy ^1.5 (tia ny favorite). Tehirizina ao `Bot.book` (`<hash>:<uci>:<isa>`, <= 400) ary ampiasain'ny `Engine.bestMove` alohan'ny katalaogy opening.
- **Fomba / toetra** (a,s,d,q,t): `Personality.deriveStyle` amin'ny lalao rehetra (salanisa), ampiasain'ny `Eval`.
- **Elo**: ACPL amin'ny fikarohana an'ny motera manokana (hetsika 60 voafantina, depth 5), formula `3100*exp(-0.0086*ACPL)` (mitovy amin'ny Review), ampifangaroina amin'ny Elo ao amin'ny PGN raha misy. TSY mbola voatombana amin'ny lalao tena izy: azo ovaina eo amin'ny dialog alohan'ny fitehirizana.
- **Famintinana**: valiny, hetsika voalohany tiana, valiny amin'ny e4/d4.

Fanamarihana: `OWN_MAX_ELO` = 2500 (voatombana). Calibrate vs Stockfish `UCI_Elo` 2400-3000 (1500 ms/hetsika): JORO hery feno ~ **2518 ±60**
(2400: 2480 ±103, 2600: 2463 ±104, 2800: 2621 ±108; 3000 saturated). `OwnBot.profile`: depth 14/16 ho an'ny 2350/2450; > 2450 = hery feno (tsy misy fetra depth, fotoana x1). Ny Elo > 2500 dia Stockfish.

## Fanatsarana hery (Search v2)
SEE (fakana very), countermove, history gravity, IID, razoring, RFP/LMP/futility, LMR araka ny history/improving, TT replacement, time management. Mifanandrina amin'ny dikan-teny taloha (60 ms/hetsika, lalao 40): ~+70..80 Elo. OwnBot manampy fotoana (x1..x2) ho an'ny Elo 2200..2600. Tsy mbola voatombana amin'ny Stockfish UCI_Elo.

## Search v3 / Eval v3
- Eval: lanja scalar (`Eval.W`), outpost, fandrosoana piyon, tombo-pitsipika amin'ny piyon; PST/material/W voatombana (Texel) avy amin'ny lalao ~53k toerana (Tuner).
- Search: singular extension, TT cutoff amin'ny qsearch.
- Fandrefesana Elo tena izy: `tools/calibrate.yml` (workflow dispatch) → JORO vs Stockfish `UCI_Elo` 2000–2600 (`tools/calibrate.py`, `tools/OwnUci.java`). Ny vokatra no hanitsy ny `OwnBot.profile`/`OWN_MAX_ELO`.

## Fitaovana fandrefesana (Project 2800)
- `tools/Bench.java`: `java -cp cls mg.chess.offline.own.Bench [depth=9] [movetime=60]` → nodes/nps/depth.
- `tools/sprt.py`: SPRT vaovao vs taloha (`.github/workflows/sprt.yml`).
- `tools/OwnUci.java` dia mamoaka `info depth/score/nodes` (ampiasain'ny sprt.py ho an'ny adjudication).
- Fandrosoana: `ROADMAP_2800.md`.
- `tools/sprt.py --dump FILE`: manoratra toerana milamina `FEN;valiny_fotsy` (ho an'ny Texel). `--label` ho an'ny summary.
- `.github/workflows/sprt.yml`: `variants` (SPRT maromaro miaraka), `base_tgz` foana = tgz mitovy (safidy ihany no hafa).
- `tools/SelfPlay.java` (data Texel), `tools/Texel.java` (tuner), `tools/apply_tuned.py` (manoratra ny vokatra ao amin'ny Eval.java), `.github/workflows/texel.yml`.
- `Eval2` (UCI): toetra vaovao ao amin'ny Eval (phalanx, backward, passed free-path, pawn storm, danger tsy misy queen); default 0.

## Fanatsarana fikarohana (default 0, SPRT isaky ny iray)
| Safidy UCI | Inona no ataony |
|---|---|
| `SeePrune` (+`SeeQuiet`) | esorina ny quiet SEE ratsy amin'ny depth ≤ 6 |
| `HistPrune` (+`HistPruneMul`) | esorina ny quiet history ratsy loatra amin'ny depth ≤ 4 |
| `Sing2` | singular: double extension (non-PV) sy negative extension |
| `LmrTT` | LMR +1 raha capture ny ttMove |
| `QsTT` | tehirizina ao amin'ny TT ny qsearch |
| `Iir` | internal iterative reduction, solon'ny IID |
| `TtEval` | ampiasaina ny score TT ho eval amin'ny RFP/NMP/futility |
| `Contempt` (cp) | ialana ny draw ho an'ny JORO (fomba filalaovana mitoloko) |

Fanamarinana eto an-toerana: `java -cp cls mg.chess.offline.own.Match <pairs> <ms> "<optsA>" "<optsB>"`
(tsy SPRT: mahita bug lehibe fa tsy mamaritra Elo kely).
