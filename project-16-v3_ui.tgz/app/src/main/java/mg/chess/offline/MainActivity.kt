package mg.chess.offline

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

class MainActivity : ComponentActivity() {
    private val vm: ChessViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Sprites.init(this)
        BoardStyle.load(this)
        AppBackground.load(this)
        PlayerProfile.load(this)
        setContent {
            MaterialTheme(colorScheme = if (vm.darkMode) DarkScheme else LightScheme, shapes = KajyShapes) {
                val base = MaterialTheme.colorScheme.background
                val bar = MaterialTheme.colorScheme.surfaceContainer
                val dark = vm.darkMode
                val view = LocalView.current
                SideEffect {
                    val w = this@MainActivity.window
                    w.statusBarColor = base.toArgb()
                    w.navigationBarColor = bar.toArgb()
                    val c = WindowCompat.getInsetsController(w, view)
                    c.isAppearanceLightStatusBars = !dark
                    c.isAppearanceLightNavigationBars = !dark
                }
                val bg = AppBackground.image
                Box(Modifier.fillMaxSize().background(base)) {
                    if (bg != null) {
                        Image(bg, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        Box(Modifier.fillMaxSize().background(base.copy(alpha = AppBackground.dim)))
                    }
                    Scaffold(
                        containerColor = Color.Transparent,
                        bottomBar = { if (vm.screen in NAV_SCREENS) BottomNav(vm) }
                    ) { pad ->
                        Box(Modifier.padding(pad).fillMaxSize()) {
                            when (vm.screen) {
                                Screen.MENU -> MenuScreen(vm)
                                Screen.BOTS -> BotsScreen(vm)
                                Screen.GAME -> GameScreen(vm)
                                Screen.REVIEW -> ReviewScreen(vm)
                                Screen.HISTORY -> HistoryScreen(vm)
                                Screen.SETTINGS -> SettingsScreen(vm)
                                Screen.TOUR_LIST -> TourListScreen(vm)
                                Screen.TOUR_NEW -> TourNewScreen(vm)
                                Screen.TOURNAMENT -> TournamentScreen(vm)
                                Screen.WATCH -> WatchScreen(vm)
                                Screen.PGN -> PgnScreen(vm)
                                Screen.STATS -> StatsScreen(vm)
                                Screen.ARCHIVE -> ArchiveScreen(vm)
                                Screen.CHRONICLE -> ChronicleScreen(vm)
                                Screen.TRAIN -> TrainScreen(vm)
                                Screen.DRILL -> DrillScreen(vm)
                                Screen.PUZZLE -> PuzzleScreen(vm)
                                Screen.ENDGAME -> EndgameScreen(vm)
                                Screen.ABOUT -> AboutScreen(vm)
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onStart() { super.onStart(); vm.setPaused(false) }

    override fun onStop() {
        vm.setPaused(true)
        vm.saveGame(sync = true)
        super.onStop()
    }
}
