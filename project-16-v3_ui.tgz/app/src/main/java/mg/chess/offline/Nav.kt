package mg.chess.offline

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector

private data class Tab(val icon: ImageVector, val desc: String, val label: String)

private val TABS = listOf(
    Tab(Icons.Rounded.PlayArrow, "Milalao", "Milalao"),
    Tab(Icons.Rounded.EmojiEvents, "Fifaninanana", "Fifaninanana"),
    Tab(Icons.Rounded.School, "Fiofanana", "Fiofanana"),
    Tab(Icons.Rounded.History, "Tantaran'ny lalao", "Tantara"),
    Tab(Icons.Rounded.Settings, "Settings", "Settings"),
)

val NAV_SCREENS = setOf(
    Screen.MENU, Screen.BOTS, Screen.TOUR_LIST, Screen.TOUR_NEW,
    Screen.TOURNAMENT, Screen.HISTORY, Screen.SETTINGS, Screen.PGN, Screen.STATS, Screen.ARCHIVE, Screen.CHRONICLE,
    Screen.TRAIN, Screen.DRILL, Screen.PUZZLE, Screen.ENDGAME, Screen.ABOUT
)

fun tabOf(s: Screen): Int = when (s) {
    Screen.MENU, Screen.BOTS, Screen.PGN -> 0
    Screen.TOUR_LIST, Screen.TOUR_NEW, Screen.TOURNAMENT, Screen.ARCHIVE, Screen.CHRONICLE -> 1
    Screen.TRAIN, Screen.DRILL, Screen.PUZZLE, Screen.ENDGAME -> 2
    Screen.HISTORY, Screen.STATS -> 3
    Screen.SETTINGS, Screen.ABOUT -> 4
    else -> -1
}

/** Bouton nav 5: play, competition, fiofanana, game history, settings (icon fotsiny). */
@Composable
fun BottomNav(vm: ChessViewModel) {
    val sel = tabOf(vm.screen)
    NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
        TABS.forEachIndexed { i, t ->
            NavigationBarItem(
                selected = sel == i,
                onClick = { vm.goTab(i) },
                icon = { Icon(t.icon, contentDescription = t.desc) },
                label = { Text(t.label, fontSize = 10.sp, maxLines = 1, softWrap = false) },
                alwaysShowLabel = true,
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    selectedTextColor = MaterialTheme.colorScheme.primary,
                    indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
        }
    }
}
