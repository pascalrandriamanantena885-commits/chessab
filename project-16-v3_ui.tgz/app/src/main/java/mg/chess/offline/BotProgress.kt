package mg.chess.offline

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONObject
import java.io.File
import kotlin.math.roundToInt

/** Fivoaran'ny bot aorian'ny fifaninanana: Elo vaovao + fomba filalaovana miova. */
data class BotProg(val elo: Int, val style: Style, val last: Int, val games: Int)

object BotProgress {
    private const val FILE = "bot_progress.json"
    private const val K = 24.0

    var map by mutableStateOf<Map<String, BotProg>>(emptyMap())
        private set

    fun load(ctx: Context) {
        val m = HashMap<String, BotProg>()
        try {
            val f = File(ctx.filesDir, FILE)
            if (f.exists()) {
                val o = JSONObject(f.readText())
                for (k in o.keys()) {
                    val j = o.getJSONObject(k)
                    m[k] = BotProg(
                        j.getInt("elo"),
                        Style(j.optInt("a", 50), j.optInt("s", 50), j.optInt("d", 50), j.optInt("q", 50), j.optInt("t", 50)),
                        j.optInt("last", 0), j.optInt("games", 0)
                    )
                }
            }
        } catch (e: Exception) { /* tsy mandika */ }
        map = m
    }

    private fun save(ctx: Context) {
        try {
            val o = JSONObject()
            for ((k, p) in map) {
                o.put(k, JSONObject().put("elo", p.elo).put("a", p.style.aggression).put("s", p.style.sacrifice)
                    .put("d", p.style.defense).put("q", p.style.queen).put("t", p.style.trades)
                    .put("last", p.last).put("games", p.games))
            }
            File(ctx.filesDir, FILE).writeText(o.toString())
        } catch (e: Exception) { /* tsy mandika */ }
    }

    /** Apetraka eo ambonin'ny bot fototra (Elo + style tafakatra). Stockfish MAX tsy miova. */
    fun apply(b: Bot): Bot {
        if (b.elo > SF_MAX_ELO) return b
        val p = map[b.id] ?: return b
        return b.copy(elo = p.elo, movetimeMs = movetimeForElo(p.elo), style = p.style)
    }

    fun lastDelta(id: String): Int = map[id]?.last ?: 0

    private fun mix(old: Int, target: Int, w: Double) = (old + (target - old) * w).roundToInt().coerceIn(0, 100)

    /**
     * Antsoina indray mandeha aorian'ny fifaninanana vita. Mamerina fanafohezana (soratra) ho an'ny bot niova.
     * - Elo: kajy isaky ny lalao araka ny mpanohitra (K=24), nanaraka ny filaharana.
     * - Fomba: mitodika amin'ny fomba nilalaovany tao amin'ny fifaninanana (20%); ny mpandresy mafy dia mihamafy
     *   ny toetrany, ny resy be kosa dia mitodika amin'ny fiarovana.
     */
    fun applyTournament(ctx: Context, t: Tournament): List<String> {
        val cur = HashMap<String, Double>()
        val start = HashMap<String, Int>()
        val styleAcc = HashMap<String, MutableList<Style>>()
        val score = HashMap<String, Double>()
        val played = HashMap<String, Int>()
        fun botOf(id: String?): Bot? = t.player(id)?.bot
        fun live(b: Bot): Double = cur.getOrPut(b.id) {
            val e = (BotRegistry.find(b.id) ?: b).elo
            start[b.id] = e; e.toDouble()
        }
        for (m in t.matches.sortedBy { it.id }) {
            val res = m.result
            val s = when (res) { "1-0" -> 1.0; "0-1" -> 0.0; "1/2-1/2" -> 0.5; else -> continue }
            val wp = t.player(m.whiteId); val bp = t.player(m.blackId)
            if (wp == null || bp == null) continue
            val wb = wp.bot; val bb = bp.bot
            val wr = if (wb != null) live(wb) else wp.elo.toDouble()
            val br = if (bb != null) live(bb) else bp.elo.toDouble()
            if (wb != null && wb.elo <= SF_MAX_ELO) {
                cur[wb.id] = wr + K * (s - eloExpected(wr, br))
                score[wb.id] = (score[wb.id] ?: 0.0) + s; played[wb.id] = (played[wb.id] ?: 0) + 1
                if (m.moves.size >= 8) styleAcc.getOrPut(wb.id) { ArrayList() }.add(Personality.deriveStyle(m.moves, true))
            }
            if (bb != null && bb.elo <= SF_MAX_ELO) {
                cur[bb.id] = br + K * ((1 - s) - eloExpected(br, wr))
                score[bb.id] = (score[bb.id] ?: 0.0) + (1 - s); played[bb.id] = (played[bb.id] ?: 0) + 1
                if (m.moves.size >= 8) styleAcc.getOrPut(bb.id) { ArrayList() }.add(Personality.deriveStyle(m.moves, false))
            }
        }
        val out = ArrayList<String>()
        val next = HashMap(map)
        for ((id, r) in cur) {
            val b = BotRegistry.find(id) ?: continue
            if (b.elo > SF_MAX_ELO) continue
            val n = played[id] ?: 0
            if (n == 0) continue
            val old = start[id] ?: b.elo
            val ne = r.roundToInt().coerceIn(100, SF_MAX_ELO)
            val rate = (score[id] ?: 0.0) / n
            var st = b.style
            val ss = styleAcc[id]
            if (!ss.isNullOrEmpty()) {
                fun avg(f: (Style) -> Int) = ss.map(f).average().roundToInt()
                val tgt = Style(avg { it.aggression }, avg { it.sacrifice }, avg { it.defense }, avg { it.queen }, avg { it.trades })
                st = Style(
                    mix(st.aggression, tgt.aggression, 0.2), mix(st.sacrifice, tgt.sacrifice, 0.2),
                    mix(st.defense, tgt.defense, 0.2), mix(st.queen, tgt.queen, 0.2), mix(st.trades, tgt.trades, 0.2)
                )
            }
            if (n >= 2) {
                if (rate >= 0.65) {
                    fun amp(v: Int) = (v + (v - 50) * 0.1).roundToInt().coerceIn(0, 100)
                    st = Style(amp(st.aggression), amp(st.sacrifice), amp(st.defense), amp(st.queen), amp(st.trades))
                } else if (rate <= 0.35) {
                    st = st.copy(defense = (st.defense + 4).coerceAtMost(100), aggression = (st.aggression - 3).coerceAtLeast(0))
                }
            }
            val d = ne - old
            next[id] = BotProg(ne, st, d, (map[id]?.games ?: 0) + n)
            out.add("${b.name} ${if (d >= 0) "+" else ""}$d ($ne)")
        }
        map = next
        save(ctx)
        return out
    }
}
