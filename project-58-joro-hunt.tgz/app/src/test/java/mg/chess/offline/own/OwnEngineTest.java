package mg.chess.offline.own;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import org.junit.Test;

/** Fanamarinana ny motera manokana: perft (hetsika marina) + tactic fohy. */
public class OwnEngineTest {
    private static long perft(String fen, int d) {
        Pos p = new Pos();
        assertTrue(p.setFen(fen));
        return p.perft(d);
    }

    @Test public void perftStart() {
        assertEquals(197281L, perft("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1", 4));
    }

    @Test public void perftKiwipete() {
        assertEquals(97862L, perft("r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1", 3));
    }

    @Test public void perftEndgameEp() {
        assertEquals(43238L, perft("8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1", 4));
    }

    @Test public void perftPromotions() {
        assertEquals(9467L, perft("r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1", 3));
        assertEquals(62379L, perft("rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8", 3));
    }

    @Test public void profileMonotonicUpTo2500() {
        int prev = 0;
        for (int e = 400; e <= 2500; e += 50) {
            int d = OwnBot.profile(e)[0];
            assertTrue("depth tsy mihena @" + e, d >= prev);
            prev = d;
        }
        assertEquals(64, OwnBot.profile(2500)[0]);
        assertTrue(OwnBot.profile(2450)[0] < 64);
    }

    private static String best(String fen, int ms) {
        return OwnBot.bestMove(fen, new ArrayList<String>(), 2200, ms, 50, 50, 50, 50, 50);
    }

    @Test public void findsMateInOne() {
        assertEquals("a1a8", best("6k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1", 1500));
    }

    @Test public void findsMateInTwo() {
        assertEquals("d5f6", best("r2qkb1r/pp2nppp/3p4/2pNN1B1/2BnP3/3P4/PPP2PPP/R2bK2R w KQkq - 1 1", 4000));
    }

    @Test public void takesHangingQueen() {
        assertEquals("f3h4", best("rnb1kbnr/pppp1ppp/8/4p3/4P2q/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3", 2000));
    }

    @Test public void alwaysReturnsLegalMoveForWeakBot() {
        String mv = OwnBot.bestMove("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
                new ArrayList<String>(), 400, 300, 50, 50, 50, 50, 50);
        assertNotNull(mv);
        Pos p = new Pos();
        p.startPos();
        assertTrue(p.parseMove(mv) != 0);
    }

    @Test public void gambitBookLinesLegal() {
        assertTrue(GambitBook.allLegal());
    }

    @Test public void gambitBookFollowsHistory() {
        java.util.Random r = new java.util.Random(7);
        assertNotNull(GambitBook.pick(new ArrayList<>(), r));
        assertEquals(null, GambitBook.pick(java.util.Arrays.asList("c2c4"), r));
    }

    @Test public void joroStyleOffByDefault() {
        assertEquals(0, Params.JORO_STYLE.val);
        assertEquals(0, Params.JORO_BOOK.val);
    }

    @Test public void joroHuntOffByDefaultAndFindsLegalMate() {
        assertEquals(0, Params.JORO_HUNT.val);
        Params.set("JoroHunt", 1);
        try {
            Search s = new Search(new Eval(50, 50, 50, 50, 50));
            s.setHash(16);
            s.pos.startPos();
            for (String u : "e2e4 e7e5 g1f3 d7d6 f1c4 c8g4 b1c3 g7g6 f3e5 g4d1".split(" ")) s.pos.make(s.pos.parseMove(u));
            Search.Result r = s.think(6, 2000);
            assertEquals("c4f7", Pos.moveStr(r.move)); // Legall: Bxf7+ Ke7 Nd5#
            assertTrue(r.score > 29000);
        } finally {
            Params.set("JoroHunt", 0);
        }
    }
}
