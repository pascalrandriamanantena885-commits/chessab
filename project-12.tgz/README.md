# KAJY
Kotlin + Compose, chesslib, **Stockfish 17.1** (UCI, NDK, NNUE). Push amin'ny GitHub -> Actions -> Artifacts -> APK.
Stockfish: GPLv3 -> ampiasao ho open source ny app.

## Elo tena izy
- Bot 1320-3190: `UCI_LimitStrength` + `UCI_Elo` (fetra ofisialy an'ny Stockfish 17.1).
- Bot > 3190: hery feno.
- Bot < 1320: fikarohana voafetra (nodes) + safidy hetsika araka ny temperature (Engine.kt).
- Fanitsiana: `ELO_CALIB` ao amin'ny Bots.kt (0 = mivantana).
- Review / game rating: Stockfish feno hery, depth 12/16/20 (Settings), MultiPV 2, expected-points (win%).

## Sprites
Pieces + board tiles: "Cburnett Chess set" (JohnPablok remaster v2), ao amin'ny app/src/main/assets/.
Credit: Colin M.L. Burnett (Cburnett) / JohnPablok - GPLv2+ / CC BY-SA 3.0.
Avatar bot: apetaho ao amin'ny app/src/main/assets/bots/<id>.png. Raha tsy misy dia fallback no miseho.

## Fiasa
- Nav 4 (icon): Play, Fifaninanana, Tantaran'ny lalao, Settings.
- Settings: sary aloha (background) avy ao amin'ny gallerie, theme, depth review, fampidirana / fanovana / famafana bot (sary avy ao amin'ny gallerie).
- Fifaninanana: bot vs bot, olona + bot; poule -> 8ème de finale -> finale; live; review.

## Bot personalité (opening + fomba filalaovana)
- Openings.kt: katalaogy 32 opening (Fotsy: Italian, Ruy Lopez, Scotch, King's Gambit, Vienna, Evans, Danish, Smith-Morra, Open Sicilian, London, Queen's Gambit, English, Réti; Mainty: French, Caro-Kann, Scandinavian, Najdorf, Dragon, Taimanov, Pirc, Alekhine, Petroff, 1...e5, King's Indian, Grünfeld, Nimzo, Queen's Indian, QGD, Slav, Dutch, Budapest, Albin).
- Fomba (0-100, 50 = mahazatra): fanafihana, sacrifice, fiarovana, queen aloha, fifanakalozana.
- Ny Stockfish no mitazona ny Elo; ny fomba dia misafidy amin'ny hetsika mitovy lanja (tolérance centipawn araka ny Elo).
- Mamorona bot avy amin'ny lalao: Review -> "Mamorona bot avy amin'ity lalao ity" (Elo = game rating, opening + fomba hita avy amin'ny hetsika).
- Lalao: flip board, hetsika aloha/manaraka, draw (bot mandinika amin'ny Stockfish), miala, stalemate, repetition, 50 hetsika, material tsy ampy.

## Vaovao (v2.1)
- PGN -> bot: Menu "Bot avy amin'ny PGN" na ny bokotra "PGN → Bot" ao amin'ny lisitry ny bot (PgnImport.kt, PgnScreen.kt). Stockfish mandinika ny lalao 5 voalohany an'ny mpilalao (depth <= 14, hetsika 80), Elo = game rating (mifangaro amin'ny Elo ao amin'ny PGN raha misy), opening + fomba avy amin'ny hetsika.
- Sokajy bot (Tiers.kt, BotsScreen.kt): Beginner, Intermediate, Advanced, Master, Grandmaster, Legend + "Nataoko" - sivana amin'ny chip.
- Pejy fampidirana ny match (MatchIntro.kt): sary + anarana + Elo + evenement (Match amicale, Phase de poule, 8ème, Quart, Demi-finale, Finale) alohan'ny lalao.
- Lalao: border board, material nalaina, lisitry ny hetsika (SAN), tools ao anaty card. Settings: anarana + sary ho an'ny mpilalao (Profile.kt).

## Vaovao (v2.2) - Commentaire live (peo)
- Mpanao commentaire roa, lahy + vavy (Faly sy Mialy), amin'ny teny anglisy, toy ny lalao live. Peo = `TextToSpeech` an'ny Android (offline; mila peo anglisy napetraka ao amin'ny findainao). Raha tsy misy peo dia miseho ho soratra (caption) ihany.
- Rakitra: `CommentaryBrain.kt` (lahatsoratra sy lojika, tsy misy Android), `Commentator.kt` (peo, filaharana, peo roa), `CommentaryUi.kt` (bokotra + soratra), hook ao amin'ny `ChessViewModel.kt`.
- Mandeha amin'ny lalao Play (olona/bot), lalao olona ao anaty fifaninanana, ary "Jereo live" (bot vs bot).
- Misy: fampidirana (welcome, evenement, Elo, fomba filalaovana, ora), hetsika voalohany, opening, sacrifice, blunder (piece mihantona), promotion, en passant, queen trade, check, castle, material, ora (mieritreritra be, ora kely, flag), endgame, draw, valiny (mate, timeout, resign, draw, miakatra amin'ny dingana manaraka, champion).
- Fotoana mangina: resaka (mpilalao, Elo underdog, ora, toerana, zava-misy momba ny fifaninanana: mpandresy teo aloha, lalao haingana, record, h2h; tantaran'ny chess; atmosphere).
- Settings > Commentaire live: Alefa/Atsahatra, "Zava-dehibe" (kely) / "Be resaka", bokotra "Henoy ny peo". Bokotra peo ao amin'ny lalao sy Watch ihany koa.
- Ao amin'ny Watch: miandry ny commentaire ny lalao (tsy mandalo haingana loatra).
- Fanitsiana ny resaka: ovay ny banque ao amin'ny `CommentaryBrain.kt` (exchange = `x(MOOD to "text", MOOD to "text")`).
