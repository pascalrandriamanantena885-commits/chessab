package mg.chess.offline

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

private const val F_ALL = -1
private const val F_CUSTOM = 6

@Composable
fun BotsScreen(vm: ChessViewModel) {
    BackHandler { vm.toMenu() }
    var choice by remember { mutableIntStateOf(0) }
    var filter by remember { mutableIntStateOf(F_ALL) }
    val all = BotRegistry.visible
    val shown = when (filter) {
        F_ALL -> all
        F_CUSTOM -> all.filter { it.custom }
        else -> all.filter { tierOf(it.elo).ordinal == filter }
    }
    val grouped = shown.groupBy { tierOf(it.elo) }

    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 8.dp)) {
        ScreenTitle("Fidio ny bot", onBack = { vm.toMenu() }) {
            OutlinedButton({ vm.toPgn() }) { Text("PGN → Bot") }
        }
        Row(Modifier.padding(bottom = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Loko: ")
            FilterChip(choice == 0, { choice = 0 }, { Text("Fotsy") })
            FilterChip(choice == 1, { choice = 1 }, { Text("Mainty") })
            FilterChip(choice == 2, { choice = 2 }, { Text("Kisendrasendra") })
        }
        TimeControlPicker(vm)
        Spacer(Modifier.height(6.dp))
        // Sivana araka ny sokajy
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(filter == F_ALL, { filter = F_ALL }, { Text("Rehetra (${all.size})") })
            for (t in BotTier.values()) {
                val n = all.count { tierOf(it.elo) == t }
                FilterChip(filter == t.ordinal, { filter = t.ordinal }, { Text("${t.label} ($n)") })
            }
            FilterChip(filter == F_CUSTOM, { filter = F_CUSTOM }, { Text("Nataoko (${all.count { it.custom }})") })
        }
        Spacer(Modifier.height(8.dp))
        if (shown.isEmpty()) {
            Text("Tsy misy bot amin'ity sokajy ity. Azonao atao ny mamorona avy amin'ny PGN.", Modifier.padding(top = 12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            for (tier in BotTier.values()) {
                val l = grouped[tier] ?: continue
                item(key = "h_${tier.name}") { TierHeader(tier, l.size) }
                items(l, key = { it.id }) { b ->
                    BotCard(b) {
                        val white = when (choice) { 0 -> true; 1 -> false; else -> Random.nextBoolean() }
                        vm.startBotGame(b, white)
                    }
                }
            }
            item { Spacer(Modifier.height(8.dp)) }
        }
    }
}

@Composable
private fun TierHeader(t: BotTier, n: Int) {
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(5.dp).height(20.dp).clip(RoundedCornerShape(3.dp)).background(Color(t.color)))
        Spacer(Modifier.width(8.dp))
        Text(t.label, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(t.color))
        Spacer(Modifier.width(8.dp))
        Text("${t.range} - $n bot", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun BotCard(b: Bot, onClick: () -> Unit) {
    val tier = tierOf(b.elo)
    Card(
        Modifier.fillMaxWidth().clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
        border = BorderStroke(1.dp, Color(tier.color).copy(alpha = 0.45f))
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            BotAvatar(b, 58.dp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(b.name, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(b.bio, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                val spec = b.specialty()
                if (spec.isNotEmpty() && spec != b.bio) {
                    Text(spec, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                }
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Box(
                    Modifier.clip(RoundedCornerShape(10.dp)).background(Color(tier.color).copy(alpha = 0.2f))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(if (b.elo > SF_MAX_ELO) "MAX" else "${b.elo}", fontWeight = FontWeight.Bold, color = Color(tier.color))
                }
                TierChip(tier)
            }
        }
    }
}
