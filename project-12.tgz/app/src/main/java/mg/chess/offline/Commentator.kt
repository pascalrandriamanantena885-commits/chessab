package mg.chess.offline

import android.content.Context
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Mpanao commentaire amin'ny peo: peo roa (lahy + vavy) avy amin'ny TextToSpeech an'ny Android (offline,
 * anglisy). Ny andalana dia lasa miandalana ary miresaka mifandimby. Raha tsy misy peo anglisy dia
 * mbola miseho ho soratra (caption) ny resaka.
 */
class Commentator(context: Context) {
    private val app = context.applicationContext

    /** Alefa / atsahatra. */
    var enabled by mutableStateOf(true)

    /** Andalana lazaina ankehitriny (ho an'ny soratra eo amin'ny efijery). */
    var caption by mutableStateOf<CLine?>(null)
        private set

    /** Hafatra raha tsy mandeha ny peo (ohatra: tsy misy peo anglisy napetraka). */
    var status by mutableStateOf("")
        private set

    private class Eng {
        @Volatile var tts: TextToSpeech? = null
        @Volatile var ready = false
        @Volatile var failed = false
        @Volatile var basePitch = 1f
        @Volatile var voiceName = ""
    }

    private class Item(val line: CLine, val at: Long)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val engines = HashMap<Voice, Eng>()
    private val waiters = ConcurrentHashMap<String, CompletableDeferred<Unit>>()
    private val queue = ArrayDeque<Item>()
    private var runner: Job? = null
    private var captionJob: Job? = null
    private var current: CLine? = null
    private var seq = 0
    private var lastActivity = SystemClock.elapsedRealtime()
    private var initDone = false

    // ---------- fanombohana ----------
    private fun ensureInit() {
        if (initDone) return
        initDone = true
        initVoice(Voice.FEMALE)
        initVoice(Voice.MALE)
    }

    private fun initVoice(who: Voice) {
        val eng = Eng()
        engines[who] = eng
        val holder = arrayOfNulls<TextToSpeech>(1)
        try {
            holder[0] = TextToSpeech(app) { st ->
                val t = holder[0]
                if (st != TextToSpeech.SUCCESS || t == null) {
                    eng.failed = true
                    status = "Tsy mandeha ny peo (TextToSpeech tsy hita). Soratra ihany no miseho."
                } else {
                    configure(t, who, eng)
                }
            }
        } catch (e: Exception) {
            eng.failed = true
            status = "Tsy mandeha ny peo (TextToSpeech tsy hita). Soratra ihany no miseho."
        }
    }

    private fun maleByName(n: String) = n.contains("male") && !n.contains("female")
    private fun femaleByName(n: String) = n.contains("female")

    private fun configure(t: TextToSpeech, who: Voice, eng: Eng) {
        val lr = try { t.setLanguage(Locale.US) } catch (e: Exception) { TextToSpeech.LANG_NOT_SUPPORTED }
        if (lr == TextToSpeech.LANG_MISSING_DATA || lr == TextToSpeech.LANG_NOT_SUPPORTED) {
            eng.failed = true
            status = "Tsy misy peo anglisy napetraka ao amin'ny findainao. Apetraho ny \"English\" ao amin'ny Settings > Text-to-speech. Soratra ihany no miseho."
            return
        }
        eng.tts = t
        eng.basePitch = if (who == Voice.FEMALE) 1.14f else 0.84f
        try {
            val all = (t.voices ?: emptySet()).filter {
                it.locale.language == "en" && !it.features.contains("notInstalled")
            }.sortedWith(
                compareBy({ it.isNetworkConnectionRequired }, { it.locale != Locale.US }, { -it.quality })
            )
            val other = engines[if (who == Voice.FEMALE) Voice.MALE else Voice.FEMALE]?.voiceName ?: ""
            val named = all.firstOrNull {
                val n = it.name.lowercase()
                it.name != other && (if (who == Voice.FEMALE) femaleByName(n) else maleByName(n))
            }
            val pick = named ?: all.firstOrNull { it.name != other }
            if (pick != null) {
                t.voice = pick
                eng.voiceName = pick.name
                // raha mazava ny lahy/vavy avy amin'ny anarana dia kely ny fanovana peo; raha tsy izany, lehibe kokoa
                eng.basePitch = when {
                    named != null -> if (who == Voice.FEMALE) 1.04f else 0.94f
                    else -> eng.basePitch
                }
            }
        } catch (e: Exception) { /* mbola mety ny peo default */ }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { finish(utteranceId) }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { finish(utteranceId) }
            override fun onError(utteranceId: String?, errorCode: Int) { finish(utteranceId) }
            override fun onStop(utteranceId: String?, interrupted: Boolean) { finish(utteranceId) }
        })
        eng.ready = true
        if (engines.values.any { it.ready }) status = ""
    }

    private fun finish(id: String?) { if (id != null) waiters.remove(id)?.complete(Unit) }

    // ---------- fampiasana ----------
    val busy: Boolean get() = current != null || queue.isNotEmpty()

    fun pending(): Int = queue.size + (if (current != null) 1 else 0)

    /** Ora nandalovan'ny fotoana mangina (ms) hatramin'ny farany nandehanan'ny peo. */
    fun silentMs(): Long = if (busy) 0L else SystemClock.elapsedRealtime() - lastActivity

    fun say(lines: List<CLine>) {
        if (!enabled || lines.isEmpty()) return
        ensureInit()
        val now = SystemClock.elapsedRealtime()
        val top = lines.maxOf { it.pri }
        if (top >= 3) {
            queue.removeAll { it.line.pri <= 1 }
            if ((current?.pri ?: 9) <= 1) interrupt()
        } else if (top == 2) {
            queue.removeAll { it.line.pri <= 1 && now - it.at > 4_000L }
        }
        for (l in lines) queue.addLast(Item(l, now))
        while (queue.size > 8) {
            val i = queue.indexOfFirst { it.line.pri <= 1 }
            if (i < 0) break
            queue.removeAt(i)
        }
        lastActivity = now
        startRunner()
    }

    /** Miandry mandra ny lalao raha mbola miresaka ny mpanao commentaire (ho an'ny Watch). */
    suspend fun awaitCatchUp(maxMs: Long, maxPending: Int = 0) {
        if (!enabled) return
        var w = 0L
        while (pending() > maxPending && w < maxMs) { delay(80); w += 80 }
    }

    fun stop() {
        queue.clear()
        runner?.cancel(); runner = null
        interruptAll()
        current = null
        captionJob?.cancel()
        caption = null
        lastActivity = SystemClock.elapsedRealtime()
    }

    fun shutdown() {
        stop()
        for (e in engines.values) { try { e.tts?.shutdown() } catch (_: Exception) {} }
        engines.clear()
        scope.cancel()
    }

    private fun interrupt() {
        val c = current ?: return
        try { engines[c.who]?.tts?.stop() } catch (_: Exception) {}
    }

    private fun interruptAll() {
        for (e in engines.values) { try { e.tts?.stop() } catch (_: Exception) {} }
        for (d in waiters.values) d.complete(Unit)
        waiters.clear()
    }

    private fun startRunner() {
        if (runner?.isActive == true) return
        runner = scope.launch {
            try {
                while (isActive) {
                    val it = queue.removeFirstOrNull() ?: break
                    val age = SystemClock.elapsedRealtime() - it.at
                    if (it.line.pri <= 1 && age > 12_000L) continue
                    speak(it.line)
                }
            } finally {
                current = null
                lastActivity = SystemClock.elapsedRealtime()
                scheduleCaptionClear()
            }
        }
    }

    private fun scheduleCaptionClear() {
        captionJob?.cancel()
        captionJob = scope.launch {
            delay(2800)
            if (!busy) caption = null
        }
    }

    private fun readMs(l: CLine) = 700L + l.text.length * 55L

    private suspend fun speak(l: CLine) {
        current = l
        captionJob?.cancel()
        caption = l
        if (l.pauseMs > 0) delay(l.pauseMs.toLong())
        // miandry ny fanombohan'ny peo (hatramin'ny 2.5 s)
        var waited = 0
        while (waited < 2500) {
            val e = engines[l.who]
            if (e == null || e.ready || e.failed) break
            delay(100); waited += 100
        }
        val e = engines[l.who]
        val t = e?.tts
        if (e != null && e.ready && t != null) {
            try {
                t.setSpeechRate(l.mood.rate.coerceIn(0.5f, 2f))
                t.setPitch((l.mood.pitch * e.basePitch).coerceIn(0.5f, 2f))
                val id = "c" + (++seq)
                val d = CompletableDeferred<Unit>()
                waiters[id] = d
                val ok = t.speak(l.text, TextToSpeech.QUEUE_FLUSH, null, id) == TextToSpeech.SUCCESS
                if (ok) withTimeoutOrNull(4000L + l.text.length * 130L) { d.await() } else delay(readMs(l))
                waiters.remove(id)
            } catch (ex: Exception) {
                delay(readMs(l))
            }
        } else {
            delay(readMs(l))
        }
        // fiatoana kely voajanahary arakaraka ny fihetseham-po
        delay(if (l.mood == Mood.EXCITED || l.mood == Mood.SHOCKED || l.mood == Mood.TENSE) 90L else 230L)
        lastActivity = SystemClock.elapsedRealtime()
    }
}
