package mg.chess.offline

import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.PieceType
import com.github.bhlangonijr.chesslib.Side
import kotlin.math.abs
import kotlin.math.max
import kotlin.random.Random

/*
 * Commentaire live (anglisy) - lahatsoratra fotsiny, tsy misy Android eto.
 * Commentator.kt no mamaky azy amin'ny peo (TextToSpeech); ity rakitra ity no mamorona ny resaka
 * eo amin'ny mpanao commentaire roa (lahy + vavy): fampidirana, hetsika tsirairay, fotoana mangina,
 * ora, tantara, fampahalalana momba ny fifaninanana, valiny.
 */

enum class Voice { MALE, FEMALE }

/** Fihetseham-po: ny rate/pitch dia mamadika ny hafainganam-peo sy ny haavon'ny peo. */
enum class Mood(val rate: Float, val pitch: Float) {
    EXCITED(1.18f, 1.14f),
    SHOCKED(1.10f, 1.25f),
    TENSE(1.12f, 1.00f),
    PLAYFUL(1.05f, 1.10f),
    WARM(1.00f, 1.05f),
    CALM(0.95f, 1.00f),
    THOUGHTFUL(0.86f, 0.93f),
    DRAMATIC(0.86f, 0.84f)
}

/** pri: 3 = zava-dehibe (mate, blunder...), 2 = mendrika, 1 = famenoana. */
data class CLine(val who: Voice, val text: String, val mood: Mood = Mood.CALM, val pri: Int = 1, val pauseMs: Int = 0)

data class CPlayer(
    val name: String, val elo: Int?, val tier: String?, val isBot: Boolean,
    val aggression: Int = 50, val sacrifice: Int = 50, val defense: Int = 50
)

/** stage: "" (match amicale), "G", "KO16", "KO8", "KO4", "KO2". facts: fehezanteny anglisy efa vonona. */
data class CMatch(
    val white: CPlayer, val black: CPlayer,
    val stage: String, val groupName: String?, val tournament: String?,
    val baseMs: Long, val incMs: Long,
    val facts: List<String> = emptyList(),
    val extraGame: Int = 0
)

/** Sary ankehitriny (ho an'ny resaka mandritra ny fotoana mangina). */
data class LiveSnap(
    val fen: String, val ply: Int, val whiteMs: Long, val blackMs: Long,
    val clockOn: Boolean, val thinkingMs: Long
)

private val EXC = Mood.EXCITED
private val SHK = Mood.SHOCKED
private val TEN = Mood.TENSE
private val PLY = Mood.PLAYFUL
private val WRM = Mood.WARM
private val CLM = Mood.CALM
private val THO = Mood.THOUGHTFUL
private val DRM = Mood.DRAMATIC

/** Anaran'ny dingana amin'ny teny anglisy (ho an'ny peo sy ny fampahalalana). */
fun stageEnglish(stage: String, group: Int = -1): String = when (stage) {
    "G" -> "group stage" + (if (group >= 0) ", group " + ('A' + group) else "")
    "KO16" -> "round of sixteen"
    "KO8" -> "quarter-final"
    "KO4" -> "semi-final"
    "KO2" -> "final"
    else -> "friendly match"
}

private typealias Ex = List<Pair<Mood, String>>

private fun x(vararg p: Pair<Mood, String>): Ex = p.toList()

class CommentaryBrain(private val m: CMatch, private val openingName: (List<String>) -> String?, seed: Long = System.nanoTime()) {
    private val rnd = Random(seed)
    private val recent = ArrayDeque<String>()
    private var leadFemale = rnd.nextBoolean()

    /** 1 = zava-dehibe fotsiny, 2 = be resaka. */
    var level = 2

    private var lastMat: Pair<Int, Int>? = null
    private var openingDone = false
    private var endgameDone = false
    private var drawTalkDone = false
    private var marathonDone = false
    private var plyLast = 0
    private var lastBigPly = -10
    private var checkStreak = 0
    private var capStreak = 0
    private var seen = false
    private var lastWhiteMs = m.baseMs
    private var lastBlackMs = m.baseMs
    private val lowWarned = booleanArrayOf(false, false)
    private val frantic = booleanArrayOf(false, false)
    private val spentTotal = longArrayOf(0L, 0L)
    private val blunders = intArrayOf(0, 0)
    private var pendingSac: Pair<Boolean, Int>? = null   // (white sacrificed, ply)
    private var factIdx = 0
    private val factOrder = m.facts.shuffled(rnd)
    private val usedIdle = HashSet<String>()

    // ---------- fitaovana ----------
    private fun nm(white: Boolean) = if (white) m.white.name else m.black.name
    private fun pl(white: Boolean) = if (white) m.white else m.black

    private fun nextLead(): Voice {
        // matetika mifandimby, indraindray mitovy mba tsy ho voafaritra loatra
        leadFemale = if (rnd.nextInt(10) < 7) !leadFemale else leadFemale
        return if (leadFemale) Voice.FEMALE else Voice.MALE
    }

    private fun other(v: Voice) = if (v == Voice.MALE) Voice.FEMALE else Voice.MALE

    private fun <T> pick(key: String, opts: List<T>): T {
        if (opts.size == 1) return opts[0]
        var tries = 0
        var i: Int
        do {
            i = rnd.nextInt(opts.size)
            tries++
        } while (("$key#$i") in recent && tries < 8)
        recent.addLast("$key#$i")
        while (recent.size > 40) recent.removeFirst()
        return opts[i]
    }

    private fun fill(s: String, vars: Map<String, String>): String {
        var r = s
        for ((k, v) in vars) r = r.replace("{$k}", v)
        return r
    }

    private fun dlg(pri: Int, ex: Ex, vars: Map<String, String> = emptyMap(), lead: Voice = nextLead()): List<CLine> =
        ex.mapIndexed { i, (mood, t) ->
            CLine(if (i % 2 == 0) lead else other(lead), fill(t, vars), mood, pri)
        }

    private fun keep(pri: Int, lines: List<CLine>): List<CLine> =
        if (level <= 1) lines.filter { it.pri >= 2 && pri >= 2 } else lines

    private fun pieceName(t: PieceType?): String = when (t) {
        PieceType.PAWN -> "pawn"
        PieceType.KNIGHT -> "knight"
        PieceType.BISHOP -> "bishop"
        PieceType.ROOK -> "rook"
        PieceType.QUEEN -> "queen"
        PieceType.KING -> "king"
        else -> "piece"
    }

    private fun stageWord(): String = when (m.stage) {
        "G" -> "group stage" + (if (m.groupName != null) ", ${m.groupName}" else "")
        "KO16" -> "round of sixteen"
        "KO8" -> "quarter-final"
        "KO4" -> "semi-final"
        "KO2" -> "final"
        else -> "friendly match"
    }

    private fun nextStageWord(): String? = when (m.stage) {
        "KO16" -> "quarter-finals"
        "KO8" -> "semi-finals"
        "KO4" -> "final"
        else -> null
    }

    private fun minutes(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        val mm = s / 60
        val ss = s % 60
        return when {
            mm == 0L -> "$ss seconds"
            ss < 5 -> if (mm == 1L) "one minute" else "$mm minutes"
            else -> "$mm minutes and $ss seconds"
        }
    }

    private fun matOf(fen: String): Pair<Int, Int> {
        var w = 0; var b = 0
        for (c in fen.substringBefore(' ')) {
            val v = when (c.lowercaseChar()) { 'p' -> 1; 'n', 'b' -> 3; 'r' -> 5; 'q' -> 9; else -> 0 }
            if (c.isUpperCase()) w += v else b += v
        }
        return w to b
    }

    private fun countPiece(fen: String, c: Char) = fen.substringBefore(' ').count { it.lowercaseChar() == c }

    private fun leadWord(d: Int): String = when {
        d >= 9 -> "a whole queen"
        d >= 5 -> "a full rook"
        d >= 3 -> "a full piece"
        d == 2 -> "two pawns"
        else -> "a pawn"
    }

    private fun art(w: String) = if (w.isNotEmpty() && w[0].uppercaseChar() in "AEIOU") "an" else "a"

    private fun loadBoard(fen: String): Board { val b = Board(); b.loadFromFen(fen); return b }

    /** Fandresena azon'ny mpifanandrina amin'ny fakana tsara indrindra (SEE) aorian'ny hetsika. */
    private fun hangGain(post: Board, movedTo: String): Pair<Int, String> {
        var best = 0
        var sqName = movedTo
        val seen = HashSet<String>()
        for (mv in post.legalMoves()) {
            if (post.getPiece(mv.to) == Piece.NONE) continue
            val key = mv.to.name
            if (!seen.add(key)) continue
            val g = see(post, mv.to)
            if (g > best) { best = g; sqName = key.lowercase() }
        }
        return best to sqName
    }

    // =====================================================================
    //  FAMPIDIRANA
    // =====================================================================
    fun intro(): List<CLine> {
        val a = m.white; val b = m.black
        val lead = nextLead()
        val oth = other(lead)
        val out = ArrayList<CLine>()
        val vars = mapOf("w" to a.name, "b" to b.name, "t" to (m.tournament ?: ""), "s" to stageWord())
        val opener: Ex = when {
            m.stage == "KO2" -> x(
                EXC to "Ladies and gentlemen, welcome to this very special moment! It is the grand final of {t}! {w} versus {b}!",
                EXC to "The stage is set, the whole hall is silent. Only one of them will lift the trophy tonight!"
            )
            m.stage == "KO4" -> x(
                EXC to "Welcome, everyone, to this special moment! The semi-final of {t}! {w} against {b}!",
                TEN to "Whoever wins goes through to the final. Whoever loses, goes home. No pressure at all!"
            )
            m.stage == "KO8" -> x(
                EXC to "Welcome back, everyone! We are at the quarter-finals of {t}, and it is {w} versus {b}!",
                WRM to "The road is getting narrow now. Only eight players left, and one of them is about to be eliminated."
            )
            m.stage == "KO16" -> x(
                EXC to "Hello and welcome! The knockout rounds of {t} begin with {w} versus {b}!",
                TEN to "From now on, every game is win or go home!"
            )
            m.stage == "G" -> x(
                WRM to "Hello, everyone, and welcome! We are live in the group stage of {t}, with {w} against {b}!",
                CLM to "Every single point counts in this group, so expect fireworks."
            )
            m.tournament != null -> x(
                WRM to "Hello, everyone, and welcome to {t}! Today, {w} meets {b}!",
                CLM to "Let's see who will take control of the board."
            )
            else -> x(
                WRM to "Hello, everyone, and welcome to this special moment! A friendly match between {w} and {b}!",
                PLY to "Friendly, they said. But we all know nobody likes to lose!"
            )
        }
        out += dlg(3, opener, vars, lead)

        // loko + Elo
        val colorEx: Ex = if (a.elo != null && b.elo != null) {
            val fav = if (a.elo >= b.elo) a else b
            val dog = if (a.elo >= b.elo) b else a
            val diff = abs(a.elo - b.elo)
            val comp = when {
                diff < 40 -> "These two are practically equal on paper!"
                diff < 200 -> "${fav.name} is the slight favorite, by $diff Elo points."
                diff < 600 -> "${fav.name} is the clear favorite, with $diff Elo points more than ${dog.name}."
                else -> "On paper, this is David against Goliath! ${fav.name} is ${diff} Elo points higher!"
            }
            x(
                CLM to "${a.name} has the white pieces and will move first, while ${b.name} plays black.",
                THO to "${a.name} comes in rated ${a.elo}, ${b.name} is rated ${b.elo}. $comp"
            )
        } else x(
            CLM to "${a.name} has the white pieces and will move first, while ${b.name} plays black.",
            WRM to "Let's see what they have prepared for us."
        )
        out += dlg(2, colorEx, vars, lead)

        // style / tier
        val styleLine = styleRemark(a) ?: styleRemark(b)
        if (styleLine != null) out += CLine(lead, styleLine, WRM, 2)

        // fotoana
        if (m.baseMs > 0) {
            val base = (m.baseMs / 60000).toInt()
            val inc = (m.incMs / 1000).toInt()
            val tc = if (inc > 0) "$base minutes plus $inc seconds per move" else "$base minutes each"
            out += CLine(oth, "The time control is $tc. " + pick("tcx", listOf(
                "So there is not much time to waste!", "Keep an eye on those clocks!", "Every second will matter."
            )), TEN, 1)
        }
        nextFact()?.let { out += CLine(lead, it, WRM, 1) }
        out += CLine(oth, pick("start", listOf("And here we go! Let the game begin!", "Pieces are set. Let the battle begin!", "Handshakes are done... and the clocks are running!")), EXC, 2)
        return keep(3, out)
    }

    /** Mpihaino miditra afovoany ny lalao (na mody mitohy). */
    fun join(plies: Int): List<CLine> {
        val lead = nextLead()
        val vars = mapOf("w" to m.white.name, "b" to m.black.name, "t" to (m.tournament ?: ""), "k" to ((plies + 1) / 2).toString())
        return keep(3, dlg(3, x(
            WRM to "And we are back with {w} against {b}, already on move {k}!",
            TEN to "Let's see how the position looks right now."
        ), vars, lead))
    }

    private fun styleRemark(p: CPlayer): String? {
        val bits = ArrayList<String>()
        if (p.aggression >= 68) bits += "${p.name} is famous for a relentless attacking style"
        if (p.sacrifice >= 68) bits += "${p.name} absolutely loves a sacrifice, so keep your eyes open"
        if (p.defense >= 68) bits += "${p.name} is as solid as a wall in defense"
        if (p.aggression <= 32 && p.defense >= 55) bits += "${p.name} prefers patient, positional chess"
        if (bits.isEmpty()) {
            if (p.tier != null && p.elo != null && p.isBot) return "${p.name} is ${art(p.tier)} ${p.tier} level player, rated ${p.elo}."
            return null
        }
        return pick("style", bits) + "."
    }

    private fun nextFact(): String? {
        if (factOrder.isEmpty()) return null
        val f = factOrder[factIdx % factOrder.size]
        factIdx++
        return f
    }

    // =====================================================================
    //  HETSIKA
    // =====================================================================
    /**
     * preFen = toe-javatra alohan'ny hetsika, uci = hetsika (e2e4...), history = hetsika rehetra hatramin'izao (anisan'izany ity),
     * wMs/bMs = ora sisa aorian'ny hetsika.
     */
    fun onMove(preFen: String, uci: String, history: List<String>, wMs: Long, bMs: Long): List<CLine> {
        val pre = loadBoard(preFen)
        val mv = pre.legalMoves().firstOrNull { it.toString().equals(uci, true) } ?: return emptyList()
        val whiteMoved = pre.sideToMove == Side.WHITE
        val ply = history.size
        plyLast = ply
        val mover = pre.getPiece(mv.from)
        val victim = pre.getPiece(mv.to)
        val isEp = mover.pieceType == PieceType.PAWN && mv.from.name[0] != mv.to.name[0] && victim == Piece.NONE
        val captured: PieceType? = if (isEp) PieceType.PAWN else if (victim != Piece.NONE) victim.pieceType else null
        val castle = mover.pieceType == PieceType.KING && abs(mv.from.name[0] - mv.to.name[0]) == 2
        val promo = if (mv.promotion != Piece.NONE) mv.promotion.pieceType else null
        val sac = captured != PieceType.KING && isSacrifice(loadBoard(preFen), mv)
        val post = loadBoard(preFen); post.doMove(mv)
        val postFen = post.fen
        val mated = post.isMated
        val check = post.isKingAttacked
        val moverIdx = if (whiteMoved) 0 else 1
        val (w, bl) = matOf(postFen)
        val diffMover = if (whiteMoved) w - bl else bl - w
        val prev = lastMat
        val prevDiffMover = if (prev == null) 0 else if (whiteMoved) prev.first - prev.second else prev.second - prev.first
        lastMat = w to bl

        // ora
        val spent = if (!seen && ply > 2) 0L
            else if (whiteMoved) max(0L, lastWhiteMs + m.incMs - wMs) else max(0L, lastBlackMs + m.incMs - bMs)
        seen = true
        lastWhiteMs = wMs; lastBlackMs = bMs
        spentTotal[moverIdx] += spent
        val remMover = if (whiteMoved) wMs else bMs

        val vars = HashMap<String, String>()
        vars["n"] = nm(whiteMoved); vars["o"] = nm(!whiteMoved)
        vars["p"] = pieceName(mover.pieceType)
        vars["cap"] = pieceName(captured)
        vars["sq"] = mv.to.name.lowercase()
        vars["from"] = mv.from.name.lowercase()
        vars["promo"] = pieceName(promo)
        vars["k"] = ((ply + 1) / 2).toString()
        vars["lead"] = leadWord(abs(diffMover))

        val out = ArrayList<CLine>()

        // sacrifice teo aloha: valiny
        pendingSac?.let { (sw, sp) ->
            if (sp == ply - 1 && sw != whiteMoved) {
                if (captured != null && captured != PieceType.PAWN) {
                    // nalain'ny mpifanandrina ilay sacrifice
                    out += dlg(2, x(TEN to "And {n} accepts the sacrifice! Now we will see if it was a mistake or a masterpiece.", THO to "From here, {o} must prove the compensation is real."), vars)
                } else {
                    out += dlg(2, x(TEN to "{n} doesn't take the bait! Interesting.", THO to "Probably smelling a trap. Or maybe just checking the calculation twice."), vars)
                }
            }
            pendingSac = null
        }

        // 1) hetsika voalohany
        if (ply == 1) {
            val txt = when (uci.lowercase()) {
                "e2e4" -> "the king's pawn, the most popular first move in chess"
                "d2d4" -> "the queen's pawn, a classic, solid choice"
                "g1f3" -> "knight to f3, the flexible Reti approach"
                "c2c4" -> "the English opening, a very strategic choice"
                else -> "quite an unusual first move"
            }
            out += dlg(2, x(WRM to "${nm(true)} starts with $txt.", PLY to pick("fm", listOf("Right, no surprise... or maybe yes?", "Let's see how ${nm(false)} responds.", "A first move, and the game has begun!"))), vars)
        }

        // mate: ny valiny no mitantara azy
        if (mated) return keep(3, out)

        var bigDone = false

        // 2) blunder
        val (hangRaw, hangSq) = hangGain(post, mv.to.name.lowercase())
        val capVal = when (captured) {
            PieceType.PAWN -> 1; PieceType.KNIGHT, PieceType.BISHOP -> 3; PieceType.ROOK -> 5; PieceType.QUEEN -> 9; else -> 0
        }
        val hang = hangRaw - capVal      // fahaverezana tena izy (aorian'ny fakana nataon'ny mpihetsika)
        if (!sac && hang >= 3) {
            blunders[moverIdx]++
            vars["hsq"] = hangSq
            vars["hp"] = when {
                hang >= 9 -> "queen"
                hang >= 5 -> "rook"
                else -> "piece"
            }
            val ex: List<Ex> = if (castle) listOf(
                x(SHK to "Oh my God, he castles... and that's a blunder! Something is hanging!", DRM to "{o} can win material immediately. Terrible timing."),
                x(SHK to "Castling? Right now? That's a blunder! {o} can grab a {hp}!", THO to "I really didn't expect that from {n}.")
            ) else if (hang >= 9) listOf(
                x(SHK to "Oh no! {n} has just hung the queen! That's a huge blunder!", DRM to "I can't believe what I'm seeing. Game changing."),
                x(SHK to "The queen is hanging! {n} blundered, and {o} can take it on {hsq}!", EXC to "What a moment in this match!")
            ) else listOf(
                x(SHK to "Oh my God! {n} just left a {hp} hanging! That's a blunder!", THO to "{o} can simply take it on {hsq}. A very costly mistake."),
                x(SHK to "No, no, no! What was that, {n}?", DRM to "That is a serious blunder. The {hp} on {hsq} is just hanging."),
                x(TEN to "Hold on... is that {hp} protected? No! It is not! {n} has blundered!", SHK to "A huge mistake at this level."),
                x(EXC to "Wow, did you see that? {n} leaves a {hp} en prise!", PLY to "{o} won't say no to a free gift."),
                x(DRM to "Ooh. That hurts. That is a blunder.", WRM to "Everyone makes mistakes, but this one will cost {n} dearly.")
            )
            out += dlg(3, pick("blunder", ex), vars)
            bigDone = true
            checkStreak = 0
        }

        // 3) sacrifice
        if (!bigDone && sac) {
            pendingSac = whiteMoved to ply
            val ex: List<Ex> = if (check) listOf(
                x(EXC to "The {p} sacrifice, with check! That's beautiful!", EXC to "That is the kind of move you pay a ticket to see!"),
                x(SHK to "Oh! A sacrifice with check! {n} is going for the throat!", TEN to "Everything is forced now. The king must run.")
            ) else listOf(
                x(EXC to "Oh! {n} sacrifices the {p}! That's a brilliant move!", THO to "Brilliant, or desperate? Let's see if {o} dares to take it."),
                x(EXC to "He sacrifices the {p}! What a bold decision!", PLY to "I love it. {n} plays with fire tonight."),
                x(SHK to "Whoa! The {p} goes to {sq}! Is that a real sacrifice?", WRM to "Only a brave player would try this against {o}."),
                x(DRM to "A piece for nothing? Or is there a deep idea behind this {p} sacrifice?", EXC to "The tension is rising!")
            )
            out += dlg(3, pick("sac", ex), vars)
            bigDone = true
        }

        // 4) promotion
        if (!bigDone && promo != null) {
            out += dlg(3, pick("promo", listOf(
                x(EXC to "He promotes! A brand new {promo} for {n}!", WRM to "All those moves of the pawn walking up the board finally pay off."),
                x(EXC to "The pawn reaches the end! It becomes a {promo}!", TEN to "That changes everything on the board.")
            )), vars)
            bigDone = true
        }

        // 5) en passant
        if (!bigDone && isEp) {
            out += dlg(2, x(EXC to "En passant! You don't see that every day!", PLY to "The old connoisseurs love it. Well spotted, {n}!"), vars)
            bigDone = true
        }

        // 6) fakana
        if (!bigDone && captured != null) {
            capStreak++
            val queensLeft = countPiece(postFen, 'q')
            if (captured == PieceType.QUEEN && queensLeft == 0) {
                out += dlg(2, pick("qtrade", listOf(
                    x(SHK to "And the queens are off the board!", THO to "We are heading into a very different game now."),
                    x(TEN to "Both queens disappear from the board. Now it is a technical fight.", CLM to "Endgame skills will decide this one.")
                )), vars)
                bigDone = true
            } else if (captured == PieceType.QUEEN && mover.pieceType == PieceType.QUEEN && post.legalMoves().any { it.to == mv.to }) {
                out += dlg(2, x(SHK to "Queen takes queen on {sq}! Is there a recapture?", TEN to "Let's see if the queens are going to be traded."), vars)
                bigDone = true
            } else if (captured == PieceType.QUEEN) {
                out += dlg(3, x(SHK to "The queen falls! {n} takes the queen on {sq}!", DRM to "That is a huge moment in this match."), vars)
                bigDone = true
            } else if (captured == PieceType.ROOK) {
                out += dlg(2, pick("caprook", listOf(
                    x(EXC to "{n} takes the rook on {sq}!", TEN to "That is a serious gain of material."),
                    x(SHK to "The {p} captures a rook! What a swing!", WRM to "Has {o} overlooked something?")
                )), vars)
                bigDone = true
            } else if (rnd.nextInt(100) < 55 && level >= 2) {
                out += dlg(1, pick("cap", listOf(
                    x(TEN to "{p} takes {cap} on {sq}.", CLM to "A fair exchange so far."),
                    x(PLY to "Boom! The {cap} is gone.", WRM to "Trades are coming. Let's see who benefits."),
                    x(CLM to "{n} captures the {cap} on {sq}.", THO to "{o} will certainly think about the recapture."),
                    x(EXC to "Pieces are flying off the board!", PLY to "I love an open fight.")
                )), vars)
            }
            if (capStreak >= 4 && level >= 2) {
                out += CLine(nextLead(), "What an exchange fest! Pieces are disappearing quickly.", PLY, 1)
                capStreak = 0
            }
        } else capStreak = 0

        // 7) check
        if (check) {
            checkStreak++
            if (!bigDone) {
                if (checkStreak >= 3) {
                    out += dlg(2, x(EXC to "Check after check! The king is running for his life!", TEN to "{n} is not letting go!"), vars)
                    bigDone = true
                } else if (rnd.nextInt(100) < 65) {
                    out += dlg(2, pick("check", listOf(
                        x(TEN to "Check!", CLM to "{o} has to respond."),
                        x(TEN to "{n} gives check with the {p}!", THO to "The king needs to find a safe square."),
                        x(EXC to "Check on the king!", WRM to "That is an active move by {n}.")
                    )), vars)
                    bigDone = true
                }
            }
        } else checkStreak = 0

        // 8) castle
        if (!bigDone && castle) {
            val short = mv.to.name[0] == 'G'
            if (level >= 2 || rnd.nextInt(100) < 10) {
                out += dlg(1, pick(if (short) "cs" else "cl", if (short) listOf(
                    x(CLM to "{n} castles kingside. The king is safe, for now.", WRM to "Natural and healthy."),
                    x(WRM to "Short castle from {n}. Tucked away nicely.", CLM to "Now the rook is ready to join the game.")
                ) else listOf(
                    x(TEN to "{n} castles queenside! That is a sharp decision.", EXC to "Opposite sides could mean an attack is coming!"),
                    x(WRM to "Long castle! {n} wants to play for the attack.", THO to "Let's see if the king stays safe there.")
                )), vars)
                bigDone = true
            }
        }

        // 9) opening
        if (!openingDone && ply in 6..12) {
            val nme = openingName(history)
            if (nme != null) {
                openingDone = true
                out += dlg(2, pick("open", listOf(
                    x(WRM to "That looks like the $nme.", THO to "A well known path. ${nm(whiteMoved)} certainly knows the theory."),
                    x(CLM to "We are in the $nme.", PLY to "Let's see who leaves the book first!")
                )), vars)
            } else if (ply >= 10) openingDone = true
        }

        // 10) fiovaovan'ny material
        if (!bigDone && diffMover >= 3 && prevDiffMover < 3) {
            out += dlg(2, pick("lead", listOf(
                x(TEN to "{n} is now ahead by {lead}!", THO to "That can be decisive, but {o} is still fighting."),
                x(EXC to "{n} wins material! Now {n} has {lead} more!", DRM to "{o} is in real trouble.")
            )), vars)
            bigDone = true
        } else if (!bigDone && diffMover <= -3 && prevDiffMover > -3) {
            out += dlg(2, x(TEN to "And just like that, {o} is up {lead}!", THO to "{n} needs something creative now."), vars)
            bigDone = true
        }

        // 11) ora
        val base = m.baseMs
        if (base > 0) {
            val idx = moverIdx
            val thinkThreshold = max(20_000L, base / 5)
            if (spent >= thinkThreshold && ply > 6) {
                out += dlg(2, pick("long", listOf(
                    x(THO to "{n} spent a long time on that move.", CLM to "Must have been a difficult decision."),
                    x(TEN to "That took a lot of time, {n}!", WRM to "Let's hope it was worth the clock.")
                )), vars)
            }
            if (!frantic[idx] && remMover <= 10_000L && ply > 8) {
                frantic[idx] = true
                lowWarned[idx] = true
                out += dlg(3, pick("frantic", listOf(
                    x(SHK to "{n} is under ten seconds! Maybe he will lose by time out!", TEN to "The flag is hanging! Move fast!"),
                    x(EXC to "{n} is rushing out now! Only seconds left!", DRM to "One slip and the flag falls.")
                )), vars)
            } else if (!lowWarned[idx] && remMover <= max(30_000L, base / 6) && ply > 8) {
                lowWarned[idx] = true
                out += dlg(2, pick("lowtime", listOf(
                    x(TEN to "{n} is getting low on time, only ${minutes(remMover)} left.", THO to "That could be a decisive factor in this game."),
                    x(WRM to "Time pressure is starting to bite for {n}.", TEN to "He is going to have to rush.")
                )), vars + ("t" to minutes(remMover)))
            }
        }

        // 12) endgame / draw / marathon
        if (!endgameDone && ply > 20 && (w + bl) <= 24) {
            endgameDone = true
            out += dlg(2, pick("endg", listOf(
                x(THO to "We are entering the endgame now.", CLM to "Every pawn counts from here."),
                x(WRM to "The board is clearing up. This is the endgame.", TEN to "Precision matters more than ever.")
            )), vars)
        }
        if (!drawTalkDone && ply >= 70 && abs(w - bl) == 0 && (w + bl) <= 20) {
            drawTalkDone = true
            out += dlg(2, x(THO to "Material is completely equal. That will end up as a draw, I guess.", TEN to "Unless someone cracks under the pressure!"), vars)
        }
        if (!marathonDone && ply >= 120) {
            marathonDone = true
            out += dlg(2, x(SHK to "Move sixty already! This is a real marathon!", PLY to "Somebody get these players a coffee!"), vars)
        }

        // 13) hetsika mangina: resaka kely
        if (out.isEmpty() && level >= 2 && rnd.nextInt(100) < 38) {
            out += quiet(mover.pieceType, vars, diffMover)
        }

        lastBigPly = if (out.any { it.pri >= 2 }) ply else lastBigPly
        return keep(2, out)
    }

    private fun quiet(t: PieceType, vars: Map<String, String>, diff: Int): List<CLine> {
        val ex: List<Ex> = when (t) {
            PieceType.KNIGHT -> listOf(
                x(CLM to "{n} brings the knight to {sq}.", WRM to "Developing with a purpose."),
                x(PLY to "Knight to {sq}. A tricky little piece, that one.", CLM to "Always watch for forks.")
            )
            PieceType.BISHOP -> listOf(
                x(CLM to "The bishop goes to {sq}.", THO to "Looking down a long diagonal."),
                x(WRM to "{n} activates the bishop.", CLM to "Pressure builds slowly.")
            )
            PieceType.ROOK -> listOf(
                x(CLM to "Rook to {sq}.", THO to "Rooks love open files, let's see where this goes.")
            )
            PieceType.QUEEN -> listOf(
                x(TEN to "The queen moves to {sq}. Is {n} planning something?", THO to "Queens are powerful, but they can also be targets.")
            )
            PieceType.KING -> listOf(
                x(THO to "The king steps to {sq}.", CLM to "A quiet, careful move.")
            )
            else -> listOf(
                x(CLM to "Pawn to {sq}.", THO to "Gaining space on the board."),
                x(WRM to "{n} pushes the pawn forward.", CLM to "Slow, solid, strategic.")
            )
        }
        val extra = if (diff >= 3) listOf(x(CLM to "{n} is comfortably ahead now, and just needs to stay careful.", THO to "{o} has to create complications.")) else
            if (diff <= -3) listOf(x(THO to "{n} is behind in material, so something dynamic is needed.", TEN to "A comeback is possible, but the road is steep.")) else emptyList()
        return dlg(1, pick("q", ex + extra), vars)
    }

    // =====================================================================
    //  VALINY
    // =====================================================================
    /** reason: "timeout", "resign", "agreed" na "" (valiny voajanahary: mate, stalemate, draw...). */
    fun onResult(result: String, finalFen: String, plies: Int, reason: String): List<CLine> {
        val vars = HashMap<String, String>()
        val k = (plies + 1) / 2
        vars["k"] = k.toString()
        vars["t"] = m.tournament ?: ""
        val out = ArrayList<CLine>()
        val lead = nextLead()
        if (result == "1-0" || result == "0-1") {
            val whiteWon = result == "1-0"
            val win = nm(whiteWon); val lose = nm(!whiteWon)
            vars["w"] = win; vars["l"] = lose
            val head: Ex = when (reason) {
                "timeout" -> pick("rto", listOf(
                    x(EXC to "The flag falls! {l} runs out of time, and {w} wins!", DRM to "A cruel way to lose a game."),
                    x(SHK to "Time out! {l} lost on the clock!", THO to "Sometimes the clock is the toughest opponent.")
                ))
                "resign" -> pick("rres", listOf(
                    x(WRM to "{l} resigns. {w} wins the game!", CLM to "A dignified decision when the position is lost."),
                    x(TEN to "That's it! {l} gives up, and {w} takes the victory!", THO to "Sometimes you just know it's over.")
                ))
                else -> pick("rmate", listOf(
                    x(EXC to "Checkmate! {w} wins the game!", EXC to "What a finish! Take a bow, {w}!"),
                    x(SHK to "And that is checkmate! {l}'s king has nowhere to go!", WRM to "A beautiful finish by {w}.")
                ))
            }
            out += dlg(3, head, vars, lead)
            when {
                k <= 15 -> out += CLine(other(lead), "And in only $k moves! What a lightning fast game!", SHK, 2)
                k <= 25 -> out += CLine(other(lead), "A quick win, just $k moves. ${lose} will want to forget this game.", PLY, 2)
                k >= 70 -> out += CLine(other(lead), "After $k moves, that was a real marathon!", EXC, 2)
            }
            val next = nextStageWord()
            if (m.stage == "KO2") {
                out += dlg(3, x(EXC to "{w} is the champion of {t}! Congratulations!", WRM to "What a performance throughout this tournament. A very well deserved title!"), vars, lead)
            } else if (m.stage == "KO4" || m.stage == "KO8" || m.stage == "KO16") {
                out += dlg(2, x(EXC to "{w} goes through to the $next!", THO to "And that is the end of the road for {l} in this tournament."), vars, lead)
            } else if (m.stage == "G") {
                out += dlg(2, x(WRM to "A big win for {w} in the group table.", CLM to "That could be decisive when it comes to qualification."), vars, lead)
            } else {
                out += CLine(lead, pick("rfr", listOf("Good game by both players!", "Thanks for this lovely match, everybody.", "Well played, {w}!")).replace("{w}", win), WRM, 1)
            }
        } else {
            val head: Ex = when {
                reason == "agreed" -> x(CLM to "The players agree to a draw.", THO to "A sensible decision when neither side can make progress.")
                finalFen.let { !loadBoard(it).isKingAttacked && loadBoard(it).legalMoves().isEmpty() } ->
                    x(SHK to "Stalemate! It's a draw!", EXC to "What a great escape! You can't make this up!")
                else -> pick("rdraw", listOf(
                    x(CLM to "And that is a draw.", THO to "Neither side could break through."),
                    x(WRM to "The game ends in a draw after $k moves.", CLM to "A fair result, I think.")
                ))
            }
            out += dlg(3, head, vars, lead)
            if (m.stage.startsWith("KO")) {
                out += dlg(2, x(TEN to "But in a knockout, there has to be a winner! An extra game is coming!", EXC to "More tension, more drama. I love it!"), vars, lead)
            }
        }
        return keep(3, out)
    }

    // =====================================================================
    //  FOTOANA MANGINA
    // =====================================================================
    fun idle(s: LiveSnap): List<CLine> {
        val cands = ArrayList<Pair<String, () -> List<CLine>>>()
        val whiteToMove = s.fen.split(" ").getOrNull(1) != "b"
        val mover = nm(whiteToMove); val waiter = nm(!whiteToMove)
        val (w, bl) = matOf(s.fen)
        val vars = mapOf("n" to mover, "o" to waiter)
        val diffWhite = w - bl
        val total = w + bl

        // mieritreritra
        if (s.thinkingMs > 7_000) cands += "think" to { dlg(2, pick("idl-think", listOf(
            x(THO to "{n} has been thinking for a while now. This must be a critical moment.", TEN to "The whole hall holds its breath."),
            x(TEN to "Long think from {n}... what is going on in that head?", THO to "He sees something, or he sees nothing. Hard to tell!")
        )), vars) }
        if (s.thinkingMs > 20_000 && s.clockOn) cands += "think2" to { dlg(2, x(SHK to "{n} is wasting a lot of time here!", TEN to "He may regret this later on the clock."), vars) }

        // ora
        if (s.clockOn && s.ply > 6) {
            val wm = s.whiteMs; val bm = s.blackMs
            cands += "clock" to { dlg(1, x(
                CLM to "On the clocks: ${m.white.name} has ${minutes(wm)}, and ${m.black.name} has ${minutes(bm)}.",
                if (abs(wm - bm) > 25_000) THO to "${if (wm > bm) m.white.name else m.black.name} has a clear time advantage." else THO to "Pretty balanced on the clock."
            )) }
            val moreUsed = if (spentTotal[0] > spentTotal[1]) 0 else 1
            if (abs(spentTotal[0] - spentTotal[1]) > max(40_000L, m.baseMs / 4)) cands += "waste" to {
                dlg(2, x(TEN to "${nm(moreUsed == 0)} is using a lot of time compared to ${nm(moreUsed != 0)}.", THO to "Maybe he will end up losing by time out if this continues."))
            }
            if (minOf(wm, bm) < max(40_000L, m.baseMs / 6)) cands += "tight" to {
                dlg(2, x(TEN to "The clocks are getting dangerous!", EXC to "One of them might lose by time out here!"))
            }
        }

        // toerana
        if (s.ply > 8) {
            val behind = if (diffWhite <= -3) m.white.name else if (diffWhite >= 3) m.black.name else null
            val ahead = if (diffWhite <= -3) m.black.name else if (diffWhite >= 3) m.white.name else null
            if (behind != null && ahead != null) {
                val v2 = mapOf("a" to ahead, "b" to behind, "s" to stageWord())
                cands += "better" to { dlg(2, x(THO to "$ahead is better here, with extra material.", TEN to "Can $behind find something to survive in this position?"), v2) }
                if (m.stage.startsWith("KO")) cands += "surv" to {
                    dlg(2, x(TEN to "Maybe $behind can survive at this position, or his road is going to stop here at the ${stageWord()}.", DRM to "$ahead is closing in."), v2)
                }
            } else cands += "equal" to { dlg(1, x(CLM to "The material is level, so the fight is all about activity now.", THO to "Small details will decide it.")) }
            if (total <= 26 && s.ply > 30) cands += "end" to { dlg(1, x(THO to "Endgames are about precision. One tiny inaccuracy can flip the result.", CLM to "Let's watch the king activity.")) }
            val pawnsW = countPiece(s.fen, 'p')
            if (pawnsW <= 4 && total <= 20) cands += "pawns" to { dlg(1, x(CLM to "Few pawns left on the board, so a draw is always in the air.", THO to "The side with the better king usually wins these.")) }
        }

        // maso
        if (m.stage == "KO2") cands += "who" to { dlg(2, x(EXC to "Who is going to lift the trophy tonight?", TEN to "I honestly can't call it. Every move matters!")) }
        if (m.stage == "KO4") cands += "who" to { dlg(2, x(EXC to "Who is going to the final?", TEN to "Only one of these two will be playing for the title.")) }
        if (m.stage == "KO8" || m.stage == "KO16") cands += "who" to { dlg(1, x(TEN to "This is knockout chess. One bad game and you are out.", WRM to "That is what makes this format so exciting.")) }
        if (m.stage == "G") cands += "who" to { dlg(1, x(CLM to "Every point in the group matters for qualification.", THO to "A draw could be useful for some, but not for the one who needs the win.")) }

        // mpilalao
        for ((i, p) in listOf(m.white, m.black).withIndex()) {
            styleRemark(p)?.let { r -> cands += "style$i" to { dlg(1, x(WRM to r, PLY to "Let's see if that shows up in this game!")) } }
            if (p.elo != null && p.tier != null && p.isBot) cands += "tier$i" to {
                dlg(1, x(CLM to "${p.name} is rated around ${p.elo}, that is ${p.tier} level.", THO to "That says a lot about what to expect from this player."))
            }
        }
        if (m.white.elo != null && m.black.elo != null && abs(m.white.elo - m.black.elo) >= 150) {
            val dog = if (m.white.elo < m.black.elo) m.white else m.black
            val fav = if (m.white.elo < m.black.elo) m.black else m.white
            cands += "dog" to { dlg(2, x(PLY to "${dog.name} is the underdog today, but anything can happen over the board.", WRM to "${fav.name} cannot relax for a second.")) }
        }
        if (blunders[0] + blunders[1] >= 2) cands += "mistakes" to { dlg(2, x(PLY to "Plenty of mistakes today. Nobody is perfect, not even at this level!", WRM to "That is what makes chess so human.")) }

        // fampahalalana fifaninanana
        for (i in m.facts.indices) {
            val f = m.facts[(i + factIdx) % m.facts.size]
            cands += "fact${(i + factIdx) % m.facts.size}" to { dlg(2, x(WRM to f, pick("react", listOf(
                CLM to "Remember that, it could matter later.", PLY to "Now that is something to think about!",
                THO to "Interesting little detail, isn't it?", EXC to "And that adds spice to today's game!")))) }
            if (i >= 2) break
        }
        if (m.facts.isNotEmpty()) factIdx++

        // tantara
        cands += "trivia" to { val t = pick("triv", TRIVIA); dlg(1, x(WRM to t.first, pick("tr-react", listOf(PLY to "Chess never stops amazing me.", CLM to "History is always watching these players.", EXC to "Legends of the game!")) )) }
        cands += "trivia2" to { val t = pick("triv", TRIVIA); dlg(1, x(THO to "Here is a little history while they think. " + t.first, WRM to t.second)) }

        // atmosfera
        cands += "atm" to { dlg(1, pick("atm", listOf(
            x(CLM to "It is so quiet in the hall that you could hear a pin drop.", PLY to "Or a queen being sacrificed!"),
            x(THO to "Both players look completely focused.", WRM to "That level of concentration is impressive."),
            x(WRM to "What a fantastic atmosphere here today!", EXC to "The audience is on the edge of their seats!"),
            x(PLY to "I think my heart rate is higher than theirs.", CLM to "Mine too, honestly.")
        ))) }

        val usable = cands.filter { it.first !in usedIdle || it.first == "atm" }
        val pool = if (usable.isEmpty()) { usedIdle.clear(); cands } else usable
        val (key, build) = pool[rnd.nextInt(pool.size)]
        usedIdle += key
        if (usedIdle.size > 14) usedIdle.clear()
        val lines = build()
        return if (level <= 1) lines.filter { it.pri >= 2 } else lines
    }

    companion object {
        /** (fehezanteny, valin'ny mpiara-miasa). */
        val TRIVIA: List<Pair<String, String>> =
            listOf(
                "In 1997, the computer Deep Blue beat world champion Garry Kasparov in a six game match." to "That was a historic day for chess and for computers.",
                "The fastest possible checkmate is the fool's mate, in just two moves." to "Let's hope nobody falls for that today!",
                "The number of possible chess games is often said to be larger than the number of atoms in the observable universe." to "So every game here is truly unique.",
                "Magnus Carlsen became a grandmaster at only thirteen years old." to "Imagine what the next generation is going to do!",
                "In 1972, Bobby Fischer beat Boris Spassky in Reykjavik to become world champion." to "A match that was followed all over the world.",
                "The famous Immortal Game was played in 1851 by Adolf Anderssen, who sacrificed a bishop, both rooks and even his queen, and still won." to "Pure romantic chess!",
                "Garry Kasparov became world champion at only twenty two years old, in 1985." to "The youngest undisputed champion at that time.",
                "The longest official tournament game ever played lasted 269 moves, and it ended in a draw, in 1989." to "I hope today's game is a bit shorter!",
                "The word checkmate comes from the Persian phrase shah mat, which means the king is helpless." to "A beautiful origin for a beautiful word.",
                "Chess is believed to have started in India around the sixth century, in a game called chaturanga." to "Fifteen hundred years of strategy on sixty four squares.",
                "Judit Polgar, the strongest woman player in history, once beat Garry Kasparov in 2002." to "She was fearless at the board.",
                "Mikhail Tal, the magician from Riga, became world champion in 1960 thanks to his wild sacrifices." to "He would have loved some of today's games.",
                "The Elo rating system was created by Arpad Elo and adopted by the world chess federation in 1970." to "The same numbers you see next to the players' names!",
                "Magnus Carlsen reached a peak rating of 2882 in 2014, the highest of all time." to "A number that seems almost unreal.",
                "In 1858, Paul Morphy played his famous opera game, in a private box, during a performance in Paris." to "A game and a show at the same time.",
                "AlphaZero taught itself chess in a matter of hours, and then beat one of the strongest engines of its time." to "Machines changed how we see the game.",
                "The engine that powers this very app is Stockfish, one of the strongest chess engines in the world." to "And it's open source, which is wonderful.",
                "In 1999, Kasparov played a famous rook sacrifice against Veselin Topalov at Wijk aan Zee, often called Kasparov's Immortal." to "Some moves are just unforgettable.",
                "The queen used to be a weak piece. She became the most powerful piece at the end of the fifteenth century." to "Good thing she got her promotion!",
                "Viswanathan Anand won the world championship five times." to "A real gentleman of the game."
            )
    }
}
