package mg.chess.offline

import android.content.Context
import android.util.Log
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Side
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Valiny lalao: "1-0", "0-1", "1/2-1/2" na null raha mbola mitohy. */
fun gameResult(b: Board): String? {
    val mated = b.isMated
    val noMoves = b.legalMoves().isEmpty()
    return when {
        mated -> if (b.sideToMove == Side.WHITE) "0-1" else "1-0"
        b.isDraw || noMoves -> "1/2-1/2"
        else -> null
    }
}

fun stageLabel(s: String): String = when (s) {
    "G" -> "Phase de poule"
    "KO16" -> "8ème de finale"
    "KO8" -> "Quart de finale"
    "KO4" -> "Demi-finale"
    "KO2" -> "Finale"
    "BR" -> "Faha-3 (medaille varahina)"
    else -> when {
        s.length > 1 && s[0] == 'S' && s.drop(1).all { it.isDigit() } -> "Round ${s.drop(1)} (Swiss)"
        s.length > 1 && s[0] == 'D' && s.drop(1).all { it.isDigit() } -> "Round ${s.drop(1)} (Double)"
        else -> s
    }
}

/** Anarana feno ny lalao (round + bracket) ho an'ny lisitra sy ny Watch. */
fun matchStageLabel(m: TMatch): String = when {
    m.stage == "G" -> stageLabel("G") + " - " + groupName(m.group)
    m.stage.startsWith("D") -> when (m.group) {
        0 -> "Winners - R${m.round}"
        1 -> "Losers - R${m.round}"
        else -> if (m.round >= 2) "Grand Finale (reset)" else "Grand Finale"
    }
    else -> stageLabel(m.stage)
}

class DoubleBracket(
    val winners: List<List<BracketMatch>>,
    val losers: List<List<BracketMatch>>,
    val finals: List<List<BracketMatch>>
)

fun pow2Floor(x: Int): Int = if (x < 1) 1 else Integer.highestOneBit(x)
fun pow2Ceil(x: Int): Int { var p = 1; while (p < x) p *= 2; return p }
fun groupCountFor(n: Int): Int = if (n > 16) 8 else pow2Floor(n / 3).coerceIn(1, 8)
fun groupName(i: Int): String = "Poule " + ('A' + i)

fun describeDouble(n: Int): String {
    if (n < 4) return "Double elimination mila mpilalao 4 farafahakeliny."
    if (n > 16) return "Double elimination: mpilalao 16 no be indrindra."
    val k = pow2Ceil(n)
    return "Double elimination: tsy tonga eo ivelany raha tsy resy indroa. Winners + Losers bracket, Grand Finale (reset raha resy ny mpandresy Winners)." +
        (if (k > n) " (${k - n} bye)" else "")
}

fun describeSwiss(n: Int): String {
    if (n < 4) return "Swiss mila mpilalao 4 farafahakeliny."
    if (n > 16) return "Swiss: mpilalao 16 no be indrindra."
    var r = 0; var p = 1
    while (p < n) { p *= 2; r++ }
    val rounds = r.coerceAtLeast(3).coerceAtMost(n - 1)
    return "Swiss: $rounds round, mpilalao rehetra miady isaky ny round (araka ny isa). Ny isa ambony indrindra no tompon-daka; faha-2 sy faha-3 azo medaille."
}

fun describeFormat(n: Int, wantGroups: Boolean): String {
    if (n < 2) return "Mila mpilalao 2 farafahakeliny."
    if (n > 32) return "Mpilalao 32 no be indrindra."
    val groups = n > 16 || (wantGroups && n >= 3)
    return if (groups) {
        val g = groupCountFor(n)
        "$g poule - ny 2 voalohany isaky ny poule no miakatra mankany amin'ny " + stageLabel("KO" + (g * 2))
    } else {
        val k = pow2Ceil(n)
        val byes = k - n
        "Knockout mivantana: " + stageLabel("KO$k") + (if (byes > 0) " ($byes bye)" else "")
    }
}

private fun bracketOrder(k: Int): List<Int> {
    var l = listOf(1)
    while (l.size < k) {
        val n = l.size * 2
        l = l.flatMap { listOf(it, n + 1 - it) }
    }
    return l
}

/** Mpandray anjara: bot (snapshot) na olona (bot = null). */
data class Participant(val id: String, val name: String, val elo: Int, val bot: Bot?)

class TMatch(
    val id: Int,
    val stage: String,        // "G" na "KO16" / "KO8" / "KO4" / "KO2"
    val slot: Int,            // toerana ao amin'ny bracket (-1 ho an'ny poule)
    val game: Int,            // 0 = lalao voalohany; >0 = lalao fanampiny aorian'ny draw
    val whiteId: String?,
    val blackId: String?
) {
    var group: Int = -1
    /** Double elimination: laharan'ny round ao amin'ny bracket (group 0 = Winners, 1 = Losers, 2 = Grand Finale). */
    var round: Int = 0
    var moves: List<String> = emptyList()
    var whiteMs: Long = 0L
    var blackMs: Long = 0L
    var result: String? = null
    var winner: String? = null
    /** Analyse aorian'ny lalao (ho an'ny classement mpilalao sy ny archive brilliant). */
    var analysis: MatchAnalysis? = null
}

/** Hetsika brilliant (!!) tehirizina ao amin'ny archive an'ny fifaninanana. [ply] = laharan'ny hetsika (1 = voalohany). */
data class BrilliantMove(
    val ply: Int, val white: Boolean, val san: String, val uci: String, val fen: String,
    /** Fahaverezana (centipawn) - ho an'ny blunder; 0 ho an'ny brilliant. */
    val cpLoss: Int = 0
)

data class SideAn(
    val moves: Int, val accuracy: Double, val acpl: Int,
    val brilliant: Int, val great: Int, val mistake: Int, val blunder: Int
)

class MatchAnalysis(
    val white: SideAn, val black: SideAn, val brilliants: List<BrilliantMove>,
    /** Blunder lehibe indrindra (!!/?? ho an'ny kilan'ny Milalao). */
    val blunders: List<BrilliantMove> = emptyList()
)

fun analysisOf(r: ReviewResult): MatchAnalysis {
    fun side(side: Side, sum: SideSummary): SideAn {
        val n = r.moves.count { it.side == side }
        return SideAn(
            n, sum.accuracy, sum.acpl,
            sum.counts[Cls.BRILLIANT] ?: 0, sum.counts[Cls.GREAT] ?: 0,
            sum.counts[Cls.MISTAKE] ?: 0, sum.counts[Cls.BLUNDER] ?: 0
        )
    }
    val br = ArrayList<BrilliantMove>()
    r.moves.forEachIndexed { i, mv ->
        if (mv.cls == Cls.BRILLIANT) br.add(BrilliantMove(i + 1, mv.side == Side.WHITE, mv.san, mv.uci, r.fens.getOrElse(i) { START_FEN }))
    }
    val bl = ArrayList<BrilliantMove>()
    r.moves.forEachIndexed { i, mv ->
        if (mv.cls == Cls.BLUNDER) bl.add(BrilliantMove(i + 1, mv.side == Side.WHITE, mv.san, mv.uci, r.fens.getOrElse(i) { START_FEN }, mv.cpLoss))
    }
    return MatchAnalysis(side(Side.WHITE, r.white), side(Side.BLACK, r.black), br, bl.sortedByDescending { it.cpLoss }.take(3))
}

/** Lakile: bot = b:<id>, olona = h:<anarana> (azo ampitahaina eo amin'ny fifaninanana maro). */
fun Participant.key(): String = if (bot != null) "b:" + bot.id else "h:$name"

/** Andalana classement an'ny mpilalao iray ao anaty fifaninanana. */
data class PlayerLine(
    val id: String, val played: Int, val w: Int, val d: Int, val l: Int, val pts: Double,
    val brilliant: Int, val great: Int, val blunder: Int,
    val accuracy: Double?, val analysed: Int
)

private fun isPlayed(m: TMatch) = m.result == "1-0" || m.result == "0-1" || m.result == "1/2-1/2"

data class BracketMatch(
    val round: Int, val slot: Int,
    val whiteLabel: String, val blackLabel: String,
    val whiteId: String?, val blackId: String?,
    val scoreText: String, val winnerId: String?,
    val matches: List<TMatch>
)

data class StandRow(val id: String, val played: Int, val w: Int, val d: Int, val l: Int, val pts: Double)

class Tournament(
    val id: Long,
    var name: String,
    val players: List<Participant>,
    val baseMs: Long,
    val incMs: Long,
    val useGroups: Boolean
) {
    var groups: List<List<String>> = emptyList()
    /** "CUP" (knockout/poule) na "SWISS". */
    var format: String = "CUP"
    val isSwiss: Boolean get() = format == "SWISS"
    val isDouble: Boolean get() = format == "DOUBLE"
    /** Double elimination: round efa noforonina ("W1", "L2", "GF1"...) sy ny laharan'ny dingana ("D3"). */
    val dDone = HashSet<String>()
    var dStep: Int = 0
    private var dCur: String = "D1"
    val matches = ArrayList<TMatch>()
    var stage: String = "G"
    var champion: String? = null
    var nextId: Int = 1
    var updated: Long = System.currentTimeMillis()

    fun player(id: String?): Participant? = if (id == null) null else players.firstOrNull { it.id == id }
    fun name(id: String?): String = player(id)?.name ?: "—"
    /** Lalao ao amin'ny round (ao amin'ny Finale dia miaraka amin'ny lalao faha-3 "BR"). */
    fun stageMatches(s: String = stage): List<TMatch> =
        matches.filter { it.stage == s || (s == "KO2" && it.stage == "BR") }

    private fun addKoMatch(stg: String, slot: Int, a: String?, b: String?) {
        val swap = a == null && b != null
        val w = if (swap) b else a
        val bl = if (swap) a else b
        val m = TMatch(nextId++, stg, slot, 0, w, bl)
        if (bl == null) { m.result = "bye"; m.winner = w }
        matches.add(m)
    }

    private fun buildFirstKo(seedIds: List<String>, k: Int) {
        val order = bracketOrder(k)
        for (i in 0 until k / 2) {
            val a = seedIds.getOrNull(order[2 * i] - 1)
            val b = seedIds.getOrNull(order[2 * i + 1] - 1)
            addKoMatch("KO$k", i, a, b)
        }
    }

    fun recordResult(m: TMatch, res: String) {
        m.result = res
        if (m.stage == "G" || m.stage.startsWith("S")) return
        if (res == "1-0") {
            m.winner = m.whiteId
        } else if (res == "0-1") {
            m.winner = m.blackId
        } else if (m.game < 2) {
            // draw ao amin'ny knockout: lalao fanampiny, miova loko
            val x = TMatch(nextId++, m.stage, m.slot, m.game + 1, m.blackId, m.whiteId)
            x.group = m.group; x.round = m.round
            matches.add(x)
        } else {
            val we = player(m.whiteId)?.elo ?: 0
            val be = player(m.blackId)?.elo ?: 0
            m.winner = if (be > we) m.blackId else m.whiteId
        }
    }

    fun standings(g: Int): List<StandRow> {
        val ids = groups.getOrNull(g) ?: return emptyList()
        val ms = matches.filter { it.stage == "G" && it.group == g && it.result != null }
        val rows = ids.map { pid ->
            var w = 0; var d = 0; var l = 0
            for (m in ms) {
                val isW = m.whiteId == pid
                val isB = m.blackId == pid
                if (!isW && !isB) continue
                if (m.result == "1-0") { if (isW) w++ else l++ }
                else if (m.result == "0-1") { if (isB) w++ else l++ }
                else d++
            }
            StandRow(pid, w + d + l, w, d, l, w + d * 0.5)
        }
        return rows.sortedWith(
            compareByDescending<StandRow> { it.pts }
                .thenByDescending { it.w }
                .thenByDescending { player(it.id)?.elo ?: 0 }
        )
    }

    /** Mpandresy isaky ny slot (lahatra voalamina), na null raha mbola misy tsy voavaha. */
    fun slotWinners(): List<String>? {
        val bySlot = matches.filter { it.stage == stage }.groupBy { it.slot }.toSortedMap()
        val out = ArrayList<String>()
        for ((_, l) in bySlot) {
            val w = l.firstNotNullOfOrNull { it.winner } ?: return null
            out.add(w)
        }
        return out
    }

    fun stageComplete(): Boolean {
        if (champion != null) return false
        val ms = stageMatches()
        if (ms.isEmpty() || ms.any { it.result == null }) return false
        return if (stage == "G" || stage.startsWith("S") || stage.startsWith("D")) true else slotWinners() != null
    }

    fun advance(): Boolean {
        if (!stageComplete()) return false
        if (isDouble) return fillD()
        if (stage.startsWith("S")) {
            val r = swissRoundNo()
            if (r >= swissRoundsTotal()) { champion = swissStandings().firstOrNull()?.id; return true }
            stage = "S${r + 1}"
            buildSwissRound(r + 1)
            return true
        }
        if (stage == "G") {
            val tables = groups.indices.map { standings(it) }
            val g = tables.size
            val w = tables.map { it[0].id }
            val r = tables.map { it.getOrNull(1)?.id ?: it[0].id }
            val pairs: List<Pair<String, String>> =
                if (g == 1) listOf(w[0] to r[0])
                else (0 until g step 2).map { w[it] to r[it + 1] } + (0 until g step 2).map { w[it + 1] to r[it] }
            stage = "KO" + (pairs.size * 2)
            pairs.forEachIndexed { i, p -> addKoMatch(stage, i, p.first, p.second) }
            return true
        }
        val ws = slotWinners() ?: return false
        if (ws.size == 1) { champion = ws[0]; return true }
        if (stage == "KO4" && ws.size == 2) {
            // Lalao faha-3: resy roa amin'ny demi-finale
            val losers = (0 until 2).map { slot ->
                val ms = matches.filter { it.stage == "KO4" && it.slot == slot }.sortedBy { it.game }
                val first = ms.firstOrNull()
                listOfNotNull(first?.whiteId, first?.blackId).firstOrNull { it != ws[slot] }
            }
            if (losers[0] != null && losers[1] != null) {
                matches.add(TMatch(nextId++, "BR", 0, 0, losers[0], losers[1]))
            }
        }
        stage = "KO" + ws.size
        for (i in 0 until ws.size / 2) addKoMatch(stage, i, ws[2 * i], ws[2 * i + 1])
        return true
    }

    // ---------- Podium / medaille ----------
    /** (volamena, volafotsy) rehefa vita ny fifaninanana; null raha mbola mitohy. */
    fun podium(): Pair<String, String?>? {
        val gold = champion ?: return null
        if (isSwiss) return gold to swissStandings().getOrNull(1)?.id
        if (isDouble) {
            val gf = matches.filter { it.stage.startsWith("D") && it.group == 2 }
            val last = gf.maxOfOrNull { it.round }
            val fm = gf.filter { it.round == last }.minByOrNull { it.game }
            return gold to listOfNotNull(fm?.whiteId, fm?.blackId).firstOrNull { it != gold }
        }
        val fin = matches.filter { it.stage == "KO2" }.minByOrNull { it.game }
        val silver = listOfNotNull(fin?.whiteId, fin?.blackId).firstOrNull { it != gold }
        return gold to silver
    }

    /** Medaille varahina: mpandresy ny lalao faha-3 (cup) na faha-3 ao amin'ny Swiss. */
    fun bronze(): String? {
        if (champion == null) return null
        if (isSwiss) return swissStandings().getOrNull(2)?.id
        if (isDouble) return dSlotLoser(1, dLastL(), 0)
        return matches.filter { it.stage == "BR" }.firstNotNullOfOrNull { it.winner }
    }

    // ---------- Double elimination ----------
    fun dK(): Int = pow2Ceil(players.size)
    fun dM(): Int { var m = 0; var p = 1; while (p < dK()) { p *= 2; m++ }; return m }
    fun dLastL(): Int = 2 * dM() - 2

    /** Isan'ny lalao ao amin'ny round [r] amin'ny bracket [b] (0 = Winners, 1 = Losers). */
    fun dCount(b: Int, r: Int): Int = if (b == 0) dK() shr r else dK() shr ((r + 1) / 2 + 1)

    private fun dKey(b: Int, r: Int) = when (b) { 0 -> "W$r"; 1 -> "L$r"; else -> "GF$r" }
    private fun dMatches(b: Int, r: Int) = matches.filter { it.stage.startsWith("D") && it.group == b && it.round == r }
    fun dSlot(b: Int, r: Int, i: Int): List<TMatch> = dMatches(b, r).filter { it.slot == i }.sortedBy { it.game }
    fun dSlotWinner(b: Int, r: Int, i: Int): String? = dSlot(b, r, i).firstNotNullOfOrNull { it.winner }
    fun dSlotLoser(b: Int, r: Int, i: Int): String? {
        val ms = dSlot(b, r, i)
        val f = ms.firstOrNull() ?: return null
        val w = ms.firstNotNullOfOrNull { it.winner } ?: return null
        return listOfNotNull(f.whiteId, f.blackId).firstOrNull { it != w }
    }
    private fun dRoundDone(b: Int, r: Int): Boolean = dKey(b, r) in dDone && dMatches(b, r).all { it.result != null }
    private fun dWinners(b: Int, r: Int): List<String?> = (0 until dCount(b, r)).map { dSlotWinner(b, r, it) }
    private fun dLosers(b: Int, r: Int): List<String?> = (0 until dCount(b, r)).map { dSlotLoser(b, r, it) }

    private fun addD(b: Int, r: Int, slot: Int, a: String?, c: String?) {
        if (a == null && c == null) return
        val swap = a == null && c != null
        val w = if (swap) c else a
        val bl = if (swap) a else c
        val m = TMatch(nextId++, dCur, slot, 0, w, bl)
        m.group = b; m.round = r
        if (bl == null) { m.result = "bye"; m.winner = w }
        matches.add(m)
    }

    private fun dChampion(): String? {
        if (!dRoundDone(2, 1)) return null
        val g1 = dSlotWinner(2, 1, 0) ?: return null
        val wc = dWinners(0, dM()).firstOrNull()
        if (wc == null || g1 == wc) return g1
        if (!dRoundDone(2, 2)) return null
        return dSlotWinner(2, 2, 0)
    }

    /** Mamorona ny lalao rehetra azo atao araka ny vokatra efa vita. Mamerina true raha misy zavatra niova. */
    private fun buildNextD() {
        val m = dM(); val k = dK()
        dCur = "D${dStep + 1}"
        var created = false
        fun mark(key: String) { dDone.add(key); created = true }
        if ("W1" !in dDone) {
            mark("W1")
            val order = bracketOrder(k)
            val seeds = players.sortedByDescending { it.elo }.map { it.id }
            for (i in 0 until k / 2) addD(0, 1, i, seeds.getOrNull(order[2 * i] - 1), seeds.getOrNull(order[2 * i + 1] - 1))
        }
        for (r in 2..m) {
            if ("W$r" !in dDone && dRoundDone(0, r - 1)) {
                mark("W$r")
                val w = dWinners(0, r - 1)
                for (i in 0 until dCount(0, r)) addD(0, r, i, w[2 * i], w[2 * i + 1])
            }
        }
        if ("L1" !in dDone && dRoundDone(0, 1)) {
            mark("L1")
            val l = dLosers(0, 1)
            for (i in 0 until dCount(1, 1)) addD(1, 1, i, l[2 * i], l[2 * i + 1])
        }
        for (q in 1 until m) {
            val rd = 2 * q
            if ("L$rd" !in dDone && dRoundDone(1, rd - 1) && dRoundDone(0, q + 1)) {
                mark("L$rd")
                val a = dWinners(1, rd - 1)
                val lw = dLosers(0, q + 1).let { if (q % 2 == 1) it.reversed() else it }
                for (i in 0 until dCount(1, rd)) addD(1, rd, i, a[i], lw[i])
            }
            val ro = 2 * q + 1
            if (q < m - 1 && "L$ro" !in dDone && dRoundDone(1, rd)) {
                mark("L$ro")
                val a = dWinners(1, rd)
                for (i in 0 until dCount(1, ro)) addD(1, ro, i, a[2 * i], a[2 * i + 1])
            }
        }
        if ("GF1" !in dDone && dRoundDone(0, m) && dRoundDone(1, dLastL())) {
            mark("GF1")
            addD(2, 1, 0, dWinners(0, m).firstOrNull(), dWinners(1, dLastL()).firstOrNull())
        }
        if ("GF2" !in dDone && dRoundDone(2, 1)) {
            val g1 = dSlotWinner(2, 1, 0)
            val wc = dWinners(0, m).firstOrNull()
            val f = dSlot(2, 1, 0).firstOrNull()
            if (g1 != null && wc != null && g1 != wc && f != null) {
                mark("GF2")
                addD(2, 2, 0, f.blackId, f.whiteId)
            }
        }
        if (created) { dStep += 1; stage = dCur }
    }

    private fun fillD(): Boolean {
        var guard = 0
        while (guard++ < 24) {
            val c = dChampion()
            if (c != null) { champion = c; return true }
            val before = matches.size + dDone.size
            buildNextD()
            if (matches.size + dDone.size == before) return false
            if (stageMatches().any { it.result == null }) return true
        }
        return true
    }

    fun doubleBracket(): DoubleBracket {
        val m = dM()
        fun lab(id: String?, fallback: String) = if (id != null) name(id) else fallback
        fun build(b: Int, r: Int, i: Int, wl: String, bl: String): BracketMatch {
            val ms = dSlot(b, r, i)
            if (ms.isNotEmpty()) {
                val f = ms[0]
                val txt = ms.filter { it.result != null }.joinToString(" · ") {
                    if (it.result == "bye") "bye" else it.result!!.replace("1/2-1/2", "½-½")
                }
                return BracketMatch(r, i, name(f.whiteId), name(f.blackId), f.whiteId, f.blackId, txt, ms.firstNotNullOfOrNull { it.winner }, ms)
            }
            if (dKey(b, r) in dDone) return BracketMatch(r, i, "—", "—", null, null, "", null, emptyList())
            return BracketMatch(r, i, wl, bl, null, null, "", null, emptyList())
        }
        val winners = (1..m).map { r ->
            (0 until dCount(0, r)).map { i ->
                if (r == 1) build(0, r, i, "—", "—")
                else build(0, r, i,
                    lab(dSlotWinner(0, r - 1, 2 * i), "Mpandresy W${r - 1}.${2 * i + 1}"),
                    lab(dSlotWinner(0, r - 1, 2 * i + 1), "Mpandresy W${r - 1}.${2 * i + 2}"))
            }
        }
        val losers = (1..dLastL()).map { r ->
            val cnt = dCount(1, r)
            (0 until cnt).map { i ->
                when {
                    r == 1 -> build(1, r, i,
                        lab(dSlotLoser(0, 1, 2 * i), "Resy W1.${2 * i + 1}"),
                        lab(dSlotLoser(0, 1, 2 * i + 1), "Resy W1.${2 * i + 2}"))
                    r % 2 == 0 -> {
                        val q = r / 2
                        val idx = if (q % 2 == 1) cnt - 1 - i else i
                        build(1, r, i,
                            lab(dSlotWinner(1, r - 1, i), "Mpandresy L${r - 1}.${i + 1}"),
                            lab(dSlotLoser(0, q + 1, idx), "Resy W${q + 1}.${idx + 1}"))
                    }
                    else -> build(1, r, i,
                        lab(dSlotWinner(1, r - 1, 2 * i), "Mpandresy L${r - 1}.${2 * i + 1}"),
                        lab(dSlotWinner(1, r - 1, 2 * i + 1), "Mpandresy L${r - 1}.${2 * i + 2}"))
                }
            }
        }
        val finals = ArrayList<List<BracketMatch>>()
        finals.add(listOf(build(2, 1, 0,
            lab(dSlotWinner(0, m, 0), "Mpandresy Winners"),
            lab(dSlotWinner(1, dLastL(), 0), "Mpandresy Losers"))))
        if ("GF2" in dDone) finals.add(listOf(build(2, 2, 0, "—", "—")))
        return DoubleBracket(winners, losers, finals)
    }

    // ---------- Swiss ----------
    fun swissRoundsTotal(): Int {
        val n = players.size
        var r = 0; var p = 1
        while (p < n) { p *= 2; r++ }
        return r.coerceAtLeast(3).coerceAtMost((n - 1).coerceAtLeast(1))
    }

    private fun swissRoundNo(): Int = stage.removePrefix("S").toIntOrNull() ?: 0

    private fun pairKey(a: String, b: String) = if (a < b) "$a|$b" else "$b|$a"

    fun swissStandings(): List<StandRow> {
        val pts = HashMap<String, Double>()
        val w = HashMap<String, Int>(); val d = HashMap<String, Int>(); val l = HashMap<String, Int>()
        val opp = HashMap<String, MutableList<String>>()
        fun inc(m: HashMap<String, Int>, k: String) { m[k] = (m[k] ?: 0) + 1 }
        fun add(k: String, v: Double) { pts[k] = (pts[k] ?: 0.0) + v }
        for (m in matches) {
            if (!m.stage.startsWith("S") || m.result == null) continue
            val wi = m.whiteId; val bi = m.blackId
            if (m.result == "bye") { if (wi != null) { add(wi, 1.0); inc(w, wi) }; continue }
            if (wi == null || bi == null) continue
            opp.getOrPut(wi) { ArrayList() }.add(bi)
            opp.getOrPut(bi) { ArrayList() }.add(wi)
            when (m.result) {
                "1-0" -> { add(wi, 1.0); inc(w, wi); inc(l, bi) }
                "0-1" -> { add(bi, 1.0); inc(w, bi); inc(l, wi) }
                else -> { add(wi, 0.5); add(bi, 0.5); inc(d, wi); inc(d, bi) }
            }
        }
        fun buchholz(id: String): Double {
            var sum = 0.0
            for (o in opp[id] ?: emptyList<String>()) sum += pts[o] ?: 0.0
            return sum
        }
        val rows = players.map { p ->
            val ww = w[p.id] ?: 0; val dd = d[p.id] ?: 0; val ll = l[p.id] ?: 0
            StandRow(p.id, ww + dd + ll, ww, dd, ll, pts[p.id] ?: 0.0)
        }
        return rows.sortedWith(
            compareByDescending<StandRow> { it.pts }
                .thenByDescending { buchholz(it.id) }
                .thenByDescending { it.w }
                .thenByDescending { player(it.id)?.elo ?: 0 }
        )
    }

    private fun pairSwiss(rem: List<String>, played: Set<String>): List<Pair<String, String>>? {
        if (rem.isEmpty()) return emptyList()
        val a = rem[0]
        for (j in 1 until rem.size) {
            val b = rem[j]
            if (pairKey(a, b) in played) continue
            val rest = rem.filterIndexed { i, _ -> i != 0 && i != j }
            val sub = pairSwiss(rest, played) ?: continue
            return listOf(a to b) + sub
        }
        return null
    }

    private fun buildSwissRound(r: Int) {
        val order: List<String> =
            if (r == 1) {
                val seeds = players.sortedByDescending { it.elo }.map { it.id }
                val half = seeds.size / 2
                // top half vs bottom half
                val out = ArrayList<String>()
                for (i in 0 until half) { out.add(seeds[i]); out.add(seeds[i + half]) }
                if (seeds.size % 2 == 1) out.add(seeds.last())
                out
            } else swissStandings().map { it.id }
        val played = HashSet<String>()
        val byes = HashSet<String>()
        val whites = HashMap<String, Int>()
        val games = HashMap<String, Int>()
        for (m in matches) {
            if (!m.stage.startsWith("S")) continue
            val wi = m.whiteId; val bi = m.blackId
            if (bi == null) { if (wi != null) byes.add(wi); continue }
            if (wi == null) continue
            played.add(pairKey(wi, bi))
            whites[wi] = (whites[wi] ?: 0) + 1
            games[wi] = (games[wi] ?: 0) + 1
            games[bi] = (games[bi] ?: 0) + 1
        }
        var list = order
        var byeId: String? = null
        if (list.size % 2 == 1) {
            byeId = list.lastOrNull { it !in byes } ?: list.last()
            list = list.filter { it != byeId }
        }
        val pairs = pairSwiss(list, played) ?: pairSwiss(list, emptySet()) ?: emptyList()
        fun balance(id: String) = 2 * (whites[id] ?: 0) - (games[id] ?: 0)
        pairs.forEachIndexed { i, pr ->
            val aWhite = balance(pr.first) <= balance(pr.second)
            val w = if (aWhite) pr.first else pr.second
            val b = if (aWhite) pr.second else pr.first
            matches.add(TMatch(nextId++, "S$r", i, 0, w, b))
        }
        if (byeId != null) {
            val m = TMatch(nextId++, "S$r", pairs.size, 0, byeId, null)
            m.result = "bye"; m.winner = byeId
            matches.add(m)
        }
    }

    // ---------- Classement mpilalao ----------
    fun playerLines(): List<PlayerLine> = players.map { p ->
        var w = 0; var d = 0; var l = 0
        var br = 0; var gr = 0; var bl = 0; var an = 0
        var accSum = 0.0; var accN = 0
        for (m in matches) {
            if (!isPlayed(m)) continue
            val isW = m.whiteId == p.id
            val isB = m.blackId == p.id
            if (!isW && !isB) continue
            when (m.result) {
                "1-0" -> if (isW) w++ else l++
                "0-1" -> if (isB) w++ else l++
                else -> d++
            }
            val a = m.analysis ?: continue
            val s = if (isW) a.white else a.black
            an++
            br += s.brilliant; gr += s.great; bl += s.blunder
            accSum += s.accuracy * s.moves; accN += s.moves
        }
        PlayerLine(
            p.id, w + d + l, w, d, l, w + d * 0.5, br, gr, bl,
            if (accN > 0) accSum / accN else null, an
        )
    }

    fun analysedCount(): Int = matches.count { isPlayed(it) && it.analysis != null }
    fun playedCount(): Int = matches.count { isPlayed(it) && it.moves.size >= 2 }

    /** Hetsika brilliant rehetra (archive), vaovao aloha. */
    /** Blunder lehibe voarakitra ao amin'ny analyse (ho an'ny kilan'ny Milalao). */
    fun blunderArchive(): List<Pair<TMatch, BrilliantMove>> =
        matches.flatMap { m -> (m.analysis?.blunders ?: emptyList()).map { m to it } }

    fun brilliantArchive(): List<Pair<TMatch, BrilliantMove>> =
        matches.flatMap { m -> (m.analysis?.brilliants ?: emptyList()).map { m to it } }
            .sortedByDescending { it.first.id }

    // ---------- Schema cup (bracket) ----------
    fun firstKoSize(): Int = if (groups.isNotEmpty()) groups.size * 2 else pow2Ceil(players.size)

    fun bracket(): List<List<BracketMatch>> {
        if (isSwiss || isDouble) return emptyList()
        val out = ArrayList<List<BracketMatch>>()
        var r = firstKoSize()
        var prev: List<BracketMatch>? = null
        while (r >= 2) {
            val cur = ArrayList<BracketMatch>()
            for (i in 0 until r / 2) {
                val ms = matches.filter { it.stage == "KO$r" && it.slot == i }.sortedBy { it.game }
                if (ms.isNotEmpty()) {
                    val first = ms[0]
                    val txt = ms.filter { it.result != null }.joinToString(" · ") {
                        if (it.result == "bye") "bye" else it.result!!.replace("1/2-1/2", "½-½")
                    }
                    cur.add(BracketMatch(
                        r, i, name(first.whiteId), name(first.blackId), first.whiteId, first.blackId,
                        txt, ms.firstNotNullOfOrNull { it.winner }, ms
                    ))
                } else {
                    var wl: String; var bl: String
                    var wid: String? = null; var bid: String? = null
                    val p = prev
                    if (p == null) {
                        val g = groups.size
                        if (g <= 1) { wl = "1er " + groupName(0); bl = "2e " + groupName(0) }
                        else if (i < g / 2) { wl = "1er " + groupName(2 * i); bl = "2e " + groupName(2 * i + 1) }
                        else { val j = i - g / 2; wl = "1er " + groupName(2 * j + 1); bl = "2e " + groupName(2 * j) }
                    } else {
                        val a = p.getOrNull(2 * i); val b = p.getOrNull(2 * i + 1)
                        wid = a?.winnerId; bid = b?.winnerId
                        wl = if (wid != null) name(wid) else "Mpandresy " + (2 * i + 1)
                        bl = if (bid != null) name(bid) else "Mpandresy " + (2 * i + 2)
                    }
                    cur.add(BracketMatch(r, i, wl, bl, wid, bid, "", null, emptyList()))
                }
            }
            out.add(cur)
            prev = cur
            r /= 2
        }
        return out
    }

    companion object {
        fun create(
            id: Long, name: String, players: List<Participant>,
            baseMs: Long, incMs: Long, wantGroups: Boolean, swiss: Boolean = false, double: Boolean = false
        ): Tournament {
            val n = players.size
            val groups = !swiss && !double && (n > 16 || (wantGroups && n >= 3))
            val t = Tournament(id, name, players, baseMs, incMs, groups)
            val seeds = players.sortedByDescending { it.elo }
            if (double) {
                t.format = "DOUBLE"
                t.stage = "D0"
                t.fillD()
            } else if (swiss) {
                t.format = "SWISS"
                t.stage = "S1"
                t.buildSwissRound(1)
            } else if (groups) {
                val g = groupCountFor(n)
                val buckets = List(g) { ArrayList<String>() }
                seeds.forEachIndexed { idx, p ->
                    val row = idx / g
                    val col = idx % g
                    val gi = if (row % 2 == 0) col else g - 1 - col
                    buckets[gi].add(p.id)
                }
                t.groups = buckets.map { it.toList() }
                for ((gi, ids) in t.groups.withIndex()) {
                    for (i in ids.indices) for (j in i + 1 until ids.size) {
                        val swap = (i + j) % 2 != 0
                        val w = if (swap) ids[j] else ids[i]
                        val b = if (swap) ids[i] else ids[j]
                        val m = TMatch(t.nextId++, "G", -1, 0, w, b)
                        m.group = gi
                        t.matches.add(m)
                    }
                }
                t.stage = "G"
            } else {
                val k = pow2Ceil(n)
                t.stage = "KO$k"
                t.buildFirstKo(seeds.map { it.id }, k)
            }
            return t
        }
    }
}

private fun sideToJson(s: SideAn): JSONObject = JSONObject()
    .put("n", s.moves).put("acc", s.accuracy).put("acpl", s.acpl)
    .put("br", s.brilliant).put("gr", s.great).put("mi", s.mistake).put("bl", s.blunder)

private fun sideFromJson(o: JSONObject) = SideAn(
    o.optInt("n"), o.optDouble("acc", 0.0), o.optInt("acpl"),
    o.optInt("br"), o.optInt("gr"), o.optInt("mi"), o.optInt("bl")
)

fun analysisToJson(a: MatchAnalysis): JSONObject {
    val o = JSONObject()
    o.put("w", sideToJson(a.white)); o.put("b", sideToJson(a.black))
    val arr = JSONArray()
    for (b in a.brilliants) {
        arr.put(JSONObject().put("ply", b.ply).put("w", b.white).put("san", b.san).put("uci", b.uci).put("fen", b.fen))
    }
    o.put("brilliants", arr)
    val barr = JSONArray()
    for (b in a.blunders) {
        barr.put(JSONObject().put("ply", b.ply).put("w", b.white).put("san", b.san).put("uci", b.uci).put("fen", b.fen).put("loss", b.cpLoss))
    }
    o.put("blunders", barr)
    return o
}

fun analysisFromJson(o: JSONObject): MatchAnalysis {
    val arr = o.optJSONArray("brilliants") ?: JSONArray()
    val br = List(arr.length()) {
        val j = arr.getJSONObject(it)
        BrilliantMove(j.getInt("ply"), j.optBoolean("w", true), j.optString("san"), j.optString("uci"), j.optString("fen"))
    }
    val barr = o.optJSONArray("blunders") ?: JSONArray()
    val bl = List(barr.length()) {
        val j = barr.getJSONObject(it)
        BrilliantMove(j.getInt("ply"), j.optBoolean("w", true), j.optString("san"), j.optString("uci"), j.optString("fen"), j.optInt("loss"))
    }
    return MatchAnalysis(sideFromJson(o.getJSONObject("w")), sideFromJson(o.getJSONObject("b")), br, bl)
}

/** Fitehirizana fifaninanana: JSON isaky ny fifaninanana ao amin'ny filesDir/tournaments. */
class TournamentStore(ctx: Context) {
    private val dir = File(ctx.filesDir, "tournaments").apply { mkdirs() }

    /** Ny JSON dia atao eto (main thread, fa ny zavatra ao amin'ny [t] no miova), ny fanoratana kosa ao amin'ny filaharana. */
    fun save(t: Tournament) {
        val text = try { toJsonText(t) } catch (e: Exception) {
            Log.w("TournamentStore", "tsy azo natao JSON ny fifaninanana ${t.id}", e)
            return
        }
        DiskQueue.run { write(t.id, text) }
    }

    private fun write(id: Long, text: String) {
        val tmp = File(dir, "$id.tmp")
        val target = File(dir, "$id.json")
        val bak = File(dir, "$id.bak")
        tmp.writeText(text)
        // Tehirizina ny dikan-taloha (farany tsara) alohan'ny hanoratana ny vaovao
        if (target.exists()) try { target.copyTo(bak, overwrite = true) } catch (e: Exception) { Log.w("TournamentStore", "tsy voatahiry ny .bak $id", e) }
        if (!tmp.renameTo(target)) { target.writeText(text); tmp.delete() }
    }

    private fun toJsonText(t: Tournament): String {
            val o = JSONObject()
            o.put("id", t.id); o.put("name", t.name)
            o.put("baseMs", t.baseMs); o.put("incMs", t.incMs); o.put("useGroups", t.useGroups)
            o.put("format", t.format)
            o.put("dStep", t.dStep); o.put("dDone", t.dDone.joinToString(","))
            o.put("stage", t.stage); o.put("nextId", t.nextId); o.put("updated", t.updated)
            if (t.champion != null) o.put("champion", t.champion)
            val ps = JSONArray()
            for (p in t.players) {
                val po = JSONObject()
                po.put("id", p.id); po.put("name", p.name); po.put("elo", p.elo)
                if (p.bot != null) po.put("bot", p.bot.toJson())
                ps.put(po)
            }
            o.put("players", ps)
            val gs = JSONArray()
            for (g in t.groups) gs.put(JSONArray(g))
            o.put("groups", gs)
            val ms = JSONArray()
            for (m in t.matches) {
                val mo = JSONObject()
                mo.put("id", m.id); mo.put("stage", m.stage); mo.put("slot", m.slot); mo.put("rnd", m.round)
                mo.put("game", m.game); mo.put("group", m.group)
                if (m.whiteId != null) mo.put("white", m.whiteId)
                if (m.blackId != null) mo.put("black", m.blackId)
                mo.put("moves", JSONArray(m.moves))
                mo.put("wms", m.whiteMs); mo.put("bms", m.blackMs)
                if (m.result != null) mo.put("result", m.result)
                if (m.winner != null) mo.put("winner", m.winner)
                m.analysis?.let { mo.put("an", analysisToJson(it)) }
                ms.put(mo)
            }
            o.put("matches", ms)
            return o.toString()
    }

    fun list(): List<Tournament> {
        DiskQueue.flush()
        return (dir.listFiles { f -> f.name.endsWith(".json") } ?: emptyArray())
            .mapNotNull { f ->
                parse(f) ?: run {
                    // Simba ny rakitra: andramo ny dikan-taloha (.bak)
                    val bak = File(dir, f.name.removeSuffix(".json") + ".bak")
                    val t = if (bak.exists()) parse(bak) else null
                    Log.w("TournamentStore", "rakitra simba: ${f.name}" + if (t != null) " (naverina avy amin'ny .bak)" else " (tsy azo naverina)")
                    t
                }
            }
            .sortedByDescending { it.updated }
    }

    fun delete(id: Long) {
        DiskQueue.run {
            File(dir, "$id.json").delete(); File(dir, "$id.bak").delete(); File(dir, "$id.tmp").delete()
        }
    }

    private fun parse(f: File): Tournament? = try {
        val o = JSONObject(f.readText())
        val pa = o.getJSONArray("players")
        val players = List(pa.length()) {
            val po = pa.getJSONObject(it)
            Participant(
                po.getString("id"), po.getString("name"), po.getInt("elo"),
                if (po.has("bot")) botFromJson(po.getJSONObject("bot")) else null
            )
        }
        val t = Tournament(
            o.getLong("id"), o.getString("name"), players,
            o.getLong("baseMs"), o.getLong("incMs"), o.getBoolean("useGroups")
        )
        t.format = o.optString("format", "CUP")
        t.dStep = o.optInt("dStep", 0)
        o.optString("dDone", "").split(",").filter { it.isNotEmpty() }.forEach { t.dDone.add(it) }
        t.stage = o.getString("stage")
        t.nextId = o.getInt("nextId")
        t.updated = o.optLong("updated", t.id)
        t.champion = if (o.has("champion")) o.getString("champion") else null
        val ga = o.getJSONArray("groups")
        t.groups = List(ga.length()) { gi ->
            val a = ga.getJSONArray(gi)
            List(a.length()) { a.getString(it) }
        }
        val ma = o.getJSONArray("matches")
        for (i in 0 until ma.length()) {
            val mo = ma.getJSONObject(i)
            val m = TMatch(
                mo.getInt("id"), mo.getString("stage"), mo.getInt("slot"), mo.getInt("game"),
                if (mo.has("white")) mo.getString("white") else null,
                if (mo.has("black")) mo.getString("black") else null
            )
            m.group = mo.optInt("group", -1)
            m.round = mo.optInt("rnd", 0)
            val mv = mo.getJSONArray("moves")
            m.moves = List(mv.length()) { mv.getString(it) }
            m.whiteMs = mo.optLong("wms", 0L); m.blackMs = mo.optLong("bms", 0L)
            m.result = if (mo.has("result")) mo.getString("result") else null
            m.winner = if (mo.has("winner")) mo.getString("winner") else null
            m.analysis = mo.optJSONObject("an")?.let { analysisFromJson(it) }
            t.matches.add(m)
        }
        t
    } catch (e: Exception) {
        Log.w("TournamentStore", "tsy azo novakiana: ${f.name}", e)
        null
    }
}
