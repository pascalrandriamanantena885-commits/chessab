package mg.chess.offline

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Analytics
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// =====================================================================
//  Singa sy singa kely ampiasaina amin'ny pejy maro
// =====================================================================

/** Logo kely (soavaly) mitovy amin'ny icon an'ny app. */
@Composable
fun KajyLogo(size: Dp) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(size * 0.26f))
            .background(Brush.linearGradient(listOf(Color(0xFF34322E), Color(0xFF141311)))),
        contentAlignment = Alignment.Center
    ) {
        Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.requiredSize(size * 1.7f))
    }
}

/** Pill misafidy (filtre, loko, ora). */
@Composable
fun KajyPill(text: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.clip(shape)
            .background(if (selected) accent.copy(alpha = 0.22f) else cs.surfaceContainer)
            .border(if (selected) 1.5.dp else 1.dp, if (selected) accent else cs.outlineVariant, shape)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text, fontSize = 13.sp, maxLines = 1,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = if (selected) cs.onSurface else cs.onSurfaceVariant
        )
    }
}

fun tcCategory(t: TimeControl): String = when {
    t.baseMin <= 0 -> "Tsy misy ora"
    t.baseMin < 3 -> "Bullet"
    t.baseMin < 10 -> "Blitz"
    else -> "Rapid"
}

/** Fidio ora: tile lehibe (toa chess.com) - 4 isaky ny andalana. */
@Composable
fun TimeControlGrid(vm: ChessViewModel) {
    val cs = MaterialTheme.colorScheme
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        for (row in TIME_CONTROLS.chunked(4)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (t in row) {
                    val sel = vm.tc == t
                    val shape = RoundedCornerShape(14.dp)
                    Column(
                        Modifier.weight(1f).clip(shape)
                            .background(if (sel) cs.primary else cs.surfaceContainerHigh)
                            .border(1.dp, if (sel) cs.primary else cs.outlineVariant, shape)
                            .clickable { vm.tc = t }
                            .padding(vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            if (t.baseMin <= 0) "∞" else t.label, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                            color = if (sel) cs.onPrimary else cs.onSurface, maxLines = 1
                        )
                        Text(
                            tcCategory(t), fontSize = 10.sp, maxLines = 1,
                            color = if (sel) cs.onPrimary.copy(alpha = 0.85f) else cs.onSurfaceVariant
                        )
                    }
                }
                // Mameno ny toerana banga mba hitovy ny sakany
                repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun ModeRow(icon: ImageVector, title: String, sub: String, tint: Color, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(
        Modifier.fillMaxWidth().clickable { onClick() },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainer),
        border = BorderStroke(1.dp, cs.outlineVariant)
    ) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(46.dp).clip(RoundedCornerShape(14.dp))
                    .background(Brush.linearGradient(listOf(tint, tint.copy(alpha = 0.7f)))),
                contentAlignment = Alignment.Center
            ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(26.dp)) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(sub, fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, tint = cs.onSurfaceVariant)
        }
    }
}

// =====================================================================
//  PEJY FIAINANA (Milalao)
// =====================================================================

@Composable
fun MenuScreen(vm: ChessViewModel) {
    val cs = MaterialTheme.colorScheme
    val unfinished = vm.saved.firstOrNull { it.result == null }
    val unfinishedBot = unfinished?.let { BotRegistry.find(it.botId) }
    val tally = tallyOf(PlayerStats.games)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 10.dp),
        Arrangement.spacedBy(14.dp)
    ) {
        // ---- Header: logo + profil ----
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            KajyLogo(40.dp)
            Spacer(Modifier.width(10.dp))
            Text("KAJY", fontSize = 26.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp, color = cs.primary)
            Spacer(Modifier.weight(1f))
            Row(
                Modifier.clip(RoundedCornerShape(50)).background(cs.surfaceContainer)
                    .border(1.dp, cs.outlineVariant, RoundedCornerShape(50))
                    .clickable { vm.toStats() }
                    .padding(start = 4.dp, end = 12.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                PlayerAvatar(PlayerProfile.name, true, 32.dp)
                Spacer(Modifier.width(8.dp))
                Column {
                    Text(PlayerProfile.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text("Elo ${PlayerStats.ratingInt}", fontSize = 11.sp, color = cs.primary, fontWeight = FontWeight.Bold)
                }
            }
        }

        // ---- Hero: Milalao (diaporama: bot + badge sokajy, podium + medaille) ----
        HeroPlayCard(vm)

        // ---- Tohizo ny lalao farany ----
        if (unfinished != null) {
            Card(
                Modifier.fillMaxWidth().clickable { vm.loadGame(unfinished) },
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh),
                border = BorderStroke(1.5.dp, cs.primary.copy(alpha = 0.7f))
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (unfinishedBot != null) BotAvatar(unfinishedBot, 46.dp) else PlayerAvatar("Olona", false, 46.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Tohizo ny lalao farany", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                (if (unfinishedBot != null) "vs ${unfinishedBot.name}" else "Olona vs Olona") + " · ${(unfinished.moves.size + 1) / 2} hetsika",
                                fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            if (unfinishedBot != null) TierChip(tierOf(unfinishedBot.elo))
                        }
                    }
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(cs.primary),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Rounded.PlayArrow, null, tint = cs.onPrimary) }
                }
            }
        }

        // ---- Ora ----
        Card(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = cs.surfaceContainer),
            border = BorderStroke(1.dp, cs.outlineVariant)
        ) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Gameplay kely (brilliant / blunder avy ao amin'ny archive) - miseho ihany rehefa misy data
                val clips = buildClips(vm)
                if (clips.isNotEmpty()) HighlightClip(vm, clips)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Ora", fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text(
                        tcCategory(vm.tc) + " · " + (if (vm.tc.baseMin <= 0) "∞" else vm.tc.label),
                        fontSize = 12.sp, color = cs.primary, fontWeight = FontWeight.Bold
                    )
                }
                TimeControlGrid(vm)
            }
        }

        // ---- Fomba filalaovana hafa ----
        Text("Fomba hafa", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = cs.onSurfaceVariant, modifier = Modifier.padding(start = 4.dp))
        val doneTours = vm.tournaments.count { it.champion != null }
        ModeRow(Icons.Rounded.Group, "Olona vs Olona", "Lalao roa mpilalao amin'ny findainao iray", Color(0xFF42A5F5)) { vm.startHumanGame() }
        ModeRow(
            Icons.Rounded.EmojiEvents, "Fifaninanana",
            if (doneTours > 0) "$doneTours vita · bot vs bot, poule, cup, Swiss" else "Bot vs bot, poule, cup, Swiss, double elimination",
            Color(0xFFFFA726)
        ) { vm.goTab(1) }
        ModeRow(Icons.Rounded.School, "Fiofanana", "Puzzle avy amin'ny lalao, opening drill, endgame", Color(0xFFAB47BC)) { vm.goTab(2) }
        ModeRow(Icons.Rounded.Analytics, "PGN", "Jereo ny lalao ao amin'ny PGN na forony bot avy amin'ny mpilalao", Color(0xFF26A69A)) { vm.toPgn() }

        // ---- Statistika fohy ----
        if (tally.n > 0) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(cs.surfaceContainer)
                    .border(1.dp, cs.outlineVariant, RoundedCornerShape(18.dp))
                    .clickable { vm.toStats() }.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Ny lalaoko", fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("Elo ${PlayerStats.ratingInt}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = cs.primary)
                }
                Row(Modifier.fillMaxWidth().height(8.dp).clip(CircleShape)) {
                    if (tally.w > 0) Box(Modifier.weight(tally.w.toFloat()).fillMaxHeight().background(Color(0xFF81B64C)))
                    if (tally.d > 0) Box(Modifier.weight(tally.d.toFloat()).fillMaxHeight().background(Color(0xFF9E9E9E)))
                    if (tally.l > 0) Box(Modifier.weight(tally.l.toFloat()).fillMaxHeight().background(Color(0xFFEF5350)))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    StatBlock("${tally.w}", "Nahazo", Color(0xFF81B64C))
                    StatBlock("${tally.d}", "Draw", Color(0xFF9E9E9E))
                    StatBlock("${tally.l}", "Resy", Color(0xFFEF5350))
                }
            }
        }
        Spacer(Modifier.height(4.dp))
    }
}

@Composable
private fun StatBlock(value: String, label: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 22.sp, fontWeight = FontWeight.Black, color = color, textAlign = TextAlign.Center)
        Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
