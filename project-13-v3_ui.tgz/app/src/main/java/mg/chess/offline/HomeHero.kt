package mg.chess.offline

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.Square
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// =====================================================================
//  1) Card "Milalao": diaporama (sary bot + badge sokajy, podium + medaille)
// =====================================================================

private data class HeroSlide(
    val bot: Bot?, val name: String,
    val badge: String, val badgeColor: Long,
    val caption: String, val sub: String
)

private val GOLD = 0xFFFFD54F
private val SILVER = 0xFFCFD8DC
private val BRONZE = 0xFFD7A06B

private fun buildHeroSlides(vm: ChessViewModel): List<HeroSlide> {
    val out = ArrayList<HeroSlide>()
    // 1) Mpandresy 3 voalohany tamin'ny fifaninanana farany (sary + medaille)
    val last = vm.tournaments.filter { it.champion != null }.maxByOrNull { it.updated }
    val pd = last?.podium()
    if (last != null && pd != null) {
        val rows = listOf(
            Triple(pd.first, "🥇 Tompon-daka", GOLD),
            Triple(pd.second, "🥈 Faharoa", SILVER),
            Triple(last.bronze(), "🥉 Faha-3", BRONZE)
        )
        for ((id, label, color) in rows) {
            val p = last.player(id) ?: continue
            out.add(HeroSlide(p.bot, p.name, label, color, last.name, "Elo ${p.elo}"))
        }
    }
    // 2) Bot: Stockfish (MAX), Grandmaster, Master...
    val bots = BotRegistry.visible.sortedByDescending { it.elo }
    val featured = ArrayList<Bot>()
    bots.firstOrNull { it.elo > SF_MAX_ELO }?.let { featured.add(it) }
    for (b in bots) {
        if (featured.size >= 5) break
        if (b !in featured && tierOf(b.elo).min >= BotTier.MASTER.min) featured.add(b)
    }
    if (featured.size < 3) for (b in bots) { if (featured.size >= 3) break; if (b !in featured) featured.add(b) }
    for (b in featured) {
        val t = tierOf(b.elo)
        val label = if (b.elo > SF_MAX_ELO) "MAX" else t.label.uppercase()
        out.add(HeroSlide(b, b.name, label, t.color, if (b.elo > SF_MAX_ELO) "Hery feno" else t.label, "Elo ${if (b.elo > SF_MAX_ELO) "MAX" else b.elo.toString()}"))
    }
    return out
}

@Composable
private fun SlideTile(s: HeroSlide, modifier: Modifier) {
    Box(modifier.clip(RoundedCornerShape(22.dp)).border(2.dp, Color.White.copy(alpha = 0.7f), RoundedCornerShape(22.dp))) {
        val b = s.bot
        if (b != null) BotPortrait(b)
        else Box(
            Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF455A64), Color(0xFF263238)))),
            contentAlignment = Alignment.Center
        ) { Text(s.name.take(1).uppercase(), color = Color.White, fontSize = 52.sp, fontWeight = FontWeight.Black) }
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(46.dp)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xB3000000))))
        )
        Box(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 7.dp).clip(RoundedCornerShape(50))
                .background(Color(s.badgeColor)).padding(horizontal = 9.dp, vertical = 3.dp)
        ) {
            Text(s.badge, color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Black, maxLines = 1)
        }
    }
}

@Composable
fun HeroPlayCard(vm: ChessViewModel) {
    val slides = buildHeroSlides(vm)
    val pager = rememberPagerState(pageCount = { slides.size.coerceAtLeast(1) })
    LaunchedEffect(slides.size) {
        while (slides.size > 1) {
            delay(3600)
            pager.animateScrollToPage((pager.currentPage + 1) % slides.size)
        }
    }
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF4E8A3A), Color(0xFF81B64C))))
            .clickable { vm.toBots() }
    ) {
        Row(Modifier.padding(start = 20.dp, end = 16.dp, top = 18.dp, bottom = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("Milalao", fontSize = 32.sp, fontWeight = FontWeight.Black, color = Color.White)
                val cur = slides.getOrNull(pager.currentPage)
                Crossfade(cur, label = "hero-caption") { s ->
                    Column(Modifier.height(58.dp)) {
                        if (s != null) {
                            Text(s.name, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(s.caption, fontSize = 12.sp, color = Color.White.copy(alpha = 0.92f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(s.sub, fontSize = 12.sp, color = Color.White.copy(alpha = 0.8f), maxLines = 1)
                        } else {
                            Text("Hiady amin'ny bot, Elo 400 ka hatramin'ny Stockfish", fontSize = 13.sp, color = Color.White.copy(alpha = 0.92f))
                        }
                    }
                }
                Row(
                    Modifier.clip(RoundedCornerShape(50)).background(Color.White)
                        .padding(start = 12.dp, end = 16.dp, top = 8.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Rounded.PlayArrow, null,
                        tint = Color(0xFF3F7A2C), modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        "Fidio bot  ·  " + (if (vm.tc.baseMin <= 0) "∞" else vm.tc.label),
                        color = Color(0xFF2F5E20), fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1
                    )
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                HorizontalPager(pager, Modifier.size(128.dp)) { page ->
                    val s = slides.getOrNull(page)
                    if (s != null) SlideTile(s, Modifier.fillMaxSize())
                }
                if (slides.size > 1) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        for (i in slides.indices) {
                            val on = i == pager.currentPage
                            Box(
                                Modifier.size(width = if (on) 14.dp else 5.dp, height = 5.dp).clip(CircleShape)
                                    .background(Color.White.copy(alpha = if (on) 0.95f else 0.45f))
                            )
                        }
                    }
                }
            }
        }
    }
}

// =====================================================================
//  2) Card "Ora": gameplay kely (sous forme publicité) - brilliant (!!) / blunder (??) avy ao amin'ny archive
// =====================================================================

data class ClipItem(val t: Tournament, val m: TMatch, val mv: BrilliantMove, val brilliant: Boolean)

private fun parseBoard(fen: String): Board? = try { Board().also { it.loadFromFen(fen) } } catch (e: Exception) { null }

/** Clip hita ao amin'ny archive (brilliant + blunder), mifandimby; foana raha mbola tsy misy data. */
fun buildClips(vm: ChessViewModel): List<ClipItem> {
    val done = vm.tournaments.sortedByDescending { it.updated }
    val br = done.flatMap { t -> t.brilliantArchive().map { ClipItem(t, it.first, it.second, true) } }
    val bl = done.flatMap { t -> t.blunderArchive().map { ClipItem(t, it.first, it.second, false) } }
    val out = ArrayList<ClipItem>()
    var i = 0
    while (out.size < 6 && (i < br.size || i < bl.size)) {
        br.getOrNull(i)?.let { out.add(it) }
        bl.getOrNull(i)?.let { out.add(it) }
        i++
    }
    return out.take(6).filter { c ->
        c.mv.uci.length >= 4 && c.mv.fen.isNotBlank() && parseBoard(c.mv.fen)
            ?.legalMoves()?.any { it.toString().equals(c.mv.uci, true) } == true
    }
}

private val BRILLIANT_COLOR = Color(Cls.BRILLIANT.color)
private val BLUNDER_COLOR = Color(Cls.BLUNDER.color)

@Composable
private fun ClipBoard(item: ClipItem, move: Float, badge: Float, size: Dp) {
    val before = remember(item) { parseBoard(item.mv.fen) ?: Board() }
    val mv = remember(item) { before.legalMoves().firstOrNull { it.toString().equals(item.mv.uci, true) } }
    val after = remember(item) { (parseBoard(item.mv.fen) ?: Board()).also { b -> mv?.let { m -> b.doMove(m) } } }
    val flip = !item.mv.white
    val cell = size / 8
    val src: Square? = mv?.from
    val dst: Square? = mv?.to
    val done = move >= 1f
    fun col(sq: Square) = if (flip) 7 - sq.file.ordinal else sq.file.ordinal
    fun row(sq: Square) = if (flip) sq.rank.ordinal else 7 - sq.rank.ordinal

    Box(Modifier.size(size).clip(RoundedCornerShape(10.dp))) {
        BoardView(
            pieceAt = { sq ->
                when {
                    done -> after.getPiece(sq)
                    move > 0f && sq == src -> Piece.NONE
                    move >= 0.85f && sq == dst -> Piece.NONE
                    else -> before.getPiece(sq)
                }
            },
            flip = flip,
            last = if (done && src != null && dst != null) Pair(src, dst) else null
        )
        if (mv != null && src != null && dst != null && move > 0f && !done) {
            val fx = col(src) * (1f - move) + col(dst) * move
            val fy = row(src) * (1f - move) + row(dst) * move
            Box(Modifier.offset(x = cell * (fx + 0.04f), y = cell * (fy + 0.04f))) {
                PieceIcon(before.getPiece(src), cell * 0.92f)
            }
        }
        if (dst != null && badge > 0f) {
            val bs = cell * 0.66f
            val bx = (cell * col(dst) + cell * 0.42f).coerceAtMost(size - bs)
            val by = (cell * row(dst) - cell * 0.12f).coerceAtLeast(0.dp)
            Box(
                Modifier.offset(x = bx, y = by).size(bs)
                    .graphicsLayer { scaleX = badge; scaleY = badge }
                    .clip(CircleShape).background(if (item.brilliant) BRILLIANT_COLOR else BLUNDER_COLOR)
                    .border(1.5.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (item.brilliant) Cls.BRILLIANT.sym else Cls.BLUNDER.sym,
                    color = Color.White, fontSize = (bs.value * 0.52f).sp, fontWeight = FontWeight.Black, maxLines = 1
                )
            }
        }
    }
}

/** Gameplay kely mihodina (toy ny publicité): board + hetsika + badge (!! / ??) + soratra sy isa. */
@Composable
fun HighlightClip(vm: ChessViewModel, clips: List<ClipItem>) {
    var round by remember { mutableIntStateOf(0) }
    val move = remember { Animatable(0f) }
    val badge = remember { Animatable(0f) }
    val bar = remember { Animatable(0f) }
    val n = clips.size
    LaunchedEffect(round, n) {
        move.snapTo(0f); badge.snapTo(0f); bar.snapTo(0f)
        launch { bar.animateTo(1f, tween(4800, easing = LinearEasing)) }
        delay(900)
        move.animateTo(1f, tween(700, easing = FastOutSlowInEasing))
        delay(120)
        badge.animateTo(1f, spring(dampingRatio = 0.42f, stiffness = Spring.StiffnessLow))
        delay(2700)
        round++
    }
    val idx = round % n
    val item = clips[idx]
    val t = item.t
    val m = item.m
    val b = item.mv
    val pid = if (b.white) m.whiteId else m.blackId
    val oid = if (b.white) m.blackId else m.whiteId
    val moverElo = t.player(pid)?.elo
    val acc = m.analysis?.let { if (b.white) it.white.accuracy else it.black.accuracy }
    val accent = if (item.brilliant) BRILLIANT_COLOR else BLUNDER_COLOR
    val shape = RoundedCornerShape(16.dp)

    Column(
        Modifier.fillMaxWidth().clip(shape)
            .background(Brush.linearGradient(listOf(Color(0xFF22262B), Color(0xFF14171A))))
            .border(1.dp, accent.copy(alpha = 0.55f), shape)
            .clickable { vm.openTour(t); vm.reviewTourMatch(m, b.ply) }
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            ClipBoard(item, move.value, badge.value, 140.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(Modifier.clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.14f)).padding(horizontal = 8.dp, vertical = 2.dp)) {
                        Text("▶ GAMEPLAY", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }
                    Text("${idx + 1}/$n", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp)
                }
                Crossfade(item, label = "clip-text") { it2 ->
                    val x = it2.mv
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                if (it2.brilliant) Cls.BRILLIANT.sym else Cls.BLUNDER.sym,
                                color = if (it2.brilliant) BRILLIANT_COLOR else BLUNDER_COLOR,
                                fontSize = 30.sp, fontWeight = FontWeight.Black
                            )
                            Text(x.san, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        }
                        Text(
                            if (it2.brilliant) "Hetsika brilliant" else "Blunder -" + "%.1f".format(x.cpLoss / 100.0),
                            color = if (it2.brilliant) BRILLIANT_COLOR else BLUNDER_COLOR,
                            fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1
                        )
                    }
                }
                Text(
                    t.name(pid) + (moverElo?.let { " ($it)" } ?: ""),
                    color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text("vs ${t.name(oid)}", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    matchStageLabel(m) + " · hetsika ${(b.ply + 1) / 2}" + (acc?.let { " · ${it.toInt()}%" } ?: ""),
                    color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(t.name, color = Color.White.copy(alpha = 0.45f), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        // Bara fandrosoana (toy ny story) + "Jereo"
        Row(
            Modifier.fillMaxWidth().padding(start = 10.dp, end = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            for (i in 0 until n) {
                val frac = when { i < idx -> 1f; i == idx -> bar.value; else -> 0f }
                Box(Modifier.weight(1f).height(3.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.18f))) {
                    Box(Modifier.fillMaxHeight().fillMaxWidth(frac.coerceIn(0f, 1f)).background(accent))
                }
            }
            Spacer(Modifier.width(6.dp))
            Text("Jereo ▸", color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}
