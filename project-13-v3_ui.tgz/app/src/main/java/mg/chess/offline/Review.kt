package mg.chess.offline

import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.PieceType
import com.github.bhlangonijr.chesslib.Side
import com.github.bhlangonijr.chesslib.Square
import com.github.bhlangonijr.chesslib.move.Move
import com.github.bhlangonijr.chesslib.move.MoveList
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.roundToInt

enum class Cls(val label: String, val sym: String, val color: Long) {
    BRILLIANT("Brilliant", "!!", 0xFF1BACA6),
    GREAT("Great", "!", 0xFF5C8BB0),
    BEST("Best", "★", 0xFF81B64C),
    EXCELLENT("Excellent", "✓", 0xFF96BC4B),
    GOOD("Good", "✓", 0xFFA3B18A),
    INACCURACY("Inaccuracy", "?!", 0xFFF7C631),
    MISS("Miss", "✗", 0xFFFF7769),
    MISTAKE("Mistake", "?", 0xFFE58F2A),
    BLUNDER("Blunder", "??", 0xFFCA3431)
}

data class MoveReview(
    val san: String, val uci: String, val side: Side, val cls: Cls,
    val loss: Double, val cpLoss: Int, val accuracy: Double
)

data class SideSummary(val accuracy: Double, val acpl: Int, val rating: Int, val counts: Map<Cls, Int>)

data class ReviewResult(
    val fens: List<String>,
    val evalsWhite: List<Int>,
    val evalTexts: List<String>,
    val bestUci: List<String?>,
    val bestSan: List<String?>,
    val squares: List<Pair<Square, Square>>,
    val moves: List<MoveReview>,
    val white: SideSummary,
    val black: SideSummary
)

const val START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
const val MATE_CP = 3000

fun winPct(cp: Int): Double = 100.0 / (1.0 + exp(-0.00368208 * cp))

fun Line.stmCp(): Int {
    val m = mate
    return if (m == null) (cp ?: 0) else if (m > 0) MATE_CP - m else -(MATE_CP + m)
}

private fun stmWhite(fen: String) = fen.split(" ").getOrNull(1) != "b"

private fun evalText(line: Line, white: Boolean): String {
    val sgn = if (white) 1 else -1
    val mt = line.mate
    if (mt != null) {
        if (mt == 0) return "#"
        val m = mt * sgn
        return (if (m > 0) "+M" else "-M") + abs(m)
    }
    return String.format(java.util.Locale.US, "%+.2f", (line.cp ?: 0) * sgn / 100.0)
}

fun uciSquares(uci: String?): Pair<Square, Square>? {
    if (uci == null || uci.length < 4) return null
    return try {
        Square.fromValue(uci.substring(0, 2).uppercase()) to Square.fromValue(uci.substring(2, 4).uppercase())
    } catch (e: Exception) { null }
}

private fun uciToSan(fen: String, uci: String?): String? {
    if (uci.isNullOrEmpty()) return null
    return try {
        val b = Board(); b.loadFromFen(fen)
        val mv = b.legalMoves().firstOrNull { it.toString().equals(uci, true) } ?: return null
        val ml = MoveList(fen); ml.add(mv)
        ml.toSanArray()[0]
    } catch (e: Exception) { null }
}

fun pv(p: Piece): Int = when (p.pieceType) {
    PieceType.PAWN -> 1
    PieceType.KNIGHT -> 3
    PieceType.BISHOP -> 3
    PieceType.ROOK -> 5
    PieceType.QUEEN -> 9
    PieceType.KING -> 100
    else -> 0
}

/** Static exchange evaluation: ahoana no azon'ny mpilalao mihetsika rehefa mandray eo amin'ny sq. */
fun see(b: Board, sq: Square, depth: Int = 0): Int {
    if (depth > 8) return 0
    val caps = b.legalMoves().filter { it.to == sq && b.getPiece(it.to) != Piece.NONE }
    val m = caps.minByOrNull { pv(b.getPiece(it.from)) } ?: return 0
    val gain = pv(b.getPiece(sq))
    b.doMove(m)
    val g = max(0, gain - see(b, sq, depth + 1))
    b.undoMove()
    return g
}

/** Sacrifice: very ny sombin-javatra >= 2 (tsy ao anatin'ny pion/mpanjaka). */
fun isSacrifice(pre: Board, m: Move): Boolean {
    val moved = pre.getPiece(m.from)
    if (moved.pieceType == PieceType.PAWN || moved.pieceType == PieceType.KING) return false
    val captured = pv(pre.getPiece(m.to))
    pre.doMove(m)
    val oppGain = see(pre, m.to)
    pre.undoMove()
    return oppGain - captured >= 2
}

private fun summary(ms: List<MoveReview>): SideSummary {
    if (ms.isEmpty()) return SideSummary(0.0, 0, 0, emptyMap())
    val acc = ms.map { it.accuracy }.average()
    val acpl = ms.map { it.cpLoss }.average()
    val rating = (3100 * exp(-0.0086 * acpl)).roundToInt().coerceIn(300, 3200)
    val counts = Cls.values().associateWith { c -> ms.count { it.cls == c } }
    return SideSummary(acc, acpl.roundToInt(), rating, counts)
}

/** Fotoana fara-tampony isaky ny toerana amin'ny review (ms): haingana fa mitazona kalitao. */
fun reviewMsFor(depth: Int): Int = 350 + depth * 25

/**
 * Review haingana: ny toerana rehetra dia zaraina amin'ny motera maromaro miaraka ([extra] + [engine]),
 * misy fetra fotoana isaky ny toerana ([maxMs]) ary tsy manao analyse lava ny toerana manana hetsika tokana.
 */
suspend fun runReview(
    engine: Engine, startFen: String, moves: List<Move>, depth: Int,
    extra: List<Engine> = emptyList(),
    maxMs: Int = reviewMsFor(depth),
    multiPv: Int = 2,
    onProgress: (Int, Int) -> Unit
): ReviewResult {
    val b = Board(); b.loadFromFen(startFen)
    val fens = ArrayList<String>(); fens.add(b.fen)
    for (m in moves) { b.doMove(m); fens.add(b.fen) }

    val raw = arrayOfNulls<List<Line>>(fens.size)
    var engineOk = false
    var finished = 0
    val next = AtomicInteger(0)
    onProgress(0, fens.size)
    coroutineScope {
        (listOf(engine) + extra).map { eng ->
            async {
                while (true) {
                    val i = next.getAndIncrement()
                    if (i >= fens.size) break
                    val f = fens[i]
                    val tb = Board(); tb.loadFromFen(f)
                    val legal = tb.legalMoves()
                    raw[i] = if (legal.isEmpty()) {
                        listOf(if (tb.isMated) Line(null, 0, "") else Line(0, null, ""))
                    } else {
                        val single = legal.size == 1
                        val d = if (single) minOf(depth, 8) else depth
                        val ms = if (single) minOf(maxMs, 250) else maxMs
                        var ls = eng.analyze(f, d, ms, multiPv)
                        // Raha tsy nandeha ny motera fanampiny dia averina amin'ny motera fototra
                        if (ls.isEmpty() && eng !== engine) ls = engine.analyze(f, d, ms, multiPv)
                        if (ls.isNotEmpty()) engineOk = true
                        ls
                    }
                    finished++
                    onProgress(finished, fens.size)
                }
            }
        }.awaitAll()
    }
    if (!engineOk) throw IllegalStateException("Stockfish tsy mandeha (libstockfish.so tsy hita)")
    val analysis: List<List<Line>> = raw.map { it ?: emptyList() }

    val dummy = Line(0, null, "")
    fun l1(i: Int): Line = analysis[i].firstOrNull() ?: dummy

    val evalsWhite = ArrayList<Int>(); val evalTexts = ArrayList<String>()
    val bestUci = ArrayList<String?>(); val bestSan = ArrayList<String?>()
    for (i in fens.indices) {
        val w = stmWhite(fens[i]); val ln = l1(i)
        evalsWhite.add(if (w) ln.stmCp() else -ln.stmCp())
        evalTexts.add(evalText(ln, w))
        val bu: String? = if (ln.move.isEmpty()) null else ln.move
        bestUci.add(bu); bestSan.add(uciToSan(fens[i], bu))
    }

    val ml = MoveList(startFen)
    for (m in moves) ml.add(m)
    val sans = ml.toSanArray()

    val reviews = ArrayList<MoveReview>()
    var prevLoss = 0.0
    for (i in moves.indices) {
        val mover = if (stmWhite(fens[i])) Side.WHITE else Side.BLACK
        val lines = analysis[i]
        val top = l1(i)
        val uci = moves[i].toString()
        val playedBest = uci.equals(top.move, true)
        val cpBefore = top.stmCp()
        val cpAfter = lines.firstOrNull { it.move.equals(uci, true) }?.stmCp() ?: -l1(i + 1).stmCp()
        val winBefore = winPct(cpBefore)
        val winAfter = winPct(cpAfter)
        val loss = if (playedBest) 0.0 else max(0.0, winBefore - winAfter)
        val cpLoss = if (playedBest) 0 else max(0, cpBefore.coerceIn(-1000, 1000) - cpAfter.coerceIn(-1000, 1000))

        var cls = when {
            playedBest || loss <= 0.5 -> Cls.BEST
            loss <= 2 -> Cls.EXCELLENT
            loss <= 5 -> Cls.GOOD
            loss <= 10 -> Cls.INACCURACY
            loss <= 20 -> Cls.MISTAKE
            else -> Cls.BLUNDER
        }
        if (cls == Cls.BEST || cls == Cls.EXCELLENT) {
            val pre = Board(); pre.loadFromFen(fens[i])
            val recapture = i > 0 && moves[i].to == moves[i - 1].to
            if (isSacrifice(pre, moves[i]) && winAfter >= 45 && winBefore <= 90) {
                cls = Cls.BRILLIANT
            } else if (cls == Cls.BEST && !recapture && lines.size > 1 &&
                winBefore - winPct(lines[1].stmCp()) >= 15
            ) {
                cls = Cls.GREAT
            }
        }
        if ((cls == Cls.INACCURACY || cls == Cls.MISTAKE) && prevLoss >= 15 && winBefore >= 60) cls = Cls.MISS

        val acc = (103.1668 * exp(-0.04354 * loss) - 3.1669).coerceIn(0.0, 100.0)
        reviews.add(MoveReview(sans.getOrElse(i) { uci }, uci, mover, cls, loss, cpLoss, acc))
        prevLoss = loss
    }

    return ReviewResult(
        fens, evalsWhite, evalTexts, bestUci, bestSan,
        moves.map { it.from to it.to }, reviews,
        summary(reviews.filter { it.side == Side.WHITE }),
        summary(reviews.filter { it.side == Side.BLACK })
    )
}

/** Fanazavana amin'ny teny malagasy ho an'ny hetsika iray. */
fun clsCommentMg(mv: MoveReview): String = when (mv.cls) {
    Cls.BRILLIANT -> "Hetsika mahavariana! Sacrifice mahay izay mbola mitazona tombony lehibe."
    Cls.GREAT -> "Hetsika tena tsara: ny hany safidy mety, na hetsika nanova ny lalao."
    Cls.BEST -> "Ny hetsika tsara indrindra araka ny Stockfish."
    Cls.EXCELLENT -> "Hetsika tena tsara, saika mitovy amin'ny tsara indrindra."
    Cls.GOOD -> "Hetsika mety, saingy misy safidy tsara kokoa."
    Cls.INACCURACY -> "Tsy marina tanteraka: very ny tombony kely."
    Cls.MISS -> "Tsy nararaka ny fahafahana: nisy tombony na fandresena azo noraisina."
    Cls.MISTAKE -> "Hadisoana: very ny ampahany lehibe amin'ny toerana."
    Cls.BLUNDER -> "Hadisoana lehibe! Nivadika tanteraka ny lalao."
}

/** Famaritana ny toe-draharaha araka ny eval (cp, ho an'ny Fotsy). */
fun evalDescMg(cpWhite: Int): String {
    val w = winPct(cpWhite)
    return when {
        w >= 90 -> "Fotsy saika handresy"
        w >= 70 -> "Fotsy mandroso mazava"
        w >= 56 -> "Fotsy mahazo tombony kely"
        w > 44 -> "Mitovy ny toe-draharaha"
        w > 30 -> "Mainty mahazo tombony kely"
        w > 10 -> "Mainty mandroso mazava"
        else -> "Mainty saika handresy"
    }
}
