package mg.chess.offline.own;

/**
 * Evaluation manokana (centipawn, araka ny mpilalao ho avy). Misy toetra (personalité):
 * a=fanafihana, s=sacrifice, d=fiarovana, q=queen, t=fifanakalozana (0..100, 50 = mahazatra).
 */
public final class Eval {
    static final int[] V_MG = {0, 100, 320, 330, 500, 900, 0};
    static final int[] V_EG = {0, 115, 320, 340, 520, 950, 0};
    static final int[] PH = {0, 0, 1, 1, 2, 4, 0};
    static final int[][] PST_MG = new int[16][128];
    static final int[][] PST_EG = new int[16][128];
    static final int[] PASS_MG = {0, 0, 5, 10, 20, 35, 60, 0};
    static final int[] PASS_EG = {0, 0, 10, 20, 40, 70, 120, 0};
    static final int[] ATT_W = {0, 0, 2, 2, 3, 5, 0};
    // Lanja scalar azo tuning-na (Texel). Jereo W_* ho an'ny index.
    static final int W_DBL_MG = 0, W_DBL_EG = 1, W_ISO_MG = 2, W_ISO_EG = 3, W_SUP_MG = 4, W_SUP_EG = 5,
        W_NMOB_MG = 6, W_NMOB_EG = 7, W_BMOB_MG = 8, W_BMOB_EG = 9, W_RMOB_MG = 10, W_RMOB_EG = 11,
        W_ROPEN_MG = 12, W_ROPEN_EG = 13, W_RSEMI_MG = 14, W_RSEMI_EG = 15, W_R7_MG = 16, W_R7_EG = 17,
        W_QMOB_EG = 18, W_BPAIR_MG = 19, W_BPAIR_EG = 20, W_OUTP_MG = 21, W_OUTP_EG = 22, W_OUTPU_MG = 23,
        W_THR_MG = 24, W_THR_EG = 25, W_PKPROX = 26, W_PBLOCK = 27, W_TEMPO = 28, W_QMOB_MG = 29;
    static final int[] W = {8, 12, 12, 12, 5, 5, 4, 4, 3, 4, 1, 3, 20, 10, 10, 8, 15, 20, 2, 30, 45, 18, 10, 8, 25, 15, 3, 50, 10, 1};
    // Toetra vaovao (Eval2=1): fanamboarana piyon, tafio-drivotra, tsy misy ratsy fanaovana. Azo tuning-na (group w2).
    static final int W2_PHAL_MG = 0, W2_PHAL_EG = 1, W2_BACK_MG = 2, W2_BACK_EG = 3, W2_STORM = 4, W2_NOQ = 5, W2_FREE = 6;
    static final int[] W2 = {8, 6, 8, 10, 5, 50, 6};
    // Toetra fanafihana (Eval3=1). Azo tuning-na (group w3).
    static final int W3_OPENF = 0, W3_SEMIF = 1, W3_TROPQ = 2, W3_TROPN = 3, W3_COUNTER = 4, W3_SAC = 5, W3_SACMAX = 6,
        W3_THRATK = 7, W3_CKING = 8, W3_OPPS = 9, W3_KEXP = 10;
    static final int[] W3 = {12, 6, 3, 3, 15, 25, 60, 50, 10, 4, 4};
    static final int[][] TMG = new int[7][64], TEG = new int[7][64]; // [type][rr*8+f]

    static {
        for (int c = 0; c < 2; c++) {
            for (int sq = 0; sq < 128; sq++) {
                if ((sq & 0x88) != 0) continue;
                int f = sq & 7, r = sq >> 4;
                int rr = c == 0 ? r : 7 - r; // ambaratonga relative
                int d = Math.max(Math.abs(2 * f - 7), Math.abs(2 * r - 7));
                int cf = Math.abs(2 * f - 7);
                int pc = c << 3;
                // piyon
                int pmg = new int[]{0, -5, -5, 0, 10, 25, 40, 0}[rr];
                if (rr >= 1 && rr <= 4 && (f == 3 || f == 4)) pmg += 8 + 2 * rr;
                if (rr == 1 && (f == 0 || f == 7)) pmg -= 3;
                int peg = new int[]{0, 0, 3, 8, 18, 35, 50, 0}[rr];
                PST_MG[Pos.P | pc][sq] = pmg; PST_EG[Pos.P | pc][sq] = peg;
                PST_MG[Pos.N | pc][sq] = (7 - d) * 5 - 20; PST_EG[Pos.N | pc][sq] = (7 - d) * 4 - 16;
                PST_MG[Pos.B | pc][sq] = (7 - d) * 2 - 6;  PST_EG[Pos.B | pc][sq] = (7 - d) * 2 - 6;
                PST_MG[Pos.R | pc][sq] = (cf <= 3 ? 3 : 0); PST_EG[Pos.R | pc][sq] = 0;
                PST_MG[Pos.Q | pc][sq] = (7 - d) - 3;       PST_EG[Pos.Q | pc][sq] = (7 - d) * 2 - 6;
                PST_MG[Pos.K | pc][sq] = cf * 3 - 14 * rr;  PST_EG[Pos.K | pc][sq] = (7 - d) * 8 - 24;
                if (c == 0) for (int ty = 1; ty <= 6; ty++) {
                    TMG[ty][r * 8 + f] = PST_MG[ty][sq]; TEG[ty][r * 8 + f] = PST_EG[ty][sq];
                }
            }
        }
    }

    /** Fenoy ny PST avy amin'ny TMG/TEG (mitovy amin'ny fisaka ho an'ny mainty). */
    public static void rebuildPst() {
        for (int c = 0; c < 2; c++) for (int sq = 0; sq < 128; sq++) {
            if ((sq & 0x88) != 0) continue;
            int f = sq & 7, r = sq >> 4, rr = c == 0 ? r : 7 - r;
            for (int ty = 1; ty <= 6; ty++) {
                PST_MG[ty | (c << 3)][sq] = TMG[ty][rr * 8 + f];
                PST_EG[ty | (c << 3)][sq] = TEG[ty][rr * 8 + f];
            }
        }
    }

    // ---- Lanja voatombana (Texel) - novolavolain'ny Tuner ----
    static {
        int[] vmg = {0, 100, 364, 361, 529, 1089, 0}; int[] veg = {0, 103, 273, 300, 499, 934, 0};
        int[] w = {6, 9, 15, 8, 7, 3, 2, 4, 5, 5, 4, 3, 39, 0, 27, 13, 42, 16, 2, 65, 34, 48, 17, 24, 46, 32, 33, 38, 6, 1};
        int[] w2 = {8, 6, 8, 10, 5, 50, 6};
        int[] w3 = {12, 6, 0, 5, 31, 0, 60, 50, 15, 2, 4};
        int[] pmg = {0, 0, -19, -3, 24, 102, 196, 0}; int[] peg = {0, 0, 17, 52, 84, 108, 167, 0};
        int[] tmg1 = {0, 0, 0, 0, 0, 0, 0, 0, -9, -5, -7, -18, -19, 6, -3, -17, -4, -10, -5, -14, -8, -2, -1, -3, -9, -7, 6, 15, 12, 13, -17, -11, 6, 20, 18, 18, 27, 4, 11, 0, 24, 25, 20, 55, 12, 30, 44, 40, 50, 49, 61, 43, 23, 10, 40, 20, 0, 0, 0, 0, 0, 0, 0, 0};
        int[] teg1 = {0, 0, 0, 0, 0, 0, 0, 0, 15, 7, 11, 17, 6, 10, 9, 11, 3, 7, 10, 10, 3, 8, 0, -2, 7, 8, 5, -16, -12, 0, 10, 15, 19, 18, -4, -2, 3, 14, 17, 20, 33, 25, 27, 12, 30, 25, 13, 38, 36, 58, 47, 42, 45, 57, 66, 53, 0, 0, 0, 0, 0, 0, 0, 0};
        int[] tmg2 = {-53, -18, 12, 19, 4, -16, -7, 0, -44, 29, -12, 9, 17, 4, -26, -38, -29, 2, 1, 7, 26, 12, 28, -14, -5, -23, 2, 0, 11, -7, -14, 17, 29, -8, 18, 10, 7, -4, -15, 11, -11, 21, 8, 20, -9, -8, -8, -37, -77, -80, -11, 8, -9, 39, -10, 7, -147, -41, -39, -21, 17, -46, -25, -42};
        int[] teg2 = {-16, -17, -33, -17, -11, -15, -28, -2, -50, -8, -32, -5, -18, -9, 10, -57, -28, -1, -4, 5, 0, 1, 11, -29, -24, -7, 11, 10, -6, 7, -7, -23, -26, -5, -9, -1, 9, 0, -3, -12, -11, -25, 8, -3, -1, -12, -8, -56, -21, -18, -12, -8, -8, -8, 10, -36, -16, -7, -1, -35, -35, -17, -16, -44};
        int[] tmg3 = {-13, 45, -7, -25, 8, -10, 36, 0, 16, 12, -12, 4, 8, -3, 20, 32, -20, 24, 7, -3, -4, 15, 14, -11, -48, 2, -6, -2, 13, -3, -21, 25, 15, -10, -12, -10, 16, 5, -17, 0, 4, 1, -7, 18, 12, 48, -8, -50, -36, -6, 0, -8, -69, -5, -20, -29, -36, -8, -12, -5, -77, -46, 68, -52};
        int[] teg3 = {-7, -64, -27, -1, -25, -4, 3, -25, -39, -8, -19, -3, -5, -12, 0, -34, -13, -22, 7, 2, 2, -3, 4, -22, -17, 7, -2, 10, -10, 5, -9, -11, -33, 9, 4, 6, 7, 9, 29, -11, -3, -1, 20, 11, 4, 18, 20, 28, 2, 1, 1, -2, 27, -14, 10, -24, -6, 5, -33, 3, -7, 5, -56, -6};
        int[] tmg4 = {2, 2, -5, 0, 13, 21, 2, 2, -16, -3, -3, 5, -22, 13, -15, -13, -9, -4, -26, -34, 5, -9, -10, -3, -11, -6, -26, -18, 0, -17, -19, 2, 0, 3, 15, 44, -9, 12, -23, -2, 9, 24, 3, 13, 7, 13, 10, 21, 7, 29, 20, 19, 39, -11, 0, 4, 63, 26, 31, 34, 48, 12, 53, 27};
        int[] teg4 = {-3, -2, 8, -7, -20, -20, -11, -4, -20, -9, 0, -9, -19, -28, -9, -12, 0, -8, 2, -2, -23, -11, -12, -18, 6, 5, 17, 3, -3, 5, 3, 4, 4, 15, 18, 1, 10, 11, 12, 20, 6, 1, 0, 1, 3, -5, 9, 3, 12, 18, 3, 21, 11, 1, 3, 7, 13, 16, 15, 7, 23, 14, 1, 12};
        int[] tmg5 = {-8, -6, -1, 9, 8, -1, -17, -19, -20, -21, 8, 14, 16, 12, -5, -19, 5, 7, -6, 4, 17, -9, -2, -27, -16, -26, 2, 1, -23, -8, -14, -14, -18, -9, -2, -5, -38, -4, -18, -1, -17, 0, 1, 56, 22, 20, -6, 24, -6, 2, -18, 57, 26, 8, 31, -2, -18, 11, 25, -1, 35, 30, -5, -7};
        int[] teg5 = {-8, -23, -30, -31, -49, -14, -14, -21, -15, 9, -35, -30, -12, -11, -24, -6, -6, 6, -8, 4, 3, -1, 4, -7, -6, 9, 12, 11, 6, 1, 8, 11, 39, 4, 2, 46, 65, 21, 26, 19, -8, 8, 5, 3, 14, 9, 2, -2, 11, 4, 19, -2, 20, 10, -1, -3, -11, -11, -6, -6, -5, 9, -7, 6};
        int[] tmg6 = {-3, 9, 28, 2, 10, 3, 12, -3, 41, 15, 20, 15, 5, 18, 10, 7, 19, 16, -21, -22, -26, -18, 8, 24, 20, -27, -30, -87, -113, -30, -27, -25, -12, -21, -47, -150, -150, -69, -35, -35, -43, -52, -54, -81, -67, -59, -49, -102, -66, -38, -18, -78, -67, 44, -25, -61, -79, -53, -84, -93, -89, -89, -18, -77};
        int[] teg6 = {-24, -14, -22, -21, -23, -20, -19, -32, -38, 2, -3, -4, 0, -9, -3, -22, -12, -7, 7, 6, 5, 10, -6, -20, -37, -4, 9, 8, 12, 5, -17, -26, -55, -2, -4, -7, 2, -1, 6, -36, -4, 5, 15, 7, 0, 5, 5, -28, -50, 33, 16, 17, 3, 17, 22, -27, -123, -36, -33, -63, -96, -27, -13, -52};
        System.arraycopy(vmg, 0, V_MG, 0, vmg.length); System.arraycopy(veg, 0, V_EG, 0, veg.length);
        System.arraycopy(w, 0, W, 0, w.length);
        System.arraycopy(w2, 0, W2, 0, w2.length);
        System.arraycopy(w3, 0, W3, 0, w3.length);
        System.arraycopy(pmg, 0, PASS_MG, 0, pmg.length); System.arraycopy(peg, 0, PASS_EG, 0, peg.length);
        int[][] tm = {null, tmg1, tmg2, tmg3, tmg4, tmg5, tmg6}, te = {null, teg1, teg2, teg3, teg4, teg5, teg6};
        for (int ty = 1; ty <= 6; ty++) { System.arraycopy(tm[ty], 0, TMG[ty], 0, 64); System.arraycopy(te[ty], 0, TEG[ty], 0, 64); }
        rebuildPst();
    }
    // ---- farany ----

    private static final int[] UNDEV = {0x01, 0x02, 0x05, 0x06}; // b,c,f,g (rank 1 / +0x70 = rank 8)

    private static int cheb(int a, int b) {
        return Math.max(Math.abs((a & 7) - (b & 7)), Math.abs((a >> 4) - (b >> 4)));
    }

    // personalité (pct)
    final int matPct, attPct, defPct, queenAct, tradeTf;

    public Eval(int a, int s, int d, int q, int t) {
        matPct = 100 - (s - 50) / 5;                 // sacrifice: 90..110
        int ap = 70 + (a * 60) / 100;                  // 70..130
        attPct = ap * (100 + (s - 50) / 2) / 100;      // sacrifice mampitombo ny fanafihana
        defPct = 60 + (d * 80) / 100;                  // 60..140
        queenAct = q - 50 + (q - 50);                  // -100..+100
        tradeTf = (t - 50) * 15 / 50;                  // -15..+15 (%)
    }

    private final int[][] cnt = new int[2][10];
    private final int[][] hi = new int[2][10];
    private final int[][] lo = new int[2][10];
    private final int[] mg = new int[2], eg = new int[2];
    private final boolean[][] zone = new boolean[2][128];
    private final int[] units = new int[2], atk = new int[2];
    private final int[] nb = new int[2];
    private final int[] bishops = new int[2];
    private final int[] pawnsN = new int[2];
    private final int[] mat = new int[2];
    private final int[] qn = new int[2];
    private final int[][] rqf = new int[2][8];  // isan'ny rook/queen isaky ny rakitra (Eval3)
    private final int[] occSq = new int[40];   // toerana misy piece (<= 32)

    /** Mitovy amin'ny zone[c][t] taloha: 3x3 manodidina ny mpanjaka + andalana 2 eo aloha (3 rakitra). */
    private static boolean inZone(int kr, int kf, int c, int t) {
        int dr = (t >> 4) - kr, df = (t & 7) - kf;
        if (df < -1 || df > 1) return false;
        return (dr >= -1 && dr <= 1) || dr == (c == 0 ? 2 : -2);
    }

    @SuppressWarnings("unused")
    private void mark(Pos p, int c) {
        boolean[] z = zone[c];
        java.util.Arrays.fill(z, false);
        int k = p.ksq[c];
        int fwd = c == 0 ? 16 : -16;
        for (int dr = -1; dr <= 1; dr++) for (int df = -1; df <= 1; df++) {
            int s = k + dr * 16 + df;
            if ((s & 0x88) == 0) z[s] = true;
        }
        for (int df = -1; df <= 1; df++) {
            int s = k + 2 * fwd + df;
            if ((s & 0x88) == 0) z[s] = true;
        }
    }

    // ---- Eval cache (hash araka ny pos.key): mitahiry ny valiny mitovy tanteraka, ka tsy manova ny node ----
    private static final int EC_BITS = 17;
    private final long[] ecKey = new long[1 << EC_BITS];
    private final int[] ecVal = new int[1 << EC_BITS];

    /** Fafao rehefa miova ny Eval.W / PST (ohatra rehefa Texel tuning). */
    public void clearCache() { java.util.Arrays.fill(ecKey, 0L); }

    /** Score araka ny mpilalao ho avy (misy cache). */
    public int eval(Pos p) {
        final long k = p.key;
        final int i = (int) (k ^ (k >>> 32)) & ((1 << EC_BITS) - 1);
        if (ecKey[i] == k) return ecVal[i];
        final int v = evalRaw(p);
        ecKey[i] = k; ecVal[i] = v;
        return v;
    }

    /** Fanisana tsy misy cache. */
    public int evalRaw(Pos p) {
        final int[] b = p.b;
        for (int c = 0; c < 2; c++) {
            java.util.Arrays.fill(cnt[c], 0);
            java.util.Arrays.fill(hi[c], -1);
            java.util.Arrays.fill(lo[c], 8);
            mg[c] = 0; eg[c] = 0; units[c] = 0; atk[c] = 0; nb[c] = 0; bishops[c] = 0; pawnsN[c] = 0; mat[c] = 0; qn[c] = 0;
        }
        int phaseTot = 0, minors = 0, majors = 0;
        // pass 1: piyon + material (tahirizina ny toerana misy piece ho an'ny pass 2)
        int no = 0;
        final int[] occ = occSq;
        for (int s = 0; s < 128; s++) {
            if ((s & 0x88) != 0) { s += 7; continue; }
            int pc = b[s];
            if (pc == 0) continue;
            occ[no++] = s;
            int c = pc >> 3, ty = pc & 7;
            if (ty == Pos.P) {
                int f = s & 7, r = s >> 4;
                cnt[c][f + 1]++;
                if (r > hi[c][f + 1]) hi[c][f + 1] = r;
                if (r < lo[c][f + 1]) lo[c][f + 1] = r;
                pawnsN[c]++;
            } else if (ty != Pos.K) {
                phaseTot += PH[ty];
                nb[c]++;
                if (ty == Pos.N || ty == Pos.B) minors++; else majors++;
                if (ty == Pos.B) bishops[c]++;
                if (ty == Pos.Q) qn[c]++;
                if (ty == Pos.R || ty == Pos.Q) rqf[c][s & 7]++;
            }
        }
        if (pawnsN[0] + pawnsN[1] == 0 && majors == 0 && minors <= 1) return 0; // draw: material tsy ampy
        final boolean ev2 = Params.EVAL2.val != 0, ev3 = Params.EVAL3.val != 0;
        final boolean joro = ev3 && Params.JORO_STYLE.val != 0;
        if (ev3) { java.util.Arrays.fill(rqf[0], 0); java.util.Arrays.fill(rqf[1], 0); }
        final int kr0 = p.ksq[0] >> 4, kf0 = p.ksq[0] & 7, kr1 = p.ksq[1] >> 4, kf1 = p.ksq[1] & 7;
        for (int oi = 0; oi < no; oi++) {
            final int s = occ[oi];
            int pc = b[s];
            int c = pc >> 3, ty = pc & 7, o = c ^ 1;
            int f = s & 7, r = s >> 4, rr = c == 0 ? r : 7 - r;
            final int zkr = o == 0 ? kr0 : kr1, zkf = o == 0 ? kf0 : kf1;
            mg[c] += V_MG[ty] * matPct / 100 + PST_MG[pc][s];
            eg[c] += V_EG[ty] * matPct / 100 + PST_EG[pc][s];
            mat[c] += V_MG[ty];
            boolean hitK = false;
            switch (ty) {
                case Pos.P: {
                    if (cnt[c][f + 1] > 1) { mg[c] -= W[W_DBL_MG]; eg[c] -= W[W_DBL_EG]; }
                    if (cnt[c][f] == 0 && cnt[c][f + 2] == 0) { mg[c] -= W[W_ISO_MG]; eg[c] -= W[W_ISO_EG]; }
                    boolean passed = true;
                    for (int ff = f; ff <= f + 2 && passed; ff++) {
                        if (c == 0) { if (hi[1][ff] > r) passed = false; }
                        else { if (lo[0][ff] < r) passed = false; }
                    }
                    if (passed) {
                        int pm = PASS_MG[rr], pe = PASS_EG[rr];
                        int stop = s + (c == 0 ? 16 : -16);
                        if ((stop & 0x88) == 0) {
                            if (b[stop] != 0 && (b[stop] >> 3) != c) { pm -= pm * W[W_PBLOCK] / 100; pe -= pe * W[W_PBLOCK] / 100; }
                            eg[c] += (cheb(p.ksq[o], stop) - cheb(p.ksq[c], stop)) * W[W_PKPROX] * rr / 6;
                        }
                        mg[c] += pm; eg[c] += pe;
                        if (ev2) {
                            int fw = c == 0 ? 16 : -16, q = s + fw;
                            boolean free = true;
                            while ((q & 0x88) == 0) { if (b[q] != 0) { free = false; break; } q += fw; }
                            if (free) eg[c] += W2[W2_FREE] * rr / 2;
                        }
                    }
                    if (ev2) {
                        final int me3 = Pos.P | (c << 3);
                        final int rn = s + 1;
                        if ((rn & 0x88) == 0 && b[rn] == me3) { mg[c] += W2[W2_PHAL_MG] * rr / 4; eg[c] += W2[W2_PHAL_EG] * rr / 4; }
                        if (!passed && cnt[c][f] + cnt[c][f + 2] > 0) {
                            boolean behind = c == 0 ? (lo[c][f] <= r || lo[c][f + 2] <= r) : (hi[c][f] >= r || hi[c][f + 2] >= r);
                            if (!behind) {
                                int st = s + (c == 0 ? 16 : -16);
                                int ep3 = Pos.P | (o << 3), a1 = st + (c == 0 ? 15 : -15), a2 = st + (c == 0 ? 17 : -17);
                                if (((a1 & 0x88) == 0 && b[a1] == ep3) || ((a2 & 0x88) == 0 && b[a2] == ep3)) {
                                    mg[c] -= W2[W2_BACK_MG]; eg[c] -= W2[W2_BACK_EG];
                                }
                            }
                        }
                    }
                    if (ev3) {
                        final int okf = o == 0 ? kf0 : kf1, mkf = o == 0 ? kf1 : kf0;
                        if (Math.abs(okf - mkf) >= 3 && Math.abs(f - okf) <= 2 && rr >= 3) mg[c] += W3[W3_OPPS] * (rr - 2);
                    }
                    int sup = c == 0 ? -15 : 15;
                    int s1 = s + sup, s2 = s + (c == 0 ? -17 : 17);
                    int me = Pos.P | (c << 3);
                    if (((s1 & 0x88) == 0 && b[s1] == me) || ((s2 & 0x88) == 0 && b[s2] == me)) { mg[c] += W[W_SUP_MG]; eg[c] += W[W_SUP_EG]; }
                    break;
                }
                case Pos.N: {
                    int m = 0; boolean hit = false;
                    for (int d : Pos.KN) {
                        int t = s + d;
                        if ((t & 0x88) != 0) continue;
                        int tp = b[t];
                        if (tp != 0 && (tp >> 3) == c) continue;
                        m++;
                        if (!hit && inZone(zkr, zkf, o, t)) hit = true;
                    }
                    mg[c] += (m - 4) * W[W_NMOB_MG]; eg[c] += (m - 4) * W[W_NMOB_EG];
                    if (rr >= 3 && rr <= 5 && f >= 1 && f <= 6) {
                        boolean safe = c == 0 ? (hi[1][f] <= r && hi[1][f + 2] <= r) : (lo[0][f] >= r && lo[0][f + 2] >= r);
                        if (safe) {
                            int me2 = Pos.P | (c << 3);
                            int a1 = s + (c == 0 ? -15 : 15), a2 = s + (c == 0 ? -17 : 17);
                            boolean sup = ((a1 & 0x88) == 0 && b[a1] == me2) || ((a2 & 0x88) == 0 && b[a2] == me2);
                            mg[c] += sup ? W[W_OUTP_MG] : W[W_OUTPU_MG]; eg[c] += sup ? W[W_OUTP_EG] : W[W_OUTP_EG] / 2;
                        }
                    }
                    if (hit) { units[c] += ATT_W[ty]; atk[c]++; hitK = true; }
                    if (ev3) mg[c] += W3[W3_TROPN] * (7 - cheb(s, p.ksq[o]));
                    break;
                }
                case Pos.B: case Pos.R: case Pos.Q: {
                    int m = 0; boolean hit = false;
                    for (int di = 0; di < 8; di++) {
                        int d;
                        if (di < 4) { if (ty == Pos.B) continue; d = Pos.RD[di]; }
                        else { if (ty == Pos.R) continue; d = Pos.BD[di - 4]; }
                        int t = s + d;
                        while ((t & 0x88) == 0) {
                            int tp = b[t];
                            if (tp != 0 && (tp >> 3) == c) break;
                            m++;
                            if (!hit && inZone(zkr, zkf, o, t)) hit = true;
                            if (tp != 0) break;
                            t += d;
                        }
                    }
                    if (ty == Pos.B) { mg[c] += (m - 6) * W[W_BMOB_MG]; eg[c] += (m - 6) * W[W_BMOB_EG]; }
                    else if (ty == Pos.R) {
                        mg[c] += (m - 7) * W[W_RMOB_MG]; eg[c] += (m - 7) * W[W_RMOB_EG];
                        if (cnt[c][f + 1] == 0) {
                            if (cnt[o][f + 1] == 0) { mg[c] += W[W_ROPEN_MG]; eg[c] += W[W_ROPEN_EG]; } else { mg[c] += W[W_RSEMI_MG]; eg[c] += W[W_RSEMI_EG]; }
                        }
                        if (rr == 6 && (p.ksq[o] >> 4 == (c == 0 ? 7 : 0))) { mg[c] += W[W_R7_MG]; eg[c] += W[W_R7_EG]; }
                    } else {
                        mg[c] += (m - 14) * (100 + queenAct) / 100 * W[W_QMOB_MG]; eg[c] += (m - 14) * W[W_QMOB_EG];
                        if (rr > 0 && queenAct > 0) mg[c] += queenAct * 12 / 100;
                    }
                    if (hit) { units[c] += ATT_W[ty]; atk[c]++; hitK = true; }
                    if (ev3 && ty == Pos.Q) mg[c] += W3[W3_TROPQ] * (7 - cheb(s, p.ksq[o]));
                    break;
                }
                default: break;
            }
            if (ty >= Pos.N && ty <= Pos.Q) {
                int e1 = s + (c == 0 ? 15 : -15), e2 = s + (c == 0 ? 17 : -17);
                int ep2 = Pos.P | (o << 3);
                if (((e1 & 0x88) == 0 && b[e1] == ep2) || ((e2 & 0x88) == 0 && b[e2] == ep2)) {
                    int tm = W[W_THR_MG], te2 = W[W_THR_EG];
                    if (ev3 && hitK) { tm = tm * (100 - W3[W3_THRATK]) / 100; te2 = te2 * (100 - W3[W3_THRATK]) / 100; }
                    mg[c] -= tm; eg[c] -= te2;
                }
            }
        }
        for (int c = 0; c < 2; c++) {
            if (bishops[c] >= 2) { mg[c] += W[W_BPAIR_MG]; eg[c] += W[W_BPAIR_EG]; }
            int o = c ^ 1;
            // fiarovana mpanjaka (pawn shield) - mg ihany
            int k = p.ksq[c];
            int kf = k & 7, kr = k >> 4, krr = c == 0 ? kr : 7 - kr;
            if (krr <= 1) {
                int shield = 0;
                int fwd = c == 0 ? 16 : -16;
                int me = Pos.P | (c << 3);
                for (int ff = Math.max(0, kf - 1); ff <= Math.min(7, kf + 1); ff++) {
                    int s1 = (kr * 16 + ff) + fwd, s2 = s1 + fwd;
                    if ((s1 & 0x88) == 0 && b[s1] == me) shield += 10;
                    else if ((s2 & 0x88) == 0 && b[s2] == me) shield += 6;
                    else if (cnt[c][ff + 1] == 0) shield -= 15;
                    else shield -= 5;
                }
                mg[c] += shield * defPct / 100;
                if (ev2) {
                    int storm = 0;
                    for (int ff = Math.max(0, kf - 1); ff <= Math.min(7, kf + 1); ff++) {
                        if (cnt[o][ff + 1] == 0) continue;
                        int adv = o == 0 ? hi[o][ff + 1] : 7 - lo[o][ff + 1];
                        if (adv >= 3) storm += adv - 2;
                    }
                    mg[c] -= storm * W2[W2_STORM];
                }
            }
            if (ev3 && nb[o] > 2) {
                // rakitra misokatra manoloana ny mpanjaka + rook/queen mpifanandrina
                for (int ff = Math.max(0, kf - 1); ff <= Math.min(7, kf + 1); ff++) {
                    if (cnt[c][ff + 1] != 0 || rqf[o][ff] == 0) continue;
                    mg[c] -= cnt[o][ff + 1] == 0 ? W3[W3_OPENF] : W3[W3_SEMIF];
                }
                // mpanjaka tsy niaro eo afovoany raha mbola misy queen mpifanandrina
                if (qn[o] > 0 && krr <= 2 && kf >= 2 && kf <= 5) {
                    int missing = (cnt[c][4] == 0 ? 1 : 0) + (cnt[c][5] == 0 ? 1 : 0);
                    mg[c] -= W3[W3_CKING] * (1 + missing);
                }
            }
            // loza amin'ny mpanjaka (attackers an'ny mpifanandrina)
            if (atk[o] >= 2) {
                int danger = Math.min(350, units[o] * units[o] * 2);
                if (ev2 && qn[o] == 0) danger = danger * W2[W2_NOQ] / 100;
                if (ev3) {
                    // fanafihana vs fanafihana: raha mamely ihany koa ny c dia mihena ny loza
                    if (atk[c] >= 2) danger = danger * (100 - W3[W3_COUNTER]) / 100;
                    // sacrifice: ny mpanafika very material nefa mahery ny fanafihana dia mahazo onitra
                    int deficit = mat[c] - mat[o];
                    if (joro) {
                        // JORO: mahafoy sacrifice kokoa (atk >= 2, bonus x JoroSac%)
                        if (atk[o] >= 2 && deficit >= 100 && deficit <= 500) {
                            final int js = Params.JORO_SAC.val;
                            mg[o] += Math.min(W3[W3_SACMAX] * js / 100, danger * W3[W3_SAC] / 100 * js / 100);
                        }
                    } else if (atk[o] >= 3 && deficit >= 100 && deficit <= 500)
                        mg[o] += Math.min(W3[W3_SACMAX], danger * W3[W3_SAC] / 100);
                }
                mg[c] -= danger * attPct / 100 * defPct / 100;
            }
        }
        if (joro && Params.JORO_DEV.val != 0) {
            // Gambit: ny miaramila very material (50..400 cp) dia mahazo onitra raha mbola tsy nivoaka ny kapiteny mpifanandrina
            for (int x = 0; x < 2; x++) {
                int def = mat[1 - x] - mat[x];
                if (def < 50 || def > 400) continue;
                int base = (1 - x) == 0 ? 0 : 0x70;
                int und = 0;
                for (int k = 0; k < 4; k++) {
                    int sq = base + UNDEV[k];
                    int pc = b[sq];
                    if (pc != 0 && (pc >> 3) == (1 - x) && ((pc & 7) == Pos.N || (pc & 7) == Pos.B)) und++;
                }
                mg[x] += und * Params.JORO_DEV.val;
            }
        }
        int phase = Math.min(24, phaseTot);
        int mgS = mg[0] - mg[1], egS = eg[0] - eg[1];
        int score = (mgS * phase + egS * (24 - phase)) / 24;
        // fifanakalozana: raha mitarika ny bot dia tia manafoana piece (araka ny toetra)
        score += (mat[0] - mat[1]) * tradeTf / 100 * (24 - phase) / 24;
        // mop-up: mahomby ny fandresena amin'ny endgame tsotra
        int diff = mat[0] - mat[1];
        if (phase <= 8 && Math.abs(diff) >= 300) {
            int win = diff > 0 ? 0 : 1, lose = win ^ 1;
            if (pawnsN[lose] == 0) {
                int wk = p.ksq[win], lk = p.ksq[lose];
                int cd = Math.max(Math.abs(2 * (lk & 7) - 7), Math.abs(2 * (lk >> 4) - 7));
                int dist = Math.abs((wk & 7) - (lk & 7)) + Math.abs((wk >> 4) - (lk >> 4));
                int bonus = cd * 8 + (14 - dist) * 6;
                score += win == 0 ? bonus : -bonus;
            }
        }
        score += p.side == 0 ? W[W_TEMPO] : -W[W_TEMPO];
        return p.side == 0 ? score : -score;
    }
}
