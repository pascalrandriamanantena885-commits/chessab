#!/usr/bin/env python3
"""SPRT: dikan-teny vaovao vs taloha an'i JORO (lalao UCI, python-chess).

Ampiasa:
  python3 tools/sprt.py <cls_taloha> <cls_vaovao> [--games 2000] [--movetime 100]
                        [--elo0 0] [--elo1 5] [--workers 2] [--alpha 0.05] [--beta 0.05]

Vokatra: H1 (vaovao tsara kokoa >= elo1), H0 (tsy tsara kokoa), na tsy mbola vita (tapitra ny lalao).
Exit code: 0 = H1, 1 = H0, 2 = tsy mbola vita.
"""
import argparse, math, random, sys
from multiprocessing import Pool


def elo_to_score(e):
    return 1.0 / (1.0 + 10 ** (-e / 400.0))


def llr(w, d, l, elo0, elo1):
    """LLR (fanatatehana Gaussian, mitovy amin'ny cutechess/fastchess tsy pentanomial)."""
    n = w + d + l
    if n == 0:
        return 0.0
    mean = (w + d / 2.0) / n
    var = (w * (1 - mean) ** 2 + d * (0.5 - mean) ** 2 + l * (0 - mean) ** 2) / n
    if var < 1e-9:
        return 0.0
    s0, s1 = elo_to_score(elo0), elo_to_score(elo1)
    return n * (s1 - s0) * (2 * mean - s0 - s1) / (2 * var)


def bounds(alpha, beta):
    return math.log(beta / (1 - alpha)), math.log((1 - beta) / alpha)  # lower (H0), upper (H1)


def elo_estimate(w, d, l):
    n = w + d + l
    if n == 0:
        return 0.0, 0.0
    s = min(max((w + d / 2.0) / n, 1e-3), 1 - 1e-3)
    var = (w * (1 - s) ** 2 + d * (0.5 - s) ** 2 + l * s ** 2) / n
    elo = -400 * math.log10(1 / s - 1)
    # fahadisoana 95% (delta method)
    se = math.sqrt(var / n)
    d_elo = 400 / math.log(10) / (s * (1 - s))
    return elo, 1.96 * se * d_elo


# ---------------------------------------------------------------- lalao
_A = {}


def parse_opts(txt):
    """'ProbCut=1,HashBits=21' -> {'ProbCut': 1, 'HashBits': 21}"""
    out = {}
    for kv in (txt or "").replace(" ", ",").split(","):
        if kv.strip():
            k, v = kv.split("=")
            out[k.strip()] = int(v)
    return out


def _init(old_cls, new_cls, movetime, opts_old="", opts_new=""):
    import chess.engine
    cmd = lambda c: ["java", "-cp", c, "mg.chess.offline.own.OwnUci"]
    _A["old"] = chess.engine.SimpleEngine.popen_uci(cmd(old_cls))
    _A["new"] = chess.engine.SimpleEngine.popen_uci(cmd(new_cls))
    for key, o in (("old", parse_opts(opts_old)), ("new", parse_opts(opts_new))):
        if o:
            _A[key].configure(o)
    _A["mt"] = movetime / 1000.0


def _opening(board, seed, plies=6):
    import chess
    rng = random.Random(seed)
    for _ in range(plies):
        moves = list(board.legal_moves)
        if not moves or board.is_game_over():
            break
        board.push(rng.choice(moves))
    return board


def _score_of(info):
    try:
        return info["score"].white().score(mate_score=10000)
    except Exception:
        return None


def play_game(g):
    """Miverina: (g, valiny amin'ny fomba fijerin'ny VAOVAO: 1, 0.5, 0)."""
    import chess, chess.engine
    board = _opening(chess.Board(), seed=g // 2)
    new_white = (g % 2 == 0)
    for e in (_A["old"], _A["new"]):
        e.protocol.send_line("ucinewgame")
    lim = chess.engine.Limit(time=_A["mt"])
    big, big_sign, quiet = 0, None, 0   # fanamarinana ny valiny (adjudication)
    while not board.is_game_over(claim_draw=True) and len(board.move_stack) < 300:
        new_turn = (board.turn == chess.WHITE) == new_white
        eng = _A["new"] if new_turn else _A["old"]
        r = eng.play(board, lim, info=chess.engine.INFO_SCORE)
        board.push(r.move)
        sc = _score_of(r.info)
        if sc is not None:
            if abs(sc) >= 900:
                sgn = sc > 0
                big = big + 1 if (big > 0 and sgn == big_sign) else 1
                big_sign = sgn
            else:
                big = 0
            quiet = quiet + 1 if abs(sc) <= 15 else 0
            if big >= 6 and abs(sc) >= 900:
                white = 1.0 if sc > 0 else 0.0            # amin'ny fomba fijerin'ny Fotsy
                return g, white if new_white else 1.0 - white
            if len(board.move_stack) >= 160 and quiet >= 10:
                return g, 0.5
    res = board.result(claim_draw=True)
    white = {"1-0": 1.0, "0-1": 0.0}.get(res, 0.5)
    return g, white if new_white else 1.0 - white


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("old_cls"); ap.add_argument("new_cls")
    ap.add_argument("--games", type=int, default=2000)
    ap.add_argument("--movetime", type=int, default=100)
    ap.add_argument("--elo0", type=float, default=0.0)
    ap.add_argument("--elo1", type=float, default=5.0)
    ap.add_argument("--alpha", type=float, default=0.05)
    ap.add_argument("--beta", type=float, default=0.05)
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--opts-base", default="", help="safidy UCI an'ny taloha: Name=val,Name2=val")
    ap.add_argument("--opts-new", default="", help="safidy UCI an'ny vaovao: Name=val,Name2=val")
    a = ap.parse_args()

    lo, hi = bounds(a.alpha, a.beta)
    w = d = l = 0
    verdict = None
    print(f"SPRT [{a.elo0}, {a.elo1}] alpha={a.alpha} beta={a.beta} bounds=({lo:.2f}, {hi:.2f}) "
          f"movetime={a.movetime}ms workers={a.workers} opts_base=[{a.opts_base}] opts_new=[{a.opts_new}]", flush=True)
    with Pool(a.workers, initializer=_init, initargs=(a.old_cls, a.new_cls, a.movetime, a.opts_base, a.opts_new)) as pool:
        for i, (g, sc) in enumerate(pool.imap_unordered(play_game, range(a.games)), 1):
            if sc == 1.0: w += 1
            elif sc == 0.0: l += 1
            else: d += 1
            x = llr(w, d, l, a.elo0, a.elo1)
            if i % 20 == 0 or x <= lo or x >= hi:
                e, err = elo_estimate(w, d, l)
                print(f"{i:5d} lalao  +{w} ={d} -{l}  Elo={e:+.1f} ±{err:.1f}  LLR={x:+.2f} [{lo:.2f},{hi:.2f}]", flush=True)
            if x >= hi: verdict = "H1"; break
            if x <= lo: verdict = "H0"; break
        pool.terminate()
    e, err = elo_estimate(w, d, l)
    print(f"RESULT {verdict or 'TSY_VITA'}  +{w} ={d} -{l}  Elo={e:+.1f} ±{err:.1f}  LLR={llr(w, d, l, a.elo0, a.elo1):+.2f}")
    sys.exit({"H1": 0, "H0": 1}.get(verdict, 2))


if __name__ == "__main__":
    main()
