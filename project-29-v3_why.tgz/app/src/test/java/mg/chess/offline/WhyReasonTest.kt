package mg.chess.offline

import com.github.bhlangonijr.chesslib.Side
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class WhyReasonTest {
    @Test fun checkmateLineIsDescribed() {
        val pv = listOf("f2f3", "e7e5", "g2g4", "d8h4")
        val v = lineVerdict(START_FEN, START_FEN, 0, pv, true, Side.WHITE)
        assertEquals(1, v.kind)
        assertEquals(Side.BLACK, v.winner)
        assertEquals(2, v.mateMoves)
        assertEquals("1. f3 → 1…e5 → 2. g4 → 2…Qh4", chainText(v))
        assertTrue(verdictText(v, Side.WHITE, 0).contains("CHECKMATE"))
    }

    @Test fun pawnTradeIsEqualExchange() {
        val fen = "rnbqkbnr/ppp1pppp/8/3p4/4P3/8/PPPP1PPP/RNBQKBNR w KQkq d6 0 2"
        val v = lineVerdict(START_FEN, fen, 2, listOf("e4d5", "d8d5"), false, Side.WHITE)
        assertEquals(4, v.kind)
        assertEquals(0, v.swing)
        assertEquals("pion", v.myLost)
        assertEquals("pion", v.oppLost)
    }

    @Test fun emptyLineHasNoVerdict() {
        val v = lineVerdict(START_FEN, START_FEN, 0, emptyList(), false, Side.WHITE)
        assertEquals(0, v.kind)
        assertEquals("fallback", chainText(v, "fallback"))
    }
}
