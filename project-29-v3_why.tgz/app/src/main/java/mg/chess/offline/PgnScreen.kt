package mg.chess.offline

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** PGN -> Stockfish (game review) -> bot. */
@Composable
fun PgnScreen(vm: ChessViewModel) {
    BackHandler { vm.cancelPgn(); vm.toBots() }
    val ctx = LocalContext.current
    var text by remember { mutableStateOf("") }
    val busy = vm.pgnProgress != null
    val players = remember(vm.pgnGames) { Pgn.players(vm.pgnGames) }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            val t = try { ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } } catch (e: Exception) { null }
            if (t == null) vm.pgnError = "Tsy azo vakiana ny rakitra."
            else { text = t.take(3_000_000); vm.loadPgn(text) }
        }
    }

    val draft = vm.pgnDraft
    if (draft != null) PgnDraftDialog(draft) { vm.pgnDraft = null }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { ScreenTitle("Bot avy amin'ny PGN", onBack = { vm.cancelPgn(); vm.toBots() }) }
        item {
            Text(
                "Apetaho ny lalao PGN (na fidio rakitra .pgn). Azonao jerena ny lalao rehetra ao anatiny (Jereo), na hamorona bot avy amin'ny mpilalao (Stockfish no mandinika lalao 2: Fotsy 1 + Mainty 1).",
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        item {
            OutlinedTextField(
                text, { text = it }, label = { Text("PGN") }, minLines = 5, maxLines = 8,
                modifier = Modifier.fillMaxWidth(), enabled = !busy
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ vm.loadPgn(text) }, enabled = text.isNotBlank() && !busy) { Text("Vakio") }
                OutlinedButton({ filePicker.launch(arrayOf("*/*")) }, enabled = !busy) { Text("Fidio rakitra .pgn") }
            }
        }
        vm.pgnError?.let { e -> item { Text(e, color = MaterialTheme.colorScheme.error) } }

        val prog = vm.pgnProgress
        if (prog != null) {
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Mandinika ny lalao amin'ny Stockfish 19...", fontWeight = FontWeight.Bold)
                        LinearProgressIndicator(progress = { prog }, modifier = Modifier.fillMaxWidth())
                        Text("${(prog * 100).toInt()}% - mety haharitra minitra vitsy", fontSize = 12.sp)
                        OutlinedButton({ vm.cancelPgn() }) { Text("Foano") }
                    }
                }
            }
        }

        if (vm.pgnGames.isNotEmpty()) {
            item {
                Text(
                    "Lalao hita: ${vm.pgnGames.size} - mpilalao: ${players.size}. Fidio ny mpilalao hovakiana:",
                    fontWeight = FontWeight.Bold
                )
                Text("Lalao 2 ihany no andinihina ho an'ny mpilalao (1 amin'ny Fotsy + 1 amin'ny Mainty, hetsika 70 voalohany) mba ho haingana. Azo raisina koa ny lalao manomboka antenatenany (tag FEN: middlegame, endgame, puzzle).", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(players, key = { it.name }) { p ->
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        PlayerAvatar(p.name, false, 42.dp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.Bold)
                            Text(
                                "${p.games} lalao (Fotsy ${p.asWhite} / Mainty ${p.asBlack})" + (p.tagElo?.let { " - Elo PGN $it" } ?: ""),
                                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Button({ vm.analyzePgnPlayer(p.name) }, enabled = !busy) { Text("Bot") }
                    }
                }
            }
        }
        if (vm.pgnGames.isNotEmpty()) {
            item { Text("Jereo ny lalao ao amin'ny PGN:", fontWeight = FontWeight.Bold) }
            itemsIndexed(vm.pgnGames) { i, g ->
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${i + 1}. ${g.white} - ${g.black}", fontWeight = FontWeight.Bold, maxLines = 1)
                            Text(
                                g.result + " · hetsika ${(g.moves.size + 1) / 2}" + (if (g.fromPosition) " · toerana FEN" else "") + (if (g.event.isNotBlank()) " · ${g.event}" else ""),
                                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1
                            )
                        }
                        OutlinedButton({ vm.viewPgnGame(g) }, enabled = !busy) { Text("Jereo") }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
private fun PgnDraftDialog(d: PgnBotDraft, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var name by remember(d) { mutableStateOf(d.player.take(20)) }
    var eloText by remember(d) { mutableStateOf(d.elo.toString()) }
    var avatar by remember(d) { mutableStateOf<Bitmap?>(null) }
    var created by remember(d) { mutableStateOf(false) }
    val elo = eloText.toIntOrNull()
    val valid = name.isNotBlank() && elo != null && elo in 100..3200
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) avatar = decodeAvatar(ctx, uri)
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Bot vaovao: ${d.player}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    val a = avatar
                    if (a != null) Image(a.asImageBitmap(), null, Modifier.size(64.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                    else PlayerAvatar(name, false, 64.dp)
                    OutlinedButton({ picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text("Sary") }
                }
                OutlinedTextField(name, { name = it.take(20) }, label = { Text("Anarana") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    eloText, { eloText = it.filter { c -> c.isDigit() }.take(4) },
                    label = { Text("Elo") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "Game rating ~${d.gameRating}" + (d.tagElo?.let { ", Elo PGN $it" } ?: "") +
                        " - accuracy ${"%.1f".format(d.accuracy)}% (${d.games} lalao)", fontSize = 12.sp
                )
                if (elo != null) {
                    val t = tierOf(elo)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Sokajy:", fontSize = 13.sp); TierChip(t)
                    }
                }
                val ops = d.openings.mapNotNull { OPENING_MAP[it]?.name }
                Text("Opening: " + (if (ops.isEmpty()) (if (d.fromPosition) "tsy ampiasaina (lalao manomboka antenatenany) - ny Elo sy ny fomba ihany no raisina" else "andalana nilalaovana ihany") else ops.joinToString(", ")), fontSize = 13.sp)
                val tags = d.style.describe()
                Text("Fomba: " + (if (tags.isEmpty()) "mahazatra" else tags.joinToString(", ")), fontSize = 13.sp)
                if (created) Text("Voaforona ny bot! Hita ao amin'ny lisitry ny bot.", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
        },
        confirmButton = {
            Button(
                {
                    BotRegistry.save(ctx, null, name, elo ?: d.elo, avatar, d.openings, d.lines, d.style)
                    created = true
                },
                enabled = valid && !created
            ) { Text("Forony") }
        },
        dismissButton = { TextButton(onDismiss) { Text(if (created) "Vita" else "Foano") } }
    )
}
