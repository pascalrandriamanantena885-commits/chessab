# KAJY
Kotlin + Compose, chesslib, **Stockfish 17.1** (UCI, NDK, NNUE). Push amin'ny GitHub -> Actions -> Artifacts -> APK.
Stockfish: GPLv3 -> ampiasao ho open source ny app.

## Elo tena izy
- Bot 1320-3190: `UCI_LimitStrength` + `UCI_Elo` (fetra ofisialy an'ny Stockfish 17.1).
- Bot > 3190: hery feno.
- Bot < 1320: fikarohana voafetra (nodes) + safidy hetsika araka ny temperature (Engine.kt).
- Fanitsiana: `ELO_CALIB` ao amin'ny Bots.kt (0 = mivantana).
- Review / game rating: Stockfish feno hery, depth 12/16/20 (Settings), MultiPV 2, expected-points (win%).

## Sprites
Pieces + board tiles: "Cburnett Chess set" (JohnPablok remaster v2), ao amin'ny app/src/main/assets/.
Credit: Colin M.L. Burnett (Cburnett) / JohnPablok - GPLv2+ / CC BY-SA 3.0.
Avatar bot: apetaho ao amin'ny app/src/main/assets/bots/<id>.png. Raha tsy misy dia fallback no miseho.

## Fiasa
- Nav 4 (icon): Play, Fifaninanana, Tantaran'ny lalao, Settings.
- Settings: sary aloha (background) avy ao amin'ny gallerie, theme, depth review, fampidirana / fanovana / famafana bot (sary avy ao amin'ny gallerie).
- Fifaninanana: bot vs bot, olona + bot; poule -> 8ème de finale -> finale; live; review.
