package mg.chess.offline

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class TimeControl(val label: String, val baseMin: Int, val incSec: Int)

val TIME_CONTROLS = listOf(
    TimeControl("Tsy misy", 0, 0),
    TimeControl("1+0", 1, 0),
    TimeControl("3+0", 3, 0),
    TimeControl("3+2", 3, 2),
    TimeControl("5+0", 5, 0),
    TimeControl("10+0", 10, 0),
    TimeControl("15+10", 15, 10),
)

data class GameRecord(
    val id: Long,
    val botId: String?,
    val humanWhite: Boolean,
    val baseMs: Long,
    val incMs: Long,
    val moves: List<String>,
    val whiteMs: Long,
    val blackMs: Long,
    val result: String?,   // null = mbola mitohy
    val updated: Long
)

/** Fitehirizana lalao: rakitra JSON iray isaky ny lalao ao amin'ny filesDir/games. */
class GameStore(ctx: Context) {
    private val dir = File(ctx.filesDir, "games").apply { mkdirs() }

    fun save(r: GameRecord) {
        try {
            val o = JSONObject()
            o.put("id", r.id)
            if (r.botId != null) o.put("botId", r.botId)
            o.put("humanWhite", r.humanWhite)
            o.put("baseMs", r.baseMs)
            o.put("incMs", r.incMs)
            o.put("moves", JSONArray(r.moves))
            o.put("whiteMs", r.whiteMs)
            o.put("blackMs", r.blackMs)
            if (r.result != null) o.put("result", r.result)
            o.put("updated", r.updated)
            val tmp = File(dir, "${r.id}.tmp")
            tmp.writeText(o.toString())
            tmp.renameTo(File(dir, "${r.id}.json"))
        } catch (e: Exception) { /* tsy mandika ny lalao */ }
    }

    fun list(): List<GameRecord> =
        (dir.listFiles { f -> f.name.endsWith(".json") } ?: emptyArray())
            .mapNotNull { parse(it) }
            .sortedByDescending { it.updated }

    fun delete(id: Long) { File(dir, "$id.json").delete() }

    private fun parse(f: File): GameRecord? = try {
        val o = JSONObject(f.readText())
        val arr = o.getJSONArray("moves")
        GameRecord(
            o.getLong("id"),
            if (o.has("botId")) o.getString("botId") else null,
            o.getBoolean("humanWhite"),
            o.getLong("baseMs"), o.getLong("incMs"),
            List(arr.length()) { arr.getString(it) },
            o.getLong("whiteMs"), o.getLong("blackMs"),
            if (o.has("result")) o.getString("result") else null,
            o.optLong("updated", o.getLong("id"))
        )
    } catch (e: Exception) { null }
}
