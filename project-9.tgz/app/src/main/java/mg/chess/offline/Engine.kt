package mg.chess.offline

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import kotlin.math.exp
import kotlin.random.Random

/** Isan'ny line analyse: score (cp na mate) araka ny fijerin'ny mpilalao mihetsika, ary ny hetsika voalohany. */
data class Line(val cp: Int?, val mate: Int?, val move: String)

class Engine(private val ctx: Context) {
    private var proc: Process? = null
    private var out: OutputStreamWriter? = null
    private var inp: BufferedReader? = null
    private val mutex = Mutex()

    private fun send(s: String) { out?.write(s + "\n"); out?.flush() }

    private fun waitFor(token: String) {
        while (true) {
            val l = inp?.readLine() ?: return
            if (l.startsWith(token)) return
        }
    }

    private fun ensureStarted(): Boolean {
        if (proc?.isAlive == true) return true
        val f = File(ctx.applicationInfo.nativeLibraryDir, "libstockfish.so")
        if (!f.exists()) return false
        proc = ProcessBuilder(f.absolutePath).redirectErrorStream(true).start()
        out = OutputStreamWriter(proc!!.outputStream)
        inp = BufferedReader(InputStreamReader(proc!!.inputStream))
        send("uci"); waitFor("uciok")
        val threads = (Runtime.getRuntime().availableProcessors() / 2).coerceIn(1, 4)
        send("setoption name Threads value $threads")
        send("setoption name Hash value 128")
        send("isready"); waitFor("readyok")
        return true
    }

    private suspend fun search(go: String, onInfo: (String) -> Unit): String? = withContext(Dispatchers.IO) {
        send(go)
        var result: String? = null
        try {
            var done = false
            while (!done) {
                val l = inp?.readLine()
                if (l == null) {
                    done = true
                } else if (l.startsWith("bestmove")) {
                    val m = l.split(" ").getOrNull(1)
                    result = if (m == null || m == "(none)") null else m
                    done = true
                } else {
                    onInfo(l)
                    ensureActive()
                }
            }
        } catch (e: CancellationException) {
            send("stop")
            var d = false
            while (!d) {
                val l = inp?.readLine()
                if (l == null || l.startsWith("bestmove")) d = true
            }
            throw e
        }
        result
    }

    fun newGame() {
        try { if (proc?.isAlive == true) send("ucinewgame") } catch (_: Exception) {}
    }

    /**
     * Hetsika ho an'ny bot araka ny Elo tena izy.
     * - 1320..3190 : Stockfish 17.1 UCI_LimitStrength + UCI_Elo (fetra ofisialy, voakajy amin'ny CCRL)
     * - > 3190     : hery feno
     * - < 1320     : fikarohana voafetra (nodes) + safidy hetsika araka ny "temperature" (mitovy amin'ny olona mikorontana)
     */
    suspend fun bestMove(fen: String, bot: Bot): String? = mutex.withLock {
        try {
            val elo = bot.elo + ELO_CALIB
            val weak = elo < SF_MIN_ELO
            val ok = withContext(Dispatchers.IO) {
                if (ensureStarted()) {
                    when {
                        elo in SF_MIN_ELO..SF_MAX_ELO -> {
                            send("setoption name UCI_LimitStrength value true")
                            send("setoption name UCI_Elo value $elo")
                            send("setoption name MultiPV value 1")
                        }
                        elo > SF_MAX_ELO -> {
                            send("setoption name UCI_LimitStrength value false")
                            send("setoption name MultiPV value 1")
                        }
                        else -> {
                            send("setoption name UCI_LimitStrength value false")
                            send("setoption name MultiPV value 8")
                        }
                    }
                    send("position fen $fen")
                    true
                } else false
            }
            if (!ok) null
            else if (!weak) {
                search("go movetime ${bot.movetimeMs}") { }
            } else {
                val nodes = (30.0 * Math.pow(elo.coerceAtLeast(100) / 100.0, 1.7)).toLong().coerceAtLeast(150L)
                val lines = HashMap<Int, Line>()
                val best = search("go nodes $nodes") { l ->
                    val p = parseInfo(l)
                    if (p != null) lines[p.first] = p.second
                }
                pickWeak(lines.toSortedMap().values.toList(), elo, best)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }

    private fun pickWeak(lines: List<Line>, elo: Int, fallback: String?): String? {
        val ls = lines.filter { it.move.isNotEmpty() }
        if (ls.isEmpty()) return fallback
        val deficit = (SF_MIN_ELO - elo).coerceIn(0, 1220)
        val cps = ls.map { it.stmCp().coerceIn(-1500, 1500) }
        val top = cps.max()
        val temp = 15.0 + deficit * 0.22
        val pRandom = (deficit / 1220.0).let { it * it * 0.30 }
        if (Random.nextDouble() < pRandom) return ls.random().move
        val ws = cps.map { exp((it - top) / temp) }
        var r = Random.nextDouble() * ws.sum()
        for ((i, w) in ws.withIndex()) {
            r -= w
            if (r <= 0.0) return ls[i].move
        }
        return ls.first().move
    }

    /** Analyse feno hery (tsy voafetra) miaraka amin'ny MultiPV, mijanona amin'ny depth na fotoana farany. */
    suspend fun analyze(fen: String, depth: Int, maxMs: Int, multiPv: Int = 2): List<Line> = mutex.withLock {
        try {
            val ok = withContext(Dispatchers.IO) {
                if (ensureStarted()) {
                    send("setoption name UCI_LimitStrength value false")
                    send("setoption name MultiPV value $multiPv")
                    send("position fen $fen")
                    true
                } else false
            }
            if (!ok) emptyList()
            else {
                val lines = HashMap<Int, Line>()
                search("go depth $depth movetime $maxMs") { l ->
                    val p = parseInfo(l)
                    if (p != null) lines[p.first] = p.second
                }
                lines.toSortedMap().values.toList()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun parseInfo(l: String): Pair<Int, Line>? {
        if (!l.startsWith("info") || " score " !in l || " pv " !in l) return null
        if (" lowerbound" in l || " upperbound" in l) return null
        val t = l.split(" ")
        val mi = t.indexOf("multipv")
        val mpv = if (mi >= 0) (t.getOrNull(mi + 1)?.toIntOrNull() ?: 1) else 1
        val si = t.indexOf("score")
        val kind = t.getOrNull(si + 1) ?: return null
        val v = t.getOrNull(si + 2)?.toIntOrNull() ?: return null
        val pi = t.indexOf("pv")
        val mv = t.getOrNull(pi + 1) ?: return null
        return mpv to Line(if (kind == "cp") v else null, if (kind == "mate") v else null, mv)
    }

    fun stop() {
        try { send("quit") } catch (_: Exception) {}
        proc?.destroy(); proc = null
    }
}
