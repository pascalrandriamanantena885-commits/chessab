package mg.chess.offline

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.PieceType
import com.github.bhlangonijr.chesslib.Rank
import com.github.bhlangonijr.chesslib.Side
import com.github.bhlangonijr.chesslib.Square

private fun pieceLetter(p: Piece): String = when (p.pieceType) {
    PieceType.KING -> "k"
    PieceType.QUEEN -> "q"
    PieceType.ROOK -> "r"
    PieceType.BISHOP -> "b"
    PieceType.KNIGHT -> "n"
    else -> "p"
}

private fun pieceKey(p: Piece) = (if (p.pieceSide == Side.WHITE) "w" else "b") + pieceLetter(p)

private fun glyph(p: Piece): String = when (p.pieceType) {
    PieceType.KING -> "♚"
    PieceType.QUEEN -> "♛"
    PieceType.ROOK -> "♜"
    PieceType.BISHOP -> "♝"
    PieceType.KNIGHT -> "♞"
    else -> "♟"
} + "\uFE0E"

@Composable
fun BoardView(
    pieceAt: (Square) -> Piece,
    flip: Boolean,
    modifier: Modifier = Modifier,
    selected: Square? = null,
    targets: List<Square> = emptyList(),
    last: Pair<Square, Square>? = null,
    hint: Pair<Square, Square>? = null,
    onSquare: ((Square) -> Unit)? = null,
) {
    val boardImg = Sprites.board
    BoxWithConstraints(modifier.fillMaxWidth().aspectRatio(1f)) {
        val cell = maxWidth / 8
        if (boardImg != null) {
            Image(boardImg, null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
        }
        Column {
            for (r in 0..7) Row {
                for (f in 0..7) {
                    val rank = if (flip) r else 7 - r
                    val file = if (flip) 7 - f else f
                    val sq = Square.encode(Rank.allRanks[rank], com.github.bhlangonijr.chesslib.File.allFiles[file])
                    val dark = (rank + file) % 2 == 0
                    val tile = if (dark) Sprites.dark else Sprites.light
                    val bg = when {
                        boardImg != null || tile != null -> Color.Transparent
                        dark -> Color(0xFF769656)
                        else -> Color(0xFFEEEED2)
                    }
                    Box(
                        Modifier.size(cell).background(bg)
                            .clickable(enabled = onSquare != null) { onSquare?.invoke(sq) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (boardImg == null && tile != null) {
                            Image(tile, null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                        }
                        if (sq == selected) {
                            Box(Modifier.fillMaxSize().background(Color(0x99F6F669)))
                        } else if (last != null && (sq == last.first || sq == last.second)) {
                            Box(Modifier.fillMaxSize().background(Color(0x66F6F669)))
                        }
                        if (hint != null && (sq == hint.first || sq == hint.second)) {
                            Box(Modifier.fillMaxSize().background(Color(0x6600A0FF)))
                        }
                        val p = pieceAt(sq)
                        if (p != Piece.NONE) PieceIcon(p, cell * 0.92f)
                        if (sq in targets) {
                            Box(Modifier.size(cell / 3).clip(CircleShape).background(Color(0x88000000)))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PieceIcon(p: Piece, size: Dp) {
    val bmp = Sprites.pieces[pieceKey(p)]
    if (bmp != null) {
        Image(bmp, null, Modifier.size(size), contentScale = ContentScale.Fit)
    } else {
        val white = p.pieceSide == Side.WHITE
        Text(
            glyph(p), fontSize = (size.value * 0.85f).sp,
            color = if (white) Color.White else Color.Black,
            style = TextStyle(shadow = Shadow(if (white) Color.Black else Color.White, Offset(0f, 0f), 6f))
        )
    }
}
