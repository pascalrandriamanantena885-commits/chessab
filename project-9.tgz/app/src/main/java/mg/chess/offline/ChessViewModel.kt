package mg.chess.offline

import android.app.Application
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.PieceType
import com.github.bhlangonijr.chesslib.Side
import com.github.bhlangonijr.chesslib.Square
import com.github.bhlangonijr.chesslib.move.Move
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min

enum class Screen { MENU, BOTS, GAME, REVIEW, HISTORY, SETTINGS, TOUR_LIST, TOUR_NEW, TOURNAMENT, WATCH }

/** Lalao bot vs bot mandeha (simulation) - azo arahina live. */
class SimState(val matchId: Int, val board: Board, w: Long, b: Long) {
    var version by mutableIntStateOf(0)
    var whiteMs by mutableLongStateOf(w)
    var blackMs by mutableLongStateOf(b)
    var thinkStart by mutableLongStateOf(0L)
    var thinkingWhite by mutableStateOf(true)
    var last by mutableStateOf<Pair<Square, Square>?>(null)
    var plies by mutableIntStateOf(0)
    var result by mutableStateOf<String?>(null)
}

private val PROMO_ORDER = listOf(PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT)

class ChessViewModel(app: Application) : AndroidViewModel(app) {
    private val engine = Engine(app)
    private val store = GameStore(app)
    private val tourStore = TournamentStore(app)
    private val prefs = app.getSharedPreferences("chess_prefs", 0)

    // Settings
    var darkMode by mutableStateOf(true); private set
    /** Halalin'ny fanadihadiana (Stockfish depth): 12 haingana, 16 antonony, 20 lalina. */
    var reviewDepth by mutableIntStateOf(16); private set

    // Fifaninanana
    var tournaments by mutableStateOf<List<Tournament>>(emptyList()); private set
    var tour by mutableStateOf<Tournament?>(null); private set
    var tourVersion by mutableIntStateOf(0); private set
    var tourMatch by mutableStateOf<TMatch?>(null); private set
    var sim by mutableStateOf<SimState?>(null); private set
    var watchId by mutableIntStateOf(-1)
    var watchDelay by mutableLongStateOf(600L)
    var simRunningId by mutableIntStateOf(-1); private set
    var autoMode by mutableStateOf(false); private set
    private val simQueue = ArrayDeque<Int>()
    private var simJob: Job? = null
    private var reviewReturn = Screen.GAME

    var board = Board(); private set
    var version by mutableIntStateOf(0); private set
    var screen by mutableStateOf(Screen.MENU)
    var bot by mutableStateOf<Bot?>(null); private set
    var vsBot by mutableStateOf(false); private set
    var humanWhite by mutableStateOf(true); private set
    var selected by mutableStateOf<Square?>(null)
    var thinking by mutableStateOf(false); private set
    var message by mutableStateOf("")
    var over by mutableStateOf(false); private set
    val played = mutableStateListOf<Move>()

    // Promotion
    var promoMoves by mutableStateOf<List<Move>?>(null); private set

    // Clock
    var tc by mutableStateOf(TIME_CONTROLS[0])
    var clockOn by mutableStateOf(false); private set
    var whiteMs by mutableLongStateOf(0L); private set
    var blackMs by mutableLongStateOf(0L); private set
    private var baseMs = 0L
    private var incMs = 0L
    private var flagged: Side? = null
    private var paused = false
    private var tickJob: Job? = null

    // Fitehirizana
    var saved by mutableStateOf<List<GameRecord>>(emptyList()); private set
    private var gameId = 0L
    private var result: String? = null

    // Review
    var review by mutableStateOf<ReviewResult?>(null); private set
    var reviewProgress by mutableStateOf(0f); private set
    var reviewError by mutableStateOf<String?>(null); private set
    var reviewPly by mutableIntStateOf(0)

    private var botJob: Job? = null
    private var reviewJob: Job? = null

    init {
        BotRegistry.load(app)
        saved = store.list()
        tournaments = tourStore.list()
        darkMode = prefs.getBoolean("dark", true)
        reviewDepth = prefs.getInt("review_depth", 16)
    }

    fun setDark(b: Boolean) { darkMode = b; prefs.edit().putBoolean("dark", b).apply() }
    fun setReviewDepth(d: Int) { reviewDepth = d; prefs.edit().putInt("review_depth", d).apply() }
    fun toSettings() { screen = Screen.SETTINGS }

    /** Bouton nav: 0 play, 1 competition, 2 game history, 3 settings. */
    fun goTab(i: Int) {
        when (i) {
            0 -> if (screen != Screen.MENU) { botJob?.cancel(); screen = Screen.MENU }
            1 -> if (tabOf(screen) != 1) toTourList()
            2 -> toHistory()
            3 -> screen = Screen.SETTINGS
        }
    }

    // ---------- Fanombohana lalao ----------
    fun startHumanGame() = startGame(null, true)
    fun startBotGame(b: Bot, white: Boolean) = startGame(b, white)
    fun restart() {
        if (tourMatch != null) return
        TIME_CONTROLS.firstOrNull { it.baseMin * 60_000L == baseMs && it.incSec * 1000L == incMs }?.let { tc = it }
        startGame(bot, humanWhite)
    }
    fun toBots() { screen = Screen.BOTS }
    fun toHistory() { saved = store.list(); screen = Screen.HISTORY }

    private fun startGame(b: Bot?, white: Boolean) {
        botJob?.cancel(); reviewJob?.cancel()
        engine.newGame()
        board = Board()
        tourMatch = null
        played.clear(); review = null; reviewError = null; promoMoves = null
        bot = b; vsBot = b != null; humanWhite = white
        selected = null; thinking = false; flagged = null
        gameId = System.currentTimeMillis()
        baseMs = tc.baseMin * 60_000L; incMs = tc.incSec * 1000L
        clockOn = baseMs > 0; whiteMs = baseMs; blackMs = baseMs
        screen = Screen.GAME
        refresh(); startTicker()
        if (vsBot && !humanWhite) botMove()
    }

    fun loadGame(rec: GameRecord, thenReview: Boolean = false) {
        botJob?.cancel(); reviewJob?.cancel()
        val b = Board()
        val list = ArrayList<Move>()
        for (u in rec.moves) {
            val m = b.legalMoves().firstOrNull { it.toString().equals(u, true) } ?: break
            b.doMove(m); list.add(m)
        }
        board = b
        played.clear(); played.addAll(list)
        review = null; reviewError = null; promoMoves = null
        gameId = rec.id
        tourMatch = null
        bot = BotRegistry.find(rec.botId)
        vsBot = bot != null; humanWhite = rec.humanWhite
        baseMs = rec.baseMs; incMs = rec.incMs
        clockOn = baseMs > 0; whiteMs = rec.whiteMs; blackMs = rec.blackMs
        flagged = when {
            clockOn && whiteMs <= 0L -> Side.WHITE
            clockOn && blackMs <= 0L -> Side.BLACK
            else -> null
        }
        selected = null; thinking = false
        screen = Screen.GAME
        refresh(); startTicker()
        if (thenReview) startReview()
        else if (vsBot && !humanTurn() && !over) botMove()
    }

    fun deleteGame(id: Long) { store.delete(id); saved = store.list() }

    fun saveGame() {
        if (played.isEmpty() || gameId == 0L) return
        store.save(
            GameRecord(
                gameId, bot?.id, humanWhite, baseMs, incMs,
                played.map { it.toString() }, whiteMs, blackMs, result, System.currentTimeMillis()
            )
        )
        saved = store.list()
    }

    fun toMenu() {
        botJob?.cancel(); reviewJob?.cancel()
        thinking = false
        if (tourMatch != null) {
            tourMatch = null
            tourVersion++
            screen = Screen.TOURNAMENT
            return
        }
        saveGame()
        screen = Screen.MENU
    }

    // ---------- Clock ----------
    fun setPaused(p: Boolean) { paused = p }

    private fun startTicker() {
        tickJob?.cancel()
        if (!clockOn) return
        var last = SystemClock.elapsedRealtime()
        tickJob = viewModelScope.launch {
            while (true) {
                delay(100)
                val now = SystemClock.elapsedRealtime()
                val dt = now - last
                last = now
                if (paused || screen != Screen.GAME || played.isEmpty() || over) continue
                if (board.sideToMove == Side.WHITE) {
                    whiteMs = max(0L, whiteMs - dt)
                    if (whiteMs == 0L) flag(Side.WHITE)
                } else {
                    blackMs = max(0L, blackMs - dt)
                    if (blackMs == 0L) flag(Side.BLACK)
                }
            }
        }
    }

    private fun flag(s: Side) {
        flagged = s
        refresh()
        saveGame()
        syncTour()
    }

    // ---------- Lalao ----------
    private fun humanTurn() = !vsBot || (board.sideToMove == Side.WHITE) == humanWhite

    fun legalFrom(sq: Square): List<Move> = board.legalMoves().filter { it.from == sq }

    fun onSquare(sq: Square) {
        if (thinking || over || promoMoves != null || !humanTurn()) return
        val sel = selected
        val piece = board.getPiece(sq)
        val own = piece != Piece.NONE && piece.pieceSide == board.sideToMove
        if (sel == null || own) {
            selected = if (own) sq else null
            return
        }
        val cands = legalFrom(sel).filter { it.to == sq }
        if (cands.isEmpty()) { selected = null; return }
        val promos = cands.filter { it.promotion != Piece.NONE }
        if (promos.isNotEmpty()) {
            promoMoves = promos.sortedBy { PROMO_ORDER.indexOf(it.promotion.pieceType) }
            return
        }
        selected = null
        applyMove(cands[0])
        if (vsBot && !over) botMove()
    }

    fun choosePromotion(m: Move) {
        promoMoves = null
        applyMove(m)
        if (vsBot && !over) botMove()
    }

    fun cancelPromotion() { promoMoves = null; selected = null }

    private fun applyMove(mv: Move) {
        val mover = board.sideToMove
        board.doMove(mv)
        played.add(mv)
        if (clockOn) {
            if (mover == Side.WHITE) whiteMs += incMs else blackMs += incMs
        }
        selected = null
        refresh()
        saveGame()
        syncTour()
    }

    private fun botMove() {
        val b = bot ?: return
        thinking = true
        botJob?.cancel()
        botJob = viewModelScope.launch {
            val remaining = if (board.sideToMove == Side.WHITE) whiteMs else blackMs
            val mt = if (clockOn) min(b.movetimeMs.toLong(), max(50L, remaining / 25)).toInt() else b.movetimeMs
            val uci = engine.bestMove(board.fen, b.copy(movetimeMs = mt))
            thinking = false
            if (over) return@launch
            val mv = board.legalMoves().firstOrNull { it.toString().equals(uci, true) }
            if (mv != null) applyMove(mv) else message = "Stockfish tsy namaly"
        }
    }

    fun undo() {
        if (tourMatch != null) return
        if (thinking || played.isEmpty() || flagged != null) return
        board.undoMove(); played.removeAt(played.lastIndex)
        if (vsBot && !humanTurn() && played.isNotEmpty()) {
            board.undoMove(); played.removeAt(played.lastIndex)
        }
        selected = null; promoMoves = null
        refresh()
        saveGame()
        if (vsBot && !humanTurn() && !over) botMove()
    }

    private fun refresh() {
        val noMoves = board.legalMoves().isEmpty()
        val mated = board.isMated
        val draw = !mated && (board.isDraw || noMoves)
        val f = flagged
        result = when {
            f == Side.WHITE -> "0-1"
            f == Side.BLACK -> "1-0"
            mated -> if (board.sideToMove == Side.WHITE) "0-1" else "1-0"
            draw -> "1/2-1/2"
            else -> null
        }
        over = result != null
        message = when {
            f != null -> "Lany ora ny " + (if (f == Side.WHITE) "Fotsy" else "Mainty") + " - " +
                (if (f == Side.WHITE) "Mainty" else "Fotsy") + " no nahazo"
            mated -> "Checkmate! " + (if (board.sideToMove == Side.WHITE) "Mainty" else "Fotsy") + " no nahazo"
            draw -> "Draw"
            board.isKingAttacked -> "Check!"
            else -> ""
        }
        version++
    }

    // ---------- Review / Analyse ----------
    fun startReview() {
        if (played.isEmpty()) return
        botJob?.cancel(); reviewJob?.cancel()
        thinking = false
        screen = Screen.REVIEW
        review = null; reviewError = null; reviewProgress = 0f
        val moves = played.toList()
        reviewJob = viewModelScope.launch {
            try {
                val r = runReview(engine, START_FEN, moves, reviewDepth) { i, n -> reviewProgress = i.toFloat() / n }
                review = r
                reviewPly = moves.size
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                reviewError = e.message ?: "Hadisoana"
            }
        }
    }

    fun leaveReview() {
        reviewJob?.cancel()
        if (reviewReturn == Screen.TOURNAMENT) {
            reviewReturn = Screen.GAME
            screen = Screen.TOURNAMENT
            return
        }
        screen = Screen.GAME
        if (vsBot && !humanTurn() && !over && !thinking) botMove()
    }

    override fun onCleared() { saveGame(); simJob?.cancel(); engine.stop() }

    // ================= FIFANINANANA =================

    fun toTourList() {
        botJob?.cancel()
        tourMatch = null
        screen = Screen.TOUR_LIST
    }
    fun toTourNew() { screen = Screen.TOUR_NEW }

    fun openTour(t: Tournament) {
        if (tour?.id != t.id) stopSim()
        tour = t; tourVersion++
        screen = Screen.TOURNAMENT
    }

    fun deleteTour(t: Tournament) {
        if (tour?.id == t.id) { stopSim(); tour = null }
        tourStore.delete(t.id)
        tournaments = tournaments.filter { it.id != t.id }
    }

    fun createTour(name: String, players: List<Participant>, baseMs: Long, incMs: Long, wantGroups: Boolean) {
        stopSim()
        val t = Tournament.create(System.currentTimeMillis(), name, players, baseMs, incMs, wantGroups)
        tourStore.save(t)
        tournaments = listOf(t) + tournaments
        openTour(t)
    }

    private fun tourSave() {
        val t = tour ?: return
        t.updated = System.currentTimeMillis()
        tourStore.save(t)
        tourVersion++
    }

    fun isBotMatch(m: TMatch): Boolean {
        val t = tour ?: return false
        return t.player(m.whiteId)?.bot != null && t.player(m.blackId)?.bot != null
    }

    fun tourPlayer(side: Side): Participant? {
        val m = tourMatch ?: return null
        return tour?.player(if (side == Side.WHITE) m.whiteId else m.blackId)
    }

    fun advanceTour() {
        val t = tour ?: return
        if (t.advance()) tourSave()
    }

    // ---------- Lalao olona ao anaty fifaninanana ----------
    fun playTourMatch(m: TMatch) {
        val t = tour ?: return
        if (m.result != null) return
        val wp = t.player(m.whiteId) ?: return
        val bp = t.player(m.blackId) ?: return
        if (wp.bot != null && bp.bot != null) return
        botJob?.cancel(); reviewJob?.cancel()
        val b = Board()
        played.clear()
        for (u in m.moves) {
            val mv = b.legalMoves().firstOrNull { it.toString().equals(u, true) } ?: break
            b.doMove(mv); played.add(mv)
        }
        board = b
        review = null; reviewError = null; promoMoves = null
        tourMatch = m
        bot = wp.bot ?: bp.bot
        vsBot = bot != null
        humanWhite = wp.bot == null
        baseMs = t.baseMs; incMs = t.incMs
        clockOn = baseMs > 0
        whiteMs = if (played.isEmpty()) baseMs else m.whiteMs
        blackMs = if (played.isEmpty()) baseMs else m.blackMs
        flagged = when {
            clockOn && played.isNotEmpty() && whiteMs <= 0L -> Side.WHITE
            clockOn && played.isNotEmpty() && blackMs <= 0L -> Side.BLACK
            else -> null
        }
        result = null
        selected = null; thinking = false
        gameId = 0L
        reviewReturn = Screen.GAME
        screen = Screen.GAME
        refresh(); startTicker()
        syncTour()
        if (vsBot && !humanTurn() && !over) botMove()
    }

    private fun syncTour() {
        val m = tourMatch ?: return
        val t = tour ?: return
        m.moves = played.map { it.toString() }
        m.whiteMs = whiteMs; m.blackMs = blackMs
        val r = result
        if (over && r != null && m.result == null) t.recordResult(m, r)
        tourSave()
    }

    // ---------- Simulation bot vs bot ----------
    private fun queuePending(t: Tournament) {
        for (m in t.stageMatches()) {
            if (m.result == null && isBotMatch(m) && m.id != simRunningId && m.id !in simQueue) simQueue.addLast(m.id)
        }
    }

    fun simOne(m: TMatch, watch: Boolean) {
        if (m.result != null || !isBotMatch(m)) return
        if (m.id != simRunningId) { simQueue.remove(m.id); simQueue.addFirst(m.id) }
        if (watch) { watchId = m.id; screen = Screen.WATCH }
        ensureSimLoop()
    }

    fun simAllPending() {
        val t = tour ?: return
        queuePending(t)
        ensureSimLoop()
    }

    fun runAuto() {
        val t = tour ?: return
        autoMode = true
        queuePending(t)
        ensureSimLoop()
    }

    fun stopSim() {
        simQueue.clear()
        autoMode = false
        simJob?.cancel()
        simRunningId = -1
        tourSave()
    }

    fun leaveWatch() { screen = Screen.TOURNAMENT }

    private fun ensureSimLoop() {
        if (simJob?.isActive == true) return
        simJob = viewModelScope.launch {
            try {
                while (true) {
                    val t = tour ?: break
                    if (simQueue.isEmpty()) {
                        if (!autoMode) break
                        if (t.champion != null) break
                        if (t.stageComplete()) { t.advance(); tourSave() }
                        if (t.champion != null) break
                        queuePending(t)
                        if (simQueue.isEmpty()) break
                    }
                    val id = simQueue.removeFirst()
                    val m = t.matches.firstOrNull { it.id == id } ?: continue
                    if (m.result != null) continue
                    simRunningId = id
                    try {
                        runSim(t, m)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        tourMsg = "Hadisoana: " + (e.message ?: "")
                    }
                    simRunningId = -1
                }
            } finally {
                simRunningId = -1
                autoMode = false
            }
        }
    }

    var tourMsg by mutableStateOf("")

    private suspend fun runSim(t: Tournament, m: TMatch) {
        val wb = t.player(m.whiteId)?.bot ?: return
        val bb = t.player(m.blackId)?.bot ?: return
        val b = Board()
        val moves = ArrayList<String>()
        for (u in m.moves) {
            val mv = b.legalMoves().firstOrNull { it.toString().equals(u, true) } ?: break
            b.doMove(mv); moves.add(u)
        }
        val clock = t.baseMs > 0
        var wMs = if (moves.isEmpty() || !clock) t.baseMs else m.whiteMs
        var bMs = if (moves.isEmpty() || !clock) t.baseMs else m.blackMs
        val st = SimState(m.id, b, wMs, bMs)
        st.plies = moves.size
        sim = st
        var res: String? = null
        while (res == null) {
            res = gameResult(b)
            if (res != null) break
            if (moves.size >= 500) { res = "1/2-1/2"; break }
            val white = b.sideToMove == Side.WHITE
            val pb = if (white) wb else bb
            val remaining = if (white) wMs else bMs
            val mt = if (clock) min(pb.movetimeMs.toLong(), max(50L, remaining / 25)).toInt() else pb.movetimeMs
            val t0 = SystemClock.elapsedRealtime()
            st.thinkingWhite = white
            st.thinkStart = t0
            val uci = engine.bestMove(b.fen, pb.copy(movetimeMs = mt))
            val spent = SystemClock.elapsedRealtime() - t0
            st.thinkStart = 0L
            if (clock) {
                if (white) wMs = max(0L, wMs - spent) else bMs = max(0L, bMs - spent)
                if ((white && wMs <= 0L) || (!white && bMs <= 0L)) {
                    st.whiteMs = wMs; st.blackMs = bMs
                    res = if (white) "0-1" else "1-0"
                    break
                }
            }
            val legal = b.legalMoves()
            val mv = legal.firstOrNull { it.toString().equals(uci, true) } ?: legal.random()
            b.doMove(mv)
            moves.add(mv.toString())
            if (clock) { if (white) wMs += t.incMs else bMs += t.incMs }
            st.whiteMs = wMs; st.blackMs = bMs
            st.last = mv.from to mv.to
            st.plies = moves.size
            st.version++
            m.moves = moves.toList(); m.whiteMs = wMs; m.blackMs = bMs
            if (moves.size % 12 == 0) tourSave()
            if (watchId == m.id && screen == Screen.WATCH) delay(watchDelay)
        }
        m.moves = moves.toList(); m.whiteMs = wMs; m.blackMs = bMs
        st.result = res
        st.version++
        t.recordResult(m, res ?: "1/2-1/2")
        tourSave()
    }

    // ---------- Review lalao fifaninanana ----------
    fun reviewTourMatch(m: TMatch) {
        if (m.moves.isEmpty()) return
        botJob?.cancel(); reviewJob?.cancel()
        val b = Board()
        val list = ArrayList<Move>()
        for (u in m.moves) {
            val mv = b.legalMoves().firstOrNull { it.toString().equals(u, true) } ?: break
            b.doMove(mv); list.add(mv)
        }
        board = b
        played.clear(); played.addAll(list)
        tourMatch = null
        bot = null; vsBot = false; humanWhite = true
        gameId = 0L
        reviewReturn = Screen.TOURNAMENT
        startReview()
    }
}
