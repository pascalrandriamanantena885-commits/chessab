package mg.chess.offline

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs

/**
 * Bot = Elo tena izy. Ny Stockfish 17.1 no mampihatra ny fetra (UCI_LimitStrength + UCI_Elo, 1320-3190).
 * Ambanin'ny 1320 dia ampiana fikarohana voafetra + safidy hetsika tsy tonga lafatra (jereo Engine.kt).
 * movetimeMs = fotoana fisainana ambony indrindra isaky ny hetsika.
 */
data class Bot(
    val id: String, val name: String, val elo: Int, val bio: String,
    val movetimeMs: Int, val color: Long,
    val custom: Boolean = false, val rev: Long = 0L
)

const val SF_MIN_ELO = 1320
const val SF_MAX_ELO = 3190

/** Fanitsiana: Elo ampiasain'ny motera = Elo bot + CALIB. 0 = mivantana araka ny kajy Stockfish (CCRL). */
const val ELO_CALIB = 0

fun movetimeForElo(elo: Int): Int = when {
    elo > SF_MAX_ELO -> 3000
    else -> (250 + elo / 2).coerceIn(300, 1500)
}

// Elo dia tena Elo ampiasain'ny Stockfish 17.1 (UCI_Elo) ary amin'ny fikarohana voafetra ho an'ny < 1320.
val BOTS = listOf(
    Bot("ravao", "Ravao", 400, "Vao mianatra milalao. Mora diso.", movetimeForElo(400), 0xFFE57373),
    Bot("rakoto", "Rakoto", 700, "Mazoto fa tsy mijery lavitra.", movetimeForElo(700), 0xFFFFB74D),
    Bot("soa", "Soa", 1000, "Milalao tsara fa mety hadino ny fandrika.", movetimeForElo(1000), 0xFFFFD54F),
    Bot("tojo", "Tojo", 1300, "Mahay tactic fohy.", movetimeForElo(1300), 0xFF81C784),
    Bot("fara", "Fara", 1600, "Mpilalao club matanjaka.", movetimeForElo(1600), 0xFF4DB6AC),
    Bot("hery", "Hery", 1900, "Mahay mijery lavitra ary tsy mora diso.", movetimeForElo(1900), 0xFF64B5F6),
    Bot("andry", "Andry", 2300, "Ambaratonga master.", movetimeForElo(2300), 0xFF9575CD),
    Bot("max", "Stockfish", 3200, "Hery feno an'ny Stockfish 17.1.", movetimeForElo(3200), 0xFF455A64),
)

private val PALETTE = listOf(
    0xFFE57373, 0xFFFFB74D, 0xFFFFD54F, 0xFF81C784, 0xFF4DB6AC,
    0xFF64B5F6, 0xFF9575CD, 0xFFF06292, 0xFFA1887F, 0xFF90A4AE
)

fun Bot.toJson(): JSONObject {
    val o = JSONObject()
    o.put("id", id); o.put("name", name); o.put("elo", elo); o.put("bio", bio)
    o.put("mt", movetimeMs)
    o.put("color", color); o.put("custom", custom); o.put("rev", rev)
    return o
}

fun botFromJson(o: JSONObject): Bot = Bot(
    o.getString("id"), o.getString("name"), o.getInt("elo"), o.optString("bio", ""),
    movetimeForElo(o.getInt("elo")), o.getLong("color"),
    o.optBoolean("custom", false), o.optLong("rev", 0L)
)

/** Sary boribory 256x256 avy amin'ny Uri (kare afovoany). */
fun decodeAvatar(ctx: Context, uri: Uri): Bitmap? {
    try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 512 && bounds.outHeight / (sample * 2) >= 512) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return null
        val side = minOf(bmp.width, bmp.height)
        val sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
        return Bitmap.createScaledBitmap(sq, 256, 256, true)
    } catch (e: Exception) {
        return null
    }
}

/** Lisitry ny bot: default (azo afenina) + ireo nataon'ny mpampiasa (tehirizina ao amin'ny filesDir). */
object BotRegistry {
    var custom by mutableStateOf<List<Bot>>(emptyList())
        private set
    var hidden by mutableStateOf<Set<String>>(emptySet())
        private set
    private var loaded = false

    val visible: List<Bot>
        get() = (BOTS.filter { it.id !in hidden } + custom).sortedBy { it.elo }

    fun find(id: String?): Bot? = if (id == null) null else (BOTS + custom).firstOrNull { it.id == id }

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        try {
            val f = File(ctx.filesDir, "custom_bots.json")
            if (f.exists()) {
                val a = JSONArray(f.readText())
                custom = List(a.length()) { botFromJson(a.getJSONObject(it)) }
            }
        } catch (e: Exception) { /* tsy mandika */ }
        val set = ctx.getSharedPreferences("chess_prefs", Context.MODE_PRIVATE).getStringSet("hidden", null)
        hidden = set?.toSet() ?: emptySet()
    }

    private fun persist(ctx: Context) {
        try {
            val a = JSONArray()
            for (b in custom) a.put(b.toJson())
            File(ctx.filesDir, "custom_bots.json").writeText(a.toString())
        } catch (e: Exception) { /* tsy mandika */ }
    }

    private fun persistHidden(ctx: Context) {
        ctx.getSharedPreferences("chess_prefs", Context.MODE_PRIVATE)
            .edit().putStringSet("hidden", hidden.toSet()).apply()
    }

    fun save(ctx: Context, existing: Bot?, name: String, elo: Int, avatar: Bitmap?) {
        val e = elo.coerceIn(100, 3200)
        val id = existing?.id ?: ("c" + System.currentTimeMillis())
        val clean = name.trim().ifEmpty { "Bot" }
        val b = Bot(
            id, clean, e, "Bot nataonao (Elo $e)", movetimeForElo(e),
            existing?.color ?: PALETTE[abs(clean.hashCode()) % PALETTE.size],
            true, System.currentTimeMillis()
        )
        if (avatar != null) {
            try {
                val dir = File(ctx.filesDir, "avatars").apply { mkdirs() }
                File(dir, "$id.png").outputStream().use { avatar.compress(Bitmap.CompressFormat.PNG, 100, it) }
            } catch (ex: Exception) { /* tsy mandika */ }
        }
        custom = if (existing != null) custom.map { if (it.id == id) b else it } else custom + b
        persist(ctx)
    }

    fun delete(ctx: Context, b: Bot) {
        if (b.custom) {
            custom = custom.filter { it.id != b.id }
            try { File(File(ctx.filesDir, "avatars"), "${b.id}.png").delete() } catch (_: Exception) {}
            persist(ctx)
        } else {
            hidden = hidden + b.id
            persistHidden(ctx)
        }
    }

    fun restoreDefaults(ctx: Context) {
        hidden = emptySet()
        persistHidden(ctx)
    }
}
