package mg.chess.offline.own;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.zip.GZIPInputStream;

/**
 * Texel tuning an'ny Eval (coordinate descent, train/validation).
 * Ampiasa: java -Xmx3g -cp cls mg.chess.offline.own.Texel <out.txt> <data1> [data2 ...]
 *   safidy (-Dname=val): groups=val,pass,w,pst  passes=6  minutes=300  threads=<cpu>  maxpos=0  step=1
 * Vokatra: tuned.txt = andalana Java azo apetaka mivantana ao amin'ny static block ao amin'ny Eval ("Lanja voatombana").
 * Data: "FEN;valiny_fotsy" (1.0/0.5/0.0). Validation = ~10% (bloc 256 toerana, ho fihanaky ny leakage amin'ny lalao iray).
 */
public class Texel {
    static byte[] bd, ks; static boolean[] blk; static float[] res; static int n;
    static int threads;
    static ExecutorService pool;
    static Eval[] evs; static Pos[] ps;
    static double c = Math.log(10) / 400.0;   // * K

    // ---------------------------------------------------------------- data
    static void load(List<String> files, int maxpos) throws IOException {
        int cap = 1 << 20;
        bd = new byte[cap * 64]; ks = new byte[cap * 2]; blk = new boolean[cap]; res = new float[cap];
        Pos p = new Pos(); n = 0; int bad = 0;
        for (String f : files) {
            InputStream in = new FileInputStream(f);
            if (f.endsWith(".gz")) in = new GZIPInputStream(in);
            try (BufferedReader br = new BufferedReader(new InputStreamReader(in))) {
                String line;
                while ((line = br.readLine()) != null) {
                    int i = line.lastIndexOf(';');
                    if (i < 0) continue;
                    float r;
                    try { r = Float.parseFloat(line.substring(i + 1).trim()); } catch (Exception e) { bad++; continue; }
                    if (!p.setFen(line.substring(0, i))) { bad++; continue; }
                    if (maxpos > 0 && n >= maxpos) break;
                    if (n == bd.length / 64) {
                        bd = Arrays.copyOf(bd, bd.length * 2); ks = Arrays.copyOf(ks, ks.length * 2);
                        blk = Arrays.copyOf(blk, blk.length * 2); res = Arrays.copyOf(res, res.length * 2);
                    }
                    for (int rr = 0; rr < 8; rr++) for (int ff = 0; ff < 8; ff++) bd[n * 64 + rr * 8 + ff] = (byte) p.b[rr * 16 + ff];
                    ks[n * 2] = (byte) p.ksq[0]; ks[n * 2 + 1] = (byte) p.ksq[1];
                    blk[n] = p.side == 1; res[n] = r; n++;
                }
            }
        }
        System.out.println("DATA toerana=" + n + " diso=" + bad);
    }

    // ---------------------------------------------------------------- erreur
    static double sig(double s, double k) { return 1.0 / (1.0 + Math.exp(-k * c * s)); }

    /** Fahadisoana salanisa: val=false -> train (i%10 != 0), true -> validation (i%10 == 0). */
    static double err(double k, boolean val) throws Exception {
        List<Future<double[]>> fs = new ArrayList<>();
        int chunk = (n + threads - 1) / threads;
        for (int t = 0; t < threads; t++) {
            final int tt = t, lo = t * chunk, hi = Math.min(n, lo + chunk);
            fs.add(pool.submit(() -> {
                Pos p = ps[tt]; Eval ev = evs[tt];
                double sum = 0; int cnt = 0;
                for (int i = lo; i < hi; i++) {
                    if ((((i >> 8) % 10) == 0) != val) continue;   // validation = blocs de 256 (tsy mitohy amin'ny lalao iray ihany)
                    for (int r = 0; r < 8; r++) for (int f = 0; f < 8; f++) p.b[r * 16 + f] = bd[i * 64 + r * 8 + f];
                    p.ksq[0] = ks[i * 2]; p.ksq[1] = ks[i * 2 + 1]; p.side = blk[i] ? 1 : 0;
                    int v = ev.evalRaw(p);
                    double w = blk[i] ? -v : v;
                    double d = res[i] - sig(w, k);
                    sum += d * d; cnt++;
                }
                return new double[]{sum, cnt};
            }));
        }
        double s = 0, m = 0;
        for (Future<double[]> f : fs) { double[] x = f.get(); s += x[0]; m += x[1]; }
        return s / Math.max(1, m);
    }

    // ---------------------------------------------------------------- parameter
    static final class Par {
        final String name, group; final int[] arr; final int idx, min, max; final boolean pst;
        Par(String name, String group, int[] arr, int idx, int min, int max, boolean pst) {
            this.name = name; this.group = group; this.arr = arr; this.idx = idx; this.min = min; this.max = max; this.pst = pst;
        }
        int get() { return arr[idx]; }
        void set(int v) { arr[idx] = v; if (pst) Eval.rebuildPst(); }
    }

    static List<Par> params(Set<String> groups) {
        List<Par> L = new ArrayList<>();
        if (groups.contains("val")) {
            for (int t = 2; t <= 5; t++) L.add(new Par("V_MG[" + t + "]", "val", Eval.V_MG, t, 50, 1500, false));
            for (int t = 1; t <= 5; t++) L.add(new Par("V_EG[" + t + "]", "val", Eval.V_EG, t, 50, 1500, false));
        }
        if (groups.contains("w2")) {
            for (int i = 0; i < Eval.W2.length; i++) L.add(new Par("W2[" + i + "]", "w2", Eval.W2, i, 0, i == Eval.W2_NOQ ? 100 : 200, false));
        }
        if (groups.contains("pass")) {
            for (int r = 2; r <= 6; r++) L.add(new Par("PASS_MG[" + r + "]", "pass", Eval.PASS_MG, r, -50, 300, false));
            for (int r = 2; r <= 6; r++) L.add(new Par("PASS_EG[" + r + "]", "pass", Eval.PASS_EG, r, -50, 400, false));
        }
        if (groups.contains("w")) {
            for (int i = 0; i < Eval.W.length; i++) L.add(new Par("W[" + i + "]", "w", Eval.W, i, 0, 200, false));
        }
        if (groups.contains("pst")) {
            for (int t = 1; t <= 6; t++) for (int i = 0; i < 64; i++) {
                if (t == 1 && (i < 8 || i >= 56)) continue;           // piyon: andalana 1 sy 8 tsy ampiasaina
                L.add(new Par("TMG[" + t + "][" + i + "]", "pst", Eval.TMG[t], i, -150, 150, true));
                L.add(new Par("TEG[" + t + "][" + i + "]", "pst", Eval.TEG[t], i, -150, 150, true));
            }
        }
        return L;
    }

    // ---------------------------------------------------------------- vokatra
    static String arr(int[] a) {
        StringBuilder sb = new StringBuilder("{");
        for (int i = 0; i < a.length; i++) { if (i > 0) sb.append(", "); sb.append(a[i]); }
        return sb.append("}").toString();
    }

    static String dump() {
        StringBuilder sb = new StringBuilder();
        sb.append("int[] vmg = ").append(arr(Eval.V_MG)).append("; int[] veg = ").append(arr(Eval.V_EG)).append(";\n");
        sb.append("int[] w = ").append(arr(Eval.W)).append(";\n");
        sb.append("int[] w2 = ").append(arr(Eval.W2)).append(";\n");
        sb.append("int[] pmg = ").append(arr(Eval.PASS_MG)).append("; int[] peg = ").append(arr(Eval.PASS_EG)).append(";\n");
        for (int t = 1; t <= 6; t++) sb.append("int[] tmg").append(t).append(" = ").append(arr(Eval.TMG[t])).append(";\n");
        for (int t = 1; t <= 6; t++) sb.append("int[] teg").append(t).append(" = ").append(arr(Eval.TEG[t])).append(";\n");
        return sb.toString();
    }

    static int[][] snapshot(List<Par> L) { int[] v = new int[L.size()]; for (int i = 0; i < v.length; i++) v[i] = L.get(i).get(); return new int[][]{v}; }

    public static void main(String[] a) throws Exception {
        String out = a[0];
        List<String> files = new ArrayList<>(Arrays.asList(a).subList(1, a.length));
        Set<String> groups = new HashSet<>(Arrays.asList(System.getProperty("groups", "val,pass,w").split(",")));
        int passes = Integer.getInteger("passes", 6), step = Integer.getInteger("step", 1);
        long deadline = System.nanoTime() + Long.getLong("minutes", 300L) * 60_000_000_000L;
        threads = Integer.getInteger("threads", Runtime.getRuntime().availableProcessors());
        if (groups.contains("w2") || Boolean.getBoolean("eval2")) Params.set("Eval2", 1);   // toetra vaovao mandeha rehefa tuning-na ny w2
        load(files, Integer.getInteger("maxpos", 0));
        if (n < 1000) { System.out.println("DATA tsy ampy (<1000)"); System.exit(1); }
        pool = Executors.newFixedThreadPool(threads);
        evs = new Eval[threads]; ps = new Pos[threads];
        for (int t = 0; t < threads; t++) { evs[t] = new Eval(50, 50, 50, 50, 50); ps[t] = new Pos(); }

        // K tsara indrindra (golden section)
        double lo = 0.2, hi = 3.0, gr = 0.6180339887;
        for (int it = 0; it < 18; it++) {
            double m1 = hi - gr * (hi - lo), m2 = lo + gr * (hi - lo);
            if (err(m1, false) < err(m2, false)) hi = m2; else lo = m1;
        }
        final double K = (lo + hi) / 2;
        double best = err(K, false), v0 = err(K, true), bestVal = v0;
        System.out.printf("K=%.3f  train=%.6f  val=%.6f  (baseline)%n", K, best, v0);

        List<Par> L = params(groups);
        System.out.println("PARAMS " + L.size() + " groups=" + groups + " threads=" + threads);
        int[][] bestSnap = snapshot(L); int worse = 0;
        for (int pass = 1; pass <= passes && System.nanoTime() < deadline; pass++) {
            int changed = 0;
            for (Par p : L) {
                if (System.nanoTime() > deadline) break;
                int old = p.get(); boolean moved = false;
                for (int dir : new int[]{+1, -1}) {
                    while (true) {
                        int nv = p.get() + dir * step;
                        if (nv < p.min || nv > p.max) break;
                        p.set(nv);
                        double e = err(K, false);
                        if (e < best - 1e-9) { best = e; moved = true; } else { p.set(nv - dir * step); break; }
                    }
                    if (moved) break;
                }
                if (p.get() != old) changed++;
            }
            double val = err(K, true);
            System.out.printf("PASS %d  changed=%d  train=%.6f  val=%.6f%n", pass, changed, best, val);
            if (val < bestVal - 1e-9) { bestVal = val; bestSnap = snapshot(L); worse = 0; } else worse++;
            if (changed == 0 || worse >= 2) break;
        }
        // Avereno ny voalohany tsara indrindra amin'ny validation
        for (int i = 0; i < L.size(); i++) L.get(i).arr[L.get(i).idx] = bestSnap[0][i];
        Eval.rebuildPst();
        double fin = err(K, false), finVal = err(K, true);
        System.out.printf("FINAL train=%.6f val=%.6f (val baseline %.6f, fahasamihafana %+.6f)%n", fin, finVal, v0, finVal - v0);
        try (PrintWriter pw = new PrintWriter(out)) { pw.print(dump()); }
        System.out.println("-> " + out);
        pool.shutdown();
    }
}
