package mg.chess.offline

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.roundToInt

/** Fanafarana ny schema + classement ho sary (PNG) na PDF, hozaraina. */
object TourExport {
    private const val BG = 0xFF14181F.toInt()
    private const val CARD = 0xFF222A36.toInt()
    private const val LINE = 0xFF5B677A.toInt()
    private const val TXT = 0xFFEAEFF7.toInt()
    private const val SUB = 0xFF9AA7BA.toInt()
    private const val ACC = 0xFF7BD389.toInt()
    private const val GOLD = 0xFFF2C14E.toInt()
    private const val SILVER = 0xFFC0C6D0.toInt()
    private const val BRONZE = 0xFFCD7F32.toInt()

    private fun paint(color: Int, size: Float, bold: Boolean = false, align: Paint.Align = Paint.Align.LEFT) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        textSize = size
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        textAlign = align
    }

    private fun fit(p: Paint, s: String, maxW: Float): String {
        if (p.measureText(s) <= maxW) return s
        var t = s
        while (t.length > 1 && p.measureText("$t…") > maxW) t = t.dropLast(1)
        return "$t…"
    }

    private fun fmt(p: Double) = if (p % 1.0 == 0.0) "${p.toInt()}" else "$p"

    private fun medalColor(t: Tournament, id: String?): Int? {
        val pd = t.podium() ?: return null
        return when (id) {
            pd.first -> GOLD
            pd.second -> SILVER
            t.bronze() -> BRONZE
            else -> null
        }
    }

    private class Row(val id: String, val cells: List<String>)

    private fun rows(t: Tournament): Pair<List<String>, List<Row>> {
        return if (t.isSwiss) {
            val head = listOf("#", "Mpilalao", "V", "N", "D", "Pts")
            head to t.swissStandings().mapIndexed { i, r ->
                Row(r.id, listOf("${i + 1}", t.name(r.id), "${r.w}", "${r.d}", "${r.l}", fmt(r.pts)))
            }
        } else {
            val pd = t.podium()
            fun rank(id: String) = when (id) {
                pd?.first -> 0
                pd?.second -> 1
                t.bronze() -> 2
                else -> 3
            }
            val sorted = t.playerLines().sortedWith(
                compareBy<PlayerLine> { rank(it.id) }.thenByDescending { it.pts }.thenByDescending { it.brilliant }
            )
            val head = listOf("#", "Mpilalao", "J", "V", "N", "D", "Pts", "!!", "!", "??", "Préc.")
            head to sorted.mapIndexed { i, l ->
                val an = l.analysed > 0
                Row(l.id, listOf(
                    "${i + 1}", t.name(l.id), "${l.played}", "${l.w}", "${l.d}", "${l.l}", fmt(l.pts),
                    if (an) "${l.brilliant}" else "-", if (an) "${l.great}" else "-", if (an) "${l.blunder}" else "-",
                    l.accuracy?.let { "${it.roundToInt()}%" } ?: "-"
                ))
            }
        }
    }

    fun render(t: Tournament): Bitmap {
        val pad = 40f
        val rounds = t.bracket()
        val cardW = 250f; val cardH = 78f; val gap = 50f; val pitch = 96f; val head = 40f
        val bracketH = if (rounds.isEmpty()) 0f else head + pitch * rounds.first().size
        val bracketW = if (rounds.isEmpty()) 0f else rounds.size * (cardW + gap) - gap
        val (cols, data) = rows(t)
        val rowH = 46f
        val titleH = 150f
        val width = max(1200f, bracketW + 2 * pad).toInt()
        val height = (pad + titleH + (if (bracketH > 0f) bracketH + 70f else 0f) + 70f + rowH * (data.size + 1) + pad).toInt()
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(BG)

        var y = pad
        c.drawText(fit(paint(TXT, 54f, true), t.name, width - 2 * pad), pad, y + 54f, paint(TXT, 54f, true))
        val sub = (if (t.champion != null) "Vita" else stageLabel(t.stage)) + " - ${t.players.size} mpilalao" +
            (if (t.isSwiss) " - Swiss" else "")
        c.drawText(sub, pad, y + 96f, paint(SUB, 28f))
        val pd = t.podium()
        if (pd != null) {
            var x = pad
            fun medal(col: Int, name: String) {
                c.drawCircle(x + 14f, y + 128f, 12f, paint(col, 10f).apply { style = Paint.Style.FILL })
                val p = paint(TXT, 28f, true)
                c.drawText(name, x + 36f, y + 138f, p)
                x += 36f + p.measureText(name) + 36f
            }
            medal(GOLD, t.name(pd.first))
            pd.second?.let { medal(SILVER, t.name(it)) }
            t.bronze()?.let { medal(BRONZE, t.name(it)) }
        }
        y += titleH

        if (rounds.isNotEmpty()) {
            val lp = paint(LINE, 4f).apply { style = Paint.Style.STROKE; strokeWidth = 4f }
            fun cy(r: Int, i: Int): Float {
                val span = (1 shl r).toFloat()
                return y + head + pitch * (i * span + span / 2f)
            }
            for (r in 0 until rounds.size - 1) {
                val x0 = pad + r * (cardW + gap) + cardW
                val xm = x0 + gap / 2f
                val x1 = pad + (r + 1) * (cardW + gap)
                for (i in rounds[r].indices) {
                    val yy = cy(r, i); val py = cy(r + 1, i / 2)
                    c.drawLine(x0, yy, xm, yy, lp); c.drawLine(xm, yy, xm, py, lp); c.drawLine(xm, py, x1, py, lp)
                }
            }
            rounds.forEachIndexed { r, list ->
                val x = pad + r * (cardW + gap)
                c.drawText(stageLabel("KO${list.first().round}"), x, y + 26f, paint(ACC, 26f, true))
                list.forEachIndexed { i, bm ->
                    val cyv = cy(r, i)
                    val rect = RectF(x, cyv - cardH / 2, x + cardW, cyv + cardH / 2)
                    c.drawRoundRect(rect, 14f, 14f, paint(CARD, 10f))
                    val stroke = paint(if (bm.round == 2) GOLD else LINE, 10f).apply { style = Paint.Style.STROKE; strokeWidth = 2f }
                    c.drawRoundRect(rect, 14f, 14f, stroke)
                    fun line(label: String, id: String?, win: Boolean, dy: Float) {
                        val p = paint(if (win) ACC else TXT, 24f, win)
                        val col = medalColor(t, id)
                        var tx = rect.left + 14f
                        if (col != null) { c.drawCircle(tx + 6f, rect.top + dy - 8f, 7f, paint(col, 10f)); tx += 20f }
                        c.drawText(fit(p, label, rect.right - tx - 10f), tx, rect.top + dy, p)
                    }
                    line(bm.whiteLabel, bm.whiteId, bm.whiteId != null && bm.winnerId == bm.whiteId, 32f)
                    line(bm.blackLabel, bm.blackId, bm.blackId != null && bm.winnerId == bm.blackId, 62f)
                    if (bm.scoreText.isNotEmpty()) c.drawText(fit(paint(SUB, 20f), bm.scoreText, cardW), x + 6f, rect.bottom + 22f, paint(SUB, 20f))
                }
            }
            y += bracketH + 70f
        }

        // Tabilao classement
        c.drawText(if (t.isSwiss) "Tabilao Swiss" else "Classement mpilalao", pad, y + 30f, paint(ACC, 30f, true))
        y += 50f
        val tableW = width - 2 * pad
        val widths: List<Float> =
            if (cols.size == 6) listOf(60f, tableW - 60f - 3 * 70f - 110f, 70f, 70f, 70f, 110f)
            else listOf(60f, tableW - 810f, 70f, 70f, 70f, 70f, 110f, 80f, 80f, 90f, 110f)
        val hp = paint(SUB, 24f, true)
        var x = pad
        cols.forEachIndexed { i, h -> c.drawText(h, x + 8f, y + 32f, hp); x += widths[i] }
        y += rowH
        data.forEachIndexed { ri, r ->
            val rect = RectF(pad, y, width - pad, y + rowH - 4f)
            if (ri % 2 == 0) c.drawRoundRect(rect, 8f, 8f, paint(CARD, 10f))
            val col = medalColor(t, r.id)
            var xx = pad
            r.cells.forEachIndexed { i, cell ->
                val p = paint(if (i == 1 && col != null) col else TXT, 24f, i == 1 || i == cols.size - 1)
                val avail = widths[i] - 12f
                c.drawText(fit(p, cell, avail), xx + 8f, y + 32f, p)
                xx += widths[i]
            }
            y += rowH
        }
        return bmp
    }

    fun exportPng(ctx: Context, t: Tournament): File {
        val f = File(ShareUtil.sharedDir(ctx), "kajy-${ShareUtil.safeName(t.name)}.png")
        val bmp = render(t)
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()
        return f
    }

    fun exportPdf(ctx: Context, t: Tournament): File {
        val f = File(ShareUtil.sharedDir(ctx), "kajy-${ShareUtil.safeName(t.name)}.pdf")
        val bmp = render(t)
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(bmp.width, bmp.height, 1).create())
        page.canvas.drawBitmap(bmp, 0f, 0f, null)
        doc.finishPage(page)
        FileOutputStream(f).use { doc.writeTo(it) }
        doc.close()
        bmp.recycle()
        return f
    }
}
