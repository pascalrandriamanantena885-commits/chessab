#!/usr/bin/env python3
"""Fandrefesana Elo: JORO vs Stockfish (UCI_Elo). Ampiasa: python3 calibrate.py <java classes dir> <games per level> <movetime ms> [levels...]"""
import sys, math, chess, chess.engine
cls, games, mt = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
levels = [int(x) for x in sys.argv[4:]] or [2000, 2200, 2400, 2600]
own = chess.engine.SimpleEngine.popen_uci(["java", "-cp", cls, "mg.chess.offline.own.OwnUci"])
sf = chess.engine.SimpleEngine.popen_uci(["stockfish"])
est = []
for lv in levels:
    sf.configure({"UCI_LimitStrength": True, "UCI_Elo": lv})
    pts = 0.0
    for g in range(games):
        b = chess.Board(); own_white = g % 2 == 0
        own.protocol.send_line("ucinewgame")
        while not b.is_game_over(claim_draw=True) and b.fullmove_number < 200:
            eng = own if (b.turn == chess.WHITE) == own_white else sf
            r = eng.play(b, chess.engine.Limit(time=mt / 1000.0))
            b.push(r.move)
        res = b.result(claim_draw=True)
        sc = {"1-0": 1.0, "0-1": 0.0}.get(res, 0.5)
        pts += sc if own_white else 1.0 - sc
    s = min(max(pts / games, 0.02), 0.98)
    e = lv - 400 * math.log10(1 / s - 1)
    est.append(e)
    print(f"UCI_Elo={lv}: score={pts}/{games} -> Elo~{e:.0f}", flush=True)
print(f"Tombana Elo ~ {sum(est)/len(est):.0f}")
own.quit(); sf.quit()
