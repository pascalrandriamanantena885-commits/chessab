package mg.chess.offline.own;

import java.util.LinkedHashMap;

/**
 * Parameter azo ovaina (UCI setoption / SPSA) sy "switch" ho an'ny fikarohana vaovao.
 * Ny soatoavina default dia mitovy amin'ny fitondran-tena taloha: ny safidy vaovao (ProbCut, CaptHist, ContHist)
 * dia 0 (tsy mandeha) ka mitovy tanteraka ny node raha tsy novana.
 */
public final class Params {
    public static final class P {
        public final String name; public final int def, min, max; public volatile int val;
        P(String n, int d, int mn, int mx) { name = n; def = d; min = mn; max = mx; val = d; }
    }

    public static final LinkedHashMap<String, P> ALL = new LinkedHashMap<>();
    private static P reg(String n, int d, int mn, int mx) { P p = new P(n, d, mn, mx); ALL.put(n, p); return p; }

    // --- safidy / fanamafisana ---
    public static final P HASH_BITS     = reg("HashBits", 19, 16, 24);      // 2^bits entana TT
    public static final P PROBCUT       = reg("ProbCut", 0, 0, 1);
    public static final P PROBCUT_MARGIN = reg("ProbCutMargin", 200, 50, 500);
    public static final P CAPT_HIST     = reg("CaptHist", 0, 0, 1);
    public static final P CONT_HIST     = reg("ContHist", 0, 0, 1);
    // --- lanja azo tuning-na (SPSA); default = ny soatoavina taloha ---
    public static final P RFP_MARGIN    = reg("RfpMargin", 95, 40, 160);
    public static final P RFP_MARGIN_IMP = reg("RfpMarginImp", 70, 30, 140);
    public static final P RAZOR_MARGIN  = reg("RazorMargin", 260, 120, 500);
    public static final P FUT_BASE      = reg("FutBase", 90, 30, 200);
    public static final P FUT_MUL       = reg("FutMul", 90, 30, 200);
    public static final P NMP_BASE      = reg("NmpBase", 3, 2, 5);
    public static final P ASP_DELTA     = reg("AspDelta", 40, 10, 100);
    public static final P LMR_BASE      = reg("LmrBase", 75, 0, 150);        // /100
    public static final P LMR_DIV       = reg("LmrDiv", 225, 150, 350);      // /100

    /** Miverina true raha fantatra ny anarana. */
    public static boolean set(String name, int v) {
        P p = ALL.get(name);
        if (p == null) return false;
        p.val = Math.max(p.min, Math.min(p.max, v));
        if (p == LMR_BASE || p == LMR_DIV) Search.rebuildLmr();
        return true;
    }

    private Params() {}
}
