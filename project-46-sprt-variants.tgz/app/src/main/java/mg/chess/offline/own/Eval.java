package mg.chess.offline.own;

/**
 * Evaluation manokana (centipawn, araka ny mpilalao ho avy). Misy toetra (personalité):
 * a=fanafihana, s=sacrifice, d=fiarovana, q=queen, t=fifanakalozana (0..100, 50 = mahazatra).
 */
public final class Eval {
    static final int[] V_MG = {0, 100, 320, 330, 500, 900, 0};
    static final int[] V_EG = {0, 115, 320, 340, 520, 950, 0};
    static final int[] PH = {0, 0, 1, 1, 2, 4, 0};
    static final int[][] PST_MG = new int[16][128];
    static final int[][] PST_EG = new int[16][128];
    static final int[] PASS_MG = {0, 0, 5, 10, 20, 35, 60, 0};
    static final int[] PASS_EG = {0, 0, 10, 20, 40, 70, 120, 0};
    static final int[] ATT_W = {0, 0, 2, 2, 3, 5, 0};
    // Lanja scalar azo tuning-na (Texel). Jereo W_* ho an'ny index.
    static final int W_DBL_MG = 0, W_DBL_EG = 1, W_ISO_MG = 2, W_ISO_EG = 3, W_SUP_MG = 4, W_SUP_EG = 5,
        W_NMOB_MG = 6, W_NMOB_EG = 7, W_BMOB_MG = 8, W_BMOB_EG = 9, W_RMOB_MG = 10, W_RMOB_EG = 11,
        W_ROPEN_MG = 12, W_ROPEN_EG = 13, W_RSEMI_MG = 14, W_RSEMI_EG = 15, W_R7_MG = 16, W_R7_EG = 17,
        W_QMOB_EG = 18, W_BPAIR_MG = 19, W_BPAIR_EG = 20, W_OUTP_MG = 21, W_OUTP_EG = 22, W_OUTPU_MG = 23,
        W_THR_MG = 24, W_THR_EG = 25, W_PKPROX = 26, W_PBLOCK = 27, W_TEMPO = 28, W_QMOB_MG = 29;
    static final int[] W = {8, 12, 12, 12, 5, 5, 4, 4, 3, 4, 1, 3, 20, 10, 10, 8, 15, 20, 2, 30, 45, 18, 10, 8, 25, 15, 3, 50, 10, 1};
    static final int[][] TMG = new int[7][64], TEG = new int[7][64]; // [type][rr*8+f]

    static {
        for (int c = 0; c < 2; c++) {
            for (int sq = 0; sq < 128; sq++) {
                if ((sq & 0x88) != 0) continue;
                int f = sq & 7, r = sq >> 4;
                int rr = c == 0 ? r : 7 - r; // ambaratonga relative
                int d = Math.max(Math.abs(2 * f - 7), Math.abs(2 * r - 7));
                int cf = Math.abs(2 * f - 7);
                int pc = c << 3;
                // piyon
                int pmg = new int[]{0, -5, -5, 0, 10, 25, 40, 0}[rr];
                if (rr >= 1 && rr <= 4 && (f == 3 || f == 4)) pmg += 8 + 2 * rr;
                if (rr == 1 && (f == 0 || f == 7)) pmg -= 3;
                int peg = new int[]{0, 0, 3, 8, 18, 35, 50, 0}[rr];
                PST_MG[Pos.P | pc][sq] = pmg; PST_EG[Pos.P | pc][sq] = peg;
                PST_MG[Pos.N | pc][sq] = (7 - d) * 5 - 20; PST_EG[Pos.N | pc][sq] = (7 - d) * 4 - 16;
                PST_MG[Pos.B | pc][sq] = (7 - d) * 2 - 6;  PST_EG[Pos.B | pc][sq] = (7 - d) * 2 - 6;
                PST_MG[Pos.R | pc][sq] = (cf <= 3 ? 3 : 0); PST_EG[Pos.R | pc][sq] = 0;
                PST_MG[Pos.Q | pc][sq] = (7 - d) - 3;       PST_EG[Pos.Q | pc][sq] = (7 - d) * 2 - 6;
                PST_MG[Pos.K | pc][sq] = cf * 3 - 14 * rr;  PST_EG[Pos.K | pc][sq] = (7 - d) * 8 - 24;
                if (c == 0) for (int ty = 1; ty <= 6; ty++) {
                    TMG[ty][r * 8 + f] = PST_MG[ty][sq]; TEG[ty][r * 8 + f] = PST_EG[ty][sq];
                }
            }
        }
    }

    /** Fenoy ny PST avy amin'ny TMG/TEG (mitovy amin'ny fisaka ho an'ny mainty). */
    public static void rebuildPst() {
        for (int c = 0; c < 2; c++) for (int sq = 0; sq < 128; sq++) {
            if ((sq & 0x88) != 0) continue;
            int f = sq & 7, r = sq >> 4, rr = c == 0 ? r : 7 - r;
            for (int ty = 1; ty <= 6; ty++) {
                PST_MG[ty | (c << 3)][sq] = TMG[ty][rr * 8 + f];
                PST_EG[ty | (c << 3)][sq] = TEG[ty][rr * 8 + f];
            }
        }
    }

    // ---- Lanja voatombana (Texel) - novolavolain'ny Tuner ----
    static {
        int[] vmg = {0, 100, 320, 333, 495, 906, 0}; int[] veg = {0, 107, 317, 337, 520, 957, 0};
        int[] w = {15, 11, 9, 0, 0, 0, 1, 8, 5, 1, 2, 5, 6, 4, 18, 13, 14, 39, 8, 42, 45, 35, 19, 26, 45, 34, 23, 41, 6, 0};
        int[] pmg = {0, 0, -1, 20, 40, 55, 80, 0}; int[] peg = {0, 0, -9, 18, 60, 90, 140, 0};
        int[] tmg1 = {0, 0, 0, 0, 0, 0, 0, 0, -6, -8, 4, 1, -2, -6, -5, -15, -7, -5, 0, 1, 6, -4, -1, -12, -6, 2, -1, 14, 14, 3, 1, -1, 14, 10, 8, 29, 19, 11, 14, 17, 25, 28, 27, 26, 24, 24, 27, 27, 40, 41, 40, 40, 40, 40, 40, 39, 0, 0, 0, 0, 0, 0, 0, 0};
        int[] teg1 = {0, 0, 0, 0, 0, 0, 0, 0, -1, -3, 10, 4, 2, -3, 2, 2, 1, -3, 8, -2, 11, 1, 7, -1, 6, 9, 8, -4, 0, 5, 5, 9, 25, 18, 18, 18, 14, 20, 15, 14, 35, 40, 35, 36, 33, 37, 33, 38, 51, 52, 51, 48, 50, 49, 50, 49, 0, 0, 0, 0, 0, 0, 0, 0};
        int[] tmg2 = {-20, -13, -20, -20, -20, -21, -18, -20, -21, -9, -12, -9, -13, -9, -11, -20, -28, -10, 1, -1, 1, 4, -12, -19, -18, -9, -2, 13, 6, 1, -9, -19, -21, -7, 1, 7, 7, -1, -11, -21, -20, -10, -1, 1, 0, 1, -10, -20, -20, -10, -10, -10, -10, -10, -10, -20, -20, -20, -20, -20, -20, -20, -20, -20};
        int[] teg2 = {-16, -15, -16, -16, -16, -16, -16, -15, -17, -8, -10, -8, -10, -7, -9, -16, -17, -7, -1, 0, 0, 2, -9, -17, -16, -7, -4, 11, 6, -1, -7, -16, -16, -7, 1, 9, 7, 0, -8, -16, -16, -8, -1, 1, -1, 0, -8, -16, -16, -8, -8, -8, -8, -8, -8, -16, -16, -16, -16, -16, -16, -16, -16, -16};
        int[] tmg3 = {-6, -7, -5, -6, -6, -2, -6, -6, -6, 5, -3, -3, -2, -2, -4, -6, -5, -2, 5, -2, 0, 5, -2, -1, -7, -2, 4, 5, 6, -3, -2, -7, -6, -2, 2, 4, 5, 3, -4, -4, -6, -2, 2, 3, 2, 1, -2, -6, -7, -2, -2, -2, -2, -2, -2, -7, -6, -6, -6, -6, -6, -6, -6, -6};
        int[] teg3 = {-7, -7, -7, -6, -6, -4, -6, -6, -6, -3, -3, -2, -2, -1, -1, -7, -7, -4, 3, 0, 4, 6, -2, -4, -7, -3, 1, 7, 4, 1, -2, -6, -5, -2, 2, 5, 6, 3, -3, -6, -6, -1, 1, 3, 0, 3, -1, -6, -6, -2, -2, -2, -2, -2, -2, -7, -6, -6, -6, -6, -7, -6, -6, -6};
        int[] tmg4 = {2, -3, 5, 5, 1, 3, 1, 7, -6, -3, 3, 4, 2, 4, -2, 0, -1, 0, 1, 3, 3, 2, 0, -1, -2, 0, 3, 3, 2, 3, -1, 2, 0, 1, 4, 3, 3, 3, 0, -1, 0, 0, 3, 3, 3, 3, 0, 0, 0, 0, 4, 3, 3, 3, -1, 0, 0, 0, 3, 3, 3, 3, 0, 0};
        int[] teg4 = {-3, 0, 2, 0, -2, 1, 2, 1, -2, -1, 0, 0, -1, -1, 0, -1, 0, 1, -2, 0, -1, -1, 0, -1, 0, 1, 0, 0, -2, 0, 1, 1, 0, 1, 1, 1, -1, 0, 1, 0, -1, 1, 0, 1, -1, 0, 1, 1, 0, 1, 1, 1, 0, 0, 0, 1, 0, 1, 0, 0, -1, 0, 0, 0};
        int[] tmg5 = {-2, -1, -3, 2, -3, -2, -3, -3, -2, -1, -4, 0, -2, 0, -2, -3, -3, 2, 0, -1, 0, -2, -1, -4, -3, -1, 0, 5, 5, 1, -1, -1, -4, -1, 1, 4, 2, 0, -2, -2, -3, -1, 1, 2, 1, 1, -3, -2, -4, -1, -1, -1, -1, -2, 0, -2, -4, -3, -2, -3, -3, -3, -3, -2};
        int[] teg5 = {-6, -6, -5, -6, -6, -6, -6, -6, -6, -2, -3, -2, -2, -2, -3, -6, -6, -2, 2, 2, 2, 1, -2, -6, -6, -2, 2, 7, 7, 2, -1, -6, -6, -1, 2, 6, 6, 2, -2, -5, -6, -2, 2, 3, 2, 2, -2, -6, -6, -2, -2, -2, -2, -2, -2, -6, -6, -6, -6, -6, -6, -6, -6, -6};
        int[] tmg6 = {21, 19, 11, 2, 5, 7, 15, 16, 7, 1, -5, -8, -11, -7, 2, 7, -7, -13, -19, -25, -28, -18, -13, -6, -21, -27, -33, -40, -40, -33, -27, -21, -35, -41, -47, -53, -53, -47, -41, -35, -49, -55, -61, -67, -67, -61, -55, -49, -63, -69, -75, -81, -81, -75, -69, -63, -77, -83, -89, -95, -95, -89, -83, -77};
        int[] teg6 = {-24, -22, -23, -21, -23, -23, -23, -27, -25, -9, -9, -5, -6, -10, -6, -24, -24, -8, 6, 8, 3, 9, -9, -22, -23, -8, 9, 21, 21, 6, -8, -24, -24, -7, 8, 23, 20, 8, -8, -24, -23, -7, 7, 8, 8, 9, -8, -24, -24, -8, -8, -8, -7, -8, -8, -24, -24, -24, -24, -24, -24, -24, -24, -24};
        System.arraycopy(vmg, 0, V_MG, 0, vmg.length); System.arraycopy(veg, 0, V_EG, 0, veg.length);
        System.arraycopy(w, 0, W, 0, w.length);
        System.arraycopy(pmg, 0, PASS_MG, 0, pmg.length); System.arraycopy(peg, 0, PASS_EG, 0, peg.length);
        int[][] tm = {null, tmg1, tmg2, tmg3, tmg4, tmg5, tmg6}, te = {null, teg1, teg2, teg3, teg4, teg5, teg6};
        for (int ty = 1; ty <= 6; ty++) { System.arraycopy(tm[ty], 0, TMG[ty], 0, 64); System.arraycopy(te[ty], 0, TEG[ty], 0, 64); }
        rebuildPst();
    }
    // ---- farany ----

    private static int cheb(int a, int b) {
        return Math.max(Math.abs((a & 7) - (b & 7)), Math.abs((a >> 4) - (b >> 4)));
    }

    // personalité (pct)
    final int matPct, attPct, defPct, queenAct, tradeTf;

    public Eval(int a, int s, int d, int q, int t) {
        matPct = 100 - (s - 50) / 5;                 // sacrifice: 90..110
        int ap = 70 + (a * 60) / 100;                  // 70..130
        attPct = ap * (100 + (s - 50) / 2) / 100;      // sacrifice mampitombo ny fanafihana
        defPct = 60 + (d * 80) / 100;                  // 60..140
        queenAct = q - 50 + (q - 50);                  // -100..+100
        tradeTf = (t - 50) * 15 / 50;                  // -15..+15 (%)
    }

    private final int[][] cnt = new int[2][10];
    private final int[][] hi = new int[2][10];
    private final int[][] lo = new int[2][10];
    private final int[] mg = new int[2], eg = new int[2];
    private final boolean[][] zone = new boolean[2][128];
    private final int[] units = new int[2], atk = new int[2];
    private final int[] nb = new int[2];
    private final int[] bishops = new int[2];
    private final int[] pawnsN = new int[2];
    private final int[] mat = new int[2];
    private final int[] occSq = new int[40];   // toerana misy piece (<= 32)

    /** Mitovy amin'ny zone[c][t] taloha: 3x3 manodidina ny mpanjaka + andalana 2 eo aloha (3 rakitra). */
    private static boolean inZone(int kr, int kf, int c, int t) {
        int dr = (t >> 4) - kr, df = (t & 7) - kf;
        if (df < -1 || df > 1) return false;
        return (dr >= -1 && dr <= 1) || dr == (c == 0 ? 2 : -2);
    }

    @SuppressWarnings("unused")
    private void mark(Pos p, int c) {
        boolean[] z = zone[c];
        java.util.Arrays.fill(z, false);
        int k = p.ksq[c];
        int fwd = c == 0 ? 16 : -16;
        for (int dr = -1; dr <= 1; dr++) for (int df = -1; df <= 1; df++) {
            int s = k + dr * 16 + df;
            if ((s & 0x88) == 0) z[s] = true;
        }
        for (int df = -1; df <= 1; df++) {
            int s = k + 2 * fwd + df;
            if ((s & 0x88) == 0) z[s] = true;
        }
    }

    // ---- Eval cache (hash araka ny pos.key): mitahiry ny valiny mitovy tanteraka, ka tsy manova ny node ----
    private static final int EC_BITS = 17;
    private final long[] ecKey = new long[1 << EC_BITS];
    private final int[] ecVal = new int[1 << EC_BITS];

    /** Fafao rehefa miova ny Eval.W / PST (ohatra rehefa Texel tuning). */
    public void clearCache() { java.util.Arrays.fill(ecKey, 0L); }

    /** Score araka ny mpilalao ho avy (misy cache). */
    public int eval(Pos p) {
        final long k = p.key;
        final int i = (int) (k ^ (k >>> 32)) & ((1 << EC_BITS) - 1);
        if (ecKey[i] == k) return ecVal[i];
        final int v = evalRaw(p);
        ecKey[i] = k; ecVal[i] = v;
        return v;
    }

    /** Fanisana tsy misy cache. */
    public int evalRaw(Pos p) {
        final int[] b = p.b;
        for (int c = 0; c < 2; c++) {
            java.util.Arrays.fill(cnt[c], 0);
            java.util.Arrays.fill(hi[c], -1);
            java.util.Arrays.fill(lo[c], 8);
            mg[c] = 0; eg[c] = 0; units[c] = 0; atk[c] = 0; nb[c] = 0; bishops[c] = 0; pawnsN[c] = 0; mat[c] = 0;
        }
        int phaseTot = 0, minors = 0, majors = 0;
        // pass 1: piyon + material (tahirizina ny toerana misy piece ho an'ny pass 2)
        int no = 0;
        final int[] occ = occSq;
        for (int s = 0; s < 128; s++) {
            if ((s & 0x88) != 0) { s += 7; continue; }
            int pc = b[s];
            if (pc == 0) continue;
            occ[no++] = s;
            int c = pc >> 3, ty = pc & 7;
            if (ty == Pos.P) {
                int f = s & 7, r = s >> 4;
                cnt[c][f + 1]++;
                if (r > hi[c][f + 1]) hi[c][f + 1] = r;
                if (r < lo[c][f + 1]) lo[c][f + 1] = r;
                pawnsN[c]++;
            } else if (ty != Pos.K) {
                phaseTot += PH[ty];
                nb[c]++;
                if (ty == Pos.N || ty == Pos.B) minors++; else majors++;
                if (ty == Pos.B) bishops[c]++;
            }
        }
        if (pawnsN[0] + pawnsN[1] == 0 && majors == 0 && minors <= 1) return 0; // draw: material tsy ampy
        final int kr0 = p.ksq[0] >> 4, kf0 = p.ksq[0] & 7, kr1 = p.ksq[1] >> 4, kf1 = p.ksq[1] & 7;
        for (int oi = 0; oi < no; oi++) {
            final int s = occ[oi];
            int pc = b[s];
            int c = pc >> 3, ty = pc & 7, o = c ^ 1;
            int f = s & 7, r = s >> 4, rr = c == 0 ? r : 7 - r;
            final int zkr = o == 0 ? kr0 : kr1, zkf = o == 0 ? kf0 : kf1;
            mg[c] += V_MG[ty] * matPct / 100 + PST_MG[pc][s];
            eg[c] += V_EG[ty] * matPct / 100 + PST_EG[pc][s];
            mat[c] += V_MG[ty];
            switch (ty) {
                case Pos.P: {
                    if (cnt[c][f + 1] > 1) { mg[c] -= W[W_DBL_MG]; eg[c] -= W[W_DBL_EG]; }
                    if (cnt[c][f] == 0 && cnt[c][f + 2] == 0) { mg[c] -= W[W_ISO_MG]; eg[c] -= W[W_ISO_EG]; }
                    boolean passed = true;
                    for (int ff = f; ff <= f + 2 && passed; ff++) {
                        if (c == 0) { if (hi[1][ff] > r) passed = false; }
                        else { if (lo[0][ff] < r) passed = false; }
                    }
                    if (passed) {
                        int pm = PASS_MG[rr], pe = PASS_EG[rr];
                        int stop = s + (c == 0 ? 16 : -16);
                        if ((stop & 0x88) == 0) {
                            if (b[stop] != 0 && (b[stop] >> 3) != c) { pm -= pm * W[W_PBLOCK] / 100; pe -= pe * W[W_PBLOCK] / 100; }
                            eg[c] += (cheb(p.ksq[o], stop) - cheb(p.ksq[c], stop)) * W[W_PKPROX] * rr / 6;
                        }
                        mg[c] += pm; eg[c] += pe;
                    }
                    int sup = c == 0 ? -15 : 15;
                    int s1 = s + sup, s2 = s + (c == 0 ? -17 : 17);
                    int me = Pos.P | (c << 3);
                    if (((s1 & 0x88) == 0 && b[s1] == me) || ((s2 & 0x88) == 0 && b[s2] == me)) { mg[c] += W[W_SUP_MG]; eg[c] += W[W_SUP_EG]; }
                    break;
                }
                case Pos.N: {
                    int m = 0; boolean hit = false;
                    for (int d : Pos.KN) {
                        int t = s + d;
                        if ((t & 0x88) != 0) continue;
                        int tp = b[t];
                        if (tp != 0 && (tp >> 3) == c) continue;
                        m++;
                        if (!hit && inZone(zkr, zkf, o, t)) hit = true;
                    }
                    mg[c] += (m - 4) * W[W_NMOB_MG]; eg[c] += (m - 4) * W[W_NMOB_EG];
                    if (rr >= 3 && rr <= 5 && f >= 1 && f <= 6) {
                        boolean safe = c == 0 ? (hi[1][f] <= r && hi[1][f + 2] <= r) : (lo[0][f] >= r && lo[0][f + 2] >= r);
                        if (safe) {
                            int me2 = Pos.P | (c << 3);
                            int a1 = s + (c == 0 ? -15 : 15), a2 = s + (c == 0 ? -17 : 17);
                            boolean sup = ((a1 & 0x88) == 0 && b[a1] == me2) || ((a2 & 0x88) == 0 && b[a2] == me2);
                            mg[c] += sup ? W[W_OUTP_MG] : W[W_OUTPU_MG]; eg[c] += sup ? W[W_OUTP_EG] : W[W_OUTP_EG] / 2;
                        }
                    }
                    if (hit) { units[c] += ATT_W[ty]; atk[c]++; }
                    break;
                }
                case Pos.B: case Pos.R: case Pos.Q: {
                    int m = 0; boolean hit = false;
                    for (int di = 0; di < 8; di++) {
                        int d;
                        if (di < 4) { if (ty == Pos.B) continue; d = Pos.RD[di]; }
                        else { if (ty == Pos.R) continue; d = Pos.BD[di - 4]; }
                        int t = s + d;
                        while ((t & 0x88) == 0) {
                            int tp = b[t];
                            if (tp != 0 && (tp >> 3) == c) break;
                            m++;
                            if (!hit && inZone(zkr, zkf, o, t)) hit = true;
                            if (tp != 0) break;
                            t += d;
                        }
                    }
                    if (ty == Pos.B) { mg[c] += (m - 6) * W[W_BMOB_MG]; eg[c] += (m - 6) * W[W_BMOB_EG]; }
                    else if (ty == Pos.R) {
                        mg[c] += (m - 7) * W[W_RMOB_MG]; eg[c] += (m - 7) * W[W_RMOB_EG];
                        if (cnt[c][f + 1] == 0) {
                            if (cnt[o][f + 1] == 0) { mg[c] += W[W_ROPEN_MG]; eg[c] += W[W_ROPEN_EG]; } else { mg[c] += W[W_RSEMI_MG]; eg[c] += W[W_RSEMI_EG]; }
                        }
                        if (rr == 6 && (p.ksq[o] >> 4 == (c == 0 ? 7 : 0))) { mg[c] += W[W_R7_MG]; eg[c] += W[W_R7_EG]; }
                    } else {
                        mg[c] += (m - 14) * (100 + queenAct) / 100 * W[W_QMOB_MG]; eg[c] += (m - 14) * W[W_QMOB_EG];
                        if (rr > 0 && queenAct > 0) mg[c] += queenAct * 12 / 100;
                    }
                    if (hit) { units[c] += ATT_W[ty]; atk[c]++; }
                    break;
                }
                default: break;
            }
            if (ty >= Pos.N && ty <= Pos.Q) {
                int e1 = s + (c == 0 ? 15 : -15), e2 = s + (c == 0 ? 17 : -17);
                int ep2 = Pos.P | (o << 3);
                if (((e1 & 0x88) == 0 && b[e1] == ep2) || ((e2 & 0x88) == 0 && b[e2] == ep2)) {
                    mg[c] -= W[W_THR_MG]; eg[c] -= W[W_THR_EG];
                }
            }
        }
        for (int c = 0; c < 2; c++) {
            if (bishops[c] >= 2) { mg[c] += W[W_BPAIR_MG]; eg[c] += W[W_BPAIR_EG]; }
            int o = c ^ 1;
            // fiarovana mpanjaka (pawn shield) - mg ihany
            int k = p.ksq[c];
            int kf = k & 7, kr = k >> 4, krr = c == 0 ? kr : 7 - kr;
            if (krr <= 1) {
                int shield = 0;
                int fwd = c == 0 ? 16 : -16;
                int me = Pos.P | (c << 3);
                for (int ff = Math.max(0, kf - 1); ff <= Math.min(7, kf + 1); ff++) {
                    int s1 = (kr * 16 + ff) + fwd, s2 = s1 + fwd;
                    if ((s1 & 0x88) == 0 && b[s1] == me) shield += 10;
                    else if ((s2 & 0x88) == 0 && b[s2] == me) shield += 6;
                    else if (cnt[c][ff + 1] == 0) shield -= 15;
                    else shield -= 5;
                }
                mg[c] += shield * defPct / 100;
            }
            // loza amin'ny mpanjaka (attackers an'ny mpifanandrina)
            if (atk[o] >= 2) {
                int danger = Math.min(350, units[o] * units[o] * 2);
                mg[c] -= danger * attPct / 100 * defPct / 100;
            }
        }
        int phase = Math.min(24, phaseTot);
        int mgS = mg[0] - mg[1], egS = eg[0] - eg[1];
        int score = (mgS * phase + egS * (24 - phase)) / 24;
        // fifanakalozana: raha mitarika ny bot dia tia manafoana piece (araka ny toetra)
        score += (mat[0] - mat[1]) * tradeTf / 100 * (24 - phase) / 24;
        // mop-up: mahomby ny fandresena amin'ny endgame tsotra
        int diff = mat[0] - mat[1];
        if (phase <= 8 && Math.abs(diff) >= 300) {
            int win = diff > 0 ? 0 : 1, lose = win ^ 1;
            if (pawnsN[lose] == 0) {
                int wk = p.ksq[win], lk = p.ksq[lose];
                int cd = Math.max(Math.abs(2 * (lk & 7) - 7), Math.abs(2 * (lk >> 4) - 7));
                int dist = Math.abs((wk & 7) - (lk & 7)) + Math.abs((wk >> 4) - (lk >> 4));
                int bonus = cd * 8 + (14 - dist) * 6;
                score += win == 0 ? bonus : -bonus;
            }
        }
        score += p.side == 0 ? W[W_TEMPO] : -W[W_TEMPO];
        return p.side == 0 ? score : -score;
    }
}
