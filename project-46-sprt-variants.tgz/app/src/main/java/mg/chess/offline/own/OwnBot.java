package mg.chess.offline.own;

import java.util.List;
import java.util.Random;

/**
 * Bot mahaleo tena (tsy miankina amin'ny Stockfish). Ny Elo dia mamaritra ny depth/tabataba (fanombanana vonjimaika,
 * mila fanitsiana amin'ny lalao tena izy); ny toetra (a,s,d,q,t) dia ao amin'ny evaluation.
 */
public final class OwnBot {
    private static Search search;
    private static String sig = "";
    private static final Random RND = new Random();

    private OwnBot() {}

    /** {depth, noiseCp}; depth >= 64 = tsy voafetra (fotoana ihany). */
    public static int[] profile(int elo) {
        if (elo <= 500) return new int[]{1, 220};
        if (elo <= 700) return new int[]{1, 140};
        if (elo <= 900) return new int[]{2, 110};
        if (elo <= 1100) return new int[]{2, 70};
        if (elo <= 1300) return new int[]{3, 55};
        if (elo <= 1500) return new int[]{3, 25};
        if (elo <= 1700) return new int[]{4, 12};
        if (elo <= 1850) return new int[]{5, 0};
        if (elo <= 1950) return new int[]{6, 0};
        if (elo <= 2050) return new int[]{8, 0};
        if (elo <= 2150) return new int[]{10, 0};
        if (elo <= 2250) return new int[]{12, 0};
        if (elo <= 2350) return new int[]{14, 0};
        if (elo <= 2450) return new int[]{16, 0};
        if (elo <= 2550) return new int[]{18, 0};
        if (elo <= 2650) return new int[]{20, 0};
        return new int[]{64, 0};
    }

    public static synchronized void newGame() {
        if (search != null) search.clear();
    }

    /** Miverina hetsika UCI (na null raha tsy misy hetsika / FEN diso). */
    public static synchronized String bestMove(String fen, List<String> history, int elo, int movetimeMs,
                                               int a, int s, int d, int q, int t) {
        String nsig = a + "," + s + "," + d + "," + q + "," + t;
        if (search == null || !nsig.equals(sig)) {
            search = new Search(new Eval(a, s, d, q, t));
            sig = nsig;
        }
        try {
            search.pos.setFenWithHistory(fen, history);
        } catch (Exception e) {
            return null;
        }
        int[] pf = profile(elo);
        Search.Result r;
        if (pf[1] > 0) r = search.thinkWeak(pf[0], pf[1], Math.max(300, movetimeMs), RND);
        else {
            // Elo > 2200: fotoana bebe kokoa (hatramin'ny x2 amin'ny 2600) mba hahatratra depth ambony
            long ms = Math.max(100, movetimeMs);
            if (elo > 2200) ms = ms * (400 + Math.min(400, elo - 2200)) / 400;
            r = search.think(pf[0], ms);
        }
        if (r.move == 0) return null;
        return Pos.moveStr(r.move);
    }
}
