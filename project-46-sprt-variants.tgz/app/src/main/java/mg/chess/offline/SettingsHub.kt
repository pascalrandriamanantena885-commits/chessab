package mg.chess.offline

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.IconButton
import androidx.compose.material3.TextButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private enum class SetSec(val title: String, val sub: String, val icon: ImageVector) {
    PROFILE("Mpilalao", "Anarana sy sarinao", Icons.Rounded.Person),
    LOOK("Endrika", "Theme, board, piece, sary aloha", Icons.Rounded.Palette),
    PLAY("Filalaovana", "Premove, fanamafisana, feo, review, baterie", Icons.Rounded.Tune),
    BOTS("Bot", "Lisitra, fanovana, import / export", Icons.Rounded.SmartToy),
    DATA("Backup", "Backup, restore, backup automatique", Icons.Rounded.Backup),
}

/** Pejy fandraisana ny Settings: sokajy mazava; tsindrio ny iray dia misokatra ny pejiny. */
@Composable
fun SettingsHub(vm: ChessViewModel) {
    var section by rememberSaveable { mutableStateOf<String?>(null) }
    BackHandler { if (section != null) section = null else vm.toMenu() }
    val sec = SetSec.values().firstOrNull { it.name == section }
    val cs = MaterialTheme.colorScheme

    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 8.dp)) {
        if (sec == null) {
            ScreenTitle("Settings", trailing = { QuitAppButton(vm) })
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(SetSec.values().toList()) { s ->
                    val summary = when (s) {
                        SetSec.PROFILE -> PlayerProfile.name.ifBlank { s.sub }
                        SetSec.LOOK -> if (vm.darkMode) "Maizina · ${s.sub}" else "Mazava · ${s.sub}"
                        SetSec.PLAY -> "Feo ${if (vm.soundOn) "alefa" else "atsahatra"} · review depth ${vm.reviewDepth}"
                        SetSec.BOTS -> "${BotRegistry.visible.size} bot · ${BotRegistry.custom.size} nataoko"
                        else -> s.sub
                    }
                    HubRow(s.icon, s.title, summary) { section = s.name }
                }
                item { HubRow(Icons.Rounded.Info, "Momba / Credits", "Fahazoan-dalana, Stockfish, sary") { vm.screen = Screen.ABOUT } }
                item { Spacer(Modifier.height(12.dp)) }
            }
        } else {
            ScreenTitle(sec.title, onBack = { section = null })
            when (sec) {
                SetSec.PROFILE -> SectionList { item { PlayerProfileCard() } }
                SetSec.LOOK -> SectionList {
                    item { ThemeCard(vm) }
                    item { StyleCard() }
                    item { BackgroundCard() }
                }
                SetSec.PLAY -> SectionList {
                    item { GameplayCard(vm) }
                    item { ReviewDepthCard(vm) }
                    item { PowerSaverCard() }
                }
                SetSec.BOTS -> BotManager(vm)
                SetSec.DATA -> SectionList { item { BackupCard(vm) } }
            }
        }
    }
}

@Composable
private fun SectionList(content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        content()
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
private fun HubRow(icon: ImageVector, title: String, sub: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(
        Modifier.fillMaxWidth().clickable { onClick() },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainer)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(CircleShape).background(cs.primaryContainer), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = cs.onPrimaryContainer)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(sub, fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 1)
            }
            Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, tint = cs.onSurfaceVariant)
        }
    }
}

@Composable
private fun SettingCard(title: String, content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

@Composable
private fun ThemeCard(vm: ChessViewModel) = SettingCard("Endrika (theme)") {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(!vm.darkMode, { vm.setDark(false) }, { Text("Mazava (Light)") })
        FilterChip(vm.darkMode, { vm.setDark(true) }, { Text("Maizina (Dark)") })
    }
    Text("Tsy manaraka ny theme an'ny findainao ny app: ity safidy ity ihany no manapaka.", fontSize = 12.sp)
}

@Composable
private fun ReviewDepthCard(vm: ChessViewModel) = SettingCard("Fanadihadiana lalao (Stockfish 19)") {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(vm.reviewDepth == 12, { vm.chooseReviewDepth(12) }, { Text("Haingana") })
        FilterChip(vm.reviewDepth == 16, { vm.chooseReviewDepth(16) }, { Text("Antonony") })
        FilterChip(vm.reviewDepth == 20, { vm.chooseReviewDepth(20) }, { Text("Lalina") })
    }
    Text("Depth ${vm.reviewDepth}: arakaraka ny halalina no mihamatotra ny review sy ny game rating, saingy lava kokoa.", fontSize = 12.sp)
}

@Composable
private fun PowerSaverCard() {
    val ctx = LocalContext.current
    SettingCard("Mode mampitsitsy baterie") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(PowerSaver.mode == 0, { PowerSaver.setMode(ctx, 0) }, { Text("Atsahatra") })
            FilterChip(PowerSaver.mode == 1, { PowerSaver.setMode(ctx, 1) }, { Text("Auto") })
            FilterChip(PowerSaver.mode == 2, { PowerSaver.setMode(ctx, 2) }, { Text("Alefa") })
        }
        Text(
            "Auto = arahina ny Battery Saver an'ny Android. Rehefa mihetsika: Stockfish thread 1, fisainana fohy kokoa, review maivana, live mampiasa motera iray, ary tsy misy animation mihodina." +
                (if (PowerSaver.active) " (Mihetsika ankehitriny)" else ""),
            fontSize = 12.sp
        )
    }
}

@Composable
private fun BackgroundCard() {
    val ctx = LocalContext.current
    var bgMsg by remember { mutableStateOf("") }
    // Photo picker = mamoha ny gallerie mivantana (tsy mila alalana)
    val bgPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) bgMsg = if (AppBackground.set(ctx, uri)) "Voasoloka ny sary aloha." else "Tsy azo vakiana io sary io."
    }
    SettingCard("Sary aloha (Background)") {
        val bgImg = AppBackground.image
        if (bgImg != null) {
            Image(bgImg, null, Modifier.fillMaxWidth().height(110.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ bgPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                Text(if (bgImg == null) "Fidio sary (gallerie)" else "Ovay ny sary")
            }
            if (bgImg != null) OutlinedButton({ AppBackground.clear(ctx); bgMsg = "Nesorina ny sary aloha." }) { Text("Esory") }
        }
        if (bgImg != null) {
            Text("Hamafin'ny fanaronana (ho an'ny fahitana ny soratra)", fontSize = 12.sp)
            Slider(AppBackground.dim, { AppBackground.setDim(ctx, it) }, valueRange = 0.3f..0.95f)
        }
        if (bgMsg.isNotEmpty()) Text(bgMsg, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
    }
}

/** Bokotra "Hiala" (icon) ao amin'ny Settings: manamarina aloha, avy eo mihidy tanteraka ny app (voatahiry ny lalao). */
@Composable
private fun QuitAppButton(vm: ChessViewModel) {
    val ctx = LocalContext.current
    var ask by remember { mutableStateOf(false) }
    IconButton({ ask = true }) {
        Icon(Icons.Rounded.PowerSettingsNew, contentDescription = "Hiala amin'ny app", tint = MaterialTheme.colorScheme.error)
    }
    if (ask) {
        AlertDialog(
            onDismissRequest = { ask = false },
            title = { Text("Hiala amin'ny app?") },
            text = { Text("Hikatona tanteraka ny app. Voatahiry ny lalao mbola tsy vita.") },
            confirmButton = {
                TextButton({
                    ask = false
                    var c: android.content.Context = ctx
                    while (c is android.content.ContextWrapper && c !is android.app.Activity) c = c.baseContext
                    (c as? android.app.Activity)?.finishAndRemoveTask()
                }) { Text("Hiala", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton({ ask = false }) { Text("Foano") } }
        )
    }
}
