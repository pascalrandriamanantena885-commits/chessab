#!/usr/bin/env python3
"""Fandrefesana Elo: JORO vs Stockfish (UCI_Elo) - dikan-teny haingana.

Fanatsarana: adjudication, fanombohana kisendrasendra mifandimby loko, Pool (workers),
fijanonana raha ampy ny fahatokisana (CI) na raha saturated, ary fitambarana mizana araka ny CI.

Ampiasa:
  python3 tools/calibrate.py <cls> --levels 2000 [2200 ...] [--games 40] [--movetime 1500]
                             [--sf-movetime N] [--workers 2] [--min-games 12] [--target-ci 45]
                             [--out calib-2000.json]
  python3 tools/calibrate.py --aggregate <lahatahiry misy calib-*.json>
"""
import argparse, glob, json, math, os, random, sys
from multiprocessing import Pool


# ------------------------------------------------------------------ matematika
def level_stats(w, d, l):
    """Miverina (score, elo_diff, se_elo) amin'ny fomba fijerin'i JORO."""
    n = w + d + l
    if n == 0:
        return 0.5, 0.0, 1e9
    s = (w + d / 2.0) / n
    var = (w * (1 - s) ** 2 + d * (0.5 - s) ** 2 + l * s ** 2) / n
    se_s = max(math.sqrt(var / n), 0.5 / n)
    sc = min(max(s, 0.5 / n), 1 - 0.5 / n)
    diff = -400 * math.log10(1 / sc - 1)
    se = 400 / math.log(10) * se_s / (sc * (1 - sc))
    return s, diff, se


def aggregate(results):
    """Fitambarana mizana araka ny 1/se^2; ny ambaratonga mifanentana (10-90%) ihany raha misy."""
    rows = []
    for r in results:
        s, diff, se = level_stats(r["w"], r["d"], r["l"])
        rows.append((r["level"], r["w"], r["d"], r["l"], s, r["level"] + diff, se))
    rows.sort()
    good = [x for x in rows if 0.10 <= x[4] <= 0.90] or rows
    wsum = sum(1 / x[6] ** 2 for x in good)
    est = sum(x[5] / x[6] ** 2 for x in good) / wsum
    err = 1.96 * math.sqrt(1 / wsum)
    lines = ["| UCI_Elo | +W =D -L | score | Elo JORO | ±95% |", "|---|---|---|---|---|"]
    for lv, w, d, l, s, e, se in rows:
        mark = "" if (lv, w, d, l, s, e, se) in good else " (saturated, tsy tafiditra)"
        lines.append(f"| {lv} | +{w} ={d} -{l} | {s*100:.0f}% | {e:.0f} | ±{1.96*se:.0f}{mark} |")
    lines.append(f"\n**Tombana Elo ~ {est:.0f} ±{err:.0f}**")
    return "\n".join(lines), est, err


# ------------------------------------------------------------------ lalao
_A = {}


def _init(cls, level, mt, sf_mt):
    import chess.engine
    _A["own"] = chess.engine.SimpleEngine.popen_uci(["java", "-cp", cls, "mg.chess.offline.own.OwnUci"])
    sf = chess.engine.SimpleEngine.popen_uci(["stockfish"])
    sf.configure({"Threads": 1, "Hash": 16, "UCI_LimitStrength": True, "UCI_Elo": level})
    _A["sf"] = sf
    _A["lim_own"] = chess.engine.Limit(time=mt / 1000.0)
    _A["lim_sf"] = chess.engine.Limit(time=sf_mt / 1000.0)


def _opening(board, seed, plies=6):
    rng = random.Random(seed)
    for _ in range(plies):
        moves = list(board.legal_moves)
        if not moves or board.is_game_over():
            break
        board.push(rng.choice(moves))
    return board


def _score_of(info):
    try:
        return info["score"].white().score(mate_score=10000)
    except Exception:
        return None


def play_game(args):
    """(g, seed_base) -> (g, valiny amin'ny fomba fijerin'i JORO: 1 / 0.5 / 0)."""
    import chess, chess.engine
    g, seed_base = args
    board = _opening(chess.Board(), seed=seed_base + g // 2)   # opening mitovy, loko miova
    own_white = (g % 2 == 0)
    _A["own"].protocol.send_line("ucinewgame")
    big, big_sign, quiet = 0, None, 0

    def own_pts(white_pts):
        return white_pts if own_white else 1.0 - white_pts

    while not board.is_game_over(claim_draw=True) and len(board.move_stack) < 300:
        own_turn = (board.turn == chess.WHITE) == own_white
        eng, lim = (_A["own"], _A["lim_own"]) if own_turn else (_A["sf"], _A["lim_sf"])
        r = eng.play(board, lim, info=chess.engine.INFO_SCORE)
        board.push(r.move)
        sc = _score_of(r.info)
        if sc is None:
            continue
        if abs(sc) >= 900:                       # resign: >=900cp mandritra 6 ply mifanesy
            sgn = sc > 0
            big = big + 1 if (big > 0 and sgn == big_sign) else 1
            big_sign = sgn
            if big >= 6:
                return g, own_pts(1.0 if sc > 0 else 0.0)
        else:
            big = 0
        quiet = quiet + 1 if abs(sc) <= 15 else 0
        if len(board.move_stack) >= 160 and quiet >= 10:   # kanto: ~0 mandritra 10 ply
            return g, 0.5
    res = board.result(claim_draw=True)
    return g, own_pts({"1-0": 1.0, "0-1": 0.0}.get(res, 0.5))


def run_level(a, level):
    w = d = l = 0
    stop = "lalao rehetra vita"
    with Pool(a.workers, initializer=_init,
              initargs=(a.cls, level, a.movetime, a.sf_movetime or a.movetime)) as pool:
        jobs = [(g, 1000 * level) for g in range(a.games)]
        for i, (g, sc) in enumerate(pool.imap_unordered(play_game, jobs), 1):
            if sc == 1.0: w += 1
            elif sc == 0.0: l += 1
            else: d += 1
            s, diff, se = level_stats(w, d, l)
            if i % 4 == 0:
                print(f"  UCI_Elo={level} {i:3d} lalao +{w} ={d} -{l} score={s*100:.0f}% "
                      f"Elo~{level+diff:.0f} ±{1.96*se:.0f}", flush=True)
            if i >= a.min_games and i % 2 == 0:      # isaky ny roa (tsy mifandimby loko)
                if 1.96 * se <= a.target_ci:
                    stop = f"CI ±{1.96*se:.0f} <= {a.target_ci}"; break
                if s >= a.saturate or s <= 1 - a.saturate:
                    stop = f"saturated ({s*100:.0f}%)"; break
        pool.terminate()
    s, diff, se = level_stats(w, d, l)
    print(f"UCI_Elo={level}: +{w} ={d} -{l} score={s*100:.0f}% -> Elo~{level+diff:.0f} "
          f"±{1.96*se:.0f}  [{stop}]", flush=True)
    return {"level": level, "w": w, "d": d, "l": l}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cls", nargs="?")
    ap.add_argument("--levels", type=int, nargs="+", default=[2000, 2200, 2400, 2600])
    ap.add_argument("--games", type=int, default=40, help="lalao ambony indrindra isaky ny ambaratonga")
    ap.add_argument("--movetime", type=int, default=1500)
    ap.add_argument("--sf-movetime", type=int, default=0, help="0 = mitovy amin'ny JORO")
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--min-games", type=int, default=12)
    ap.add_argument("--target-ci", type=float, default=45.0, help="±Elo (95%%) hijanonana")
    ap.add_argument("--saturate", type=float, default=0.92)
    ap.add_argument("--out", default="")
    ap.add_argument("--aggregate", default="")
    a = ap.parse_args()

    if a.aggregate:
        res = []
        for f in sorted(glob.glob(os.path.join(a.aggregate, "**", "calib-*.json"), recursive=True)):
            res += json.load(open(f))
        if not res:
            print("::error::Tsy hita ny calib-*.json"); sys.exit(1)
        table, est, err = aggregate(res)
        print(table)
        if os.environ.get("GITHUB_STEP_SUMMARY"):
            with open(os.environ["GITHUB_STEP_SUMMARY"], "a") as f:
                f.write("### Fandrefesana Elo JORO\n" + table + "\n")
        return

    if not a.cls:
        ap.error("mila <cls> na --aggregate")
    results = [run_level(a, lv) for lv in a.levels]
    if a.out:
        json.dump(results, open(a.out, "w"))
    print(aggregate(results)[0])


if __name__ == "__main__":
    main()
