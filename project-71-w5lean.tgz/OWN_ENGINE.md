# JORO — motera manokana (own engine)

# Motera manokana (tsy miankina amin'ny Stockfish)

Toerana: `app/src/main/java/mg/chess/offline/own/` (Java madio, tsy mampiasa Android na chesslib).

- `Pos.java`   : board 0x88, hetsika marina, make/unmake, zobrist, repetition (perft voamarina).
- `Eval.java`  : evaluation (material, PST, piyon, mobility, fiarovana mpanjaka, fanafihana) + TOETRA: a/s/d/q/t.
- `Search.java`: iterative deepening, PVS, TT, null move, LMR, futility, quiescence; `thinkWeak` ho an'ny Elo ambany.
- `OwnBot.java`: API ho an'ny app + `profile(elo)` = {depth, tabataba cp}.

Fampiasana: `Engine.bestMove` -> opening book (Personality) -> OwnBot raha `OWN_ENGINE && elo <= OWN_MAX_ELO` (Bots.kt).
Ny Stockfish dia mijanona ho an'ny Review / Why / analyze sy ny bot > OWN_MAX_ELO.
Hanajanona: `const val OWN_ENGINE = false` ao amin'ny Bots.kt.

## Bot avy amin'ny PGN (`PgnBot.java`)
Ny motera manokana no mamorona bot avy amin'ny PGN, tsy mila Stockfish (ChessViewModel.analyzePgnPlayerOwn, raha `OWN_ENGINE`):
- **Book / opening favorite**: ny hetsika tena nataon'ilay mpilalao tamin'ny lalao ROHY (hatramin'ny 300), 24 ply voalohany, voarakitra amin'ny hash an'ny toerana (mahafantatra transposition). Lanja: fandresena 1.5, nul 1.2, resy 1.0; safidy ^1.5 (tia ny favorite). Tehirizina ao `Bot.book` (`<hash>:<uci>:<isa>`, <= 400) ary ampiasain'ny `Engine.bestMove` alohan'ny katalaogy opening.
- **Fomba / toetra** (a,s,d,q,t): `Personality.deriveStyle` amin'ny lalao rehetra (salanisa), ampiasain'ny `Eval`.
- **Elo**: ACPL amin'ny fikarohana an'ny motera manokana (hetsika 60 voafantina, depth 5), formula `3100*exp(-0.0086*ACPL)` (mitovy amin'ny Review), ampifangaroina amin'ny Elo ao amin'ny PGN raha misy. TSY mbola voatombana amin'ny lalao tena izy: azo ovaina eo amin'ny dialog alohan'ny fitehirizana.
- **Famintinana**: valiny, hetsika voalohany tiana, valiny amin'ny e4/d4.

Fanamarihana: `OWN_MAX_ELO` = 2500 (voatombana). Calibrate vs Stockfish `UCI_Elo` 2400-3000 (1500 ms/hetsika): JORO hery feno ~ **2518 ±60**
(2400: 2480 ±103, 2600: 2463 ±104, 2800: 2621 ±108; 3000 saturated). `OwnBot.profile`: depth 14/16 ho an'ny 2350/2450; > 2450 = hery feno (tsy misy fetra depth, fotoana x1). Ny Elo > 2500 dia Stockfish.

## Fanatsarana hery (Search v2)
SEE (fakana very), countermove, history gravity, IID, razoring, RFP/LMP/futility, LMR araka ny history/improving, TT replacement, time management. Mifanandrina amin'ny dikan-teny taloha (60 ms/hetsika, lalao 40): ~+70..80 Elo. OwnBot manampy fotoana (x1..x2) ho an'ny Elo 2200..2600. Tsy mbola voatombana amin'ny Stockfish UCI_Elo.

## Search v3 / Eval v3
- Eval: lanja scalar (`Eval.W`), outpost, fandrosoana piyon, tombo-pitsipika amin'ny piyon; PST/material/W voatombana (Texel) avy amin'ny lalao ~53k toerana (Tuner).
- Search: singular extension, TT cutoff amin'ny qsearch.
- Fandrefesana Elo tena izy: `tools/calibrate.yml` (workflow dispatch) → JORO vs Stockfish `UCI_Elo` 2000–2600 (`tools/calibrate.py`, `tools/OwnUci.java`). Ny vokatra no hanitsy ny `OwnBot.profile`/`OWN_MAX_ELO`.

## Fitaovana fandrefesana (Project 2800)
- `tools/Bench.java`: `java -cp cls mg.chess.offline.own.Bench [depth=9] [movetime=60]` → nodes/nps/depth.
- `tools/sprt.py`: SPRT vaovao vs taloha (`.github/workflows/sprt.yml`).
- `tools/OwnUci.java` dia mamoaka `info depth/score/nodes` (ampiasain'ny sprt.py ho an'ny adjudication).
- Fandrosoana: `ROADMAP_2800.md`.
- `tools/sprt.py --dump FILE`: manoratra toerana milamina `FEN;valiny_fotsy` (ho an'ny Texel). `--label` ho an'ny summary.
- `.github/workflows/sprt.yml`: `variants` (SPRT maromaro miaraka), `base_tgz` foana = tgz mitovy (safidy ihany no hafa).
- `tools/SelfPlay.java` (data Texel), `tools/Texel.java` (tuner), `tools/apply_tuned.py` (manoratra ny vokatra ao amin'ny Eval.java), `.github/workflows/texel.yml`.
- `Eval2` (UCI): toetra vaovao ao amin'ny Eval (phalanx, backward, passed free-path, pawn storm, danger tsy misy queen); default 0.

## Fanatsarana fikarohana (default 0, SPRT isaky ny iray)
| Safidy UCI | Inona no ataony |
|---|---|
| `SeePrune` (+`SeeQuiet`) | esorina ny quiet SEE ratsy amin'ny depth ≤ 6 |
| `HistPrune` (+`HistPruneMul`) | esorina ny quiet history ratsy loatra amin'ny depth ≤ 4 |
| `Sing2` | singular: double extension (non-PV) sy negative extension |
| `LmrTT` | LMR +1 raha capture ny ttMove |
| `QsTT` | tehirizina ao amin'ny TT ny qsearch |
| `Iir` | internal iterative reduction, solon'ny IID |
| `TtEval` | ampiasaina ny score TT ho eval amin'ny RFP/NMP/futility |
| `Contempt` (cp) | ialana ny draw ho an'ny JORO (fomba filalaovana mitoloko) |

Fanamarinana eto an-toerana: `java -cp cls mg.chess.offline.own.Match <pairs> <ms> "<optsA>" "<optsB>"`
(tsy SPRT: mahita bug lehibe fa tsy mamaritra Elo kely).

## Fomba JORO (gambit / sacrifice) - project-57
Default 0 (tsy miova ny JORO raha tsy alefa; nodes bench depth 9 = 505153 mitovy amin'ny project-56).
| Safidy UCI | Inona no ataony |
|---|---|
| `JoroStyle` | Eval: bonus sacrifice (atk>=2, x`JoroSac`%) + onitra gambit (`JoroDev` cp isaky ny kapiteny tsy mbola nivoaka an'ny mpifanandrina, raha very material 50..400 cp ny sacrificer) ; Search: contempt `JoroContempt` raha `Contempt`=0 |
| `JoroSac` (100..300, 150) | % an'ny bonus sacrifice |
| `JoroDev` (0..20, 6) | cp isaky ny kapiteny tsy mivoaka |
| `JoroContempt` (0..60, 25) | ialana ny draw |
| `JoroBook` | `GambitBook.java`: King's/Vienna/Danish/Evans/Scotch/Smith-Morra/Blackmar-Diemer (Fotsy); Benko/Albin/Budapest/Two Knights (Mainty). OwnBot ihany (elo > 1700); tsy misy fiantraikany amin'ny SPRT |
SPRT: `variants: ["JoroStyle=1"]` (+ `["JoroStyle=1,JoroSac=200"]`...). Ekena raha tsy mihoatra ny ~-10 Elo amin'ny neutral.

## Gambit JORO: sacrifice mamaky ny fiarovana (project-58)
| Safidy UCI | Inona no ataony |
|---|---|
| `JoroHunt` (default 0) | **Eval:** raha very material 50..700 cp ny mpanafika (misy queen na fanafihana >= 3) dia mahazo bonus (mg) araka ny (a) isan'ny file manodidina ny mpanjaka tsy misy piyon (`JoroHuntHole`, 6 cp) sy (b) ny toerana handosirana ny mpanjaka (tsy voafehy / tsy voasakana) <= 2 (`JoroHuntFlight`, 8 cp), voafetra amin'ny `JoroHuntMax` (30). **Search:** ny hetsika mankany akaikin'ny mpanjaka mpifanandrina (<= 2 square) dia tsy esorina amin'ny pruning (bad capture, LMP, futility...) ary ahena kokoa ny LMR; ny sacrifice (capture SEE ratsy) akaikin'ny mpanjaka dia mahazo +1 ply (depth >= 5, ply <= 20). |
Fandrefesana (30 ms, 16 lalao, tabataba): `JoroHuntMax=70` = -338 Elo (be loatra), `JoroHuntMax=25-30` ~ 0, ny fikarohana irery ~ 0.
SPRT: `["JoroHunt=1"]`, `["JoroStyle=1,JoroHunt=1"]`, `["JoroHunt=1,JoroHuntMax=20"]`...

## Rook gambit JORO (project-59)
| Safidy UCI | Inona no ataony |
|---|---|
| `JoroRook` (default 0) | **Eval:** raha very material 50..700 cp ny mpanafika ary misy mpanafika >= 2 manodidina ny mpanjaka, ny rook mifanakaiky (contact; `JoroRookContact` 25 cp, antsasany raha tsy voaaro) na amin'ny file/rank misokatra mankany amin'ny mpanjaka (`JoroRookOpen` 10 cp) dia mahazo bonus (max `JoroRookMax` 40). **Search:** ny capture SEE ratsy (ny SEE no mande voalohany) dia tsy esorina raha aorian'ny hetsika dia misy rook contact/line misokatra (`rookGambit`), ary mahazo +1 ply (depth >= 5, ply <= 20). |
Fanamarinana style: `java -cp cls mg.chess.offline.own.StyleStats <pairs> <ms> "JoroStyle=1,JoroHunt=1,JoroRook=1" ""` -> check/100 hetsika, sacrifice/100 hetsika (very >= 100 cp aorian'ny 3 ply fa score >= -50), rookSac, mate, fandresena.
SPRT: `["JoroStyle=1,JoroHunt=1,JoroRook=1"]` (variant iray, prior foana raha vaovao).

## project-60: Iir + ContHist default 1 (SPRT H1)
- `Iir=1`: +14,5 Elo ±9,0 (3600 lalao, LLR +4,55, SPRT [0,10] a=b=0,1).
- `ContHist=1`: +15,7 Elo ±9,0 (3600 lalao, LLR +5,11).
- Tsy mandalo: `LmrCut` (~0), `LmrHist2` (+3,1, mankany H0). Mbola tsy voamarina: `ProbCut` (+5), `HistPrune` (+3) - averina amin'ny movetime 400.
- Bench depth 9: nodes=482251 (taloha 505153). Ny style JORO (`JoroStyle`, `JoroHunt`, `JoroRook`, `JoroBook`) mijanona default 0.
- Fitsapana "roa miaraka": `base_tgz=project-59-joro-rook.tgz`, `variants=[""]`.

## project-61: SPSA (`tools/spsa.py`, `.github/workflows/spsa.yml`)
- Chain maromaro (default 4) mahaleo tena; isaky ny iteration: theta+ vs theta- (`pairs`x2 lalao), ovaina theta mankany amin'ny nandresy. Vokatra = salanisan'ny chain (Polyak, 1/3 farany).
- Ny min/max/default dia alaina avy amin'ny safidy UCI (Params.java), ka tsy mila lisitra manokana.
- Fandefasana: Actions -> "SPSA (tuning parameter)". Default: RfpMargin, RfpMarginImp, RazorMargin, FutBase, FutMul, NmpBase, AspDelta, LmrBase, LmrDiv; 4 chain x 150 iteration x 12 lalao (~7200 lalao, ~2-5 ora/chain).
- Ny summary dia manome `SPRT variants: ["A=..,B=.."]` hapetaka mivantana ao amin'ny SPRT (`base_tgz` foana), ary `Hitohy: start={...}` hampiasaina ao amin'ny `start` raha tohizana.
- Fitsapana lojika (mock): mivondrona akaiky ny optimum (A 118/120, B 52/50, C 4/4, D 256/260). Tsy mbola nandefa tamin'ny motera tena izy.

## project-62: parameter SPSA (RfpMargin 74, RazorMargin 179, AspDelta 21)
- SPSA (4 chain, ~7200 lalao): chain mitovy lalana ho an'ny RfpMargin, RazorMargin, AspDelta (ambany noho ny default); FutBase/LmrBase/LmrDiv/RfpMarginImp tabataba (tsy novana).
- SPRT vs project-61: `RfpMargin=74,RazorMargin=179,AspDelta=21` = **H1**, +34,3 Elo ±15,6 (1200 lalao, LLR +4,70; mety ambony kokoa noho ny marina noho ny fijanonana aloha). Ny 8 parameter rehetra = +11,9 (tsy mazava): manamafy fa ny tabataba no manimba.
- Default vaovao ao amin'ny Params.java: RfpMargin 95->74, RazorMargin 260->179, AspDelta 40->21.

## project-63: Eval4 (default 0) + drafitra Texel/data eval
- `Eval4=1` (Params): bishop ratsy (piyon amin'ny loko mitovy, `W4_BADB_*`), knight/rook araka ny isan'ny piyon (`W4_NPAWN`, `W4_RPAWN`), rook voasakana ambadika (`W4_TRAPR`), scaling endgame (`W4_OCB` bishop loko mifanohitra, `W4_NOPAWN` mpandresy tsy misy piyon, lohasaha < 400 cp). Default 0: bench depth 9 nodes=410246 (tsy miova).
- Texel: group `w4` vaovao; `texel.yml` mamoaka `texel-tuned-project.tgz` (project + Eval.java voatombana), input `maxpos`.
- Fanamarihana: ny PST ankehitriny dia voatombana tamin'ny ~53k toerana ihany (770 parameter): overfit. Ny data be no tena fanatsarana.
- Test eto an-toerana (5691 toerana, 7 parameter w4): mandeha ny Texel -> tuned.txt -> apply_tuned.py; ny sanda tonga amin'ny faran'ny sakany (data kely loatra) ka tsy azo ampiasaina.

## project-65: Texel (val,pass,w,w3,w4) + Eval4 default 1
- Texel: 3 991 750 toerana, 67 parameter (val, pass, w, w3, w4), 8 pass: val 0,081894 -> 0,080818 (train 0,080586; tsy overfit).
- SPRT `Eval4=1` (tuned) vs project-63: **H1** +24,1 Elo +-16,0 (1200 lalao, LLR +2,89, [0,10] a=b=0,1).
- w4 voatombana: {BADB_MG 1, BADB_EG 0, NPAWN 5, RPAWN 0, TRAPR 7, OCB 17, NOPAWN 0} -> ny tombony dia avy amin'ny scaling endgame (OCB, tsy misy piyon) sy knight/piyon; tsy ilaina ny bishop ratsy / rook-piyon.
- Eval4 default 1. PST (tmg/teg) mbola tsy novana (Texel manaraka: groups=pst).
- Bench depth 9: nodes=488280. Tgz madio (tsy misy cls/, screen.*).

## project-66: Texel PST sparse (~20x haingana)
- Fahitana: ny Texel PST taloha dia 1 pass = ~4 ora (736 parameter x 2-3 fanandramana x 8M toerana): nijanona antsasany (log "PASS 1 changed=454" = TSY TAPITRA). val 0,081336 -> 0,081124 (-0,000212, pass antsasany).
- Ankehitriny: ny `groups=pst` dia mampiasa `sparse` (default true): isaky ny fanandramana dia averina kajy ny toerana misy ilay piece amin'io toerana io ihany (~6% ny toerana), marina tanteraka. Fitsapana: mitovy tanteraka amin'ny fomba taloha (changed=482, train 0,052589, tuned.txt mitovy) fa 2,0 min -> 0,1 min.
- Ny log dia manoratra "PASS n tapitra/TSY TAPITRA ... (a/b parameter, X min)". Azo ovaina: `-Dsparse=false` (fomba taloha).
- Tombana: pass iray ~15-25 min amin'ny 8M toerana -> azo atao 8+ pass ao anatin'ny 5 ora.

## project-68: Eval5 (default 0) - toetra vaovao 7, group Texel `w5`
| Toetra | Anarana | Inona no ataony |
|---|---|---|
| Rook ao ambadiky ny passer | `W5_RBP` | eg: rook amin'ny rakitra iray amin'ny passer (ny azy na ny mpifanandrina) ary ambany noho ny piyon |
| King safety: toerana handosirana | `W5_KFLIGHT` | raha atk>=2: danger += (3 - toerana handosirana tsy voafehy) x lanja (<= 2 sisa) |
| King safety: mpiaro akaiky | `W5_DEFPC` | danger -= % isaky ny piece mpiaro <= 2 square (hatramin'ny 3) |
| Space | `W5_SPACE` | mg: square azo antoka (c-f, ambaratonga 2-4) x isan'ny piece |
| Passer tsy azo atsahatra | `W5_UNSTOP` | eg: fitsipika ny efamira raha tsy misy piece ny mpifanandrina (x margin <= 4, voakajy ny tour) |
| Rook endgame | `W5_RSCALE` | scale/64 ho an'ny rook vs rook, tsy mihoatra ny 1 piyon ny fahasamihafana |
| Rook mifandray | `W5_CONNR` | mg + antsasany eg raha tsy misy sakana eo anelanelan'ny rook roa |
- Default 0: bench depth 9 nodes=488280 (mitovy amin'ny project-65/66), perft PASS.
- Symmetry (fotsy/mainty) voamarina: 3000 toerana, 0 tsy mitovy (Eval5=0 sy 1).
- Vidiny: evalRaw 12,0 -> 14,7 us (+22%); nps (tena izy) mety -5..-8%. Ny Texel/SPRT no hamaritra raha mendrika.
- Texel: `groups=...,w5` (mampandeha ny Eval5 ho azy). Sanda default (6,20,8,2,25,56,8) dia tombana fotsiny, tsy voatombana.
- Fanamarihana: ny PST voatombana (project-67) tsy ao anatin'ity tgz ity; ampifangaroina amin'ny `tuned.txt` PST.

## project-69: PST voatombana (project-67) ao amin'ny Eval5
- `tuned.txt` (PST pass 4, val 0,081954) napetraka tamin'ny `apply_tuned.py`: ny `tmg1-6` sy `teg1-6` ihany no niova; `vmg/veg/w/w2/w3/w4/pmg/peg` mitovy.
- Eval5 default 0 foana; `W5` mbola tsy voatombana. Mbola tsy voamarina eto: bench depth 9 (tokony hiova satria PST vaovao) sy perft.
- Manaraka: SPRT PST vaovao (base project-66), Texel `groups=w5`, SPRT `Eval5=1`.

## project-70: W5 voatombana (Texel groups=w5, data 4,0M toerana)
- W5 {6,20,8,2,25,56,8} -> {21,0,18,0,100,51,9}; val 0,082451 -> 0,082223 (-0,000228). Ny hafa rehetra tsy niova (PST project-69).
- Eval5 default 0 foana. Manaraka: SPRT Eval5=1 vs project-69 (elo0=-3, elo1=5).

## project-71: Eval5 tsy mandany zavatra tsy ilaina + UNSTOP fetra lehibe
- SPRT Eval5=1 vs project-69 (W5 voatombana, 1200 lalao): -4,9 ±15,8 Elo, tsy mbola mazava (LLR -0,73).
- `Eval.java`: `W5_SPACE` sy `W5_KFLIGHT` (tuned = 0) dia tsy kajiana intsony (`if (W5[...] != 0)`), ka tsy mandany `p.attacked` sy ny loop space. Mitovy ny vokatra (bench tsy miova, Eval5=1 sy 0). Tsy voamarina eto (tsy misy javac): alefaso bench/perft.
- `Texel.java`: fetra ambony ny `W5_UNSTOP` 100 -> 250 (nitsangana tamin'ny 100).
- Manaraka: Texel groups=w5 indray (prev_run_id), dia SPRT Eval5=1 vs project-69.
