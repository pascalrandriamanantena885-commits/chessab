package mg.chess.offline.own;

import java.util.Random;

/** Fikarohana: iterative deepening + PVS + TT + null move + LMR + quiescence. */
public final class Search {
    static final int INF = 32000, MATE = 30000, MATE_BOUND = MATE - 200;
    static final int MAXPLY = 96;
    static final int TT_BITS = 19;
    static final int[][] LMR = new int[64][64];

    static {
        for (int d = 1; d < 64; d++) for (int m = 1; m < 64; m++)
            LMR[d][m] = (int) (0.75 + Math.log(d) * Math.log(m) / 2.25);
    }

    public final Pos pos = new Pos();
    Eval ev;
    private final long[] tKey = new long[1 << TT_BITS];
    private final int[] tMove = new int[1 << TT_BITS];
    private final short[] tScore = new short[1 << TT_BITS];
    private final byte[] tDepth = new byte[1 << TT_BITS];
    private final byte[] tFlag = new byte[1 << TT_BITS]; // 1=exact 2=lower 3=upper
    private final int[][] killers = new int[MAXPLY + 2][2];
    private final int[][][] hist = new int[2][128][128];
    private final int[][] cmv = new int[128][128];          // countermove[prevFrom][prevTo]
    private final int[] moveAt = new int[MAXPLY + 2];
    private final int[] evalAt = new int[MAXPLY + 2];
    private final int[][] quietsTried = new int[MAXPLY + 2][64];
    private final int[] sb = new int[128];
    private final int[] gain = new int[40];
    static final int[] SEEV = {0, 100, 320, 330, 500, 900, 20000};
    private final int[][] mv = new int[MAXPLY + 2][256];
    private final int[][] sc = new int[MAXPLY + 2][256];

    long nodes;
    private long deadline;
    private boolean stop;
    private int rootMove, rootScore;
    int lastDepth;

    public Search(Eval ev) { this.ev = ev; }

    public void clear() {
        java.util.Arrays.fill(tKey, 0L);
        for (int[] k : killers) { k[0] = 0; k[1] = 0; }
        for (int[][] a : hist) for (int[] b : a) java.util.Arrays.fill(b, 0);
        for (int[] c : cmv) java.util.Arrays.fill(c, 0);
    }

    // ---------- SEE (static exchange evaluation) ----------
    private int leastAttacker(int to, int side) {
        final int[] b = sb;
        final int off = side << 3;
        if (side == 0) {
            int s1 = to - 15, s2 = to - 17;
            if ((s1 & 0x88) == 0 && b[s1] == Pos.P) return s1;
            if ((s2 & 0x88) == 0 && b[s2] == Pos.P) return s2;
        } else {
            int s1 = to + 15, s2 = to + 17;
            if ((s1 & 0x88) == 0 && b[s1] == (Pos.P | 8)) return s1;
            if ((s2 & 0x88) == 0 && b[s2] == (Pos.P | 8)) return s2;
        }
        for (int d : Pos.KN) { int s = to + d; if ((s & 0x88) == 0 && b[s] == (Pos.N | off)) return s; }
        for (int d : Pos.BD) {
            int s = to + d;
            while ((s & 0x88) == 0) { int p = b[s]; if (p != 0) { if (p == (Pos.B | off)) return s; break; } s += d; }
        }
        for (int d : Pos.RD) {
            int s = to + d;
            while ((s & 0x88) == 0) { int p = b[s]; if (p != 0) { if (p == (Pos.R | off)) return s; break; } s += d; }
        }
        for (int d : Pos.BD) {
            int s = to + d;
            while ((s & 0x88) == 0) { int p = b[s]; if (p != 0) { if (p == (Pos.Q | off)) return s; break; } s += d; }
        }
        for (int d : Pos.RD) {
            int s = to + d;
            while ((s & 0x88) == 0) { int p = b[s]; if (p != 0) { if (p == (Pos.Q | off)) return s; break; } s += d; }
        }
        for (int d : Pos.KG) { int s = to + d; if ((s & 0x88) == 0 && b[s] == (Pos.K | off)) return s; }
        return -1;
    }

    /** SEE ho an'ny fakana m (alohan'ny make). Miverina cp araka ny mpilalao mihetsika. */
    int see(int m) {
        final int from = Pos.from(m), to = Pos.to(m);
        System.arraycopy(pos.b, 0, sb, 0, 128);
        final int us = pos.side;
        final boolean ep = (Pos.flag(m) & Pos.F_EP) != 0;
        int victim = ep ? Pos.P : (sb[to] & 7);
        int cur = sb[from] & 7;
        if (ep) sb[to + (us == 0 ? -16 : 16)] = 0;
        int d = 0;
        gain[0] = SEEV[victim];
        if (Pos.promo(m) != 0) { gain[0] += SEEV[Pos.promo(m)] - 100; cur = Pos.promo(m); }
        sb[from] = 0;
        sb[to] = cur | (us << 3);
        int side = us;
        boolean pruned = false;
        while (true) {
            side ^= 1;
            int sq = leastAttacker(to, side);
            if (sq < 0) break;
            d++;
            if (d >= 38) { pruned = true; break; }
            gain[d] = SEEV[cur] - gain[d - 1];
            if (Math.max(-gain[d - 1], gain[d]) < 0) { pruned = true; break; }
            cur = sb[sq] & 7;
            sb[sq] = 0;
        }
        if (pruned) d--;
        while (d > 0) { gain[d - 1] = -Math.max(-gain[d - 1], gain[d]); d--; }
        return gain[0];
    }

    private static int gravity(int h, int bonus) {
        return h + bonus - h * Math.abs(bonus) / 16384;
    }

    private void checkTime() {
        if (System.nanoTime() > deadline) stop = true;
    }

    private static int scoreToTT(int s, int ply) { return s >= MATE_BOUND ? s + ply : s <= -MATE_BOUND ? s - ply : s; }
    private static int scoreFromTT(int s, int ply) { return s >= MATE_BOUND ? s - ply : s <= -MATE_BOUND ? s + ply : s; }

    private int qsearch(int alpha, int beta, int ply) {
        if ((++nodes & 2047) == 0) checkTime();
        if (stop) return 0;
        final boolean inCheck = pos.inCheck();
        if (ply >= MAXPLY) return ev.eval(pos);
        int stand = -INF;
        if (!inCheck) {
            stand = ev.eval(pos);
            if (stand >= beta) return stand;
            if (stand > alpha) alpha = stand;
        }
        int[] ms = mv[ply], ss = sc[ply];
        int n = inCheck ? pos.genAll(ms) : pos.gen(ms, true);
        for (int i = 0; i < n; i++) {
            int m = ms[i];
            int victim = (Pos.flag(m) & Pos.F_EP) != 0 ? Pos.P : (pos.b[Pos.to(m)] & 7);
            int att = pos.b[Pos.from(m)] & 7;
            ss[i] = victim * 16 - att + (Pos.promo(m) != 0 ? 200 : 0);
        }
        int legal = 0, best = stand;
        for (int i = 0; i < n; i++) {
            int bi = i;
            for (int j = i + 1; j < n; j++) if (ss[j] > ss[bi]) bi = j;
            if (bi != i) { int t = ms[i]; ms[i] = ms[bi]; ms[bi] = t; t = ss[i]; ss[i] = ss[bi]; ss[bi] = t; }
            int m = ms[i];
            if (!inCheck && Pos.promo(m) == 0) {
                int victim = (Pos.flag(m) & Pos.F_EP) != 0 ? Pos.P : (pos.b[Pos.to(m)] & 7);
                if (stand + Eval.V_MG[victim] + 200 < alpha) continue; // delta pruning
                int att = pos.b[Pos.from(m)] & 7;
                if (SEEV[victim] < SEEV[att] && see(m) < 0) continue;   // fakana very
            }
            if (!pos.make(m)) continue;
            legal++;
            int score = -qsearch(-beta, -alpha, ply + 1);
            pos.unmake();
            if (stop) return 0;
            if (score > best) {
                best = score;
                if (score > alpha) { alpha = score; if (score >= beta) return score; }
            }
        }
        if (inCheck && legal == 0) return -MATE + ply;
        return best;
    }

    private int search(int alpha, int beta, int depth, int ply, boolean nullOk) {
        if ((++nodes & 2047) == 0) checkTime();
        if (stop) return 0;
        final boolean pv = beta - alpha > 1;
        final boolean root = ply == 0;
        if (!root) {
            if (pos.half >= 100 || pos.repeated()) return 0;
            alpha = Math.max(alpha, -MATE + ply);
            beta = Math.min(beta, MATE - ply - 1);
            if (alpha >= beta) return alpha;
        }
        final boolean inCheck = pos.inCheck();
        if (inCheck && ply < MAXPLY - 8) depth++;
        if (depth <= 0) return qsearch(alpha, beta, ply);
        if (ply >= MAXPLY - 2) return ev.eval(pos);

        final int idx = (int) (pos.key & ((1 << TT_BITS) - 1));
        int ttMove = 0;
        if (tKey[idx] == pos.key) {
            ttMove = tMove[idx];
            if (!pv && !root && tDepth[idx] >= depth) {
                int ts = scoreFromTT(tScore[idx], ply);
                int fl = tFlag[idx];
                if (fl == 1 || (fl == 2 && ts >= beta) || (fl == 3 && ts <= alpha)) return ts;
            }
        }
        final int staticEval = inCheck ? -INF : ev.eval(pos);
        evalAt[ply] = staticEval;
        final boolean improving = !inCheck && ply >= 2 && evalAt[ply - 2] != -INF && staticEval > evalAt[ply - 2];
        if (!pv && !inCheck && !root) {
            // reverse futility
            if (depth <= 7 && staticEval - (improving ? 70 : 95) * depth >= beta && Math.abs(beta) < MATE_BOUND)
                return staticEval - (improving ? 70 : 95) * depth;
            // razoring
            if (depth <= 2 && staticEval + 260 * depth < alpha) {
                int v = qsearch(alpha, beta, ply);
                if (v <= alpha) return v;
            }
            // null move
            if (nullOk && depth >= 3 && staticEval >= beta && pos.hasNonPawn(pos.side)) {
                int r = 3 + depth / 4 + Math.min(2, (staticEval - beta) / 200);
                moveAt[ply] = 0;
                pos.makeNull();
                int s = -search(-beta, -beta + 1, depth - 1 - r, ply + 1, false);
                pos.unmakeNull();
                if (stop) return 0;
                if (s >= beta) return s >= MATE_BOUND ? beta : s;
            }
        }
        // internal iterative deepening
        if (ttMove == 0 && depth >= 5 && !root && (pv || staticEval + 100 >= beta)) {
            search(alpha, beta, depth - 2, ply, false);
            if (stop) return 0;
            if (tKey[idx] == pos.key) ttMove = tMove[idx];
        }

        int[] ms = mv[ply], ss = sc[ply];
        int n = pos.genAll(ms);
        final int side = pos.side;
        final int prevMove = ply > 0 ? moveAt[ply - 1] : 0;
        final int counter = prevMove != 0 ? cmv[Pos.from(prevMove)][Pos.to(prevMove)] : 0;
        for (int i = 0; i < n; i++) {
            int m = ms[i];
            int s;
            if (m == ttMove) s = 10_000_000;
            else if ((Pos.flag(m) & Pos.F_CAP) != 0) {
                int victim = (Pos.flag(m) & Pos.F_EP) != 0 ? Pos.P : (pos.b[Pos.to(m)] & 7);
                int att = pos.b[Pos.from(m)] & 7;
                int mvv = victim * 16 - att + (Pos.promo(m) == Pos.Q ? 100 : 0);
                if (SEEV[victim] >= SEEV[att]) s = 2_000_000 + mvv;
                else s = see(m) >= 0 ? 2_000_000 + mvv : -2_000_000 + mvv;
            } else if (Pos.promo(m) != 0) s = Pos.promo(m) == Pos.Q ? 1_900_000 : -3_000_000;
            else if (m == killers[ply][0]) s = 1_000_000;
            else if (m == killers[ply][1]) s = 900_000;
            else if (m == counter) s = 800_000;
            else s = hist[side][Pos.from(m)][Pos.to(m)];
            ss[i] = s;
        }
        int best = -INF, bestMove = 0, legal = 0, nq = 0;
        final int origAlpha = alpha;
        final int[] tried = quietsTried[ply];
        for (int i = 0; i < n; i++) {
            int bi = i;
            for (int j = i + 1; j < n; j++) if (ss[j] > ss[bi]) bi = j;
            if (bi != i) { int t = ms[i]; ms[i] = ms[bi]; ms[bi] = t; t = ss[i]; ss[i] = ss[bi]; ss[bi] = t; }
            int m = ms[i];
            final boolean quiet = (Pos.flag(m) & Pos.F_CAP) == 0 && Pos.promo(m) == 0;
            final int hs = quiet ? hist[side][Pos.from(m)][Pos.to(m)] : 0;
            final boolean badCap = !quiet && ss[i] < -1_000_000 && ss[i] > -2_500_000;
            if (!root && !pv && !inCheck && legal > 0 && best > -MATE_BOUND) {
                if (badCap && depth <= 5 && ss[i] != 10_000_000) continue; // fakana very amin'ny depth fohy
                if (quiet) {
                    if (depth <= 6 && legal > (improving ? 5 : 3) + depth * depth) continue;     // late move pruning
                    if (depth <= 6 && staticEval + 90 + 90 * depth <= alpha && hs < 4000) continue; // futility
                }
            }
            if (!pos.make(m)) continue;
            legal++;
            moveAt[ply] = m;
            final boolean givesCheck = pos.inCheck();
            int score;
            if (legal == 1) {
                score = -search(-beta, -alpha, depth - 1, ply + 1, true);
            } else {
                int red = 0;
                if (depth >= 3 && legal > 2 && !inCheck && !givesCheck && (quiet || badCap)) {
                    red = LMR[Math.min(depth, 63)][Math.min(legal, 63)];
                    if (pv) red--;
                    if (!improving) red++;
                    if (quiet) {
                        if (hs > 6000) red--;
                        else if (hs < -4000) red++;
                        if (m == killers[ply][0] || m == killers[ply][1] || m == counter) red--;
                    }
                    if (red < 0) red = 0;
                    if (red > depth - 2) red = depth - 2;
                }
                score = -search(-alpha - 1, -alpha, depth - 1 - red, ply + 1, true);
                if (score > alpha && red > 0) score = -search(-alpha - 1, -alpha, depth - 1, ply + 1, true);
                if (score > alpha && score < beta) score = -search(-beta, -alpha, depth - 1, ply + 1, true);
            }
            pos.unmake();
            if (stop) return 0;
            if (quiet && nq < 63) tried[nq++] = m;
            if (score > best) {
                best = score; bestMove = m;
                if (root) { rootMove = m; rootScore = score; }
                if (score > alpha) {
                    alpha = score;
                    if (score >= beta) {
                        if (quiet) {
                            if (killers[ply][0] != m) { killers[ply][1] = killers[ply][0]; killers[ply][0] = m; }
                            if (prevMove != 0) cmv[Pos.from(prevMove)][Pos.to(prevMove)] = m;
                            int bonus = Math.min(1600, 36 * depth * depth);
                            int[] h = hist[side][Pos.from(m)];
                            h[Pos.to(m)] = gravity(h[Pos.to(m)], bonus);
                            for (int q = 0; q < nq - 1; q++) {
                                int qm = tried[q];
                                int[] hq = hist[side][Pos.from(qm)];
                                hq[Pos.to(qm)] = gravity(hq[Pos.to(qm)], -bonus);
                            }
                        }
                        break;
                    }
                }
            }
        }
        if (legal == 0) return inCheck ? -MATE + ply : 0;
        final boolean sameKey = tKey[idx] == pos.key;
        if (!sameKey || depth + 2 >= tDepth[idx] || best > origAlpha && best < beta) {
            tKey[idx] = pos.key;
            if (bestMove != 0 || !sameKey) tMove[idx] = bestMove;
            tDepth[idx] = (byte) Math.min(depth, 100);
            tScore[idx] = (short) scoreToTT(best, ply);
            tFlag[idx] = (byte) (best >= beta ? 2 : best > origAlpha ? 1 : 3);
        }
        return best;
    }

    public static final class Result {
        public int move; public int score; public int depth; public long nodes;
    }

    /** Fikarohana mahazatra: iterative deepening hatramin'ny maxDepth na fotoana. */
    public Result think(int maxDepth, long moveTimeMs) {
        long t0 = System.nanoTime();
        deadline = t0 + moveTimeMs * 1_000_000L;
        double softF = 0.5; int lastBest = 0; int stable = 0;
        long softBase = moveTimeMs * 1_000_000L;
        stop = false; nodes = 0; rootMove = 0;
        Result res = new Result();
        int[] ms = new int[256];
        int n = pos.genAll(ms);
        int cnt = 0, only = 0;
        for (int i = 0; i < n; i++) if (pos.make(ms[i])) { pos.unmake(); cnt++; only = ms[i]; }
        if (cnt == 0) return res;
        res.move = only;
        if (cnt == 1) { res.depth = 0; return res; }
        int prev = 0;
        for (int d = 1; d <= maxDepth && d < MAXPLY - 10; d++) {
            int alpha = -INF, beta = INF, delta = 40;
            if (d >= 5) { alpha = prev - delta; beta = prev + delta; }
            int score;
            while (true) {
                score = search(alpha, beta, d, 0, false);
                if (stop) break;
                if (score <= alpha) { alpha = Math.max(-INF, alpha - delta); delta *= 2; if (delta > 800) alpha = -INF; }
                else if (score >= beta) { beta = Math.min(INF, beta + delta); delta *= 2; if (delta > 800) beta = INF; }
                else break;
            }
            if (stop) break;
            if (rootMove == lastBest) stable++; else { stable = 0; softF = 0.75; }
            lastBest = rootMove;
            if (stable >= 3) softF = 0.4;
            res.move = rootMove; res.score = score; res.depth = d; prev = score;
            if (Math.abs(score) > MATE_BOUND && d >= 6) break;
            if (System.nanoTime() > t0 + (long) (softBase * softF)) break;
        }
        res.nodes = nodes;
        lastDepth = res.depth;
        return res;
    }

    /** Fikarohana ho an'ny bot malemy: jerena daholo ny hetsika amin'ny depth voafetra, ampiana "tabataba" (centipawn). */
    public Result thinkWeak(int depth, int noiseCp, long moveTimeMs, Random rnd) {
        long t0 = System.nanoTime();
        deadline = t0 + moveTimeMs * 1_000_000L;
        stop = false; nodes = 0;
        Result res = new Result();
        int[] ms = new int[256];
        int n = pos.genAll(ms);
        int bestMv = 0; double bestVal = -1e18; int bestScore = 0;
        for (int i = 0; i < n; i++) {
            int m = ms[i];
            if (!pos.make(m)) continue;
            int s;
            s = -search(-INF, INF, Math.max(0, depth - 1), 1, true);
            pos.unmake();
            if (stop && bestMv != 0) break;
            if (stop) s = 0;
            double v = s;
            if (Math.abs(s) < MATE_BOUND) v += rnd.nextGaussian() * noiseCp;
            else if (s > 0) v += 5000; // mate azo: aza very very mba tsy hita
            if (v > bestVal) { bestVal = v; bestMv = m; bestScore = s; }
        }
        res.move = bestMv; res.score = bestScore; res.depth = depth; res.nodes = nodes;
        return res;
    }
}
