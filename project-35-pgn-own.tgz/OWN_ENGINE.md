# Motera manokana (tsy miankina amin'ny Stockfish)

Toerana: `app/src/main/java/mg/chess/offline/own/` (Java madio, tsy mampiasa Android na chesslib).

- `Pos.java`   : board 0x88, hetsika marina, make/unmake, zobrist, repetition (perft voamarina).
- `Eval.java`  : evaluation (material, PST, piyon, mobility, fiarovana mpanjaka, fanafihana) + TOETRA: a/s/d/q/t.
- `Search.java`: iterative deepening, PVS, TT, null move, LMR, futility, quiescence; `thinkWeak` ho an'ny Elo ambany.
- `OwnBot.java`: API ho an'ny app + `profile(elo)` = {depth, tabataba cp}.

Fampiasana: `Engine.bestMove` -> opening book (Personality) -> OwnBot raha `OWN_ENGINE && elo <= OWN_MAX_ELO` (Bots.kt).
Ny Stockfish dia mijanona ho an'ny Review / Why / analyze sy ny bot > OWN_MAX_ELO.
Hanajanona: `const val OWN_ENGINE = false` ao amin'ny Bots.kt.

## Bot avy amin'ny PGN (`PgnBot.java`)
Ny motera manokana no mamorona bot avy amin'ny PGN, tsy mila Stockfish (ChessViewModel.analyzePgnPlayerOwn, raha `OWN_ENGINE`):
- **Book / opening favorite**: ny hetsika tena nataon'ilay mpilalao tamin'ny lalao ROHY (hatramin'ny 300), 24 ply voalohany, voarakitra amin'ny hash an'ny toerana (mahafantatra transposition). Lanja: fandresena 1.5, nul 1.2, resy 1.0; safidy ^1.5 (tia ny favorite). Tehirizina ao `Bot.book` (`<hash>:<uci>:<isa>`, <= 400) ary ampiasain'ny `Engine.bestMove` alohan'ny katalaogy opening.
- **Fomba / toetra** (a,s,d,q,t): `Personality.deriveStyle` amin'ny lalao rehetra (salanisa), ampiasain'ny `Eval`.
- **Elo**: ACPL amin'ny fikarohana an'ny motera manokana (hetsika 60 voafantina, depth 5), formula `3100*exp(-0.0086*ACPL)` (mitovy amin'ny Review), ampifangaroina amin'ny Elo ao amin'ny PGN raha misy. TSY mbola voatombana amin'ny lalao tena izy: azo ovaina eo amin'ny dialog alohan'ny fitehirizana.
- **Famintinana**: valiny, hetsika voalohany tiana, valiny amin'ny e4/d4.

Fanamarihana: `OWN_MAX_ELO` = 2600 (dingana depth 11..16 ho an'ny 2150-2650). Ny Elo ao `OwnBot.profile` dia vonjimaika. Tsy maintsy tombanana amin'ny Stockfish `UCI_Elo`
(lalao 200+) ary ovaina ny depth/tabataba mba hitovy ny Elo ao amin'ny app.

## Fanatsarana hery (Search v2)
SEE (fakana very), countermove, history gravity, IID, razoring, RFP/LMP/futility, LMR araka ny history/improving, TT replacement, time management. Mifanandrina amin'ny dikan-teny taloha (60 ms/hetsika, lalao 40): ~+70..80 Elo. OwnBot manampy fotoana (x1..x2) ho an'ny Elo 2200..2600. Tsy mbola voatombana amin'ny Stockfish UCI_Elo.
