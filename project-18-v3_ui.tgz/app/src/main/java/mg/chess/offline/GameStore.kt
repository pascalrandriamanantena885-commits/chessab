package mg.chess.offline

import android.content.Context
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class TimeControl(val label: String, val baseMin: Int, val incSec: Int)

val TIME_CONTROLS = listOf(
    TimeControl("Tsy misy", 0, 0),
    TimeControl("1+0", 1, 0),
    TimeControl("3+0", 3, 0),
    TimeControl("3+2", 3, 2),
    TimeControl("5+0", 5, 0),
    TimeControl("10+0", 10, 0),
    TimeControl("15+10", 15, 10),
)

data class GameRecord(
    val id: Long,
    val botId: String?,
    val humanWhite: Boolean,
    val baseMs: Long,
    val incMs: Long,
    val moves: List<String>,
    val whiteMs: Long,
    val blackMs: Long,
    val result: String?,   // null = mbola mitohy
    val updated: Long,
    /** FEN fanombohana (edit board); START_FEN raha lalao mahazatra. */
    val startFen: String = START_FEN
)

/** Fitehirizana lalao: rakitra JSON iray isaky ny lalao ao amin'ny filesDir/games. */
class GameStore(ctx: Context) {
    private val dir = File(ctx.filesDir, "games").apply { mkdirs() }

    /** Soratana ao amin'ny filaharana (tsy misakana ny main thread). */
    fun save(r: GameRecord) { DiskQueue.run { write(r) } }

    private fun write(r: GameRecord) {
        try {
            val o = JSONObject()
            o.put("id", r.id)
            if (r.botId != null) o.put("botId", r.botId)
            o.put("humanWhite", r.humanWhite)
            o.put("baseMs", r.baseMs)
            o.put("incMs", r.incMs)
            o.put("moves", JSONArray(r.moves))
            o.put("whiteMs", r.whiteMs)
            o.put("blackMs", r.blackMs)
            if (r.result != null) o.put("result", r.result)
            o.put("updated", r.updated)
            if (r.startFen != START_FEN) o.put("startFen", r.startFen)
            val text = o.toString()
            val target = File(dir, "${r.id}.json")
            val tmp = File(dir, "${r.id}.tmp")
            tmp.writeText(text)
            // Raha tsy mety ny rename (ohatra fanovana filesystem), soratana mivantana
            if (!tmp.renameTo(target)) { target.writeText(text); tmp.delete() }
        } catch (e: Exception) {
            Log.w("GameStore", "tsy voatahiry ny lalao ${r.id}", e)
        }
    }

    fun list(): List<GameRecord> {
        DiskQueue.flush()
        return listNow()
    }

    private fun listNow(): List<GameRecord> =
        (dir.listFiles { f -> f.name.endsWith(".json") } ?: emptyArray())
            .mapNotNull { parse(it) }
            .sortedByDescending { it.updated }

    fun delete(id: Long) { DiskQueue.run { File(dir, "$id.json").delete() } }

    private fun parse(f: File): GameRecord? = try {
        val o = JSONObject(f.readText())
        val arr = o.getJSONArray("moves")
        GameRecord(
            o.getLong("id"),
            if (o.has("botId")) o.getString("botId") else null,
            o.getBoolean("humanWhite"),
            o.getLong("baseMs"), o.getLong("incMs"),
            List(arr.length()) { arr.getString(it) },
            o.getLong("whiteMs"), o.getLong("blackMs"),
            if (o.has("result")) o.getString("result") else null,
            o.optLong("updated", o.getLong("id")),
            o.optString("startFen", START_FEN)
        )
    } catch (e: Exception) {
        Log.w("GameStore", "rakitra simba: ${f.name}", e)
        null
    }
}
