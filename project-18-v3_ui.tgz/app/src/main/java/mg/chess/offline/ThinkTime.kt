package mg.chess.offline

import kotlin.math.max
import kotlin.math.min

/**
 * Fitantanana ny fotoana fisainan'ny bot, mifanaraka amin'ny ora (toy ny olona):
 * - Ora lava (10+ min): mandinika lalina, tsy maika => fotoana/depth lehibe kokoa.
 * - Blitz/Bullet: tsy ampy fotoana handinihana ela => fohy ny fisainana, mihena ny depth (kivy kokoa).
 * - Mijery ny ora sisa + increment, ny dingan'ny lalao (fanokafana haingana, middlegame lalina), ary
 *   rehefa mahory ny ora (time pressure) dia mihazakazaka.
 */
object ThinkTime {
    /** Anton'ny ora: 1.0 = ora antonony (5 min). */
    fun controlFactor(baseMs: Long): Double {
        val m = baseMs / 60000.0
        return when {
            m <= 1.0 -> 0.4
            m <= 2.0 -> 0.55
            m <= 3.0 -> 0.75
            m <= 5.0 -> 1.0
            m <= 10.0 -> 2.0
            m <= 15.0 -> 2.8
            else -> 3.5
        }
    }

    /** Fotoana (ms) hisainan'ny bot amin'ity hetsika ity. */
    fun budget(bot: Bot, remainingMs: Long, incMs: Long, baseMs: Long, ply: Int, clock: Boolean): Int {
        if (!clock) return bot.movetimeMs
        var comfort = bot.movetimeMs * controlFactor(baseMs)
        comfort *= when {
            ply < 10 -> 0.5          // fanokafana: haingana
            ply < 60 -> 1.25         // middlegame: lalina
            ply > 90 -> 0.9
            else -> 1.0
        }
        val movesLeft = if (ply < 60) 30.0 else 22.0
        var share = remainingMs / movesLeft + 0.7 * incMs
        if (remainingMs < 8_000L) share = min(share, remainingMs / 18.0 + 0.5 * incMs) // time pressure
        if (PowerSaver.active) comfort *= 0.5   // mode baterie: fisainana fohy kokoa
        val mt = min(comfort, share * 0.9)
        val hardCap = max(40.0, remainingMs / 4.0)
        return min(mt, hardCap).toInt().coerceIn(40, 20_000)
    }

    /** Ratio fotoana / fotoana fototra an'ny Elo: >1 lalina kokoa, <1 maika. */
    fun ratio(bot: Bot): Double = bot.movetimeMs.toDouble() / movetimeForElo(bot.elo).coerceAtLeast(1)

    /** Fanitsiana depth araka ny ratio. */
    fun depthBonus(bot: Bot): Int {
        val r = ratio(bot)
        return when {
            r >= 3.0 -> 2
            r >= 1.6 -> 1
            r <= 0.5 -> -2
            r <= 0.8 -> -1
            else -> 0
        }
    }
}
