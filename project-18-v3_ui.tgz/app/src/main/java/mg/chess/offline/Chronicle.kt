package mg.chess.offline

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val DECISIVE = setOf("1-0", "0-1")
private val FINISHED = setOf("1-0", "0-1", "1/2-1/2")

/** Isan'ny titre (tompon-daka) isaky ny mpilalao (lakile = Participant.key()). Champion = 2 na maro. */
fun championTitles(tours: List<Tournament>): Map<String, Int> {
    val m = HashMap<String, Int>()
    for (t in tours) {
        val k = t.player(t.champion)?.key() ?: continue
        m[k] = (m[k] ?: 0) + 1
    }
    return m
}

const val CHAMPION_MIN_TITLES = 2

private fun winnerId(m: TMatch): String? = when (m.result) { "1-0" -> m.whiteId; "0-1" -> m.blackId; else -> null }

private fun tcText(t: Tournament): String {
    if (t.baseMs <= 0) return "Tsy misy ora"
    val cat = when {
        t.baseMs < 180_000L -> "Bullet"
        t.baseMs < 600_000L -> "Blitz"
        else -> "Rapid"
    }
    return "${t.baseMs / 60000}+${t.incMs / 1000} $cat"
}

private fun formatText(t: Tournament): String = when {
    t.isSwiss -> "Swiss"
    t.isDouble -> "Double elimination"
    else -> "Cup"
}

private fun finalMatches(t: Tournament): List<TMatch> {
    val fm = if (t.isDouble) t.matches.filter { it.stage.startsWith("D") && it.group == 2 }
    else t.matches.filter { it.stage == "KO2" }
    return fm.filter { it.result in FINISHED }.sortedBy { it.id }
}

private fun scoreLine(t: Tournament, m: TMatch): String =
    "${t.name(m.whiteId)} ${m.result} ${t.name(m.blackId)}"

/** Zava-niavaka tamin'ny fifaninanana (soratra). titleNo = laharan'ny titre an'ny mpandresy. */
fun chronicleHighlights(t: Tournament, titleNo: Int): List<String> {
    val out = ArrayList<String>()
    val games = t.matches.filter { it.result in FINISHED && it.moves.size >= 2 }
    val champ = t.player(t.champion)
    if (champ != null) {
        var w = 0; var d = 0; var l = 0
        for (m in games) {
            val me = m.whiteId == champ.id
            if (!me && m.blackId != champ.id) continue
            when (m.result) {
                "1/2-1/2" -> d++
                "1-0" -> if (me) w++ else l++
                else -> if (me) l++ else w++
            }
        }
        out += "🏆 ${champ.name}: titre faha-$titleNo · $w fandresena, $d draw, $l faharesena" + (if (l == 0 && w > 0) " - tsy resy mihitsy!" else "")
    }
    val dec = games.filter { it.result in DECISIVE }
    dec.minByOrNull { it.moves.size }?.let { m ->
        out += "⚡ Fandresena haingana: ${t.name(winnerId(m))} tamin'ny hetsika ${(m.moves.size + 1) / 2} (${matchStageLabel(m)})"
    }
    games.maxByOrNull { it.moves.size }?.let { m ->
        out += "⏳ Lalao lava indrindra: ${t.name(m.whiteId)} - ${t.name(m.blackId)}, hetsika ${(m.moves.size + 1) / 2} (${m.result})"
    }
    var best: TMatch? = null; var bestDiff = 99
    for (m in dec) {
        val wn = t.player(winnerId(m)); val ln = t.player(if (winnerId(m) == m.whiteId) m.blackId else m.whiteId)
        if (wn == null || ln == null) continue
        val diff = ln.elo - wn.elo
        if (diff > bestDiff) { bestDiff = diff; best = m }
    }
    best?.let { m ->
        val wn = t.player(winnerId(m))!!
        val ln = t.player(if (winnerId(m) == m.whiteId) m.blackId else m.whiteId)!!
        out += "😮 Fahatalanjonana: ${wn.name} (${wn.elo}) nandresy ${ln.name} (${ln.elo})"
    }
    val draws = games.count { it.result == "1/2-1/2" }
    if (draws > 0) out += "🤝 Draw: $draws amin'ny lalao ${games.size}"
    val lines = t.playerLines()
    lines.filter { it.brilliant > 0 }.maxByOrNull { it.brilliant }?.let { out += "✨ Brilliant (!!) betsaka indrindra: ${t.name(it.id)} - ${it.brilliant}" }
    lines.filter { it.accuracy != null && it.played >= 2 }.maxByOrNull { it.accuracy ?: 0.0 }?.let {
        out += "🎖 Précision ambony indrindra: ${t.name(it.id)} - ${(it.accuracy ?: 0.0).toInt()}%"
    }
    lines.filter { it.blunder > 0 }.maxByOrNull { it.blunder }?.let { out += "💥 Blunder betsaka indrindra: ${t.name(it.id)} - ${it.blunder}" }
    return out
}

@Composable
fun ChronicleScreen(vm: ChessViewModel) {
    BackHandler { vm.toTourList() }
    vm.tourVersion
    val cs = MaterialTheme.colorScheme
    val chrono = vm.tournaments.filter { it.champion != null }.sortedBy { it.updated }
    // laharan'ny titre isaky ny fifaninanana (araka ny filaharana)
    val titleNo = HashMap<Long, Int>()
    run {
        val c = HashMap<String, Int>()
        for (t in chrono) {
            val k = t.player(t.champion)?.key() ?: continue
            c[k] = (c[k] ?: 0) + 1
            titleNo[t.id] = c[k] ?: 1
        }
    }
    val done = chrono.reversed()
    val fmt = remember { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()) }
    var open by remember { mutableStateOf(setOf<Long>()) }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { ScreenTitle("Historique", onBack = { vm.toTourList() }) }
        if (done.isEmpty()) item { Text("Mbola tsy misy fifaninanana vita. Ho hita eto ny tantaran'ny fifaninanana rehetra rehefa vita izy.") }
        items(done, key = { it.id }) { t ->
            val pd = t.podium()
            val finals = finalMatches(t)
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = cs.surfaceContainer)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(t.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(
                        fmt.format(Date(t.updated)) + " · ${t.players.size} mpilalao · ${formatText(t)} · ${tcText(t)}",
                        fontSize = 12.sp, color = cs.onSurfaceVariant
                    )
                    if (pd != null) {
                        val rows = listOf("🥇" to pd.first, "🥈" to pd.second, "🥉" to t.bronze())
                        for ((medal, id) in rows) {
                            val p = t.player(id) ?: continue
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(medal, fontSize = 18.sp)
                                Spacer(Modifier.width(6.dp))
                                ClipAvatar(p, 26.dp)
                                Spacer(Modifier.width(8.dp))
                                Text(p.name, fontWeight = if (medal == "🥇") FontWeight.Bold else FontWeight.Normal, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                    if (finals.isNotEmpty()) {
                        Text("Match finale", fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
                        for (m in finals) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    scoreLine(t, m) + " · hetsika ${(m.moves.size + 1) / 2}",
                                    Modifier.weight(1f), fontSize = 13.sp
                                )
                                if (m.moves.isNotEmpty()) OutlinedButton({ vm.openTour(t); vm.reviewTourMatch(m) }) { Text("Jereo") }
                            }
                        }
                    }
                    val hl = chronicleHighlights(t, titleNo[t.id] ?: 1)
                    if (hl.isNotEmpty()) {
                        Text("Zava-niavaka", fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
                        for (h in hl) Text(h, fontSize = 13.sp)
                    }
                    val isOpen = t.id in open
                    Text(
                        if (isOpen) "Andiany rehetra ▴" else "Andiany rehetra ▾",
                        color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                        modifier = Modifier.padding(top = 4.dp).clickable { open = if (isOpen) open - t.id else open + t.id }
                    )
                    if (isOpen) {
                        val stages = LinkedHashMap<String, MutableList<TMatch>>()
                        for (m in t.matches.sortedBy { it.id }) {
                            if (m.result !in FINISHED) continue
                            stages.getOrPut(matchStageLabel(m)) { ArrayList() }.add(m)
                        }
                        for ((label, ms) in stages) {
                            Text(label, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                            for (m in ms) Text(scoreLine(t, m), fontSize = 12.sp, color = cs.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}
