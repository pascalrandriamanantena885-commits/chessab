package mg.chess.offline

import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.move.MoveList
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Hetsika UCI -> SAN (mijanona amin'ny hetsika tsy ara-dalàna voalohany). */
fun sanMoves(uci: List<String>, startFen: String = START_FEN): List<String> {
    val b = Board()
    if (startFen != START_FEN) b.loadFromFen(startFen)
    val ml = MoveList(startFen)
    for (u in uci) {
        val m = b.legalMoves().firstOrNull { it.toString().equals(u, true) } ?: break
        b.doMove(m)
        ml.add(m)
    }
    return try { ml.toSanArray().toList() } catch (e: Exception) { emptyList() }
}

/** FEN aorian'ny hetsika voalohany `upto` (na farany raha tsy omena). */
fun fenAfter(uci: List<String>, upto: Int = uci.size, startFen: String = START_FEN): String {
    val b = Board()
    if (startFen != START_FEN) b.loadFromFen(startFen)
    var n = 0
    for (u in uci) {
        if (n >= upto) break
        val m = b.legalMoves().firstOrNull { it.toString().equals(u, true) } ?: break
        b.doMove(m); n++
    }
    return b.fen
}

fun pgnResultToken(r: String?): String = when (r) {
    "1-0", "0-1", "1/2-1/2" -> r
    else -> "*"
}

/** Mamorona PGN manara-penitra (tag roa-folo + movetext 80 tsipika). */
fun buildPgn(
    moves: List<String>,
    white: String, black: String,
    whiteElo: Int?, blackElo: Int?,
    result: String?,
    baseMs: Long, incMs: Long,
    dateMillis: Long,
    event: String = "KAJY - Match amicale",
    startFen: String = START_FEN
): String {
    val sb = StringBuilder()
    fun tag(k: String, v: String) {
        sb.append('[').append(k).append(" \"")
            .append(v.replace("\\", "\\\\").replace("\"", "\\\""))
            .append("\"]\n")
    }
    val token = pgnResultToken(result)
    tag("Event", event)
    tag("Site", "KAJY Android")
    tag("Date", SimpleDateFormat("yyyy.MM.dd", Locale.US).format(Date(dateMillis)))
    tag("Round", "-")
    tag("White", white)
    tag("Black", black)
    tag("Result", token)
    if (whiteElo != null) tag("WhiteElo", whiteElo.toString())
    if (blackElo != null) tag("BlackElo", blackElo.toString())
    tag("TimeControl", if (baseMs <= 0) "-" else (baseMs / 1000).toString() + (if (incMs > 0) "+" + (incMs / 1000) else ""))
    if (startFen != START_FEN) { tag("SetUp", "1"); tag("FEN", startFen) }
    sb.append('\n')

    val line = StringBuilder()
    fun put(tok: String) {
        if (line.isNotEmpty() && line.length + 1 + tok.length > 80) {
            sb.append(line).append('\n')
            line.setLength(0)
        }
        if (line.isNotEmpty()) line.append(' ')
        line.append(tok)
    }
    val off = if (startFen.split(" ").getOrNull(1) == "b") 1 else 0
    for ((i, san) in sanMoves(moves, startFen).withIndex()) {
        val k = i + off
        put(if (k % 2 == 0) "${k / 2 + 1}. $san" else if (i == 0) "${k / 2 + 1}... $san" else san)
    }
    put(token)
    sb.append(line).append('\n')
    return sb.toString()
}

/** PGN an'ny lalao voatahiry (GameRecord). */
fun pgnOfRecord(rec: GameRecord): String {
    val bot = BotRegistry.find(rec.botId)
    val me = PlayerProfile.name
    val other = bot?.name ?: "Mpilalao 2"
    val white = if (bot == null || rec.humanWhite) me else other
    val black = if (bot == null) other else if (rec.humanWhite) other else me
    val wElo = if (bot != null && !rec.humanWhite) bot.elo else null
    val bElo = if (bot != null && rec.humanWhite) bot.elo else null
    return buildPgn(rec.moves, white, black, wElo, bElo, rec.result, rec.baseMs, rec.incMs, rec.id, startFen = rec.startFen)
}
