package mg.chess.offline

import android.content.Context
import android.os.PowerManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Mode mampitsitsy baterie: 0 = atsahatra, 1 = auto (araka ny "Battery Saver" an'ny Android), 2 = alefa foana.
 * Rehefa mihetsika: Stockfish thread 1, fotoana fisainana fohy kokoa, review maivana, tsy misy motera fanampiny,
 * live mampiasa motera iray ihany, ary tsy misy animation mihodina (diaporama / clip).
 */
object PowerSaver {
    private const val KEY = "power_saver"
    var mode by mutableIntStateOf(0); private set
    private var sys by mutableStateOf(false)

    val active: Boolean get() = mode == 2 || (mode == 1 && sys)

    fun load(ctx: Context) {
        mode = ctx.getSharedPreferences("chess_prefs", 0).getInt(KEY, 0).coerceIn(0, 2)
        refresh(ctx)
    }

    fun refresh(ctx: Context) {
        sys = try { (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isPowerSaveMode } catch (e: Exception) { false }
    }

    fun setMode(ctx: Context, m: Int) {
        mode = m.coerceIn(0, 2)
        ctx.getSharedPreferences("chess_prefs", 0).edit().putInt(KEY, mode).apply()
        refresh(ctx)
    }
}
