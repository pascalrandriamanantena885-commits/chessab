plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "mg.chess.offline"
    compileSdk = 34
    defaultConfig {
        applicationId = "mg.chess.offline"
        minSdk = 24
        targetSdk = 34
        versionCode = 18
        versionName = "3.8"
        ndk { abiFilters += listOf("arm64-v8a") }
    }
    signingConfigs {
        create("release") {
            // App tsy zaraina ao amin'ny Play Store, nefa ilaina ny sonia mba ho azo apetraka ny APK.
            // 1) GitHub Secrets (KS_FILE, KS_PASS, KEY_ALIAS, KEY_PASS) raha misy; 2) raha tsy izany: app/kajy.jks (ao anaty project)
            // -> sonia TSY MIOVA isaky ny build, ka azo vaoana ambonin'ny dikan-teny teo aloha (tsy "App not installed").
            val f = System.getenv("KS_FILE")
            if (f != null && file(f).exists()) {
                storeFile = file(f)
                storePassword = System.getenv("KS_PASS")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASS")
            } else {
                storeFile = file("kajy.jks")
                storePassword = "kajy-offline"
                keyAlias = "kajy"
                keyPassword = "kajy-offline"
            }
        }
    }
    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("release")
        }
        release {
            // Tsy atao minify: tsy misy loza amin'ny Compose/chesslib/Stockfish (process) ary mora kokoa ny fanamarinana
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    testOptions { unitTests.isReturnDefaultValues = true }
    packaging { jniLibs { useLegacyPackaging = true } }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("com.github.bhlangonijr:chesslib:1.3.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20231013")   // org.json tena izy ho an'ny unit test (BotPackTest)
}
