package mg.chess.offline

import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.PieceType
import com.github.bhlangonijr.chesslib.Side
import com.github.bhlangonijr.chesslib.Square
import com.github.bhlangonijr.chesslib.move.MoveList
import java.util.Locale
import kotlin.math.abs

/**
 * "Why?" ao amin'ny Review: manazava ny fizotry ny lalao nahatonga ny hetsika manan-danja (brilliant, great, blunder...)
 * sy mamorona replay (frame isaky ny hetsika) mba hilalao kely ny lalao mankany amin'io toerana io.
 */
fun whyApplies(c: Cls): Boolean =
    c == Cls.BRILLIANT || c == Cls.GREAT || c == Cls.BLUNDER || c == Cls.MISTAKE || c == Cls.MISS

/** kind: 0 = hetsika nilalaovina teo aloha, 1 = ilay hetsika manan-danja, 2 = andalana manaraka (Stockfish). */
data class WhyFrame(val fen: String, val label: String, val last: Pair<Square, Square>?, val cls: Cls?, val kind: Int, val note: String? = null)

data class WhyReport(val headline: String, val points: List<String>, val story: List<String>)

/** "12. Qxb7" (Fotsy) na "12…Nf6" (Mainty); [i] = laharana 0-based ao amin'ny lalao, mifanaraka amin'ny FEN fanombohana. */
fun plyLabel(startFen: String, i: Int, san: String): String {
    val off = if (blackFirst(startFen)) 1 else 0
    val n = startMoveNo(startFen) + (i + off) / 2
    return if ((i + off) % 2 == 0) "$n. $san" else "$n…$san"
}

fun fmtCp(cp: Int): String =
    if (abs(cp) >= MATE_CP - 100) (if (cp > 0) "+M" else "-M") + (MATE_CP - abs(cp))
    else String.format(Locale.US, "%+.2f", cp / 100.0)

private fun pieceNameMg(p: Piece): String = typeNameMg(p.pieceType)

private fun typeNameMg(t: PieceType): String = when (t) {
    PieceType.PAWN -> "pion"
    PieceType.KNIGHT -> "knight"
    PieceType.BISHOP -> "bishop"
    PieceType.ROOK -> "rook"
    PieceType.QUEEN -> "queen"
    PieceType.KING -> "mpanjaka"
    else -> "piece"
}

private fun sq(s: Square) = s.toString().lowercase()

private fun materialOf(b: Board, side: Side): Int {
    var m = 0
    for (s in Square.values()) {
        if (s == Square.NONE) continue
        val p = b.getPiece(s)
        if (p == Piece.NONE || p.pieceSide != side || p.pieceType == PieceType.KING) continue
        m += pv(p)
    }
    return m
}

/** Piece an'ny [side] azon'ny mpanohitra raisina (tsy voaaro): (kare, piece, tombony). Ny board dia tsy maintsy ho anjaran'ny mpanohitra. */
private fun hangingOf(b: Board, side: Side): List<Triple<Square, Piece, Int>> {
    val out = ArrayList<Triple<Square, Piece, Int>>()
    for (s in Square.values()) {
        if (s == Square.NONE) continue
        val p = b.getPiece(s)
        if (p == Piece.NONE || p.pieceSide != side || p.pieceType == PieceType.KING) continue
        val g = see(b, s)
        if (g > 0) out.add(Triple(s, p, g))
    }
    return out.sortedByDescending { it.third }
}


// ---------------------------------------------------------------------
//  Fiafaran'ny andalana: tsy isa hetsika raikitra fa ny VOKATRA ao amin'ny lalao
// ---------------------------------------------------------------------

/** Fetra fiarovana fotsiny (tsy hanao replay lava tsy misy farany); tsy ny isa no mamaritra ny fiafarana. */
const val PV_HARD_CAP = 40
private const val PV_QUIET_FALLBACK = 6

/** keep = isan'ny hetsika tazonina; resolved = nisy vokatra mazava (mate / stalemate / draw / fifanakalozana vita); event = nisy fakana piece na promotion. */
class PvPlan(val keep: Int, val resolved: Boolean, val event: Boolean)

/**
 * Mamaritra hatraiza no tokony hijerena ny andalana [pv] manomboka amin'ny [fen]:
 *  - mijanona rehefa MATE, STALEMATE na DRAW;
 *  - raha misy fakana piece / promotion: mitohy mandra-pahavita ny fifanakalozana (recapture na check mitohy), dia mijanona rehefa milamina ny toerana;
 *  - raha mate no andrasana ([toMate]): mandra-pahatongan'ny mate.
 * Raha tsy misy na inona na inona amin'izany ao amin'ny andalana (toerana milamina), dia tazonina ny hetsika vitsivitsy voalohany.
 */
fun pvPlan(fen: String, pv: List<String>, toMate: Boolean = false): PvPlan {
    val b = Board()
    try { b.loadFromFen(fen) } catch (_: Exception) { return PvPlan(0, false, false) }
    val cap = ArrayList<Boolean>(); val chk = ArrayList<Boolean>(); val term = ArrayList<Boolean>()
    try {
        for (u in pv.take(PV_HARD_CAP)) {
            val mv = b.legalMoves().firstOrNull { it.toString().equals(u, true) } ?: break
            val pawn = b.getPiece(mv.from).pieceType == PieceType.PAWN
            val isCap = b.getPiece(mv.to) != Piece.NONE || (pawn && mv.from.file != mv.to.file) || mv.promotion != Piece.NONE
            b.doMove(mv)
            cap.add(isCap); chk.add(b.isKingAttacked)
            term.add(b.isMated || b.isStaleMate || b.isDraw)
        }
    } catch (_: Exception) { /* tapaka eto */ }
    val n = cap.size
    var seen = false
    for (k in 0 until n) {
        if (term[k]) return PvPlan(k + 1, true, seen || cap[k])
        if (toMate) continue
        if (cap[k]) seen = true
        if (seen && k + 1 < n && !(cap[k + 1] || chk[k + 1])) return PvPlan(k + 1, true, true)
    }
    return if (seen || toMate) PvPlan(n, false, seen) else PvPlan(minOf(n, PV_QUIET_FALLBACK), false, false)
}

/** Vokatra farany amin'ny andalana: kind 0 = tsy misy, 1 = checkmate, 2 = stalemate, 3 = draw, 4 = very piece. */
class Outcome(val kind: Int, val loser: Side?, val whiteLost: String, val blackLost: String)

private fun countBy(b: Board, side: Side): Map<PieceType, Int> {
    val m = HashMap<PieceType, Int>()
    for (s in Square.values()) {
        if (s == Square.NONE) continue
        val p = b.getPiece(s)
        if (p == Piece.NONE || p.pieceSide != side || p.pieceType == PieceType.KING) continue
        m[p.pieceType] = (m[p.pieceType] ?: 0) + 1
    }
    return m
}

/** Piece very ny [side] eo anelanelan'ny toerana roa: "queen + 2 pion". */
private fun lostText(b0: Board, b1: Board, side: Side): String {
    val c0 = countBy(b0, side); val c1 = countBy(b1, side)
    val parts = ArrayList<String>()
    for (t in listOf(PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT, PieceType.PAWN)) {
        val d = (c0[t] ?: 0) - (c1[t] ?: 0)
        if (d > 0) parts.add((if (d > 1) "$d " else "") + typeNameMg(t))
    }
    return parts.joinToString(" + ")
}

fun outcomeOf(startFen: String, sim: PvSim): Outcome {
    if (sim.fens.isEmpty()) return Outcome(0, null, "", "")
    return try {
        val b0 = Board().also { it.loadFromFen(startFen) }
        val b1 = Board().also { it.loadFromFen(sim.fens.last()) }
        val wl = lostText(b0, b1, Side.WHITE); val bl = lostText(b0, b1, Side.BLACK)
        when {
            b1.isMated -> Outcome(1, b1.sideToMove, wl, bl)
            b1.isStaleMate -> Outcome(2, null, wl, bl)
            b1.isDraw -> Outcome(3, null, wl, bl)
            wl.isNotEmpty() || bl.isNotEmpty() -> Outcome(4, null, wl, bl)
            else -> Outcome(0, null, "", "")
        }
    } catch (_: Exception) { Outcome(0, null, "", "") }
}

/** Soratra fohy aseho eo ambanin'ny board rehefa tonga any amin'ny frame farany. */
fun outcomeNote(o: Outcome): String? = when (o.kind) {
    1 -> "CHECKMATE · ${if (o.loser == Side.WHITE) "Fotsy" else "Mainty"} no voa-mate"
    2 -> "STALEMATE · draw (tsy afaka mihetsika, tsy voa-check)"
    3 -> "DRAW"
    4 -> "Very: " + listOfNotNull(
        o.whiteLost.takeIf { it.isNotEmpty() }?.let { "Fotsy $it" },
        o.blackLost.takeIf { it.isNotEmpty() }?.let { "Mainty $it" }
    ).joinToString(" · ")
    else -> null
}

class PvSim(val sans: List<String>, val fens: List<String>, val squares: List<Pair<Square, Square>>)

/** Alefaso amin'ny board ny andalana PV (UCI) hatramin'ny [max] hetsika; mijanona raha tsy ara-dalàna. */
fun simulatePv(fen: String, pv: List<String>, max: Int): PvSim {
    val b = Board(); b.loadFromFen(fen)
    val ml = MoveList(fen)
    val fens = ArrayList<String>(); val squares = ArrayList<Pair<Square, Square>>()
    try {
        for (u in pv.take(max)) {
            val mv = b.legalMoves().firstOrNull { it.toString().equals(u, true) } ?: break
            ml.add(mv); b.doMove(mv)
            fens.add(b.fen); squares.add(mv.from to mv.to)
        }
    } catch (_: Exception) { /* tapaka eto */ }
    val sans = if (fens.isEmpty()) emptyList() else try { ml.toSanArray().toList() } catch (_: Exception) { emptyList() }
    return PvSim(sans.take(fens.size), fens, squares)
}

/** "13…Qxb7 14. Rxb7 Nf6": laharana ampiharina amin'ny hetsika voalohany sy amin'ny hetsika Fotsy. */
fun pvText(startFen: String, firstPly: Int, sans: List<String>): String {
    val off = if (blackFirst(startFen)) 1 else 0
    val sb = StringBuilder()
    for ((k, s) in sans.withIndex()) {
        val i = firstPly + k
        val white = (i + off) % 2 == 0
        val n = startMoveNo(startFen) + (i + off) / 2
        if (k > 0) sb.append(' ')
        if (white) sb.append("$n. ") else if (k == 0) sb.append("$n…")
        sb.append(s)
    }
    return sb.toString()
}

/** Fanazavana feno. [before] = analyse alohan'ny hetsika (MultiPV), [after] = analyse aorian'izay; mety ho foana (tsy misy motera). */
fun buildWhyReport(r: ReviewResult, ply: Int, before: List<Line>, after: List<Line>): WhyReport {
    val mv = r.moves[ply - 1]
    val startFen = r.fens[0]
    val moverWhite = mv.side == Side.WHITE
    val me = if (moverWhite) "Fotsy" else "Mainty"
    val opp = if (moverWhite) "Mainty" else "Fotsy"
    val oppSide = if (moverWhite) Side.BLACK else Side.WHITE
    fun evMe(i: Int) = (if (moverWhite) 1 else -1) * r.evalsWhite[i]
    val evB = evMe(ply - 1); val evA = evMe(ply)

    val bBefore = Board().also { it.loadFromFen(r.fens[ply - 1]) }
    val played = bBefore.legalMoves().firstOrNull { it.toString().equals(mv.uci, true) }
    val piece = played?.let { bBefore.getPiece(it.from) } ?: Piece.NONE
    val captured = played?.let { bBefore.getPiece(it.to) } ?: Piece.NONE
    val bAfter = Board().also { it.loadFromFen(r.fens[ply]) }

    val afterTop = after.firstOrNull()
    val pvA = afterTop?.pv ?: emptyList()
    val sim = simulatePv(r.fens[ply], pvA, pvPlan(r.fens[ply], pvA, afterTop?.mate != null).keep)
    val reply = sim.sans.firstOrNull()
    val endB = Board().also { it.loadFromFen(sim.fens.lastOrNull() ?: r.fens[ply]) }
    val myLoss = materialOf(bAfter, mv.side) - materialOf(endB, mv.side)
    val oppLoss = materialOf(bAfter, oppSide) - materialOf(endB, oppSide)
    val netMat = oppLoss - myLoss   // > 0: ny mpilalao no mahazo material ao amin'ny andalana
    val line = if (sim.sans.isEmpty()) "" else pvText(startFen, ply, sim.sans)
    val hang = try { hangingOf(Board().also { it.loadFromFen(r.fens[ply]) }, mv.side) } catch (_: Exception) { emptyList() }
    val oppMate = afterTop?.mate   // ho an'ny mpanohitra (mpihetsika ao amin'ny toerana vaovao)

    val pts = ArrayList<String>()
    val headline = "Nahoana ny ${mv.san} no ${mv.cls.label} ${mv.cls.sym}?"

    pts.add("Alohan'ny hetsika: ${evalDescMg(r.evalsWhite[ply - 1])} (${r.evalTexts[ply - 1]}). " +
        "Aorian'ny ${mv.san}: ${evalDescMg(r.evalsWhite[ply])} (${r.evalTexts[ply]}).")

    when (mv.cls) {
        Cls.BRILLIANT -> {
            val sac = played != null && try { isSacrifice(Board().also { it.loadFromFen(r.fens[ply - 1]) }, played) } catch (_: Exception) { false }
            val pn = pieceNameMg(piece)
            if (sac) {
                val h = hang.firstOrNull { it.first == played!!.to }
                pts.add("Sacrifice: ny $me dia nanome ny $pn (${pv(piece)} point)" +
                    (if (h != null) " amin'ny ${sq(h.first)}, izay azon'ny $opp raisina" else "") +
                    " ary tsy nandray fa nijery lavitra kokoa.")
            } else pts.add("Hetsika tsy dia hita: tsy hitan'ny rafitra tsotra ny tombony ao aminy.")
            if (reply != null) pts.add("Raha mamaly amin'ny $reply ny $opp, dia mitohy ny andalana: $line.")
            when {
                oppMate != null && oppMate < 0 -> pts.add("Mitarika mate ho an'ny $me amin'ny ${-oppMate} hetsika.")
                netMat >= 1 -> pts.add("Averina ny material (+$netMat point) ao amin'ny andalana, ka tsy very ny sorona.")
                else -> pts.add("Na dia very material aza vetivety, mitazona ny toerana (eval ${fmtCp(evB)} → ${fmtCp(evA)}) satria mahazo hetsika/fanafihana ny $me.")
            }
        }
        Cls.GREAT -> {
            val second = before.getOrNull(1)
            if (second != null && before.isNotEmpty()) {
                val alt = simulatePv(r.fens[ply - 1], second.pv, 1).sans.firstOrNull()
                val drop = winPct(before[0].stmCp()) - winPct(second.stmCp())
                if (alt != null) pts.add(
                    "Ny hetsika faharoa tsara indrindra (${alt}) dia mampihena ny eval ho ${fmtCp(second.stmCp())}" +
                        " (very ≈ ${drop.toInt()}% amin'ny fahafahana handresy). Noho izany ny ${mv.san} no hany safidy tena tsara."
                )
            }
            when {
                evB <= -80 && evA >= -40 -> pts.add("Namonjy ny toerana: avy amin'ny ${fmtCp(evB)} ho ${fmtCp(evA)} ho an'ny $me.")
                evA - evB >= 100 -> pts.add("Nanova ny lalao: eval ho an'ny $me ${fmtCp(evB)} → ${fmtCp(evA)}.")
                else -> pts.add("Hetsika mitazona ny tombony sy manafoana ny fanehoan-kevitry ny $opp.")
            }
            if (reply != null) pts.add("Andalana manaraka (Stockfish): $line.")
        }
        else -> {   // BLUNDER / MISTAKE / MISS
            pts.add("Very ≈ ${String.format(Locale.US, "%.1f", mv.cpLoss / 100.0)} pion (${mv.loss.toInt()}% amin'ny fahafahana handresy) vokatry ny hetsika.")
            val top = hang.firstOrNull()
            when {
                oppMate != null && oppMate > 0 ->
                    pts.add("Ny $opp dia afaka manao mate amin'ny $oppMate hetsika: $line.")
                top != null ->
                    pts.add(
                        (if (played != null && top.first == played.to) "Ny ${pieceNameMg(top.second)} nafindrao dia mivadika amin'ny ${sq(top.first)}"
                        else "Ny ${pieceNameMg(top.second)} amin'ny ${sq(top.first)} dia tsy voaaro intsony") +
                            ": afaka misambotra azy ny $opp (≈ +${top.third} point)" + (if (reply != null) " ($reply)." else ".")
                    )
                myLoss - oppLoss >= 2 ->
                    pts.add("Ao amin'ny andalana tsara indrindra ho an'ny $opp ($line) dia very ${myLoss - oppLoss} point material ny $me.")
                reply != null ->
                    pts.add("Ny $opp dia manana safidy tsara: $reply — $line.")
                else -> pts.add("Nanome fahafahana ny $opp hanatsara ny toerany.")
            }
            if (captured != Piece.NONE && mv.cls != Cls.MISS) pts.add("Nandray ${pieceNameMg(captured)} ny ${mv.san}, fa tsy nojerena ny vokany.")
            val best = r.bestSan[ply - 1]
            if (best != null) {
                val bp = before.firstOrNull()?.let { simulatePv(r.fens[ply - 1], it.pv, pvPlan(r.fens[ply - 1], it.pv, it.mate != null).keep) }
                val bl = if (bp != null && bp.sans.isNotEmpty()) " (andalana: ${pvText(startFen, ply - 1, bp.sans)})" else ""
                pts.add("Tsara kokoa: $best$bl — eval ${before.firstOrNull()?.let { fmtCp(it.stmCp()) } ?: fmtCp(evB)}.")
            }
            if (mv.cls == Cls.MISS) pts.add("Nisy fahafahana handresy/mandroso lehibe tsy nararaka rehefa avy nisy hadisoana teo aloha.")
        }
    }

    // ---- Fiafarana: ny vokatra any amin'ny farany ----
    if (sim.sans.isNotEmpty()) {
        val oc = outcomeOf(r.fens[ply], sim)
        val mine = if (moverWhite) oc.whiteLost else oc.blackLost
        val his = if (moverWhite) oc.blackLost else oc.whiteLost
        when (oc.kind) {
            1 -> pts.add(
                if (oc.loser == mv.side) "Fiafarana: CHECKMATE - ny $me no voa-mate (${sim.sans.size} hetsika aorian'ny ${mv.san}): $line."
                else "Fiafarana: CHECKMATE - ny $me no manao mate ny $opp: $line."
            )
            2 -> pts.add(
                "Fiafarana: STALEMATE - tsy afaka mihetsika ny mpanohitra nefa tsy voa-check, ka draw ny lalao. " +
                    when {
                        evB >= 150 -> "Nanana toerana mandresy ny $me (${fmtCp(evB)}) nefa lasa draw."
                        evB <= -150 -> "Namonjy ny $me tamin'ny draw."
                        else -> ""
                    }
            )
            3 -> pts.add("Fiafarana: DRAW (tsy ampy material, famerenana toerana na fitsipika 50 hetsika).")
            4 -> pts.add(
                "Fiafarana: " + listOfNotNull(
                    mine.takeIf { it.isNotEmpty() }?.let { "very $it ny $me" },
                    his.takeIf { it.isNotEmpty() }?.let { "very $it ny $opp" }
                ).joinToString(", ") + " (aorian'ny fifanakalozana: $line)."
            )
            else -> pts.add("Tsy misy mate, stalemate na very piece mazava ao amin'ny andalana: ny toerana ihany no niova (eval ${fmtCp(evB)} → ${fmtCp(evA)}).")
        }
    }

    // ---- Fizotra: hetsika 6 teo aloha ----
    val story = ArrayList<String>()
    val lo = maxOf(0, ply - 1 - 6)
    if (ply - 1 > lo) {
        story.add("Eval: ${r.evalTexts[lo]} → ${r.evalTexts[ply - 1]} tao anatin'ny ${ply - 1 - lo} hetsika.")
        for (i in lo until ply - 1) {
            val m = r.moves[i]
            story.add("${plyLabel(startFen, i, m.san)} ${m.cls.sym}  (eval ${r.evalTexts[i + 1]})")
        }
        val prevErr = (lo until ply - 1).lastOrNull {
            r.moves[it].side != mv.side && r.moves[it].cls in listOf(Cls.INACCURACY, Cls.MISS, Cls.MISTAKE, Cls.BLUNDER)
        }
        if (prevErr != null && (mv.cls == Cls.BRILLIANT || mv.cls == Cls.GREAT)) {
            val m = r.moves[prevErr]
            story.add("Ny $opp dia nanao ${plyLabel(startFen, prevErr, m.san)} (${m.cls.label}), izay nanokatra ny fahafahana ho an'ny $me.")
        }
    } else story.add("Hetsika voalohany ao amin'ny lalao/toerana: tsy misy fizotra teo aloha.")
    return WhyReport(headline, pts, story)
}

private fun lastOf(r: ReviewResult, i: Int): Pair<Square, Square>? = r.squares.getOrNull(i)

/** Replay: hetsika 6 teo aloha → ny hetsika manan-danja → andalana Stockfish mandra-pahatongan'ny VOKATRA (mate, stalemate, very piece...). */
fun playedFrames(r: ReviewResult, ply: Int, afterPv: List<String>, mate: Boolean = false, lead: Int = 6): List<WhyFrame> {
    val startFen = r.fens[0]
    val lo = maxOf(0, ply - 1 - lead)
    val out = ArrayList<WhyFrame>()
    out.add(WhyFrame(r.fens[lo], "Toerana", if (lo > 0) lastOf(r, lo - 1) else null, null, 0))
    for (i in lo until ply - 1) out.add(WhyFrame(r.fens[i + 1], plyLabel(startFen, i, r.moves[i].san), lastOf(r, i), null, 0))
    out.add(WhyFrame(r.fens[ply], plyLabel(startFen, ply - 1, r.moves[ply - 1].san), lastOf(r, ply - 1), r.moves[ply - 1].cls, 1))
    val sim = simulatePv(r.fens[ply], afterPv, pvPlan(r.fens[ply], afterPv, mate).keep)
    val note = outcomeNote(outcomeOf(r.fens[ply], sim))
    for (k in sim.sans.indices) {
        out.add(WhyFrame(sim.fens[k], plyLabel(startFen, ply + k, sim.sans[k]), sim.squares[k], null, 2, if (k == sim.sans.lastIndex) note else null))
    }
    return out
}

/** Replay hafa: araka ny andalana [pv] manomboka amin'ny toerana alohan'ny hetsika (hetsika tsara kokoa / safidy hafa), mandra-pahatongan'ny vokatra. */
fun altFrames(r: ReviewResult, ply: Int, pv: List<String>, mate: Boolean = false): List<WhyFrame> {
    val startFen = r.fens[0]
    val out = ArrayList<WhyFrame>()
    out.add(WhyFrame(r.fens[ply - 1], "Toerana alohan'ny hetsika", lastOf(r, ply - 2), null, 0))
    val sim = simulatePv(r.fens[ply - 1], pv, pvPlan(r.fens[ply - 1], pv, mate).keep)
    val note = outcomeNote(outcomeOf(r.fens[ply - 1], sim))
    for (k in sim.sans.indices) {
        out.add(WhyFrame(sim.fens[k], plyLabel(startFen, ply - 1 + k, sim.sans[k]), sim.squares[k], null, if (k == 0) 1 else 2, if (k == sim.sans.lastIndex) note else null))
    }
    return out
}
