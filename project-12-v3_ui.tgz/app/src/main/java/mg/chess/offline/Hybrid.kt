package mg.chess.offline

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File

/** Safidy Hybrid (Stockfish + Berserk). Raha tsy misy ny binary Berserk dia Stockfish ihany no mandeha. */
object Hybrid {
    private const val PREFS = "kajy_hybrid"
    var enabled by mutableStateOf(true)
        private set

    fun load(ctx: Context) {
        enabled = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("enabled", true)
    }

    fun set(ctx: Context, v: Boolean) {
        enabled = v
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("enabled", v).apply()
    }

    fun available(ctx: Context): Boolean = File(ctx.applicationInfo.nativeLibraryDir, BK_BIN).exists()
}
