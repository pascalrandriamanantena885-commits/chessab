package mg.chess.offline

import android.util.Log
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.TimeUnit

/**
 * Filaharana tokana ho an'ny fanoratana rakitra (lalao, fifaninanana): tsy misakana ny main thread,
 * ary mitazona ny filaharana (save, delete) ka tsy misy fanoratana taloha mandrava ny vaovao.
 */
object DiskQueue {
    private val exec = Executors.newSingleThreadExecutor { r -> Thread(r, "kajy-disk") }

    fun run(task: () -> Unit) {
        val safe = Runnable {
            try { task() } catch (e: Exception) { Log.w("DiskQueue", "hadisoana fanoratana", e) }
        }
        try { exec.execute(safe) } catch (e: RejectedExecutionException) { safe.run() }
    }

    /** Miandry ny fanoratana rehetra efa ao amin'ny filaharana (alaina alohan'ny backup/restore/vakiana lisitra). */
    fun flush(timeoutMs: Long = 3000L) {
        try { exec.submit {}.get(timeoutMs, TimeUnit.MILLISECONDS) } catch (_: Exception) {}
    }
}
