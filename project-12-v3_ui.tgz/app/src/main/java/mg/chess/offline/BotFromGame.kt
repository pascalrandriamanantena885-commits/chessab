package mg.chess.offline

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/**
 * Mamorona bot vaovao avy amin'ny lalao vita:
 * Elo = game rating (aorian'ny review), opening = hita avy amin'ny hetsika nataon'ilay mpilalao,
 * fomba filalaovana = kajiana avy amin'ny hetsika rehetra nataony (sacrifice, fiarovana, queen aloha...).
 */
@Composable
fun BotFromGameDialog(vm: ChessViewModel, r: ReviewResult, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val moves = remember { vm.played.map { it.toString().lowercase() } }
    var white by remember { mutableStateOf(if (vm.vsBot) vm.humanWhite else true) }
    var created by remember { mutableStateOf(false) }

    val sum = if (white) r.white else r.black
    val suggestedElo = ((sum.rating / 50.0).roundToInt() * 50).coerceIn(100, 3200)
    var name by remember(white) { mutableStateOf(if (white) "Bot Fotsy" else "Bot Mainty") }
    var eloText by remember(white) { mutableStateOf(suggestedElo.toString()) }
    val openings = remember(white) { Personality.detectOpenings(moves, white) }
    val style = remember(white) { Personality.deriveStyle(moves, white) }
    val elo = eloText.toIntOrNull()
    val valid = name.isNotBlank() && elo != null && elo in 100..3200 && moves.size >= 4

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Mamorona bot avy amin'ity lalao ity") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Fidio ny mpilalao hovakiana:", fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(white, { white = true; created = false }, { Text("Fotsy") })
                    FilterChip(!white, { white = false; created = false }, { Text("Mainty") })
                }
                OutlinedTextField(
                    name, { name = it.take(20) }, label = { Text("Anarana") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    eloText, { eloText = it.filter { c -> c.isDigit() }.take(4) },
                    label = { Text("Elo (game rating ~${sum.rating})") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                val opNames = openings.mapNotNull { OPENING_MAP[it]?.name }
                Text(
                    "Opening: " + (if (opNames.isEmpty()) "tsy hita ao amin'ny katalaogy - ho raisina ny andalana nilalaovana" else opNames.joinToString(", ")),
                    fontSize = 13.sp
                )
                val tags = style.describe()
                Text(
                    "Fomba: " + (if (tags.isEmpty()) "mahazatra (tsy misy ambony indrindra)" else tags.joinToString(", ")),
                    fontSize = 13.sp
                )
                Text(
                    "Ny Stockfish no mitazona ny hery araka ny Elo; ny opening sy ny fomba no manasaraka azy. Azonao ovaina ao amin'ny Settings aorian'izay.",
                    fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (created) Text("Voaforona ny bot! Hita ao amin'ny lisitry ny bot.", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val lines = listOf(Personality.gameLine(moves, white))
                    BotRegistry.save(ctx, null, name, elo ?: suggestedElo, null, openings, lines, style)
                    created = true
                },
                enabled = valid && !created
            ) { Text("Forony") }
        },
        dismissButton = { TextButton(onDismiss) { Text(if (created) "Vita" else "Foano") } }
    )
}
