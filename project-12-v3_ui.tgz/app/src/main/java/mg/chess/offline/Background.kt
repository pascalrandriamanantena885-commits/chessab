package mg.chess.offline

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import java.io.File

/** Sary aloha (background) azon'ny mpampiasa isafidy avy ao amin'ny gallerie; tehirizina ao amin'ny filesDir/bg.jpg. */
object AppBackground {
    var image by mutableStateOf<ImageBitmap?>(null)
        private set
    /** 0.3..0.95 = hamafin'ny fanaronana eo ambonin'ny sary (ho an'ny fahitana soratra). */
    var dim by mutableFloatStateOf(0.7f)
        private set
    private var loaded = false

    private fun file(ctx: Context) = File(ctx.filesDir, "bg.jpg")
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("chess_prefs", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        dim = prefs(ctx).getFloat("bg_dim", 0.7f)
        try {
            val f = file(ctx)
            if (f.exists()) image = BitmapFactory.decodeFile(f.absolutePath)?.asImageBitmap()
        } catch (e: Exception) { /* tsy mandika */ }
    }

    fun setDim(ctx: Context, v: Float) {
        dim = v.coerceIn(0.3f, 0.95f)
        prefs(ctx).edit().putFloat("bg_dim", dim).apply()
    }

    fun set(ctx: Context, uri: Uri): Boolean {
        val bmp = decodeScaled(ctx, uri, 1600) ?: return false
        return try {
            file(ctx).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            image = bmp.asImageBitmap()
            true
        } catch (e: Exception) { false }
    }

    fun clear(ctx: Context) {
        try { file(ctx).delete() } catch (_: Exception) {}
        image = null
    }

    private fun decodeScaled(ctx: Context, uri: Uri, maxSide: Int): Bitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    } catch (e: Exception) { null }
}
