package mg.chess.offline

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import kotlin.math.abs

/** Mpilalao olona: anarana + sary (tehirizina ao amin'ny findainao). */
object PlayerProfile {
    var name by mutableStateOf("Ianao"); private set
    var avatar by mutableStateOf<ImageBitmap?>(null); private set

    private fun file(ctx: Context) = File(ctx.filesDir, "player.png")

    fun load(ctx: Context) {
        name = ctx.getSharedPreferences("chess_prefs", 0).getString("player_name", "Ianao") ?: "Ianao"
        avatar = try { BitmapFactory.decodeFile(file(ctx).absolutePath)?.asImageBitmap() } catch (e: Exception) { null }
    }

    fun setName(ctx: Context, n: String) {
        val v = n.trim().ifEmpty { "Ianao" }.take(20)
        name = v
        ctx.getSharedPreferences("chess_prefs", 0).edit().putString("player_name", v).apply()
    }

    fun setAvatar(ctx: Context, uri: Uri): Boolean {
        val bmp = decodeAvatar(ctx, uri) ?: return false
        return try {
            file(ctx).outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
            avatar = bmp.asImageBitmap(); true
        } catch (e: Exception) { false }
    }

    fun clearAvatar(ctx: Context) { file(ctx).delete(); avatar = null }
}

private val HUES = listOf(0xFF5C8BB0, 0xFF81B64C, 0xFFE58F2A, 0xFF9575CD, 0xFF4DB6AC, 0xFFF06292)

/** Sary mpilalao olona: sary voafidy raha ianao, na boribory misy litera voalohany. */
@Composable
fun PlayerAvatar(name: String, you: Boolean, size: Dp) {
    val img = if (you || name == PlayerProfile.name) PlayerProfile.avatar else null
    if (img != null) {
        Image(img, null, Modifier.size(size).clip(CircleShape), contentScale = ContentScale.Crop)
    } else {
        Box(
            Modifier.size(size).clip(CircleShape).background(Color(HUES[abs(name.hashCode()) % HUES.size])),
            contentAlignment = Alignment.Center
        ) {
            Text(name.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.45f).sp)
        }
    }
}

/** Card ao amin'ny Settings: anarana sy sary ho an'ny mpilalao. */
@Composable
fun PlayerProfileCard() {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf(PlayerProfile.name) }
    var msg by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) msg = if (PlayerProfile.setAvatar(ctx, uri)) "Voatahiry ny sary." else "Tsy azo vakiana io sary io."
    }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Mpilalao (anarana sy sary)", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                PlayerAvatar(PlayerProfile.name, true, 64.dp)
                Spacer(Modifier.width(12.dp))
                OutlinedTextField(
                    text, { text = it.take(20); PlayerProfile.setName(ctx, it) },
                    label = { Text("Anarana") }, singleLine = true, modifier = Modifier.weight(1f)
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text("Fidio sary") }
                if (PlayerProfile.avatar != null) OutlinedButton({ PlayerProfile.clearAvatar(ctx); msg = "Nesorina ny sary." }) { Text("Esory") }
            }
            if (msg.isNotEmpty()) Text(msg, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
        }
    }
}
