package mg.chess.offline

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Anaran'ny mpanao commentaire (miseho ao amin'ny soratra eo amin'ny efijery). */
fun voiceLabel(v: Voice) = "Faly"

/** Andalana kely: bokotra peo (alefa/atsahatra) + ny soratra lazain'ny mpanao commentaire ankehitriny. */
@Composable
fun CommentaryBar(vm: ChessViewModel, modifier: Modifier = Modifier) {
    val line = vm.commentator.caption
    Row(
        modifier.fillMaxWidth().padding(vertical = 3.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceContainer)
            .heightIn(min = 44.dp).padding(start = 2.dp, end = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton({ vm.setCommentary(!vm.commentaryOn) }, Modifier.size(40.dp)) {
            Icon(
                if (vm.commentaryOn) Icons.AutoMirrored.Rounded.VolumeUp else Icons.AutoMirrored.Rounded.VolumeOff,
                "Commentaire",
                tint = if (vm.commentaryOn) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
            )
        }
        Spacer(Modifier.width(4.dp))
        Column(Modifier.weight(1f).padding(vertical = 4.dp)) {
            when {
                !vm.commentaryOn -> Text("Commentaire: atsahatra (tsindrio ny peo hanokafana)", fontSize = 12.sp, color = MaterialTheme.colorScheme.outline)
                line != null -> {
                    Text(voiceLabel(line.who), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(line.text, fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                }
                else -> Text("Commentaire live: Faly dia miandry ny hetsika manaraka...", fontSize = 12.sp, color = MaterialTheme.colorScheme.outline)
            }
        }
    }
}
