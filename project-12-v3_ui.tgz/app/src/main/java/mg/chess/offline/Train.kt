package mg.chess.offline

import android.content.Context
import android.content.res.Configuration
import android.util.Log
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.School
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.PieceType
import com.github.bhlangonijr.chesslib.Side
import com.github.bhlangonijr.chesslib.Square
import com.github.bhlangonijr.chesslib.move.Move
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs
import kotlin.math.min

// =====================================================================
//  PUZZLE STORE - puzzle avy amin'ny Review (Brilliant / Mistake / Blunder)
// =====================================================================

data class Puzzle(val fen: String, val solution: String, val brilliant: Boolean)

class PuzzleStore(ctx: Context) {
    private val file = File(ctx.filesDir, "puzzles.json")
    private val items = ArrayList<Puzzle>()

    init { load() }

    private fun load() {
        try {
            if (!file.exists()) return
            val a = JSONArray(file.readText())
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                items.add(Puzzle(o.getString("fen"), o.getString("sol"), o.optBoolean("b", false)))
            }
        } catch (e: Exception) {
            Log.w("PuzzleStore", "load: $e")
        }
    }

    private fun save() {
        try {
            val a = JSONArray()
            for (p in items) a.put(JSONObject().put("fen", p.fen).put("sol", p.solution).put("b", p.brilliant))
            val tmp = File(file.parentFile, "puzzles.json.tmp")
            tmp.writeText(a.toString())
            if (!tmp.renameTo(file)) file.writeText(a.toString())
        } catch (e: Exception) {
            Log.w("PuzzleStore", "save: $e")
        }
    }

    @Synchronized fun all(): List<Puzzle> = items.toList()
    @Synchronized fun count(): Int = items.size

    /** Alaina ny puzzle rehetra ao amin'ny review: Brilliant (hita ny hetsika) + Mistake/Blunder (hita ny tsara kokoa). */
    @Synchronized fun addFrom(r: ReviewResult) {
        var changed = false
        for ((i, m) in r.moves.withIndex()) {
            val fen = r.fens.getOrNull(i) ?: continue
            val p = when (m.cls) {
                Cls.BRILLIANT -> Puzzle(fen, m.uci.lowercase(), true)
                Cls.MISTAKE, Cls.BLUNDER -> {
                    val best = r.bestUci.getOrNull(i) ?: continue
                    if (best.isBlank() || best.equals(m.uci, true)) continue
                    Puzzle(fen, best.lowercase(), false)
                }
                else -> continue
            }
            if (items.none { it.fen == p.fen && it.solution == p.solution }) { items.add(p); changed = true }
        }
        while (items.size > 300) items.removeAt(0)
        if (changed) save()
    }
}

// =====================================================================
//  FAMPIASANA ROA TOKANA
// =====================================================================

private fun Board.moveByUci(uci: String): Move? =
    legalMoves().firstOrNull { it.toString().equals(uci, true) }

@Composable
private fun isLandscape(): Boolean = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

/** Portrait: board ambony, panel ambany. Landscape: board miankavanana, panel miankavia (azo hodinihina). */
@Composable
private fun Split(board: @Composable () -> Unit, panel: @Composable ColumnScope.() -> Unit) {
    if (isLandscape()) {
        Row(Modifier.fillMaxSize().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Box(Modifier.fillMaxHeight().aspectRatio(1f), contentAlignment = Alignment.Center) { board() }
            Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) { panel() }
        }
    } else {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            board()
            panel()
        }
    }
}

/** Board azo tsindriana: safidio ny piece dia ny kare (queen foana ny promotion). */
@Composable
private fun TrainBoard(
    board: Board, version: Int, flip: Boolean,
    last: Pair<Square, Square>? = null, hint: Pair<Square, Square>? = null,
    enabled: Boolean = true, onMove: (Move) -> Unit
) {
    var sel by remember(version) { mutableStateOf<Square?>(null) }
    val v = version
    val targets = sel?.let { s -> board.legalMoves().filter { it.from == s }.map { it.to } } ?: emptyList()
    BoardView(
        pieceAt = { sq -> if (v < 0) Piece.NONE else board.getPiece(sq) },
        flip = flip, selected = sel, targets = targets, last = last, hint = hint,
        onSquare = if (!enabled) null else { sq ->
            val s = sel
            val cand = if (s == null) emptyList() else board.legalMoves().filter { it.from == s && it.to == sq }
            if (cand.isNotEmpty()) {
                val m = cand.firstOrNull { it.promotion != Piece.NONE && it.promotion.pieceType == PieceType.QUEEN } ?: cand.first()
                sel = null
                onMove(m)
            } else {
                val p = board.getPiece(sq)
                sel = if (p != Piece.NONE && p.pieceSide == board.sideToMove) sq else null
            }
        }
    )
}

@Composable
private fun cardColors() = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)

// =====================================================================
//  HUB
// =====================================================================

@Composable
fun TrainScreen(vm: ChessViewModel) {
    BackHandler { vm.toMenu() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ScreenTitle("Fiofanana")
        HubCard(Icons.Rounded.Extension, "Puzzle / Tactique",
            "${vm.puzzles.count()} puzzle avy amin'ny lalaonao (Brilliant, Mistake, Blunder). Tsy mila internet.") { vm.screen = Screen.PUZZLE }
        HubCard(Icons.Rounded.MenuBook, "Opening",
            "Drill sy quiz amin'ny opening ${OPENINGS.size}: ianaro ny andalana teorika.") { vm.screen = Screen.DRILL }
        HubCard(Icons.Rounded.School, "Endgame",
            "R+K vs K, mate amin'ny Q, B+B, pion... miaraka amin'ny bot.") { vm.screen = Screen.ENDGAME }
    }
}

@Composable
private fun HubCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(
        Modifier.fillMaxWidth().clickable { onClick() }, colors = cardColors(),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, cs.outlineVariant)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(
                Modifier.size(54.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp)).background(cs.primaryContainer),
                contentAlignment = Alignment.Center
            ) { Icon(icon, null, tint = cs.onPrimaryContainer, modifier = Modifier.size(30.dp)) }
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(sub, fontSize = 13.sp, color = cs.onSurfaceVariant)
            }
            Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, tint = cs.onSurfaceVariant)
        }
    }
}

// =====================================================================
//  PUZZLE
// =====================================================================

@Composable
fun PuzzleScreen(vm: ChessViewModel) {
    BackHandler { vm.screen = Screen.TRAIN }
    val list = remember { vm.puzzles.all().shuffled() }
    var idx by remember { mutableIntStateOf(0) }
    var solved by remember { mutableIntStateOf(0) }
    if (list.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            ScreenTitle("Puzzle", onBack = { vm.screen = Screen.TRAIN })
            Text("Mbola tsy misy puzzle. Milalao dia ampiasao ny Review: ny hetsika Brilliant sy ny Mistake/Blunder dia tahirizina ho azy eto.")
        }
        return
    }
    val p = list[idx % list.size]
    val board = remember(idx) { Board().also { it.loadFromFen(p.fen) } }
    var version by remember(idx) { mutableIntStateOf(0) }
    var msg by remember(idx) { mutableStateOf("") }
    var done by remember(idx) { mutableStateOf(false) }
    var hint by remember(idx) { mutableStateOf<Pair<Square, Square>?>(null) }
    val flip = board.sideToMove == Side.BLACK

    Split(
        board = {
            TrainBoard(board, version, flip, hint = hint, enabled = !done) { m ->
                if (m.toString().equals(p.solution, true)) {
                    board.doMove(m); version++; done = true; solved++
                    msg = "Marina! ✓"
                } else {
                    msg = "Tsy izay. Andramo indray."
                }
            }
        },
        panel = {
            ScreenTitle("Puzzle", onBack = { vm.screen = Screen.TRAIN })
            Text(
                if (p.brilliant) "Hitao ny hetsika tsara indrindra (Brilliant)."
                else "Nisy hadisoana teto. Hita ny hetsika tsara indrindra.",
                fontSize = 15.sp
            )
            Text(if (flip) "Mainty no milalao" else "Fotsy no milalao", color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (msg.isNotEmpty()) Text(msg, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text("Voavaha: $solved · ${idx % list.size + 1}/${list.size}", fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!done) OutlinedButton({ hint = uciSquares(p.solution) }) { Text("Valiny") }
                Button({ idx++ }) { Text("Manaraka") }
            }
        }
    )
}

// =====================================================================
//  OPENING: drill + quiz
// =====================================================================

@Composable
fun DrillScreen(vm: ChessViewModel) {
    var open by remember { mutableStateOf<Opening?>(null) }
    var quiz by remember { mutableStateOf(false) }
    BackHandler { if (open != null) open = null else vm.screen = Screen.TRAIN }
    val op = open
    when {
        quiz -> OpeningQuiz(onExit = { quiz = false })
        op != null -> OpeningDrill(op, onExit = { open = null })
        else -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ScreenTitle("Opening", onBack = { vm.screen = Screen.TRAIN })
            Button({ quiz = true }, Modifier.fillMaxWidth()) { Text("Quiz: iza no opening ity?") }
            Text("Drill: safidio ny opening", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
            for (side in listOf(true, false)) {
                Text(if (side) "Fotsy" else "Mainty", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                for (o in OPENINGS.filter { it.white == side }) {
                    OutlinedButton({ open = o }, Modifier.fillMaxWidth()) { Text(o.name) }
                }
            }
        }
    }
}

@Composable
private fun OpeningDrill(op: Opening, onExit: () -> Unit) {
    var round by remember(op) { mutableIntStateOf(0) }
    val line = remember(op, round) { op.lines.random() }
    val board = remember(op, round) { Board() }
    var version by remember(op, round) { mutableIntStateOf(0) }
    var idx by remember(op, round) { mutableIntStateOf(0) }
    var mistakes by remember(op, round) { mutableIntStateOf(0) }
    var msg by remember(op, round) { mutableStateOf("") }
    var last by remember(op, round) { mutableStateOf<Pair<Square, Square>?>(null) }
    var hint by remember(op, round) { mutableStateOf<Pair<Square, Square>?>(null) }
    val finished = idx >= line.size
    val userTurn = !finished && ((idx % 2 == 0) == op.white)

    fun play(m: Move) {
        board.doMove(m); idx++; version++; last = m.from to m.to; hint = null
    }

    // Ny mpanohitra (andalana teorika) no mandeha ho azy
    LaunchedEffect(op, round, version) {
        if (idx < line.size && !userTurn) {
            delay(500)
            board.moveByUci(line[idx])?.let { play(it) }
        }
    }

    Split(
        board = {
            TrainBoard(board, version, flip = !op.white, last = last, hint = hint, enabled = userTurn) { m ->
                if (m.toString().equals(line[idx], true)) {
                    msg = "✓"; play(m)
                } else {
                    mistakes++
                    msg = "Tsy ao amin'ny teorika. Andramo indray."
                    if (mistakes >= 1) hint = uciSquares(line[idx])
                }
            }
        },
        panel = {
            ScreenTitle(op.name, onBack = onExit)
            Text(if (op.white) "Ianao: Fotsy" else "Ianao: Mainty", color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (msg.isNotEmpty() && !finished) Text(msg, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("Hetsika ${min(idx, line.size)}/${line.size} · hadisoana: $mistakes", fontSize = 13.sp)
            if (finished) {
                Text("Vita ny andalana! ${if (mistakes == 0) "Tsy nisy hadisoana 🎉" else "Hadisoana: $mistakes"}", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button({ round++ }) { Text("Andiany hafa") }
                    OutlinedButton(onExit) { Text("Opening hafa") }
                }
            }
        }
    )
}

@Composable
private fun OpeningQuiz(onExit: () -> Unit) {
    var round by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var asked by remember { mutableIntStateOf(0) }
    val q = remember(round) {
        val o = OPENINGS.random()
        val l = o.lines.random()
        val n = min(l.size, 8)
        val b = Board()
        for (k in 0 until n) b.moveByUci(l[k])?.let { b.doMove(it) }
        val others = OPENINGS.filter { it.id != o.id }.shuffled().take(3)
        Triple(o, b, (others + o).shuffled())
    }
    val (o, b, options) = q
    var answer by remember(round) { mutableStateOf<Opening?>(null) }
    Split(
        board = { TrainBoard(b, 0, flip = false, enabled = false) { } },
        panel = {
            ScreenTitle("Quiz opening", onBack = onExit)
            Text("Opening iza ity?", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            for (opt in options) {
                val a = answer
                val label = when {
                    a == null -> opt.name
                    opt.id == o.id -> "✓ ${opt.name}"
                    opt.id == a.id -> "✗ ${opt.name}"
                    else -> opt.name
                }
                OutlinedButton({
                    if (answer == null) { answer = opt; asked++; if (opt.id == o.id) score++ }
                }, Modifier.fillMaxWidth()) { Text(label) }
            }
            Text("Isa: $score/$asked", fontSize = 13.sp)
            if (answer != null) Button({ round++ }) { Text("Manaraka") }
        }
    )
}

// =====================================================================
//  ENDGAME vs BOT
// =====================================================================

private data class Endgame(val title: String, val goal: String, val fen: String)

private val ENDGAMES = listOf(
    Endgame("R+K vs K", "Mate amin'ny Rook", "8/8/8/4k3/8/8/4K3/R7 w - - 0 1"),
    Endgame("Q+K vs K", "Mate amin'ny Queen", "8/8/8/4k3/8/8/4K3/3Q4 w - - 0 1"),
    Endgame("B+B+K vs K", "Mate amin'ny Bishop roa", "8/8/8/4k3/8/8/4K3/2B2B2 w - - 0 1"),
    Endgame("P+K vs K", "Ataovy Queen ny pion, dia mate", "8/8/8/4k3/8/4K3/4P3/8 w - - 0 1"),
)

@Composable
fun EndgameScreen(vm: ChessViewModel) {
    var sel by remember { mutableStateOf<Endgame?>(null) }
    BackHandler { if (sel != null) sel = null else vm.screen = Screen.TRAIN }
    val eg = sel
    if (eg == null) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ScreenTitle("Endgame", onBack = { vm.screen = Screen.TRAIN })
            for (e in ENDGAMES) {
                Card(Modifier.fillMaxWidth().clickable { sel = e }, colors = cardColors()) {
                    Column(Modifier.padding(14.dp)) {
                        Text(e.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text(e.goal, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    } else EndgamePlay(vm, eg) { sel = null }
}

@Composable
private fun EndgamePlay(vm: ChessViewModel, eg: Endgame, onExit: () -> Unit) {
    var round by remember(eg) { mutableIntStateOf(0) }
    val board = remember(eg, round) { Board().also { it.loadFromFen(eg.fen) } }
    var version by remember(eg, round) { mutableIntStateOf(0) }
    var moves by remember(eg, round) { mutableIntStateOf(0) }
    var result by remember(eg, round) { mutableStateOf<String?>(null) }
    var last by remember(eg, round) { mutableStateOf<Pair<Square, Square>?>(null) }
    val bot = remember {
        (BotRegistry.visible.minByOrNull { abs(it.elo - 2000) }
            ?: BotRegistry.visible.first())
            .copy(openings = emptyList(), lines = emptyList(), style = Style(), movetimeMs = 500)
    }

    fun check() {
        result = when {
            board.isMated -> if (board.sideToMove == Side.BLACK) "Mate! Nandresy ianao 🎉 ($moves hetsika)" else "Voa-mate ianao."
            board.isStaleMate -> "Stalemate - draw. Andramo indray."
            board.isDraw -> "Draw (fanjakana tsy mahomby). Andramo indray."
            else -> null
        }
    }

    // Hetsik'ny bot
    LaunchedEffect(eg, round, version) {
        if (result == null && board.sideToMove == Side.BLACK) {
            val uci = vm.trainBot(board.fen, bot)
            val m = uci?.let { board.moveByUci(it) } ?: board.legalMoves().firstOrNull()
            if (m != null) { board.doMove(m); last = m.from to m.to; version++; check() }
        }
    }

    Split(
        board = {
            TrainBoard(board, version, flip = false, last = last, enabled = result == null && board.sideToMove == Side.WHITE) { m ->
                board.doMove(m); moves++; last = m.from to m.to; version++; check()
            }
        },
        panel = {
            ScreenTitle(eg.title, onBack = onExit)
            Text(eg.goal, fontSize = 15.sp)
            Text("Hetsika: $moves", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (result == null && board.sideToMove == Side.BLACK) Text("Mieritreritra ny bot...", fontSize = 13.sp)
            result?.let { Text(it, fontWeight = FontWeight.Bold, fontSize = 17.sp) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ vm.trainNewGame(); round++ }) { Text("Atombohy indray") }
                OutlinedButton(onExit) { Text("Hiverina") }
            }
        }
    )
}

// =====================================================================
//  MOMBA / CREDITS
// =====================================================================

@Composable
fun AboutScreen(vm: ChessViewModel) {
    BackHandler { vm.screen = Screen.SETTINGS }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ScreenTitle("Momba / Credits", onBack = { vm.screen = Screen.SETTINGS })
        Text("KAJY - lalao chess offline", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Version ${BuildInfo.version}", color = MaterialTheme.colorScheme.onSurfaceVariant)
        CreditCard("Fahazoan-dalana", "KAJY dia app malalaka (open source) ambanin'ny GNU GPL v3 na taty aoriana. Misy ny kaody sy ny LICENSE ao amin'ny repo.")
        CreditCard("Stockfish 19", "Motera chess + NNUE, avy amin'ny mpamorona Stockfish. Fahazoan-dalana: GPL-3.0-or-later. github.com/official-stockfish/Stockfish")
        CreditCard("Berserk (Hybrid)", "Motera chess UCI, Jay Honnold. GPL-3.0. Ampiasaina ho mpiara-miasa amin'ny Stockfish raha tafapetraka ao amin'ny APK. github.com/jhonnold/berserk")
        CreditCard("Sary piece sy board", "Cburnett Chess set (remaster JohnPablok). Colin M.L. Burnett / JohnPablok. CC BY-SA 3.0 (GPLv2+). Ny sary dia mbola ambanin'ny CC BY-SA ihany rehefa zaraina.")
        CreditCard("Tranombakoka", "chesslib (Apache-2.0), AndroidX, Jetpack Compose ary Kotlin coroutines (Apache-2.0).")
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun CreditCard(title: String, body: String) {
    Card(Modifier.fillMaxWidth(), colors = cardColors()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(body, fontSize = 14.sp)
        }
    }
}

object BuildInfo { const val version = "2.5" }
