package mg.chess.offline

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** Endrika KAJY: maitso (toa chess.com), contrast avo. Tsy manaraka ny dark/light an'ny findainao. */
val Green = Color(0xFF81B64C)
val GreenDark = Color(0xFF5D9948)

val LightScheme = lightColorScheme(
    primary = GreenDark, onPrimary = Color.White,
    primaryContainer = Color(0xFFDCEFCB), onPrimaryContainer = Color(0xFF10260A),
    secondary = Color(0xFF4A5A66), onSecondary = Color.White,
    secondaryContainer = Color(0xFFE1E8EE), onSecondaryContainer = Color(0xFF111A21),
    tertiary = Color(0xFFE58F2A),
    background = Color(0xFFF1EFEA), onBackground = Color(0xFF1C1B19),
    surface = Color(0xFFF8F6F2), onSurface = Color(0xFF1C1B19),
    surfaceVariant = Color(0xFFE4E1DA), onSurfaceVariant = Color(0xFF3A3834),
    surfaceContainer = Color(0xFFFFFFFF),
    surfaceContainerHigh = Color(0xFFFFFFFF),
    surfaceContainerHighest = Color(0xFFFFFFFF),
    outline = Color(0xFF6E6B64),
    error = Color(0xFFB3261E), onError = Color.White
)

val DarkScheme = darkColorScheme(
    primary = Green, onPrimary = Color(0xFF10200A),
    primaryContainer = Color(0xFF2F4A1C), onPrimaryContainer = Color(0xFFDDF2C8),
    secondary = Color(0xFFB9C3CC), onSecondary = Color(0xFF111A21),
    secondaryContainer = Color(0xFF3A3F44), onSecondaryContainer = Color(0xFFFFFFFF),
    tertiary = Color(0xFFF2A94B),
    background = Color(0xFF1F1E1B), onBackground = Color(0xFFF2F1EE),
    surface = Color(0xFF262421), onSurface = Color(0xFFF2F1EE),
    surfaceVariant = Color(0xFF33312D), onSurfaceVariant = Color(0xFFE3E1DC),
    surfaceContainer = Color(0xFF2E2C29),
    surfaceContainerHigh = Color(0xFF34322F),
    surfaceContainerHighest = Color(0xFF3A3834),
    outline = Color(0xFF9A978F),
    error = Color(0xFFFF8A80), onError = Color(0xFF3B0004)
)

val KajyShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)
