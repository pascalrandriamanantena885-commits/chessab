package mg.chess.offline

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Backup / restore: rakitra .zip iray misy ny Elo-nao + statistika (stats.json), ny bot nataonao (+ sary),
 * ny profile mpilalao, ny lalao voatahiry, ny fifaninanana ary ny settings.
 * Azo averina ao amin'ny findaina vaovao.
 */
object BackupManager {
    private const val VERSION = 1
    private const val PREFS = "chess_prefs"

    private val DIRS = listOf("games", "tournaments", "avatars")
    private val FILES = listOf("stats.json", "custom_bots.json", "player.png")

    fun suggestedName(): String =
        "kajy-backup-" + SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date()) + ".zip"

    private fun prefsToJson(ctx: Context): JSONObject {
        val o = JSONObject()
        for ((k, v) in ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).all) {
            val e = JSONObject()
            when (v) {
                is Boolean -> { e.put("t", "b"); e.put("v", v) }
                is Int -> { e.put("t", "i"); e.put("v", v) }
                is Long -> { e.put("t", "l"); e.put("v", v) }
                is Float -> { e.put("t", "f"); e.put("v", v.toDouble()) }
                is String -> { e.put("t", "s"); e.put("v", v) }
                is Set<*> -> { e.put("t", "ss"); e.put("v", JSONArray(v.map { it.toString() })) }
                else -> continue
            }
            o.put(k, e)
        }
        return o
    }

    private fun prefsFromJson(ctx: Context, o: JSONObject) {
        val ed = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        ed.clear()
        for (k in o.keys()) {
            val e = o.getJSONObject(k)
            when (e.getString("t")) {
                "b" -> ed.putBoolean(k, e.getBoolean("v"))
                "i" -> ed.putInt(k, e.getInt("v"))
                "l" -> ed.putLong(k, e.getLong("v"))
                "f" -> ed.putFloat(k, e.getDouble("v").toFloat())
                "s" -> ed.putString(k, e.getString("v"))
                "ss" -> {
                    val a = e.getJSONArray("v")
                    ed.putStringSet(k, HashSet(List(a.length()) { a.getString(it) }))
                }
            }
        }
        ed.commit()
    }

    private fun ZipOutputStream.addBytes(name: String, bytes: ByteArray) {
        putNextEntry(ZipEntry(name)); write(bytes); closeEntry()
    }

    private fun ZipOutputStream.addFile(name: String, f: File) {
        if (f.isFile) addBytes(name, f.readBytes())
    }

    /** Soraty ao amin'ny [os] ny zip manontolo. Mamerina ny isan'ny rakitra lalao/fifaninanana/sary. */
    fun writeZip(ctx: Context, os: java.io.OutputStream): Int {
        DiskQueue.flush()   // miandry ny fanoratana efa ao amin'ny filaharana
        var n = 0
        ZipOutputStream(os.buffered()).use { z ->
            val meta = JSONObject().put("app", "KAJY").put("version", VERSION).put("time", System.currentTimeMillis())
            z.addBytes("meta.json", meta.toString().toByteArray())
            z.addBytes("prefs.json", prefsToJson(ctx).toString().toByteArray())
            for (f in FILES) z.addFile(f, File(ctx.filesDir, f))
            for (d in DIRS) {
                File(ctx.filesDir, d).listFiles()?.forEach { f ->
                    if (f.isFile && !f.name.endsWith(".tmp") && !f.name.endsWith(".bak")) { z.addFile("$d/${f.name}", f); n++ }
                }
            }
        }
        return n
    }

    /** Soratana ao amin'ny [uri] (misafidy rakitra ny mpampiasa). Mamerina hafatra ho an'ny mpampiasa. */
    fun export(ctx: Context, uri: Uri): String = try {
        val n = ctx.contentResolver.openOutputStream(uri)!!.use { writeZip(ctx, it) }
        "Voatahiry ny backup ($n rakitra + stats + bot + settings)."
    } catch (e: Exception) {
        "Tsy lasa ny backup: " + (e.message ?: "hadisoana")
    }

    /** Backup ho an'ny fizarana (Drive, WhatsApp...). */
    fun exportForShare(ctx: Context): File {
        val f = File(ShareUtil.sharedDir(ctx), suggestedName())
        FileOutputStream(f).use { writeZip(ctx, it) }
        return f
    }

    private fun safeName(n: String): Boolean = n.isNotEmpty() && !n.contains("..") && !n.contains('/') && !n.contains('\\')

    /**
     * Averina avy amin'ny [uri]. Alaina any amin'ny toerana vonjimaika aloha, ary tsy misy fahavoazana
     * raha tsy mety ny rakitra. Mamerina null raha tafita, na hafatra diso.
     */
    fun restore(ctx: Context, uri: Uri): String? {
        val opened = try { ctx.contentResolver.openInputStream(uri) } catch (e: Exception) { null }
        val ins = opened ?: return "Tsy afaka namaky ny rakitra."
        return ins.use { restoreFrom(ctx, it) }
    }

    fun restoreFile(ctx: Context, f: File): String? = f.inputStream().use { restoreFrom(ctx, it) }

    fun restoreFrom(ctx: Context, input: java.io.InputStream): String? {
        DiskQueue.flush()   // tsy hisy fanoratana taloha mandrava ny rakitra averina
        val tmp = File(ctx.cacheDir, "restore").apply { deleteRecursively(); mkdirs() }
        try {
            var hasMeta = false
            input.let { ins ->
                ZipInputStream(ins.buffered()).use { z ->
                    while (true) {
                        val e = z.nextEntry ?: break
                        if (e.isDirectory) continue
                        val parts = e.name.split("/")
                        val ok = when (parts.size) {
                            1 -> parts[0] == "meta.json" || parts[0] == "prefs.json" || parts[0] in FILES
                            2 -> parts[0] in DIRS && safeName(parts[1])
                            else -> false
                        }
                        if (!ok) continue
                        val out = File(tmp, e.name)
                        out.parentFile?.mkdirs()
                        out.outputStream().use { z.copyTo(it) }
                        if (e.name == "meta.json") hasMeta = true
                    }
                }
            }
            if (!hasMeta) return "Tsy backup KAJY io rakitra io."
            val meta = JSONObject(File(tmp, "meta.json").readText())
            if (meta.optString("app") != "KAJY") return "Tsy backup KAJY io rakitra io."
            // Hamarino aloha fa mety ny JSON
            File(tmp, "stats.json").takeIf { it.exists() }?.let { JSONObject(it.readText()) }
            File(tmp, "custom_bots.json").takeIf { it.exists() }?.let { JSONArray(it.readText()) }
            val prefsJson = File(tmp, "prefs.json").takeIf { it.exists() }?.let { JSONObject(it.readText()) }

            // Ampiharo
            for (f in FILES) {
                val dst = File(ctx.filesDir, f)
                val src = File(tmp, f)
                if (src.exists()) src.copyTo(dst, overwrite = true) else dst.delete()
            }
            for (d in DIRS) {
                val dst = File(ctx.filesDir, d)
                dst.deleteRecursively(); dst.mkdirs()
                File(tmp, d).listFiles()?.forEach { it.copyTo(File(dst, it.name), overwrite = true) }
            }
            if (prefsJson != null) prefsFromJson(ctx, prefsJson)
            return null
        } catch (e: Exception) {
            return "Tsy mety ny backup: " + (e.message ?: "hadisoana")
        } finally {
            tmp.deleteRecursively()
        }
    }
}

/**
 * Backup automatique: isan'andro na isan'herinandro (rehefa misokatra ny app), ary alohan'ny fanovana lehibe
 * (restore, famafana fifaninanana, famafana statistika). Tehirizina ao amin'ny filesDir/auto_backups
 * (tsy voakasik'ny restore); ny 7 farany "auto" sy ny 5 farany "before" ihany no tazonina.
 */
object AutoBackup {
    private const val PREFS = "auto_backup_prefs"
    private fun p(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun dir(ctx: Context): File = File(ctx.filesDir, "auto_backups").apply { mkdirs() }

    /** 0 = tsy misy, 1 = isan'andro, 2 = isan'herinandro */
    fun mode(ctx: Context): Int = p(ctx).getInt("mode", 1)
    fun setMode(ctx: Context, m: Int) { p(ctx).edit().putInt("mode", m).apply() }
    fun last(ctx: Context): Long = p(ctx).getLong("last", 0L)

    fun list(ctx: Context): List<File> =
        dir(ctx).listFiles { f -> f.isFile && f.name.endsWith(".zip") }?.sortedByDescending { it.lastModified() } ?: emptyList()

    private fun prune(ctx: Context) {
        for (prefix in listOf("auto-", "before-")) {
            val keep = if (prefix == "auto-") 7 else 5
            list(ctx).filter { it.name.startsWith(prefix) }.drop(keep).forEach { it.delete() }
        }
    }

    /** [tag]: "auto" na "before-restore" / "before-delete" / "before-reset". */
    fun snapshot(ctx: Context, tag: String): File? = try {
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        val f = File(dir(ctx), "$tag-$stamp.zip".let { if (it.startsWith("auto-") || it.startsWith("before-")) it else "auto-$it" })
        val tmp = File(dir(ctx), f.name + ".tmp")
        FileOutputStream(tmp).use { BackupManager.writeZip(ctx, it) }
        tmp.renameTo(f)
        prune(ctx)
        f
    } catch (e: Exception) { null }

    /** Antsoina rehefa misokatra ny app (ao amin'ny thread IO). */
    fun maybeRun(ctx: Context) {
        val m = mode(ctx)
        if (m == 0) return
        val interval = if (m == 1) 24L * 3600_000L else 7L * 24L * 3600_000L
        val now = System.currentTimeMillis()
        if (now - last(ctx) < interval) return
        if (snapshot(ctx, "auto") != null) p(ctx).edit().putLong("last", now).apply()
    }
}

/** Card ao amin'ny Settings: Backup / Restore. */
@Composable
fun BackupCard(vm: ChessViewModel) {
    val ctx = LocalContext.current
    var msg by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf<Uri?>(null) }
    var pendingFile by remember { mutableStateOf<File?>(null) }
    var autoMode by remember { mutableIntStateOf(AutoBackup.mode(ctx)) }
    var refresh by remember { mutableIntStateOf(0) }
    val autoFiles = remember(refresh, msg) { AutoBackup.list(ctx) }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri: Uri? ->
        if (uri != null) msg = BackupManager.export(ctx, uri)
    }
    val opener = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) pending = uri
    }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Backup / Restore", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(
                "Tehirizo ao anaty rakitra .zip ny Elo-nao, ny statistika, ny bot nataonao, ny lalao, ny fifaninanana ary ny settings, mba tsy ho very rehefa manova findaina.",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ saver.launch(BackupManager.suggestedName()) }) { Text("Backup") }
                OutlinedButton({ opener.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }) { Text("Restore") }
            }
            OutlinedButton({
                try {
                    val f = BackupManager.exportForShare(ctx)
                    ShareUtil.share(ctx, f, "application/zip", "Zarao ny backup")
                } catch (e: Exception) { msg = "Tsy lasa ny fizarana: " + (e.message ?: "") }
            }, Modifier.fillMaxWidth()) { Text("Zarao (Drive, WhatsApp...)") }
            Text("Backup automatique", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for ((v, label) in listOf(0 to "Tsy misy", 1 to "Isan'andro", 2 to "Isan'herinandro")) {
                    FilterChip(autoMode == v, { autoMode = v; AutoBackup.setMode(ctx, v) }, { Text(label, fontSize = 12.sp) })
                }
            }
            val lastT = AutoBackup.last(ctx)
            Text(
                "Mitahiry ihany koa alohan'ny restore sy ny famafana fifaninanana/statistika. " +
                    (if (lastT > 0) "Farany: " + SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(lastT)) else "Mbola tsy nisy."),
                fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            for (f in autoFiles.take(4)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        f.name.removeSuffix(".zip") + " (" + (f.length() / 1024) + " KB)",
                        Modifier.weight(1f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    TextButton({ pendingFile = f }) { Text("Averina", fontSize = 12.sp) }
                    TextButton({
                        try { ShareUtil.share(ctx, copyToShared(ctx, f), "application/zip", "Zarao ny backup") }
                        catch (e: Exception) { msg = "Tsy lasa ny fizarana." }
                    }) { Text("Zarao", fontSize = 12.sp) }
                }
            }
            if (msg.isNotEmpty()) Text(msg, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
        }
    }
    val u = pending
    if (u != null) {
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("Haverina ny backup?") },
            text = { Text("Hosoloina ny Elo, statistika, bot, lalao, fifaninanana ary settings ankehitriny amin'ny ao amin'ny backup.") },
            confirmButton = {
                Button({
                    pending = null
                    AutoBackup.snapshot(ctx, "before-restore")
                    val err = BackupManager.restore(ctx, u)
                    if (err == null) { vm.reloadAfterRestore(); msg = "Voaverina ny backup." } else msg = err
                    refresh++
                }) { Text("Averina") }
            },
            dismissButton = { TextButton({ pending = null }) { Text("Foano") } }
        )
    }
    val pf = pendingFile
    if (pf != null) {
        AlertDialog(
            onDismissRequest = { pendingFile = null },
            title = { Text("Haverina ity backup ity?") },
            text = { Text(pf.name + "\n\nHosoloina ny zava-drehetra ankehitriny (nefa hotahirizina aloha ny toe-javatra ankehitriny).") },
            confirmButton = {
                Button({
                    pendingFile = null
                    AutoBackup.snapshot(ctx, "before-restore")
                    val err = BackupManager.restoreFile(ctx, pf)
                    if (err == null) { vm.reloadAfterRestore(); msg = "Voaverina ny backup." } else msg = err
                    refresh++
                }) { Text("Averina") }
            },
            dismissButton = { TextButton({ pendingFile = null }) { Text("Foano") } }
        )
    }
}

private fun copyToShared(ctx: Context, f: File): File {
    val out = File(ShareUtil.sharedDir(ctx), f.name)
    f.copyTo(out, overwrite = true)
    return out
}
