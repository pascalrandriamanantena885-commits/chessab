package mg.chess.offline

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool

/**
 * Feo vahoaka sy stinger (gasp, cheer, drumroll...) avy ao amin'ny res/raw.
 * Tsy mamono ny app raha tsy hita ny rakitra: mijanona amin'ny peo irery ihany.
 */
class CrowdFx(context: Context) {
    private val app = context.applicationContext
    private val lock = Any()
    private val ids = HashMap<String, Int>()
    private val loaded = HashSet<Int>()
    private var ambStream = 0
    private var wantAmbient = false
    private var released = false
    private var ambVol = BASE_AMBIENT

    private val pool: SoundPool = SoundPool.Builder()
        .setMaxStreams(5)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()

    init {
        pool.setOnLoadCompleteListener { _, sid, status ->
            if (status != 0) return@setOnLoadCompleteListener
            synchronized(lock) {
                loaded.add(sid)
                if (wantAmbient && sid == ids[AMBIENT] && ambStream == 0) startAmbientLocked()
            }
        }
        for (n in NAMES) {
            val res = try { app.resources.getIdentifier(n, "raw", app.packageName) } catch (e: Exception) { 0 }
            if (res != 0) {
                try { synchronized(lock) { ids[n] = pool.load(app, res, 1) } } catch (_: Exception) {}
            }
        }
    }

    fun play(name: String, vol: Float = 1f, rate: Float = 1f) {
        synchronized(lock) {
            if (released) return
            val sid = ids[name] ?: return
            if (!loaded.contains(sid)) return
            try { pool.play(sid, vol.coerceIn(0f, 1f), vol.coerceIn(0f, 1f), 1, 0, rate.coerceIn(0.5f, 2f)) } catch (_: Exception) {}
        }
    }

    /** Hanova ny haavon'ny feo vahoaka eo ambadika (0..1 ny excitement). */
    fun setExcitement(ex: Float) {
        synchronized(lock) {
            ambVol = BASE_AMBIENT + (MAX_AMBIENT - BASE_AMBIENT) * ex.coerceIn(0f, 1f)
            if (ambStream != 0) { try { pool.setVolume(ambStream, ambVol, ambVol) } catch (_: Exception) {} }
        }
    }

    /** Feo hetsika eo amin'ny board (tok, capture, check...). */
    fun playMove(kind: MoveKind) {
        val n = when (kind) {
            MoveKind.MOVE -> "mv_move"
            MoveKind.CAPTURE -> "mv_capture"
            MoveKind.CHECK -> "mv_check"
            MoveKind.CASTLE -> "mv_castle"
            MoveKind.PROMOTE -> "mv_promote"
        }
        // fiovaovana kely mba tsy ho mitovy foana
        play(n, 0.9f, 0.96f + Math.random().toFloat() * 0.08f)
    }

    fun startAmbient() {
        synchronized(lock) {
            if (released) return
            wantAmbient = true
            if (ambStream == 0) startAmbientLocked()
        }
    }

    private fun startAmbientLocked() {
        val sid = ids[AMBIENT] ?: return
        if (!loaded.contains(sid)) return
        try { ambStream = pool.play(sid, ambVol, ambVol, 0, -1, 1f) } catch (_: Exception) { ambStream = 0 }
    }

    fun stopAmbient() {
        synchronized(lock) {
            wantAmbient = false
            if (ambStream != 0) { try { pool.stop(ambStream) } catch (_: Exception) {}; ambStream = 0 }
        }
    }

    fun release() {
        stopAmbient()
        synchronized(lock) {
            released = true
            try { pool.release() } catch (_: Exception) {}
        }
    }

    companion object {
        const val AMBIENT = "crowd_ambient"
        const val BASE_AMBIENT = 0.16f
        const val MAX_AMBIENT = 0.38f
        val NAMES = listOf(
            "crowd_ambient", "crowd_cheer_small", "crowd_cheer_big", "crowd_gasp", "crowd_groan",
            "drumroll", "riser", "impact", "applause_short", "whoosh", "bell_start", "whistle",
            "heartbeat", "clock_tick",
            "mv_move", "mv_capture", "mv_castle", "mv_check", "mv_promote"
        )
    }
}

/** Feo iray alefa miaraka amin'ny andalana (delayMs = fiandrasana alohan'ny alefa). */
data class Cue(val name: String, val vol: Float = 1f, val delayMs: Long = 0L)

/** Mifidy ny feo mifanaraka amin'ny andalana araka ny teny, ny mood ary ny zava-dehibe (pri). */
object CueMap {
    /** evalDriven=true: ny fitsarana (blunder/sacrifice...) dia avy amin'ny Stockfish (LiveEval), fa tsy avy amin'ny teny. */
    fun forLine(l: CLine, evalDriven: Boolean = false): List<Cue> {
        if (l.pri < 2) return emptyList()
        val s = l.text.lowercase()
        fun has(vararg k: String) = k.any { s.contains(it) }
        return when {
            has("is the champion") -> listOf(Cue("crowd_cheer_big"), Cue("applause_short", 0.7f, 500))
            has("flag falls", "time out", "timeout") -> listOf(Cue("whistle", 0.8f))
            has("checkmate") -> listOf(Cue("crowd_cheer_big", 0.95f))
            has("goes through to") -> listOf(Cue("crowd_cheer_small"), Cue("applause_short", 0.6f, 400))
            has("wins the game", "takes the victory") -> listOf(Cue("crowd_cheer_small"))
            has("let the battle begin", "let the game begin", "here we go") -> listOf(Cue("bell_start", 0.8f))
            has("under ten seconds", "seconds left", "flag is hanging") -> listOf(Cue("heartbeat", 0.7f))
            has("stalemate") -> listOf(Cue("crowd_gasp"))
            has("queen falls", "takes the queen") -> listOf(Cue("impact", 0.8f), Cue("crowd_gasp", 0.8f, 150))
            evalDriven && has("blunder", "hanging", "hung ", "no, no, no", "terrible", "sacrifice",
                "tension is rising", "forced now", "going for the throat", "wins material", "marathon") -> emptyList()
            has("blunder", "hanging", "hung ", "no, no, no", "terrible") ->
                listOf(if (l.mood == Mood.SHOCKED || l.mood == Mood.TENSE || l.mood == Mood.EXCITED) Cue("crowd_gasp") else Cue("crowd_groan", 0.8f))
            has("sacrifice") -> listOf(Cue("crowd_gasp", 0.8f))
            has("tension is rising", "forced now", "going for the throat") -> listOf(Cue("riser", 0.5f))
            has("queens are off") -> listOf(Cue("crowd_gasp", 0.6f))
            has("wins material", "marathon") -> listOf(Cue("crowd_cheer_small", 0.5f))
            evalDriven -> emptyList()
            l.pri >= 3 && l.mood == Mood.SHOCKED -> listOf(Cue("crowd_gasp", 0.8f))
            l.pri >= 3 && l.mood == Mood.EXCITED -> listOf(Cue("crowd_cheer_small", 0.6f))
            else -> emptyList()
        }
    }
}

enum class MoveKind { MOVE, CAPTURE, CHECK, CASTLE, PROMOTE }

/** Haptic fohy rehefa mihetsika (mila permission VIBRATE). */
class Haptics(context: Context) {
    private val vib: android.os.Vibrator? = try {
        @Suppress("DEPRECATION")
        context.applicationContext.getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator
    } catch (_: Exception) { null }

    fun tap(kind: MoveKind) {
        val v = vib ?: return
        try {
            if (!v.hasVibrator()) return
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                val eff = when (kind) {
                    MoveKind.MOVE -> android.os.VibrationEffect.createOneShot(10, 60)
                    MoveKind.CAPTURE -> android.os.VibrationEffect.createOneShot(22, 140)
                    MoveKind.CASTLE -> android.os.VibrationEffect.createWaveform(longArrayOf(0, 12, 60, 12), -1)
                    MoveKind.CHECK, MoveKind.PROMOTE -> android.os.VibrationEffect.createWaveform(longArrayOf(0, 18, 50, 28), -1)
                }
                v.vibrate(eff)
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(if (kind == MoveKind.MOVE) 10L else 22L)
            }
        } catch (_: Exception) {}
    }
}
