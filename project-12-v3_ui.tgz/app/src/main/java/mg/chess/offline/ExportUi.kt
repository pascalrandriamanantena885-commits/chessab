package mg.chess.offline

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun toast(ctx: Context, msg: String) {
    try { Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show() } catch (_: Exception) {}
}

private fun shareText(ctx: Context, subject: String, text: String) {
    try {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, text)
        }
        ctx.startActivity(Intent.createChooser(i, subject).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        toast(ctx, "Tsy afaka nizara")
    }
}

@Composable
private fun ExportRow(label: String, onCopy: () -> Unit, onShare: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.6f))
        Button(onCopy, Modifier.weight(1f)) { Text("Adikao") }
        OutlinedButton(onShare, Modifier.weight(1f)) { Text("Zarao") }
    }
}

/** Dialog export: PGN / FEN (copy, share) + rakitra .pgn (Storage Access Framework, tsy mila alalana). */
@Composable
fun ExportDialog(title: String, pgn: String, fen: String?, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/x-chess-pgn")) { uri: Uri? ->
        if (uri != null) {
            val ok = try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(pgn.toByteArray(Charsets.UTF_8)) } != null
            } catch (e: Exception) { false }
            toast(ctx, if (ok) "Voatahiry ny rakitra PGN" else "Tsy afaka nitahiry")
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    pgn, fontSize = 11.sp, fontFamily = FontFamily.Monospace,
                    modifier = Modifier.fillMaxWidth().heightIn(max = 130.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainerHighest)
                        .verticalScroll(rememberScrollState()).padding(8.dp)
                )
                ExportRow("PGN",
                    { clip.setText(AnnotatedString(pgn)); toast(ctx, "Voadika ny PGN") },
                    { shareText(ctx, "KAJY PGN", pgn) })
                if (fen != null) {
                    ExportRow("FEN",
                        { clip.setText(AnnotatedString(fen)); toast(ctx, "Voadika ny FEN") },
                        { shareText(ctx, "KAJY FEN", fen) })
                }
                OutlinedButton(
                    { saver.launch("kajy_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) + ".pgn") },
                    Modifier.fillMaxWidth()
                ) { Text("Tehirizo ho rakitra .pgn") }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("Akatony") } }
    )
}
