package mg.chess.offline

import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.PieceType
import com.github.bhlangonijr.chesslib.move.Move
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.math.abs

enum class ReactKind { BLUNDER, MISTAKE, BRILLIANT, FIND, MATE_ALERT }

/** delta = fiovan'ny win% ho an'ny mpihetsika (mihena = ratsy). */
data class Reaction(val kind: ReactKind, val delta: Double)

/** Karazan'ny hetsika alohan'ny "doMove" (capture, castle, promotion). Ny check dia hamarinina aorian'ny hetsika. */
fun baseMoveKind(b: Board, mv: Move): MoveKind {
    if (mv.promotion != Piece.NONE) return MoveKind.PROMOTE
    val p = b.getPiece(mv.from)
    if (p.pieceType == PieceType.KING && abs(mv.to.file.ordinal - mv.from.file.ordinal) == 2) return MoveKind.CASTLE
    if (b.getPiece(mv.to) != Piece.NONE) return MoveKind.CAPTURE
    if (p.pieceType == PieceType.PAWN && mv.from.file != mv.to.file) return MoveKind.CAPTURE // en passant
    return MoveKind.MOVE
}

/** Antsoina aorian'ny doMove: raha mahavita check ny hetsika dia CHECK (afa-tsy promotion). */
fun finalMoveKind(base: MoveKind, post: Board): MoveKind =
    if (base != MoveKind.PROMOTE && post.isKingAttacked) MoveKind.CHECK else base

/**
 * Mamantatra ny kalitaon'ny hetsika amin'ny alalan'ny Stockfish (analyse fohy) mba hanaovan'ny vahoaka
 * famaliana marina: gasp rehefa blunder, cheer rehefa hetsika tokana tsara, riser rehefa hita ny mate.
 * Analyse iray isaky ny hetsika (ny faran'ny analyse dia tehirizina ho "alohan'ny hetsika" manaraka).
 */
class LiveEval(private val engine: Engine) {
    private val gate = Mutex()
    private var prevFen: String? = null
    private var prevLines: List<Line> = emptyList()
    private var mateAlerted = false

    /** Marina rehefa nahomby ny analyse farany. */
    @Volatile var active = false
        private set

    fun reset() {
        prevFen = null
        prevLines = emptyList()
        mateAlerted = false
        active = false
    }

    suspend fun onMove(preFen: String, uci: String, postFen: String, ply: Int): Reaction? = gate.withLock {
        val pre = if (prevFen == preFen && prevLines.isNotEmpty()) prevLines
        else engine.analyze(preFen, DEPTH, MS, 2)
        val post = engine.analyze(postFen, DEPTH, MS, 2)
        // post foana = toerana farany (mate/stalemate) -> ny CommentaryBrain no mitantara ny valiny
        prevFen = postFen
        prevLines = post
        active = pre.isNotEmpty() && post.isNotEmpty()
        if (!active || ply < MIN_PLY) return@withLock null

        val preWin = winPct(pre[0].stmCp())
        val postWin = 100.0 - winPct(post[0].stmCp())   // post = fijerin'ny mpilalao manaraka
        val delta = postWin - preWin
        val gap = if (pre.size >= 2) preWin - winPct(pre[1].stmCp()) else 0.0
        val playedBest = pre[0].move.equals(uci, true)
        val postMate = post[0].mate

        when {
            delta <= -25.0 -> Reaction(ReactKind.BLUNDER, delta)
            delta <= -12.0 -> Reaction(ReactKind.MISTAKE, delta)
            postMate != null && postMate < 0 && abs(postMate) <= 5 && !mateAlerted -> {
                mateAlerted = true
                Reaction(ReactKind.MATE_ALERT, delta)
            }
            playedBest && gap >= 35.0 && preWin in 12.0..92.0 -> Reaction(ReactKind.BRILLIANT, delta)
            playedBest && gap >= 20.0 && preWin in 10.0..95.0 -> Reaction(ReactKind.FIND, delta)
            else -> null
        }
    }

    companion object {
        const val DEPTH = 10
        const val MS = 220
        const val MIN_PLY = 6
    }
}
