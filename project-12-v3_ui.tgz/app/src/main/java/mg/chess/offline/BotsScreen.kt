package mg.chess.offline

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

private const val F_ALL = -1
private const val F_CUSTOM = 6

/** true = miseho foana ny Elo eo amin'ny card (toa chess.com). false = miseho rehefa voatsindry fotsiny. */
private const val SHOW_ELO_ON_CARD = true

@Composable
fun BotsScreen(vm: ChessViewModel) {
    BackHandler { vm.toMenu() }
    var choice by remember { mutableIntStateOf(0) }
    var filter by remember { mutableIntStateOf(F_ALL) }
    var selectedId by remember { mutableStateOf<String?>(null) }
    val all = BotRegistry.visible
    val shown = when (filter) {
        F_ALL -> all
        F_CUSTOM -> all.filter { it.custom }
        else -> all.filter { tierOf(it.elo).ordinal == filter }
    }
    val selected = shown.firstOrNull { it.id == selectedId }
    val cs = MaterialTheme.colorScheme

    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 8.dp)) {
        ScreenTitle("Fidio ny bot", onBack = { vm.toMenu() }) {
            OutlinedButton({ vm.toPgn() }, shape = RoundedCornerShape(50)) { Text("PGN → Bot", fontSize = 13.sp) }
        }

        // ---- Fanamboarana: loko + ora ----
        Card(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = cs.surfaceContainer),
            border = BorderStroke(1.dp, cs.outlineVariant)
        ) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ColorTile("Fotsy", 0, choice == 0, Modifier.weight(1f)) { choice = 0 }
                    ColorTile("Kisendrasendra", 2, choice == 2, Modifier.weight(1f)) { choice = 2 }
                    ColorTile("Mainty", 1, choice == 1, Modifier.weight(1f)) { choice = 1 }
                }
                TimeControlPicker(vm)
            }
        }
        Spacer(Modifier.height(10.dp))

        // ---- Sivana araka ny sokajy ----
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            KajyPill("Rehetra (${all.size})", filter == F_ALL, cs.primary) { filter = F_ALL }
            for (t in BotTier.values()) {
                val n = all.count { tierOf(it.elo) == t }
                KajyPill("${t.label} ($n)", filter == t.ordinal, Color(t.color)) { filter = t.ordinal }
            }
            KajyPill("Nataoko (${all.count { it.custom }})", filter == F_CUSTOM, cs.tertiary) { filter = F_CUSTOM }
        }
        Spacer(Modifier.height(8.dp))

        if (shown.isEmpty()) {
            Text(
                "Tsy misy bot amin'ity sokajy ity. Azonao atao ny mamorona avy amin'ny PGN.",
                Modifier.padding(top = 12.dp), color = cs.onSurfaceVariant
            )
        }

        // ---- Lisitra bot (2 colonne, card lehibe) ----
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (filter == F_ALL) {
                val groups = shown.groupBy { tierOf(it.elo) }
                for ((tier, list) in groups) {
                    item(key = "hdr_${tier.name}", span = { GridItemSpan(maxLineSpan) }) { TierHeader(tier, list.size) }
                    items(list, key = { it.id }) { b ->
                        BotCard(b, b.id == selectedId) { selectedId = if (selectedId == b.id) null else b.id }
                    }
                }
            } else {
                items(shown, key = { it.id }) { b ->
                    BotCard(b, b.id == selectedId) { selectedId = if (selectedId == b.id) null else b.id }
                }
            }
        }

        // ---- Panel antsipiriany + bokotra Milalao ----
        AnimatedVisibility(selected != null) {
            if (selected != null) {
                SelectedBotPanel(selected) {
                    val white = when (choice) { 0 -> true; 1 -> false; else -> Random.nextBoolean() }
                    vm.startBotGame(selected, white)
                }
            }
        }
    }
}

@Composable
private fun ColorTile(label: String, kind: Int, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(14.dp)
    val dot = when (kind) {
        0 -> Brush.linearGradient(listOf(Color.White, Color.White))
        1 -> Brush.linearGradient(listOf(Color(0xFF262421), Color(0xFF262421)))
        else -> Brush.horizontalGradient(0f to Color.White, 0.5f to Color.White, 0.5f to Color(0xFF262421), 1f to Color(0xFF262421))
    }
    Row(
        modifier.clip(shape)
            .background(if (selected) cs.primaryContainer else cs.surfaceContainerHigh)
            .border(if (selected) 2.dp else 1.dp, if (selected) cs.primary else cs.outlineVariant, shape)
            .clickable { onClick() }
            .padding(vertical = 10.dp, horizontal = 6.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(18.dp).clip(CircleShape).background(dot).border(1.dp, Color(0x66888888), CircleShape))
        Spacer(Modifier.width(6.dp))
        Text(
            label, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = if (selected) cs.onPrimaryContainer else cs.onSurface
        )
    }
}

@Composable
private fun TierHeader(t: BotTier, count: Int) {
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(width = 4.dp, height = 18.dp).clip(RoundedCornerShape(2.dp)).background(Color(t.color)))
        Spacer(Modifier.width(8.dp))
        Text(t.label, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(8.dp))
        Text("${t.range} · $count", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Card lehibe: sary kare lehibe + Elo + anarana + bio fohy. */
@Composable
private fun BotCard(b: Bot, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val tier = tierOf(b.elo)
    val accent = Color(tier.color)
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(cs.surfaceContainer)
            .border(if (selected) 3.dp else 1.dp, if (selected) accent else cs.outlineVariant, shape)
            .clickable { onClick() }
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(1f)) {
            BotPortrait(b)
            Box(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(60.dp)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000))))
            )
            if (SHOW_ELO_ON_CARD || selected) {
                Box(
                    Modifier.align(Alignment.BottomStart).padding(10.dp).clip(RoundedCornerShape(8.dp))
                        .background(accent).padding(horizontal = 9.dp, vertical = 3.dp)
                ) {
                    Text(
                        if (b.elo > SF_MAX_ELO) "MAX" else "${b.elo}",
                        color = Color.Black, fontSize = 13.sp, fontWeight = FontWeight.Black
                    )
                }
            }
            if (selected) {
                Box(
                    Modifier.align(Alignment.TopEnd).padding(8.dp).size(26.dp).clip(CircleShape).background(accent),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Check, null, tint = Color.Black, modifier = Modifier.size(18.dp)) }
            }
        }
        Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(b.name, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                b.bio, fontSize = 12.sp, color = cs.onSurfaceVariant, lineHeight = 15.sp,
                minLines = 2, maxLines = 2, overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/** Sary kare; raha tsy misy sary dia loko + litera voalohany. */
@Composable
private fun BotPortrait(b: Bot) {
    val ctx = LocalContext.current
    val img = remember(b.id, b.rev) { Sprites.avatar(ctx, b) }
    if (img != null) {
        Image(img, b.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    } else {
        Box(
            Modifier.fillMaxSize().background(
                Brush.linearGradient(listOf(Color(b.color), Color(b.color).copy(alpha = 0.65f)))
            ),
            contentAlignment = Alignment.Center
        ) {
            Text(b.name.take(1), color = Color.White, fontWeight = FontWeight.Black, fontSize = 56.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun SelectedBotPanel(b: Bot, onPlay: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val tier = tierOf(b.elo)
    val accent = Color(tier.color)
    Card(
        Modifier.fillMaxWidth().padding(top = 2.dp),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh),
        border = BorderStroke(1.5.dp, accent.copy(alpha = 0.7f))
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                BotAvatar(b, 52.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(b.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.weight(1f, fill = false))
                        Spacer(Modifier.width(8.dp))
                        Text(if (b.elo > SF_MAX_ELO) "MAX" else "${b.elo}", fontWeight = FontWeight.Black, color = accent)
                        Spacer(Modifier.width(8.dp))
                        TierChip(tier)
                    }
                    Text(b.bio, fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    val spec = b.specialty()
                    if (spec.isNotEmpty() && spec != b.bio) {
                        Text(spec, fontSize = 11.sp, color = cs.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            Button(
                onPlay, Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = cs.primary, contentColor = cs.onPrimary)
            ) {
                Icon(Icons.Rounded.PlayArrow, null)
                Spacer(Modifier.width(6.dp))
                Text("Milalao", fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
