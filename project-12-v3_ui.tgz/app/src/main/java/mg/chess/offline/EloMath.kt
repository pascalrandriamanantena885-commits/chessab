package mg.chess.offline

import kotlin.math.pow

/** Kajy Elo mazava (tsy misy Android) - azo andramana amin'ny unit test. */
const val START_RATING = 1200.0

/** Isa andrasana hahazoan'ny mpilalao (rating) ny bot (0..1). */
fun eloExpected(rating: Double, opponent: Double): Double =
    1.0 / (1.0 + 10.0.pow((opponent - rating) / 400.0))

/** K-factor: lehibe amin'ny voalohany (rating tsy mbola marina), mihena rehefa maro ny lalao. */
fun eloK(games: Int): Double = when {
    games < 10 -> 40.0
    games < 30 -> 28.0
    else -> 20.0
}

fun eloNext(rating: Double, games: Int, opponent: Int, score: Double): Double =
    rating + eloK(games) * (score - eloExpected(rating, opponent.toDouble()))

/** Isa an'ny olona (1 = nahazo, 0.5 = draw, 0 = resy) araka ny valiny PGN. null = tsy mbola vita. */
fun scoreOf(result: String?, humanWhite: Boolean): Double? = when (result) {
    "1/2-1/2" -> 0.5
    "1-0" -> if (humanWhite) 1.0 else 0.0
    "0-1" -> if (humanWhite) 0.0 else 1.0
    else -> null
}
