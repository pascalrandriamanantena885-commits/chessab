package mg.chess.offline

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File

/** Fizarana rakitra (Drive, WhatsApp, Telegram, email...) amin'ny alalan'ny FileProvider. */
object ShareUtil {
    fun sharedDir(ctx: Context): File = File(ctx.cacheDir, "shared").apply { mkdirs() }

    fun safeName(s: String): String =
        s.trim().replace(Regex("[^A-Za-z0-9_-]+"), "_").trim('_').ifEmpty { "kajy" }.take(40)

    fun share(ctx: Context, file: File, mime: String, title: String) {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(send, title).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
        ctx.startActivity(chooser)
    }
}
