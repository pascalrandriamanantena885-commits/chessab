package mg.chess.offline

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Sokajy bot (toa an'i chess.com): Beginner -> Legend. */
enum class BotTier(val label: String, val range: String, val color: Long, val min: Int) {
    BEGINNER("Beginner", "< 1000", 0xFF81B64C, 0),
    INTERMEDIATE("Intermediate", "1000 - 1599", 0xFF4FC3F7, 1000),
    ADVANCED("Advanced", "1600 - 2099", 0xFFFFB74D, 1600),
    MASTER("Master", "2100 - 2499", 0xFFBA68C8, 2100),
    GRANDMASTER("Grandmaster", "2500 - 3189", 0xFFEF5350, 2500),
    LEGEND("Legend", "3190+ (hery feno)", 0xFFFFD54F, 3190)
}

fun tierOf(elo: Int): BotTier = BotTier.values().last { elo >= it.min }

@Composable
fun TierChip(t: BotTier, modifier: Modifier = Modifier) {
    Box(
        modifier.clip(RoundedCornerShape(6.dp)).background(Color(t.color).copy(alpha = 0.22f))
            .padding(horizontal = 7.dp, vertical = 2.dp)
    ) {
        Text(t.label, color = Color(t.color), fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}
