package mg.chess.offline

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix

/** Loko ny board. light/dark = null => ampiasaina ny sary (tiles) ao amin'ny assets raha misy. */
data class BoardTheme(val id: String, val label: String, val light: Color?, val dark: Color?)

val BOARD_THEMES = listOf(
    BoardTheme("image", "Sary (default)", null, null),
    BoardTheme("green", "Maitso", Color(0xFFEEEED2), Color(0xFF769656)),
    BoardTheme("brown", "Volon-kazo", Color(0xFFF0D9B5), Color(0xFFB58863)),
    BoardTheme("blue", "Manga", Color(0xFFDEE3E6), Color(0xFF8CA2AD)),
    BoardTheme("gray", "Fotsy-mainty", Color(0xFFE0E0E0), Color(0xFF8D8D8D)),
    BoardTheme("purple", "Volomparasy", Color(0xFFE8DAEF), Color(0xFF8E6BAD)),
    BoardTheme("coral", "Mena", Color(0xFFF6E3D5), Color(0xFFC9715E)),
)

/** Matrix loko: r,g,b = fampitomboana (0..1+), or,og,ob = fampiakarana (0..255). */
private fun tint(r: Float, g: Float, b: Float, dr: Float = 0f, dg: Float = 0f, db: Float = 0f) = ColorMatrix(
    floatArrayOf(
        r, 0f, 0f, 0f, dr,
        0f, g, 0f, 0f, dg,
        0f, 0f, b, 0f, db,
        0f, 0f, 0f, 1f, 0f
    )
)

/** Fomba piece: sary an'ny assets (miaraka na tsy miaraka amin'ny loko), na glyph (soratra Unicode). */
class PieceTheme(
    val id: String, val label: String, val glyph: Boolean = false,
    white: ColorMatrix? = null, black: ColorMatrix? = null
) {
    val whiteFilter: ColorFilter? = white?.let { ColorFilter.colorMatrix(it) }
    val blackFilter: ColorFilter? = black?.let { ColorFilter.colorMatrix(it) }
}

val PIECE_THEMES = listOf(
    PieceTheme("classic", "Klasika (sary)"),
    PieceTheme("gold", "Volamena", white = tint(1f, 0.84f, 0.40f), black = tint(1f, 1f, 1f, 60f, 35f, 0f)),
    PieceTheme("ocean", "Ranomasina", white = tint(0.70f, 0.92f, 1f), black = tint(1f, 1f, 1f, 0f, 30f, 85f)),
    PieceTheme("rose", "Rozy", white = tint(1f, 0.78f, 0.86f), black = tint(1f, 1f, 1f, 85f, 10f, 40f)),
    PieceTheme("glyph", "Glyph (soratra)", glyph = true),
)

/** Safidin'ny mpampiasa momba ny board sy ny piece; tehirizina ao amin'ny chess_prefs. */
object BoardStyle {
    var boardId by mutableStateOf("image"); private set
    var pieceId by mutableStateOf("classic"); private set

    val board: BoardTheme get() = BOARD_THEMES.firstOrNull { it.id == boardId } ?: BOARD_THEMES[0]
    val piece: PieceTheme get() = PIECE_THEMES.firstOrNull { it.id == pieceId } ?: PIECE_THEMES[0]

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("chess_prefs", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        val p = prefs(ctx)
        boardId = p.getString("board_theme", "image") ?: "image"
        pieceId = p.getString("piece_theme", "classic") ?: "classic"
    }

    fun setBoard(ctx: Context, id: String) {
        boardId = id
        prefs(ctx).edit().putString("board_theme", id).apply()
    }

    fun setPiece(ctx: Context, id: String) {
        pieceId = id
        prefs(ctx).edit().putString("piece_theme", id).apply()
    }
}
