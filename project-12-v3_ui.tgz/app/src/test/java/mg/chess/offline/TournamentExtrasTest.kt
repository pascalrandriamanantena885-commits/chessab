package mg.chess.offline

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TournamentExtrasTest {
    private fun humans(n: Int) = List(n) { Participant("h$it", "P$it", 1000 + it, null) }

    private fun sa(br: Int, gr: Int, acc: Double) = SideAn(20, acc, 30, br, gr, 0, 0)

    @Test fun bracketHasAllRoundsEvenBeforePlay() {
        val t = Tournament.create(1L, "T", humans(8), 0L, 0L, false)
        val rounds = t.bracket()
        assertEquals(listOf(4, 2, 1), rounds.map { it.size })
        assertEquals("Mpandresy 1", rounds[1][0].whiteLabel)
    }

    @Test fun bracketWithGroupsShowsPlaceholders() {
        val t = Tournament.create(2L, "T", humans(12), 0L, 0L, true)
        val rounds = t.bracket()
        assertEquals(t.groups.size * 2, t.firstKoSize())
        assertTrue(rounds[0][0].whiteLabel.startsWith("1er"))
    }

    @Test fun podiumGivesGoldAndSilver() {
        val t = Tournament.create(3L, "T", humans(2), 0L, 0L, false)
        assertNull(t.podium())
        val m = t.matches.first { it.stage == "KO2" }
        t.recordResult(m, "1-0")
        t.advance()
        val pd = t.podium()
        assertNotNull(pd)
        assertEquals(m.whiteId, pd!!.first)
        assertEquals(m.blackId, pd.second)
    }

    @Test fun playerLinesSumBrilliantAndAccuracy() {
        val t = Tournament.create(4L, "T", humans(2), 0L, 0L, false)
        val m = t.matches.first { it.stage == "KO2" }
        m.moves = listOf("e2e4", "e7e5", "g1f3", "b8c6")
        t.recordResult(m, "1-0")
        m.analysis = MatchAnalysis(sa(2, 1, 90.0), sa(0, 3, 70.0), listOf(BrilliantMove(5, true, "Nxe5", "f3e5", "x")))
        val lines = t.playerLines().associateBy { it.id }
        assertEquals(2, lines[m.whiteId]!!.brilliant)
        assertEquals(3, lines[m.blackId]!!.great)
        assertEquals(90.0, lines[m.whiteId]!!.accuracy!!, 1e-9)
        assertEquals(1, t.brilliantArchive().size)
        assertEquals(1, t.analysedCount())
    }

    @Test fun cupWithFourPlayersHasBronzeMatch() {
        val t = Tournament.create(5L, "T", humans(4), 0L, 0L, false)
        for (m in t.stageMatches()) t.recordResult(m, "1-0")
        t.advance()
        assertEquals("KO2", t.stage)
        assertEquals(2, t.stageMatches().size) // finale + faha-3
        for (m in t.stageMatches()) t.recordResult(m, "1-0")
        assertTrue(t.advance())
        assertNotNull(t.champion)
        assertNotNull(t.bronze())
    }

    @Test fun swissPlaysAllRoundsAndGivesPodium() {
        val t = Tournament.create(6L, "T", humans(8), 0L, 0L, false, swiss = true)
        assertEquals(3, t.swissRoundsTotal())
        var guard = 0
        while (t.champion == null && guard++ < 10) {
            for (m in t.stageMatches()) if (m.result == null) t.recordResult(m, "1-0")
            t.advance()
        }
        assertNotNull(t.champion)
        val pd = t.podium()!!
        assertNotNull(pd.second)
        assertNotNull(t.bronze())
        // tsy misy mpilalao nifanandrina in-roa
        val pairs = t.matches.filter { it.blackId != null }.map { listOf(it.whiteId!!, it.blackId!!).sorted() }
        assertEquals(pairs.size, pairs.toSet().size)
    }

    @Test fun swissWithOddPlayersGivesByes() {
        val t = Tournament.create(7L, "T", humans(5), 0L, 0L, false, swiss = true)
        assertEquals(1, t.matches.count { it.result == "bye" })
    }

    private fun playOut(t: Tournament, gfWhiteLoses: Boolean = false) {
        var guard = 0
        while (t.champion == null && guard++ < 80) {
            for (m in t.stageMatches()) {
                if (m.result == null) t.recordResult(m, if (gfWhiteLoses && m.group == 2 && m.round == 1) "0-1" else "1-0")
            }
            t.advance()
        }
    }

    private fun losses(t: Tournament): Map<String, Int> {
        val out = HashMap<String, Int>()
        for (m in t.matches) {
            val w = m.winner ?: continue
            if (m.blackId == null || m.result == "bye") continue
            val l = if (m.whiteId == w) m.blackId else m.whiteId
            if (l != null) out[l] = (out[l] ?: 0) + 1
        }
        return out
    }

    @Test fun doubleEliminationEightPlayers() {
        val t = Tournament.create(8L, "T", humans(8), 0L, 0L, false, double = true)
        playOut(t)
        assertNotNull(t.champion)
        assertEquals(14, t.matches.count { it.blackId != null && it.result != "bye" })
        assertTrue(losses(t).values.all { it <= 2 })
        assertNotNull(t.podium()!!.second)
        assertNotNull(t.bronze())
    }

    @Test fun doubleEliminationWithByes() {
        for (n in 4..7) {
            val t = Tournament.create(100L + n, "T", humans(n), 0L, 0L, false, double = true)
            playOut(t)
            assertNotNull("n=$n", t.champion)
            assertTrue(losses(t).values.all { it <= 2 })
            assertNotNull(t.bronze())
        }
    }

    @Test fun doubleEliminationGrandFinaleReset() {
        val t = Tournament.create(9L, "T", humans(4), 0L, 0L, false, double = true)
        playOut(t, gfWhiteLoses = true)
        val gf = t.matches.filter { it.group == 2 }
        assertEquals(2, gf.size)
        assertEquals(gf[0].blackId, t.champion)
    }
}
