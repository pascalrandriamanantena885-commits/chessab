package mg.chess.offline

import com.github.bhlangonijr.chesslib.Board
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PersonalityTest {
    private fun feat(fen: String, uci: String): MoveFeat {
        val b = Board(); b.loadFromFen(fen)
        val mv = b.legalMoves().first { it.toString().equals(uci, true) }
        return Personality.feat(b, mv, 10)
    }

    @Test fun phaseStartIsOne() = assertEquals(1.0, Personality.phase(Board()), 1e-9)

    @Test fun phaseEndgameIsLow() {
        val b = Board(); b.loadFromFen("8/8/8/4k3/8/8/4K3/R7 w - - 0 1")
        assertTrue(Personality.phase(b) < 0.2)
        assertTrue(Personality.toleranceScale(b) < Personality.toleranceScale(Board()))
    }

    @Test fun pawnStormDetected() {
        assertTrue(feat("r4rk1/ppp2ppp/8/8/8/8/PPPPPPPP/R3K2R w KQ - 0 1", "g2g4").pawnStorm)
        assertFalse(feat("r4rk1/ppp2ppp/8/8/8/8/PPPPPPPP/R3K2R w KQ - 0 1", "a2a3").pawnStorm)
    }

    @Test fun kingAttackDetected() {
        assertTrue(feat("6k1/5ppp/8/8/8/3Q4/5PPP/6K1 w - - 0 1", "d3g6").kingAttack)
        assertFalse(feat("6k1/5ppp/8/8/8/3Q4/5PPP/6K1 w - - 0 1", "d3d1").kingAttack)
    }
}
