package mg.chess.offline

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PgnExportTest {
    private val opening = listOf("e2e4", "e7e5", "g1f3")

    @Test fun sanStopsAtIllegalMove() {
        assertEquals(1, sanMoves(listOf("e2e4", "e2e4")).size)
        assertEquals(listOf("e4", "e5", "Nf3"), sanMoves(opening))
    }

    @Test fun pgnHasHeadersAndNumberedMoves() {
        val pgn = buildPgn(opening, "Ianao", "Ravao", null, 400, "1-0", 300_000L, 2_000L, 0L)
        assertTrue(pgn.contains("[White \"Ianao\"]"))
        assertTrue(pgn.contains("[Black \"Ravao\"]"))
        assertTrue(pgn.contains("[BlackElo \"400\"]"))
        assertTrue(pgn.contains("[Result \"1-0\"]"))
        assertTrue(pgn.contains("[TimeControl \"300+2\"]"))
        assertTrue(pgn.contains("1. e4 e5 2. Nf3 1-0"))
    }

    @Test fun unfinishedGameUsesStar() {
        val pgn = buildPgn(opening, "A", "B", null, null, null, 0L, 0L, 0L)
        assertTrue(pgn.contains("[Result \"*\"]"))
        assertTrue(pgn.contains("[TimeControl \"-\"]"))
        assertTrue(pgn.trimEnd().endsWith("*"))
    }

    @Test fun quotesInNamesAreEscaped() {
        val pgn = buildPgn(emptyList(), "A\"B", "C", null, null, null, 0L, 0L, 0L)
        assertTrue(pgn.contains("[White \"A\\\"B\"]"))
    }

    @Test fun fenAfterZeroMovesIsStartPosition() {
        assertEquals(START_FEN.substringBefore(" "), fenAfter(opening, 0).substringBefore(" "))
    }

    @Test fun movetextLinesAreWrapped() {
        val many = ArrayList<String>()
        repeat(12) { many.addAll(listOf("g1f3", "g8f6", "f3g1", "f6g8")) }
        val pgn = buildPgn(many, "A", "B", null, null, null, 0L, 0L, 0L)
        val body = pgn.substringAfter("\n\n")
        assertTrue(body.lines().all { it.length <= 80 })
    }
}
