# Third-party notices

| Component | Author | License |
|---|---|---|
| Stockfish 19 (UCI engine + NNUE net) | The Stockfish developers | GPL-3.0-or-later - https://github.com/official-stockfish/Stockfish |
| Berserk (optional, Hybrid) | Jay Honnold | GPL-3.0 - https://github.com/jhonnold/berserk |
| Cburnett chess set (JohnPablok remaster) - pieces and board tiles | Colin M.L. Burnett / JohnPablok | CC BY-SA 3.0 (GPLv2+ dual) |
| chesslib | Ben-Hur Langoni Junior | Apache-2.0 |
| AndroidX / Jetpack Compose / Kotlin coroutines | Google / JetBrains | Apache-2.0 |

Source code of this app: ampio eto ny rohy GitHub repo.
