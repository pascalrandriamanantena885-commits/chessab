SPRITES (tsy voatery - raha tsy misy dia mampiasa loko/glyph ny app)

pieces/  -> wk.png wq.png wr.png wb.png wn.png wp.png  (fotsy)
            bk.png bq.png br.png bb.png bn.png bp.png  (mainty)
         NA sheet.png (6 colonne x 2 andalana, filaharana: K Q B N R P,
            andalana 1 = fotsy, andalana 2 = mainty)
board/   -> board.png (sary 8x8 manontolo, kare)
         NA light.png + dark.png (tile ho an'ny kare tsirairay)
bots/    -> ravao.png rakoto.png soa.png tojo.png fara.png hery.png andry.png max.png
            (sary boribory ho an'ny bot tsirairay, kare no tsara)

Apetaho ao amin'ny lahatahiry "assets/" eo amin'ny fototry ny repo GitHub.
Ny workflow no mamerina azy ao amin'ny app.
