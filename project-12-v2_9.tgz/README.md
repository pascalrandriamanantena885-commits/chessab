# KAJY
Kotlin + Compose, chesslib, **Stockfish 19** (UCI, NDK, NNUE). Push amin'ny GitHub -> Actions -> Artifacts -> APK.
Stockfish: GPLv3 -> ampiasao ho open source ny app.

## Elo tena izy
- Bot 1320-3190: `UCI_LimitStrength` + `UCI_Elo` (fetra ofisialy an'ny Stockfish 19).
- Bot > 3190: hery feno.
- Bot < 1320: fikarohana voafetra (nodes) + safidy hetsika araka ny temperature (Engine.kt).
- Fanitsiana: `ELO_CALIB` ao amin'ny Bots.kt (0 = mivantana).
- Review / game rating: Stockfish feno hery, depth 12/16/20 (Settings), MultiPV 2, expected-points (win%).

## Sprites
Pieces + board tiles: "Cburnett Chess set" (JohnPablok remaster v2), ao amin'ny app/src/main/assets/.
Credit: Colin M.L. Burnett (Cburnett) / JohnPablok - GPLv2+ / CC BY-SA 3.0.
Avatar bot: apetaho ao amin'ny app/src/main/assets/bots/<id>.png. Raha tsy misy dia fallback no miseho.

## Fiasa
- Nav 4 (icon): Play, Fifaninanana, Tantaran'ny lalao, Settings.
- Settings: sary aloha (background) avy ao amin'ny gallerie, theme, depth review, fampidirana / fanovana / famafana bot (sary avy ao amin'ny gallerie).
- Fifaninanana: bot vs bot, olona + bot; poule -> 8ème de finale -> finale; live; review.

## Bot personalité (opening + fomba filalaovana)
- Openings.kt: katalaogy 32 opening (Fotsy: Italian, Ruy Lopez, Scotch, King's Gambit, Vienna, Evans, Danish, Smith-Morra, Open Sicilian, London, Queen's Gambit, English, Réti; Mainty: French, Caro-Kann, Scandinavian, Najdorf, Dragon, Taimanov, Pirc, Alekhine, Petroff, 1...e5, King's Indian, Grünfeld, Nimzo, Queen's Indian, QGD, Slav, Dutch, Budapest, Albin).
- Fomba (0-100, 50 = mahazatra): fanafihana, sacrifice, fiarovana, queen aloha, fifanakalozana.
- Ny Stockfish no mitazona ny Elo; ny fomba dia misafidy amin'ny hetsika mitovy lanja (tolérance centipawn araka ny Elo).
- Mamorona bot avy amin'ny lalao: Review -> "Mamorona bot avy amin'ity lalao ity" (Elo = game rating, opening + fomba hita avy amin'ny hetsika).
- Lalao: flip board, hetsika aloha/manaraka, draw (bot mandinika amin'ny Stockfish), miala, stalemate, repetition, 50 hetsika, material tsy ampy.

## Vaovao (v2.1)
- PGN -> bot: Menu "Bot avy amin'ny PGN" na ny bokotra "PGN → Bot" ao amin'ny lisitry ny bot (PgnImport.kt, PgnScreen.kt). Stockfish mandinika ny lalao 5 voalohany an'ny mpilalao (depth <= 14, hetsika 80), Elo = game rating (mifangaro amin'ny Elo ao amin'ny PGN raha misy), opening + fomba avy amin'ny hetsika.
- Sokajy bot (Tiers.kt, BotsScreen.kt): Beginner, Intermediate, Advanced, Master, Grandmaster, Legend + "Nataoko" - sivana amin'ny chip.
- Pejy fampidirana ny match (MatchIntro.kt): sary + anarana + Elo + evenement (Match amicale, Phase de poule, 8ème, Quart, Demi-finale, Finale) alohan'ny lalao.
- Lalao: border board, material nalaina, lisitry ny hetsika (SAN), tools ao anaty card. Settings: anarana + sary ho an'ny mpilalao (Profile.kt).

## Vaovao (v2.2) - Commentaire live (peo)
- Mpanao commentaire roa, lahy + vavy (Faly sy Mialy), amin'ny teny anglisy, toy ny lalao live. Peo = `TextToSpeech` an'ny Android (offline; mila peo anglisy napetraka ao amin'ny findainao). Raha tsy misy peo dia miseho ho soratra (caption) ihany.
- Rakitra: `CommentaryBrain.kt` (lahatsoratra sy lojika, tsy misy Android), `Commentator.kt` (peo, filaharana, peo roa), `CommentaryUi.kt` (bokotra + soratra), hook ao amin'ny `ChessViewModel.kt`.
- Mandeha amin'ny lalao Play (olona/bot), lalao olona ao anaty fifaninanana, ary "Jereo live" (bot vs bot).
- Misy: fampidirana (welcome, evenement, Elo, fomba filalaovana, ora), hetsika voalohany, opening, sacrifice, blunder (piece mihantona), promotion, en passant, queen trade, check, castle, material, ora (mieritreritra be, ora kely, flag), endgame, draw, valiny (mate, timeout, resign, draw, miakatra amin'ny dingana manaraka, champion).
- Fotoana mangina: resaka (mpilalao, Elo underdog, ora, toerana, zava-misy momba ny fifaninanana: mpandresy teo aloha, lalao haingana, record, h2h; tantaran'ny chess; atmosphere).
- Settings > Commentaire live: Alefa/Atsahatra, "Zava-dehibe" (kely) / "Be resaka", bokotra "Henoy ny peo". Bokotra peo ao amin'ny lalao sy Watch ihany koa.
- Ao amin'ny Watch: miandry ny commentaire ny lalao (tsy mandalo haingana loatra).
- Fanitsiana ny resaka: ovay ny banque ao amin'ny `CommentaryBrain.kt` (exchange = `x(MOOD to "text", MOOD to "text")`).

## Vaovao (v2.3)
- **Elo-nao + statistika** (`EloMath.kt`, `Stats.kt`): rating manomboka 1200 (K 40 -> 28 -> 20), W/D/L, curve, lisitra isaky ny bot ary lalao farany. Voaisa ny lalao Play amin'ny bot ihany (tsy ao ny fifaninanana); lalao tsirairay indray mandeha (araka ny id). Ny lalao efa voatahiry dia voaisa indray mandeha ho azy amin'ny fanokafana voalohany. Hita ao amin'ny Tantara > Statistika; ao amin'ny lalao koa dia miseho ny Elo aorian'ny lalao.
- **Drag and drop**: tarazo ny piece eo amin'ny board (mbola mandeha ny tsindrio-roa). Mandeha amin'ny premove koa.
- **Premove**: mandritra ny fisainan'ny bot dia misafidy piece + kare; atao ho azy rehefa tonga ny anjaranao raha ara-dalàna (queen foana ny promotion). Tsindrio foana hanafoana. Settings > Fomba filalaovana.
- **Fanamafisana hetsika** (safidy): "Ekena" / "Foano" alohan'ny hetsika, miaraka amin'ny sary aloha eo amin'ny board.
- **Endrika board sy piece** (`BoardStyle.kt`, `SettingsExtra.kt`): 7 loko board, 5 fomba piece (klasika, volamena, ranomasina, rozy, glyph) + sary aloha.
- **Export** (`PgnExport.kt`, `ExportUi.kt`): PGN sy FEN -> adikao, zarao, na tehirizo ho rakitra .pgn. Ao amin'ny lalao (bokotra zaraina) sy ny Tantara.
- **Fiarovana ny motera** (`Engine.kt`): thread mamaky manokana + timeout rehetra; raha mihantona na maty ny Stockfish dia vonoina ary averina atomboka ho azy; ny bot dia mandefa indray indray mandeha.
- **Fiarovana ny fitahirizana** (`GameStore.kt`): log ny hadisoana, fallback raha tsy mety ny rename. TalkBack: famaritana ny board.
- **Unit test** (`app/src/test`): kajy Elo sy PGN. Alefaso: `./gradlew testDebugUnitTest`.

## Vaovao (v2.4)
- **Lisitry bot ho card** (`BotsScreen.kt`): grid 3 andalana, sary + anarana ihany; miseho ny Elo rehefa voatsindry ny card, ary bokotra "Milalao" ao amin'ny panel ambany. Filaharana: Elo miakatra.
- **Stockfish 19** (NNUE SFNNv16) no ampiasaina (workflow: `--branch sf_19`). Fetra `UCI_Elo` = 1320-3190 (mitovy amin'ny 17.1), ka tsy niova ny `SF_MIN_ELO` / `SF_MAX_ELO`.
- **Commentaire manaraka ny hetsika ankehitriny** (`Commentator.sayMove`): isaky ny hetsika vaovao dia voadingana ny commentaire an'ny hetsika teo aloha raha mbola tsy vita (foana ny andalana miandry, tapahina ny peo mbola mitantara). Ny valiny farany (mate, resign...) sy ny fotoana mangina dia mbola mandeha toy ny teo aloha.

## Vaovao (v2.5)
- **Backup / Restore** (`Backup.kt`, Settings > Backup / Restore): rakitra `.zip` iray misy ny Elo-nao + statistika (`stats.json`), ny bot nataonao (+ sary), ny profile, ny lalao, ny fifaninanana ary ny settings. Averina ao amin'ny findaina vaovao; marina aloha ny rakitra vao soloina ny zavatra misy.
- **Lalao maro miaraka** (`ChessViewModel.kt`, `Engine.kt`): tsy mila miandry lalao iray vita vao mandefa iray hafa. Isaky ny lalao bot dia misy motera Stockfish manokana (1 thread, hash 32); "Lalao miaraka" 1-4 ao amin'ny fifaninanana. "Jereo live"/"Simule" azo tsindriana foana (ny "Jereo live" dia manery ny fanombohana na dia feno aza ny fetra). "Auto" dia mandefa ny lalao rehetra amin'ny round miaraka.
- **Schema cup** (`TourExtras.kt`, tab "Schema"): bracket miaraka amin'ny andalana, mpandresy, score ary placeholder ("1er Poule A", "Mpandresy 1") ho an'ny round mbola tsy lalaina. Tsindrio ny card hijery review.
- **Classement mpilalao** (tab "Classement"): ✨ Brilliant (!!), ⭐ Great (!), 🎖 Précision, 🏅 Points (style classement foot). Avy amin'ny analyse Stockfish (depth 10, motera manokana ao ambadika; azo vonoina) aorian'ny lalao tsirairay, voatahiry ao amin'ny fifaninanana.
- **Archive brilliant**: ny hetsika !! rehetra voatahiry (anarana, mpiady, round, hetsika) ary bokotra "Jereo" mankany amin'ilay toerana ao amin'ny review.
- **Medaille**: 🥇 tompon-daka, 🥈 finaliste (podium ao amin'ny fifaninanana, lisitra, schema, classement).
- **Archive fifaninanana** (bokotra "🏅 Archive" ao amin'ny lisitra): tabilao medaille, ny brilliant/great/précision ambony indrindra isaky ny fifaninanana, hall of fame ny brilliant.

## Vaovao (v2.8)
- **Backup automatique** (Settings > Backup / Restore): isan'andro na isan'herinandro (default: isan'andro) rehefa misokatra ny app, ary alohan'ny restore, ny famafana fifaninanana sy ny famafana statistika. Tehirizina ao amin'ny `files/auto_backups` (7 "auto" + 5 "before" farany); azo averina na zarana avy ao amin'ny lisitra.
- **Zarao** (Drive, WhatsApp, email...): bokotra "Zarao" ho an'ny backup; "Zarao: Sary (PNG) / PDF" ho an'ny fifaninanana (schema + classement). FileProvider ao amin'ny manifest (`res/xml/file_paths.xml`).
- **Medaille varahina** 🥉: lalao faha-3 (resy roa amin'ny demi-finale) ao amin'ny cup; faha-3 ao amin'ny Swiss. Ao amin'ny podium, schema, classement, tabilao medaille.
- **Swiss** (mpilalao 4-16): round maro (3 na ceil(log2 n)), pairing araka ny isa tsy mifanandrina indroa, bye raha isan-tsisa, tie-break Buchholz.
- **Classement vaovao**: 🛡 Blunder faran'izay kely (isaky ny lalao), ⚡ Lalao faran'izay haingana (fandresena amin'ny hetsika vitsy indrindra).
- **Review**: graphe eval azo tsindrio/misintona hijery hetsika, misy marika brilliant/great/mistake/blunder; fanazavana amin'ny teny malagasy isaky ny hetsika sy ny eval.
- **Stats**: curve Elo 30/60/rehetra miaraka amin'ny min/max sy daty; % fotsy/mainty; andalana fandresena; fiovan'ny Elo net isaky ny bot.

## Vaovao (v2.9)
- **Double elimination** (mpilalao 4-16, safidy ao amin'ny "Fifaninanana vaovao"): Winners + Losers bracket, bye raha tsy pow2, Grand Finale miaraka amin'ny reset raha resy ny mpandresy Winners. Ny lalao Winners sy Losers mandeha miaraka amin'ny round iray raha vita ny fepetra. Tab "Schema" mampiseho Winners / Losers / Grand Finale; export PNG/PDF ihany koa. Medaille: 🥇 champion, 🥈 resy ao amin'ny Grand Finale, 🥉 resy ao amin'ny Losers final.
