package mg.chess.offline

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.PieceType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlin.math.exp
import kotlin.random.Random

/** Isan'ny line analyse: score (cp na mate) araka ny fijerin'ny mpilalao mihetsika, ary ny hetsika voalohany. */
data class Line(val cp: Int?, val mate: Int?, val move: String)

/** Sentinel apetraka ao anaty filaharana rehefa maty ny process Stockfish. */
const val SF_BIN = "libstockfish.so"
/** Stockfish ho an'ny CPU manana dotprod (ARMv8.2+): haingana kokoa. Raha tsy misy na tsy mandeha dia miverina amin'ny SF_BIN. */
const val SF_DP_BIN = "libstockfish_dp.so"

/**
 * Modely "olombelona" ho an'ny bot < HUMAN_MAX_ELO: Stockfish hery feno miaraka amin'ny depth voafetra araka ny Elo,
 * ary hadisoana voafehy (tsy mandroaka ny lalao rehefa efa mandroso, tsy mikorontana amin'ny endgame).
 * HUMAN_SHIFT: + = mahery kokoa ny bot rehetra, - = malemy kokoa (fanitsiana Elo rehefa avy nitsapa).
 */
const val HUMAN_MAX_ELO = 2800
private const val HUMAN_SHIFT = 0

/** (elo, depth, temp, pErr, maxErr, mateHorizon): temp/maxErr amin'ny %-n'ny fandresena (win%). */
private val HUMAN_KNOTS = arrayOf(
    doubleArrayOf(400.0, 1.0, 28.0, 0.38, 55.0, 1.0),
    doubleArrayOf(700.0, 2.0, 20.0, 0.28, 40.0, 1.0),
    doubleArrayOf(1000.0, 3.0, 14.0, 0.20, 30.0, 2.0),
    doubleArrayOf(1300.0, 4.0, 10.0, 0.14, 24.0, 2.0),
    doubleArrayOf(1600.0, 5.0, 7.5, 0.09, 18.0, 3.0),
    doubleArrayOf(2000.0, 6.0, 5.0, 0.055, 13.0, 4.0),
    doubleArrayOf(2400.0, 8.0, 3.0, 0.03, 9.0, 6.0),
    doubleArrayOf(2800.0, 11.0, 1.5, 0.012, 5.0, 10.0)
)

private class HumanParams(val depth: Int, val temp: Double, val pErr: Double, val maxErr: Double, val mateHorizon: Int)

private fun humanParams(elo: Int): HumanParams {
    val e = elo.toDouble().coerceIn(HUMAN_KNOTS.first()[0], HUMAN_KNOTS.last()[0])
    var i = 0
    while (i < HUMAN_KNOTS.size - 2 && e > HUMAN_KNOTS[i + 1][0]) i++
    val a = HUMAN_KNOTS[i]; val b = HUMAN_KNOTS[i + 1]
    val t = ((e - a[0]) / (b[0] - a[0])).coerceIn(0.0, 1.0)
    fun f(k: Int) = a[k] + (b[k] - a[k]) * t
    return HumanParams(Math.round(f(1)).toInt().coerceAtLeast(1), f(2), f(3), f(4), Math.round(f(5)).toInt())
}

private fun posKey(b: Board): String = b.fen.split(" ").take(4).joinToString(" ")
/** Marina raha manana ny fanampiana dotprod (asimddp) ny CPU. */
private val CPU_DOTPROD: Boolean by lazy {
    try {
        File("/proc/cpuinfo").useLines { ls ->
            ls.any { it.startsWith("Features") && it.split(' ', '\t', ':').contains("asimddp") }
        }
    } catch (e: Exception) { false }
}
private const val EOF_LINE = "\u0000EOF"
private const val POLL_MS = 200L
private const val START_TIMEOUT_MS = 15_000L
private const val STOP_TIMEOUT_MS = 2_000L
/** Raha tsy misy andalana avy amin'ny motera mandritra izao fotoana izao mandritra ny fikarohana = mihantona. */
private const val SEARCH_IDLE_TIMEOUT_MS = 15_000L

/**
 * Stockfish (UCI) amin'ny process: thread mamaky manokana + filaharana, ka misy timeout rehetra.
 * Raha mihantona na maty ny motera dia vonoina ary averina atomboka ho azy amin'ny antso manaraka.
 */
class Engine(
    private val ctx: Context,
    /** null = araka ny CPU; ho an'ny lalao miaraka (simulation) dia 1. */
    private val threadsOpt: Int? = null,
    private val hashMb: Int = 128,
    /** Anaran'ny binary ao amin'ny nativeLibraryDir (Stockfish ihany). */
    private val binary: String = SF_BIN
) {
    /** Dotprod nohamarinina fa tsy mandeha amin'ity finday ity (SIGILL na hafa): tsy ampiasaina intsony. */
    private var dpFailed = false
    private var proc: Process? = null
    private var out: OutputStreamWriter? = null
    private var lines: LinkedBlockingQueue<String>? = null
    private val mutex = Mutex()

    private fun alive(p: Process?): Boolean =
        p != null && try { p.exitValue(); false } catch (e: IllegalThreadStateException) { true }

    private fun send(s: String) {
        try {
            out?.write(s + "\n")
            out?.flush()
        } catch (e: Exception) {
            killProc()
        }
    }

    /** Andalana manaraka (miandry ms fara-fahabetsany): null = tapitra ny fotoana, EOF_LINE = maty ny motera. */
    private fun nextLine(ms: Long): String? {
        val q = lines ?: return EOF_LINE
        return try { q.poll(ms, TimeUnit.MILLISECONDS) } catch (e: InterruptedException) { null }
    }

    private fun waitFor(token: String, ms: Long): Boolean {
        val end = System.currentTimeMillis() + ms
        while (true) {
            val left = end - System.currentTimeMillis()
            if (left <= 0) return false
            val l = nextLine(left) ?: return false
            if (l == EOF_LINE) return false
            if (l.startsWith(token)) return true
        }
    }

    private fun killProc() {
        try { out?.close() } catch (_: Exception) {}
        try { proc?.destroy() } catch (_: Exception) {}
        proc = null; out = null; lines = null
    }

    private fun ensureStarted(): Boolean {
        if (alive(proc) && lines != null) return true
        killProc()
        val dir = ctx.applicationInfo.nativeLibraryDir
        val dp = File(dir, SF_DP_BIN)
        if (binary == SF_BIN && !dpFailed && CPU_DOTPROD && dp.exists()) {
            if (startWith(dp)) return true
            dpFailed = true   // tsy nandeha: ampiasaina ny binary mahazatra
        }
        return startWith(File(dir, binary))
    }

    private fun startWith(f: File): Boolean {
        killProc()
        if (!f.exists()) return false
        return try {
            val p = ProcessBuilder(f.absolutePath).redirectErrorStream(true).start()
            val q = LinkedBlockingQueue<String>()
            proc = p
            out = OutputStreamWriter(p.outputStream)
            lines = q
            val rd = BufferedReader(InputStreamReader(p.inputStream))
            thread(isDaemon = true, name = "kajy-sf-reader") {
                try {
                    while (true) {
                        val l = rd.readLine() ?: break
                        q.put(l)
                    }
                } catch (_: Exception) {}
                q.put(EOF_LINE)
            }
            send("uci")
            if (!waitFor("uciok", START_TIMEOUT_MS)) { killProc(); return false }
            val threads = wantedThreads()
            curThreads = threads
            val hash = wantedHash()
            curHash = hash
            send("setoption name Threads value $threads")
            send("setoption name Hash value $hash")
            send("isready")
            if (!waitFor("readyok", START_TIMEOUT_MS)) { killProc(); return false }
            true
        } catch (e: Exception) {
            killProc()
            false
        }
    }

    /** Alefaso ny fikarohana ary miandry "bestmove". Raha mihantona dia vonoina ny motera (miverina null). */
    private var curThreads = -1
    private var curHash = -1
    /** Bot ambony (> 3190): thread sy hash bebe kokoa (lalina kokoa); mode baterie = 1 thread, hash kely. */
    private var bigBot = false
    private var bigHash = 0

    private fun tuneFor(bot: Bot) {
        bigBot = bot.elo > SF_MAX_ELO
        val cores = Runtime.getRuntime().availableProcessors()
        bigHash = when {
            !bigBot || PowerSaver.active -> 0
            bot.movetimeMs >= 4000 && cores >= 6 -> 256
            bot.movetimeMs >= 2000 -> 128
            else -> 64
        }
    }

    private fun wantedThreads(): Int {
        threadsOpt?.let { return it }
        if (PowerSaver.active) return 1
        val cores = Runtime.getRuntime().availableProcessors()
        return if (bigBot) (cores * 3 / 4).coerceIn(2, 4) else (cores / 2).coerceIn(1, 4)
    }

    private fun wantedHash(): Int = if (PowerSaver.active && threadsOpt == null) minOf(hashMb, 32) else if (threadsOpt == null && bigHash > 0) maxOf(hashMb, bigHash) else hashMb

    private suspend fun search(go: String, onInfo: (String) -> Unit): String? = withContext(Dispatchers.IO) {
        val wt = wantedThreads()
        if (wt != curThreads && curThreads != -1) { send("setoption name Threads value $wt"); curThreads = wt }
        val wh = wantedHash()
        if (wh != curHash && curHash != -1) { send("setoption name Hash value $wh"); curHash = wh }
        send(go)
        var result: String? = null
        var idle = 0L
        try {
            while (true) {
                val l = nextLine(POLL_MS)
                ensureActive()
                if (l == null) {
                    idle += POLL_MS
                    if (idle >= SEARCH_IDLE_TIMEOUT_MS) { killProc(); break }
                    continue
                }
                idle = 0L
                if (l == EOF_LINE) { killProc(); break }
                if (l.startsWith("bestmove")) {
                    val m = l.split(" ").getOrNull(1)
                    result = if (m == null || m == "(none)") null else m
                    break
                }
                onInfo(l)
            }
        } catch (e: CancellationException) {
            // Sakanana ny fikarohana: "stop", ary miandry bestmove (na vonoina raha tsy tonga)
            send("stop")
            if (!waitFor("bestmove", STOP_TIMEOUT_MS)) killProc()
            throw e
        }
        result
    }

    fun newGame() {
        if (alive(proc)) send("ucinewgame")
    }

    /**
     * Hetsika ho an'ny bot araka ny Elo tena izy + personalité.
     * 1) Opening book (repertoire / andalana avy amin'ny lalao) raha mifanaraka ny tantara.
     * 2) 1320..3190 : Stockfish 19 UCI_LimitStrength + UCI_Elo; > 3190 : hery feno;
     *    < 1320 : fikarohana voafetra + safidy hetsika araka ny "temperature".
     * 3) Raha misy fomba filalaovana (style): MultiPV, ary safidiana araka ny fomba ny hetsika mitovy lanja
     *    (tsy mihoatra ny tolérance centipawn araka ny Elo), ka tsy simba ny Elo.
     */
    suspend fun bestMove(fen: String, bot: Bot, history: List<String> = emptyList()): String? = mutex.withLock {
        try {
            val pre = Board()
            pre.loadFromFen(fen)
            val legalSet = pre.legalMoves().map { it.toString().lowercase() }.toSet()
            val book = Personality.bookMove(bot, history, legalSet)
            if (book != null) {
                delay(250)
                return@withLock book
            }
            tuneFor(bot)
            val elo = bot.elo + ELO_CALIB
            if (elo < HUMAN_MAX_ELO) {
                val hm = humanMove(fen, bot, history, pre)
                if (hm != null) return@withLock hm
            }
            val weak = elo < SF_MIN_ELO
            val styled = !bot.style.neutral
            val ok = withContext(Dispatchers.IO) {
                if (ensureStarted()) {
                    val mpv = if (weak) 8 else if (styled) 5 else 1
                    if (elo in SF_MIN_ELO..SF_MAX_ELO) {
                        send("setoption name UCI_LimitStrength value true")
                        send("setoption name UCI_Elo value $elo")
                    } else {
                        send("setoption name UCI_LimitStrength value false")
                    }
                    send("setoption name MultiPV value $mpv")
                    send("position fen $fen")
                    true
                } else false
            }
            if (!ok) null
            else if (weak) {
                val nodes = (30.0 * Math.pow(elo.coerceAtLeast(100) / 100.0, 1.7) * ThinkTime.ratio(bot).coerceIn(0.6, 1.6)).toLong().coerceAtLeast(120L)
                val lines = HashMap<Int, Line>()
                val best = search("go nodes $nodes") { l ->
                    val p = parseInfo(l)
                    if (p != null) lines[p.first] = p.second
                }
                val all = lines.toSortedMap().values.toList()
                pickWeak(all, elo, best, pre, bot, history.size)
            } else if (styled) {
                val lines = HashMap<Int, Line>()
                val best = search("go movetime ${bot.movetimeMs}") { l ->
                    val p = parseInfo(l)
                    if (p != null) lines[p.first] = p.second
                }
                val all = lines.toSortedMap().values.toList()
                pickStyled(all, best, elo, pre, bot, history.size)
            } else {
                search("go movetime ${bot.movetimeMs}") { }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Fidirana hetsika "olombelona" (antsoina ao anatin'ny mutex an'ny [bestMove]).
     * 1) Stockfish hery feno, depth voafetra araka ny Elo (+ depth fanampiny amin'ny endgame mba hahavita ny fandresena).
     * 2) MultiPV 6; ny hetsika voafidy dia araka ny win% (softmax kely) + hadisoana indraindray (pErr).
     * 3) Fiarovana: rehefa mandroso (win% >= 78) dia mihena be ny hadisoana, tsy very ny tombony, mate tsotra dia lalaina,
     *    ary misoroka ny fiverenan'ny toerana mitovy (tsy misangy) sy mandroaka pion/capture rehefa efa ela ny 50-move.
     */
    private suspend fun humanMove(fen: String, bot: Bot, history: List<String>, pre: Board): String? {
        val p = humanParams(bot.elo + HUMAN_SHIFT)
        val phase = Personality.phase(pre)
        val endBonus = ((1.0 - phase) * (2.0 + p.depth / 2.0)).let { Math.round(it).toInt() }
        val depth = (p.depth + endBonus + ThinkTime.depthBonus(bot)).coerceIn(1, 16)
        val cap = bot.movetimeMs.coerceIn(40, 8000)
        val ok = withContext(Dispatchers.IO) {
            if (ensureStarted()) {
                send("setoption name UCI_LimitStrength value false")
                send("setoption name MultiPV value 6")
                send("position fen $fen")
                true
            } else false
        }
        if (!ok) return null
        val raw = HashMap<Int, Line>()
        val best = search("go depth $depth movetime $cap") { l ->
            val pi = parseInfo(l)
            if (pi != null) raw[pi.first] = pi.second
        }
        val ls = raw.toSortedMap().values.filter { it.move.isNotEmpty() }
        if (ls.isEmpty()) return best
        val w = ls.map { winPct(it.stmCp().coerceIn(-3000, 3000)) }
        val bestW = w.max()
        val top = ls[0]

        // Mate azo atao: lalaina raha ao anatin'ny "faravodilanitra" araka ny Elo (ho an'ny endgame dia mihabe)
        val horizon = p.mateHorizon + ((1.0 - phase) * 3).toInt()
        val tm = top.mate
        if (tm != null && tm in 1..horizon) return top.move

        val winning = bestW >= 78.0
        val losingBad = bestW <= 15.0

        // Fanilikilihana: toerana efa hita (fiverenana) rehefa mandroso
        val seen = HashSet<String>()
        if (bestW >= 65.0 && history.isNotEmpty()) {
            try {
                val rb = Board()
                for (u in history) {
                    val mv = rb.legalMoves().firstOrNull { it.toString().equals(u, true) } ?: break
                    rb.doMove(mv); seen.add(posKey(rb))
                }
            } catch (_: Exception) { seen.clear() }
        }
        val halfmove = fen.split(" ").getOrNull(4)?.toIntOrNull() ?: 0
        val styled = !bot.style.neutral

        // Fetran'ny fahaverezana azo ekena
        var cap2 = p.maxErr
        if (winning) cap2 = minOf(cap2, (bestW - 62.0)).coerceAtLeast(3.0)
        if (losingBad) cap2 = minOf(cap2, 12.0)

        class Cand(val mv: String, val loss: Double, var wt: Double)
        val cands = ArrayList<Cand>()
        for ((i, l) in ls.withIndex()) {
            val loss = bestW - w[i]
            if (i > 0 && loss > cap2) continue
            var wt = 1.0
            val mvObj = pre.legalMoves().firstOrNull { it.toString().equals(l.move, true) }
            if (mvObj != null) {
                if (seen.isNotEmpty()) {
                    pre.doMove(mvObj)
                    val rep = posKey(pre) in seen
                    pre.undoMove()
                    if (rep && bestW >= 65.0) wt *= 0.05
                }
                if (winning && halfmove >= 24) {
                    val pc = pre.getPiece(mvObj.from)
                    val capt = pre.getPiece(mvObj.to) != Piece.NONE
                    if (pc.pieceType == PieceType.PAWN || capt) wt *= 4.0
                }
                if (styled) {
                    val f = Personality.feat(pre, mvObj, history.size)
                    wt *= Personality.styleWeight(f, bot.style)
                }
            }
            cands.add(Cand(l.move, loss, wt))
        }
        if (cands.isEmpty()) return top.move

        // Hadisoana indraindray (olombelona): mifidy hetsika tsy tsara indrindra ao anatin'ny fetra
        var pe = p.pErr * (0.7 + 0.3 * phase)
        if (winning) pe *= 0.25
        if (Random.nextDouble() < pe) {
            val alt = cands.filter { it.loss >= 1.5 && it.wt > 0.0 }
            if (alt.isNotEmpty()) {
                val pick = roulette(alt.map { it.mv }, alt.map { it.wt })
                if (pick != null) return pick
            }
        }

        // Fifidianana mahazatra: softmax kely araka ny loss
        var temp = p.temp * 0.4 * (0.6 + 0.4 * phase)
        if (winning) temp *= 0.5
        temp = temp.coerceAtLeast(0.6)
        val ws = cands.map { it.wt * exp(-it.loss / temp) * (if (it.loss <= 0.0) 1.5 else 1.0) }
        return roulette(cands.map { it.mv }, ws) ?: top.move
    }

    private fun featOf(pre: Board, uci: String, ply: Int): MoveFeat? {
        val mv = pre.legalMoves().firstOrNull { it.toString().equals(uci, true) } ?: return null
        return Personality.feat(pre, mv, ply)
    }

    private fun roulette(items: List<String>, ws: List<Double>): String? {
        val sum = ws.sum()
        if (sum <= 0.0) return null
        var r = Random.nextDouble() * sum
        for ((i, w) in ws.withIndex()) {
            r -= w
            if (r <= 0.0) return items[i]
        }
        return items.last()
    }

    private fun pickStyled(lines: List<Line>, best: String?, elo: Int, pre: Board, bot: Bot, ply: Int): String? {
        val ls = lines.filter { it.move.isNotEmpty() }
        if (ls.isEmpty()) return best
        val cps = ls.map { it.stmCp().coerceIn(-1500, 1500) }
        val top = cps.max()
        val scale = Personality.toleranceScale(pre)
        val baseTol = (25.0 + (3200 - elo).coerceIn(0, 2800) / 25.0) * scale
        val sacTol = Personality.sacTolerance(bot.style) * scale
        val ws = ls.mapIndexed { i, l ->
            val f = featOf(pre, l.move, ply)
            val tol = baseTol + (if (f != null && f.sacrifice) sacTol else 0.0)
            if (top - cps[i] > tol) 0.0
            else {
                val sw = if (f != null) Personality.styleWeight(f, bot.style) else 1.0
                sw * (if (l.move.equals(best, true)) 2.0 else 1.0)
            }
        }
        return roulette(ls.map { it.move }, ws) ?: best ?: ls.first().move
    }

    private fun pickWeak(lines: List<Line>, elo: Int, fallback: String?, pre: Board, bot: Bot, ply: Int): String? {
        val ls = lines.filter { it.move.isNotEmpty() }
        if (ls.isEmpty()) return fallback
        val deficit = (SF_MIN_ELO - elo).coerceIn(0, 1220)
        val cps = ls.map { it.stmCp().coerceIn(-1500, 1500) }
        val top = cps.max()
        val temp = 15.0 + deficit * 0.22
        val pRandom = (deficit / 1220.0).let { it * it * 0.30 }
        if (Random.nextDouble() < pRandom) return ls.random().move
        val styled = !bot.style.neutral
        val ws = cps.mapIndexed { i, cp ->
            var w = exp((cp - top) / temp)
            if (styled) {
                val f = featOf(pre, ls[i].move, ply)
                if (f != null) w *= Personality.styleWeight(f, bot.style)
            }
            w
        }
        return roulette(ls.map { it.move }, ws) ?: ls.first().move
    }

    /** Analyse feno hery (tsy voafetra) miaraka amin'ny MultiPV, mijanona amin'ny depth na fotoana farany. */
    suspend fun analyze(fen: String, depth: Int, maxMs: Int, multiPv: Int = 2): List<Line> = mutex.withLock {
        try {
            val ok = withContext(Dispatchers.IO) {
                if (ensureStarted()) {
                    send("setoption name UCI_LimitStrength value false")
                    send("setoption name MultiPV value $multiPv")
                    send("position fen $fen")
                    true
                } else false
            }
            if (!ok) emptyList()
            else {
                val lines = HashMap<Int, Line>()
                search("go depth $depth movetime $maxMs") { l ->
                    val p = parseInfo(l)
                    if (p != null) lines[p.first] = p.second
                }
                lines.toSortedMap().values.toList()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun parseInfo(l: String): Pair<Int, Line>? {
        if (!l.startsWith("info") || " score " !in l || " pv " !in l) return null
        if (" lowerbound" in l || " upperbound" in l) return null
        val t = l.split(" ")
        val mi = t.indexOf("multipv")
        val mpv = if (mi >= 0) (t.getOrNull(mi + 1)?.toIntOrNull() ?: 1) else 1
        val si = t.indexOf("score")
        val kind = t.getOrNull(si + 1) ?: return null
        val v = t.getOrNull(si + 2)?.toIntOrNull() ?: return null
        val pi = t.indexOf("pv")
        val mv = t.getOrNull(pi + 1) ?: return null
        return mpv to Line(if (kind == "cp") v else null, if (kind == "mate") v else null, mv)
    }

    fun stop() {
        send("quit")
        killProc()
    }
}
