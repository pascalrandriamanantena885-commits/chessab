package mg.chess.offline

import android.app.Application
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.PieceType
import com.github.bhlangonijr.chesslib.Side
import com.github.bhlangonijr.chesslib.Square
import com.github.bhlangonijr.chesslib.move.Move
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

enum class Screen { MENU, BOTS, GAME, REVIEW, HISTORY, SETTINGS, TOUR_LIST, TOUR_NEW, TOURNAMENT, WATCH, PGN, STATS, ARCHIVE, CHRONICLE, EDITOR, TRAIN, DRILL, PUZZLE, ENDGAME, ABOUT }

/** Lalao bot vs bot mandeha (simulation) - azo arahina live. */
class SimState(val matchId: Int, val board: Board, w: Long, b: Long) {
    var version by mutableIntStateOf(0)
    var whiteMs by mutableLongStateOf(w)
    var blackMs by mutableLongStateOf(b)
    var thinkStart by mutableLongStateOf(0L)
    var thinkingWhite by mutableStateOf(true)
    var last by mutableStateOf<Pair<Square, Square>?>(null)
    var plies by mutableIntStateOf(0)
    var result by mutableStateOf<String?>(null)
}

/** Halalin'ny analyse ho an'ny classement (haingana ihany fa tsy mitovy amin'ny Review feno). */
private const val ANALYSIS_DEPTH = 10

private val PROMO_ORDER = listOf(PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT)

class ChessViewModel(app: Application) : AndroidViewModel(app) {
    private val engine = Engine(app)
    val puzzles = PuzzleStore(app)
    private val store = GameStore(app)
    private val tourStore = TournamentStore(app)
    private val prefs = app.getSharedPreferences("chess_prefs", 0)

    // Settings
    var darkMode by mutableStateOf(true); private set
    /** Halalin'ny fanadihadiana (Stockfish depth): 12 haingana, 16 antonony, 20 lalina. */
    var reviewDepth by mutableIntStateOf(16); private set

    // Fifaninanana
    var tournaments by mutableStateOf<List<Tournament>>(emptyList()); private set
    var tour by mutableStateOf<Tournament?>(null); private set
    var tourVersion by mutableIntStateOf(0); private set
    var tourMatch by mutableStateOf<TMatch?>(null); private set
    /** Lalao bot vs bot mandeha miaraka: matchId -> state (azo arahina live). */
    val sims = mutableStateMapOf<Int, SimState>()
    var watchId by mutableIntStateOf(-1)
    var simRunningIds by mutableStateOf<Set<Int>>(emptySet()); private set
    var simWaitingIds by mutableStateOf<Set<Int>>(emptySet()); private set
    /** Isan'ny lalao bot afaka mandeha miaraka (motera Stockfish 1 isaky ny lalao). */
    var simParallel by mutableIntStateOf(2); private set
    var autoMode by mutableStateOf(false); private set
    private val simJobs = HashMap<Int, Job>()
    private val simTokens = HashMap<Int, Any>()
    private val simForced = HashSet<Int>()
    private var activeSims = 0
    private var autoJob: Job? = null
    private val enginePool = ArrayDeque<Engine>()
    // Analyse aorian'ny lalao (classement + archive brilliant)
    var analysisOn by mutableStateOf(true); private set
    var analysisPending by mutableIntStateOf(0); private set
    private val analysisQueue = ArrayDeque<Pair<Tournament, Int>>()
    private val analysisKeys = HashSet<String>()
    private var analysisJob: Job? = null
    private var analysisEngine: Engine? = null
    private var reviewStartPly = -1
    /** Mpilalao/fifaninanana ho an'ny puzzle (voninahitra ho an'ilay nanao ny hetsika). */
    private var reviewSrc: PuzzleSrc? = null
    /** Motera fanampiny (thread 1) ho an'ny review haingana: zaraina ny toerana amin'izy ireo. */
    private val reviewExtra = ArrayList<Engine>()
    private fun reviewHelpers(): List<Engine> {
        if (reviewExtra.isEmpty()) {
            val cores = Runtime.getRuntime().availableProcessors()
            val n = if (cores >= 6) 2 else if (cores >= 4) 1 else 0
            repeat(n) { reviewExtra.add(Engine(getApplication(), 1, 32)) }
        }
        return reviewExtra
    }
    private var reviewReturn = Screen.GAME

    var board = Board(); private set
    var version by mutableIntStateOf(0); private set
    var screen by mutableStateOf(Screen.MENU)
    var bot by mutableStateOf<Bot?>(null); private set
    var vsBot by mutableStateOf(false); private set
    var humanWhite by mutableStateOf(true); private set
    var selected by mutableStateOf<Square?>(null)
    var thinking by mutableStateOf(false); private set
    var message by mutableStateOf("")
    var over by mutableStateOf(false); private set
    val played = mutableStateListOf<Move>()

    // Fijerena tantara (hetsika aloha / manaraka) sy flip board
    /** -1 = zava-misy ankehitriny; 0..n = fijerena ny toerana aorian'ny hetsika faha-n. */
    var viewPly by mutableIntStateOf(-1); private set
    var flipped by mutableStateOf(false); private set

    // Draw / fanapahana
    var drawDialog by mutableStateOf(false)
    var resignDialog by mutableStateOf(false)
    private var forced: String? = null
    private var forcedMsg = ""

    // Promotion
    var promoMoves by mutableStateOf<List<Move>?>(null); private set

    // Premove (misafidy hetsika raha mbola mieritreritra ny bot) sy fanamafisana hetsika
    var premoveOn by mutableStateOf(true); private set
    var confirmOn by mutableStateOf(false); private set
    var premove by mutableStateOf<Pair<Square, Square>?>(null); private set
    var pendingMove by mutableStateOf<Move?>(null); private set
    /** Fanamarihana Elo aorian'ny lalao (ohatra: "Elo 1200 → 1213 (+13)"). */
    var ratingNote by mutableStateOf(""); private set

    // Clock
    var tc by mutableStateOf(TIME_CONTROLS[0])
    var clockOn by mutableStateOf(false); private set
    var whiteMs by mutableLongStateOf(0L); private set
    var blackMs by mutableLongStateOf(0L); private set
    private var baseMs = 0L
    private var incMs = 0L
    private var flagged: Side? = null
    private var paused = false
    private var tickJob: Job? = null

    // Fitehirizana
    var saved by mutableStateOf<List<GameRecord>>(emptyList()); private set
    private var gameId = 0L
    private var result: String? = null

    // Review
    var review by mutableStateOf<ReviewResult?>(null); private set
    var reviewProgress by mutableStateOf(0f); private set
    var reviewError by mutableStateOf<String?>(null); private set
    var reviewPly by mutableIntStateOf(0)

    private var botJob: Job? = null
    private var reviewJob: Job? = null
    private var pgnJob: Job? = null

    // Haptic (hozohozo, tsy ampiasaina amin'ny hetsika piece) + feo noforonina (SoundFx.kt)
    var hapticOn by mutableStateOf(true); private set
    private val haptics = Haptics(app)
    var soundOn by mutableStateOf(true); private set
    private val sfx = SoundFx()

    // Fampidirana ny match (VS) sy evenement
    var matchInfo by mutableStateOf<MatchIntroData?>(null); private set
    var introShown by mutableStateOf(false); private set
    private var pendingBotMove = false

    // PGN -> bot
    var pgnGames by mutableStateOf<List<PgnGame>>(emptyList()); private set
    var pgnProgress by mutableStateOf<Float?>(null); private set
    var pgnError by mutableStateOf<String?>(null)
    var pgnDraft by mutableStateOf<PgnBotDraft?>(null)

    init {
        BotRegistry.load(app)
        saved = store.list()
        tournaments = tourStore.list()
        loadPrefs()
        PlayerStats.load(app)
        if (!PlayerStats.exists(app)) PlayerStats.backfill(app, saved) { BotRegistry.find(it) }
        viewModelScope.launch(Dispatchers.IO) { AutoBackup.maybeRun(app) }
    }

    private fun loadPrefs() {
        darkMode = prefs.getBoolean("dark", true)
        reviewDepth = prefs.getInt("review_depth", 16)
        hapticOn = prefs.getBoolean("haptic", true)
        soundOn = prefs.getBoolean("sound", true)
        premoveOn = prefs.getBoolean("premove", true)
        confirmOn = prefs.getBoolean("confirm_move", false)
        simParallel = prefs.getInt("sim_parallel", 2).coerceIn(1, 4)
        analysisOn = prefs.getBoolean("tour_analysis", true)
    }

    /** Aorian'ny restore: avereno vakiana ny zava-drehetra avy ao amin'ny findainao. */
    fun reloadAfterRestore() {
        // Esory aloha ny fifaninanana ao anaty memory mba tsy hosoratana indray ny rakitra taloha
        tour = null
        tournaments = emptyList()
        analysisQueue.clear(); analysisKeys.clear()
        stopSim()
        BotRegistry.reload(getApplication())
        PlayerStats.load(getApplication())
        PlayerProfile.load(getApplication())
        saved = store.list()
        tournaments = tourStore.list()
        loadPrefs()
        tourVersion++
    }

    fun setDark(b: Boolean) { darkMode = b; prefs.edit().putBoolean("dark", b).apply() }
    fun chooseReviewDepth(d: Int) { reviewDepth = d; prefs.edit().putInt("review_depth", d).apply() }
    fun toSettings() { screen = Screen.SETTINGS }

    fun setPremove(on: Boolean) {
        premoveOn = on
        prefs.edit().putBoolean("premove", on).apply()
        if (!on) { premove = null; if (!humanTurn()) selected = null }
    }

    fun setConfirm(on: Boolean) {
        confirmOn = on
        prefs.edit().putBoolean("confirm_move", on).apply()
        if (!on) pendingMove = null
    }

    fun toStats() { screen = Screen.STATS }

    fun setHaptic(on: Boolean) {
        hapticOn = on
        prefs.edit().putBoolean("haptic", on).apply()
        if (on) haptics.tap(MoveKind.CAPTURE)
    }

    fun setSound(on: Boolean) {
        soundOn = on
        prefs.edit().putBoolean("sound", on).apply()
        if (on) sfx.play(Sfx.CAPTURE)
    }

    /** Feo isaky ny hetsika eo amin'ny board (move / capture / castle / check / checkmate / promotion). */
    private fun moveFeedback(kind: MoveKind) {
        if (soundOn) sfx.play(kind.sfx())
    }

    private fun gameEndSound() { if (soundOn) sfx.play(Sfx.END) }

    /** Bouton nav: 0 play, 1 competition, 2 fiofanana, 3 game history, 4 settings. */
    fun goTab(i: Int) {
        when (i) {
            0 -> if (screen != Screen.MENU) { botJob?.cancel(); screen = Screen.MENU }
            1 -> if (tabOf(screen) != 1) toTourList()
            2 -> if (tabOf(screen) != 2) screen = Screen.TRAIN
            3 -> toHistory()
            4 -> screen = Screen.SETTINGS
        }
    }

    // ---------- Fiofanana (Train.kt) ----------
    suspend fun trainBot(fen: String, b: Bot): String? = engine.bestMove(fen, b, emptyList())
    fun trainNewGame() { engine.newGame() }

    // ---------- Fanombohana lalao ----------
    fun startHumanGame() = startGame(null, true)
    fun startBotGame(b: Bot, white: Boolean) = startGame(b, white)
    fun restart() {
        if (tourMatch != null) return
        TIME_CONTROLS.firstOrNull { it.baseMin * 60_000L == baseMs && it.incSec * 1000L == incMs }?.let { tc = it }
        startGame(bot, humanWhite, showIntro = false, fen = startFen)
    }
    fun toBots() { screen = Screen.BOTS }
    fun toHistory() { screen = Screen.HISTORY }

    /** FEN fanombohan'ny lalao ankehitriny (edit board) - START_FEN raha mahazatra. */
    var startFen: String = START_FEN
        private set

    /** Karazan'ny ora an'ny lalao ankehitriny (Bullet/Blitz/Rapid) ho an'ny Elo. */
    val gameCat: TcCat get() = TcCat.of(baseMs)

    /** Manomboka lalao avy amin'ny toerana namboarina ao amin'ny Edit board. */
    fun startFromEditor(fen: String, b: Bot?, white: Boolean) { startGame(b, white, showIntro = false, fen = fen) }

    private fun startGame(b: Bot?, white: Boolean, showIntro: Boolean = true, fen: String = START_FEN) {
        botJob?.cancel(); reviewJob?.cancel(); pgnJob?.cancel(); pgnProgress = null
        engine.newGame()
        startFen = fen
        board = Board().also { if (fen != START_FEN) it.loadFromFen(fen) }
        tourMatch = null
        played.clear(); review = null; reviewError = null; promoMoves = null
        forced = null; forcedMsg = ""; viewPly = -1; flipped = false; drawDialog = false; resignDialog = false
        clearIntents(); ratingNote = ""
        bot = b; vsBot = b != null; humanWhite = white
        selected = null; thinking = false; flagged = null
        gameId = System.currentTimeMillis()
        baseMs = tc.baseMin * 60_000L; incMs = tc.incSec * 1000L
        clockOn = baseMs > 0; whiteMs = baseMs; blackMs = baseMs
        screen = Screen.GAME
        matchInfo = friendlyInfo(b, white)
        introShown = showIntro
        pendingBotMove = false
        refresh(); startTicker()
        if (soundOn) sfx.play(Sfx.START)
        if (vsBot && !humanWhite) { if (introShown) pendingBotMove = true else botMove() }
    }

    private fun clockText(): String = if (baseMs <= 0) "Tsy misy" else "${baseMs / 60000}+${incMs / 1000}"

    private fun friendlyInfo(b: Bot?, white: Boolean): MatchIntroData {
        val me = IntroSide(PlayerProfile.name, null, null, true, white)
        if (b == null) {
            return MatchIntroData(
                "Match amicale", "Olona vs Olona",
                me.copy(white = true), IntroSide("Mpilalao 2", null, null, false, false), clockText()
            )
        }
        val opp = IntroSide(b.name, b.elo, b, false, !white)
        val l = if (white) me else opp
        val r = if (white) opp else me
        return MatchIntroData("Match amicale", "vs Bot ${tierOf(b.elo).label}", l, r, clockText())
    }

    /** Alefaso ny lalao aorian'ny pejy fampidirana. */
    fun dismissIntro() {
        introShown = false
        if (pendingBotMove) {
            pendingBotMove = false
            if (vsBot && !humanTurn() && !over && !thinking) botMove()
        }
    }

    fun loadGame(rec: GameRecord, thenReview: Boolean = false) {
        botJob?.cancel(); reviewJob?.cancel()
        startFen = rec.startFen
        val b = Board().also { if (rec.startFen != START_FEN) it.loadFromFen(rec.startFen) }
        val list = ArrayList<Move>()
        for (u in rec.moves) {
            val m = b.legalMoves().firstOrNull { it.toString().equals(u, true) } ?: break
            b.doMove(m); list.add(m)
        }
        board = b
        played.clear(); played.addAll(list)
        review = null; reviewError = null; promoMoves = null
        forced = null; forcedMsg = ""; viewPly = -1; flipped = false; drawDialog = false; resignDialog = false
        clearIntents(); ratingNote = ""
        gameId = rec.id
        tourMatch = null
        bot = BotRegistry.find(rec.botId)
        vsBot = bot != null; humanWhite = rec.humanWhite
        baseMs = rec.baseMs; incMs = rec.incMs
        clockOn = baseMs > 0; whiteMs = rec.whiteMs; blackMs = rec.blackMs
        flagged = when {
            clockOn && whiteMs <= 0L -> Side.WHITE
            clockOn && blackMs <= 0L -> Side.BLACK
            else -> null
        }
        selected = null; thinking = false
        screen = Screen.GAME
        val natural = naturalResult(b)
        if (rec.result != null && natural == null && flagged == null) {
            forced = rec.result
            forcedMsg = forcedText(rec.result)
        }
        matchInfo = friendlyInfo(bot, humanWhite); introShown = false; pendingBotMove = false
        refresh(); startTicker()
        if (thenReview) startReview()
        else if (vsBot && !humanTurn() && !over) botMove()
    }

    fun deleteGame(id: Long) { store.delete(id); saved = saved.filter { it.id != id } }

    /** [sync] = miandry ny fanoratana ho vita (ampiasaina rehefa miala ny app: onStop). */
    fun saveGame(sync: Boolean = false) {
        if (played.isEmpty() || gameId == 0L) return
        val rec = GameRecord(
            gameId, bot?.id, humanWhite, baseMs, incMs,
            played.map { it.toString() }, whiteMs, blackMs, result, System.currentTimeMillis(), startFen
        )
        store.save(rec)   // soratana ao amin'ny DiskQueue, tsy misakana ny main thread
        if (sync) DiskQueue.flush()
        // Lisitra ao anaty mémoire (tsy mamaky ny rakitra rehetra isaky ny hetsika)
        saved = listOf(rec) + saved.filter { it.id != rec.id }
        val b = bot
        val r = result
        if (vsBot && b != null && r != null && played.size >= 2 && tourMatch == null && startFen == START_FEN) {
            val ch = PlayerStats.record(getApplication<Application>(), gameId, b, humanWhite, r, played.size, baseMs)
            if (ch != null) {
                ratingNote = "Elo ${ch.before} → ${ch.after} (" + (if (ch.delta >= 0) "+" else "") + ch.delta + ")"
            }
        }
    }

    fun toMenu() {
        botJob?.cancel(); reviewJob?.cancel()
        thinking = false
        clearIntents()
        introShown = false; pendingBotMove = false
        if (tourMatch != null) {
            tourMatch = null
            tourVersion++
            screen = Screen.TOURNAMENT
            return
        }
        saveGame()
        screen = Screen.MENU
    }

    // ---------- Clock ----------
    fun setPaused(p: Boolean) { paused = p }

    private fun startTicker() {
        tickJob?.cancel()
        if (!clockOn) return
        var last = SystemClock.elapsedRealtime()
        tickJob = viewModelScope.launch {
            while (true) {
                delay(100)
                val now = SystemClock.elapsedRealtime()
                val dt = now - last
                last = now
                if (paused || screen != Screen.GAME || played.isEmpty() || over) continue
                if (board.sideToMove == Side.WHITE) {
                    whiteMs = max(0L, whiteMs - dt)
                    if (whiteMs == 0L) flag(Side.WHITE)
                } else {
                    blackMs = max(0L, blackMs - dt)
                    if (blackMs == 0L) flag(Side.BLACK)
                }
            }
        }
    }

    private fun flag(s: Side) {
        flagged = s
        refresh()
        gameEndSound()
        saveGame()
        syncTour()
    }

    // ---------- Lalao ----------
    private fun humanTurn() = !vsBot || (board.sideToMove == Side.WHITE) == humanWhite

    fun legalFrom(sq: Square): List<Move> = board.legalMoves().filter { it.from == sq }

    private fun clearIntents() { premove = null; pendingMove = null }

    /** Ny andaniko: ny olona (vs bot), na ny mpilalao mihetsika (olona vs olona). */
    private fun mySide(): Side = if (!vsBot) board.sideToMove else if (humanWhite) Side.WHITE else Side.BLACK

    fun onSquare(sq: Square) {
        if (viewPly >= 0) { viewPly = -1; return }
        if (over || promoMoves != null) return
        if (!humanTurn()) { onPremoveSquare(sq); return }
        if (thinking) return
        premove = null
        pendingMove = null
        val sel = selected
        val piece = board.getPiece(sq)
        val own = piece != Piece.NONE && piece.pieceSide == board.sideToMove
        if (sel == null || own) {
            selected = if (own) sq else null
            return
        }
        val cands = legalFrom(sel).filter { it.to == sq }
        if (cands.isEmpty()) { selected = null; return }
        val promos = cands.filter { it.promotion != Piece.NONE }
        if (promos.isNotEmpty()) {
            promoMoves = promos.sortedBy { PROMO_ORDER.indexOf(it.promotion.pieceType) }
            return
        }
        selected = null
        submitHuman(cands[0])
    }

    /** Hetsika nofidin'ny olona: ampiharina avy hatrany, na miandry fanamafisana (Settings). */
    private fun submitHuman(mv: Move) {
        if (confirmOn) {
            pendingMove = mv
            selected = null
        } else {
            commitHuman(mv)
        }
    }

    private fun commitHuman(mv: Move) {
        applyMove(mv)
        if (vsBot && !over) botMove()
    }

    fun confirmPending() {
        val m = pendingMove ?: return
        pendingMove = null
        if (over || !humanTurn() || thinking) return
        commitHuman(m)
    }

    fun cancelPending() { pendingMove = null; selected = null }

    fun choosePromotion(m: Move) {
        promoMoves = null
        submitHuman(m)
    }

    fun cancelPromotion() { promoMoves = null; selected = null }

    // ---------- Premove ----------
    /** Tsindrio piece-nao dia ny kare iantsoana azy (mandritra ny fisainan'ny bot). Tsindrio indray hanafoana. */
    private fun onPremoveSquare(sq: Square) {
        if (!premoveOn || !vsBot || introShown) return
        val sel = selected
        val piece = board.getPiece(sq)
        val own = piece != Piece.NONE && piece.pieceSide == mySide()
        if (sel == null) {
            premove = null
            if (own) selected = sq
            return
        }
        when {
            sq == sel -> selected = null
            own -> selected = sq
            else -> { premove = sel to sq; selected = null }
        }
    }

    /** Ampiharina ny premove raha mbola ara-dalàna aorian'ny hetsika an'ny bot (queen foana raha promotion). */
    private fun tryPremove() {
        val pm = premove ?: return
        premove = null
        if (over || !humanTurn() || thinking) return
        val cands = board.legalMoves().filter { it.from == pm.first && it.to == pm.second }
        if (cands.isEmpty()) return
        val mv = cands.firstOrNull { it.promotion.pieceType == PieceType.QUEEN } ?: cands[0]
        commitHuman(mv)
    }

    // ---------- Drag and drop ----------
    /** Antsoin'ny board rehefa manomboka manintona piece. true = azo tarazina. */
    fun dragStart(sq: Square): Boolean {
        if (viewPly >= 0 || over || promoMoves != null || introShown) return false
        val piece = board.getPiece(sq)
        if (piece == Piece.NONE || piece.pieceSide != mySide()) return false
        if (humanTurn()) {
            if (thinking) return false
            premove = null
            pendingMove = null
        } else if (!premoveOn || !vsBot) return false
        selected = sq
        return true
    }

    fun dragDrop(from: Square, to: Square) {
        if (viewPly >= 0 || from == to) return
        val tp = board.getPiece(to)
        selected = from
        if (tp != Piece.NONE && tp.pieceSide == mySide()) return   // avela eo ambony piece-nao: tsy hetsika
        onSquare(to)
    }

    private fun applyMove(mv: Move) {
        val mover = board.sideToMove
        val baseKind = baseMoveKind(board, mv)
        board.doMove(mv)
        played.add(mv)
        moveFeedback(finalMoveKind(baseKind, board))
        if (clockOn) {
            if (mover == Side.WHITE) whiteMs += incMs else blackMs += incMs
        }
        selected = null
        viewPly = -1
        refresh()
        if (over && !board.isMated) gameEndSound()   // stalemate / repetition / 50 hetsika / material
        saveGame()
        syncTour()
    }

    private fun botMove() {
        val b = bot ?: return
        thinking = true
        botJob?.cancel()
        botJob = viewModelScope.launch {
            val remaining = if (board.sideToMove == Side.WHITE) whiteMs else blackMs
            val baseForBot = tourMatch?.let { tour?.baseMs } ?: (tc.baseMin * 60_000L)
            val mt = ThinkTime.budget(b, remaining, incMs, baseForBot, played.size, clockOn)
            var uci = engine.bestMove(board.fen, b.copy(movetimeMs = mt), if (startFen == START_FEN) played.map { it.toString() } else emptyList())
            if (uci == null && !over) {
                // Mety niverina ho azy ny motera (watchdog): andramo indray indray mandeha
                delay(300)
                uci = engine.bestMove(board.fen, b.copy(movetimeMs = mt), if (startFen == START_FEN) played.map { it.toString() } else emptyList())
            }
            thinking = false
            if (over) return@launch
            val mv = board.legalMoves().firstOrNull { it.toString().equals(uci, true) }
            if (mv != null) {
                applyMove(mv)
                if (!over && premove != null) {
                    delay(150)
                    tryPremove()
                }
            } else message = "Stockfish tsy namaly"
        }
    }

    fun undo() {
        if (tourMatch != null) return
        if (thinking || over || played.isEmpty() || flagged != null || forced != null) return
        clearIntents()
        viewPly = -1
        board.undoMove(); played.removeAt(played.lastIndex)
        if (vsBot && !humanTurn() && played.isNotEmpty()) {
            board.undoMove(); played.removeAt(played.lastIndex)
        }
        selected = null; promoMoves = null
        refresh()
        saveGame()
        if (vsBot && !humanTurn() && !over) botMove()
    }

    private fun insufficientMaterial(b: Board): Boolean {
        val placement = b.fen.substringBefore(" ")
        if (placement.any { it in "pPrRqQ" }) return false
        val minors = placement.count { it in "nNbB" }
        return minors <= 1
    }

    /** Valiny voajanahary: checkmate, stalemate, draw (repetition / 50 hetsika / material tsy ampy). */
    private fun naturalResult(b: Board): String? {
        if (b.isMated) return if (b.sideToMove == Side.WHITE) "0-1" else "1-0"
        if (b.legalMoves().isEmpty() || b.isDraw) return "1/2-1/2"
        return null
    }

    private fun sideName(s: Side) = if (s == Side.WHITE) "Fotsy" else "Mainty"

    private fun forcedText(r: String): String = when (r) {
        "1/2-1/2" -> "Draw - nifanaiky"
        "1-0" -> "Fotsy no nahazo (nitsoaka ny Mainty)"
        else -> "Mainty no nahazo (nitsoaka ny Fotsy)"
    }

    private fun refresh() {
        val noMoves = board.legalMoves().isEmpty()
        val mated = board.isMated
        val stalemate = !mated && noMoves && !board.isKingAttacked
        val natural = naturalResult(board)
        val f = flagged
        val fr = forced
        result = when {
            f == Side.WHITE -> "0-1"
            f == Side.BLACK -> "1-0"
            fr != null -> fr
            else -> natural
        }
        over = result != null
        if (over) clearIntents()
        message = when {
            f != null -> "Lany ora ny " + sideName(f) + " - " + sideName(if (f == Side.WHITE) Side.BLACK else Side.WHITE) + " no nahazo"
            fr != null -> forcedMsg
            mated -> "Checkmate! " + (if (board.sideToMove == Side.WHITE) "Mainty" else "Fotsy") + " no nahazo"
            stalemate -> "Stalemate - Draw (tsy afaka mihetsika ny " + sideName(board.sideToMove) + " fa tsy check)"
            natural != null && insufficientMaterial(board) -> "Draw - material tsy ampy hanao checkmate"
            natural != null && (board.fen.split(" ").getOrNull(4)?.toIntOrNull() ?: 0) >= 100 -> "Draw - fitsipika 50 hetsika"
            natural != null -> "Draw - fanamarihana (repetition intelo)"
            board.isKingAttacked -> "Check!"
            else -> ""
        }
        version++
    }

    // ---------- Export (PGN / FEN) ----------
    private fun exportInfo(side: Side): Pair<String, Int?> {
        if (tourMatch != null) {
            val p = tourPlayer(side)
            return (p?.name ?: sideName(side)) to p?.elo
        }
        val b = bot
        val botSide = if (vsBot) (if (humanWhite) Side.BLACK else Side.WHITE) else null
        return when {
            b != null && side == botSide -> b.name to b.elo
            side == Side.WHITE || vsBot -> PlayerProfile.name to null
            else -> "Mpilalao 2" to null
        }
    }

    /** PGN an'ny lalao ankehitriny (miaraka amin'ny valiny raha vita). */
    fun exportPgn(): String {
        val (w, we) = exportInfo(Side.WHITE)
        val (bl, be) = exportInfo(Side.BLACK)
        val event = tourMatch?.let { m -> (tour?.name ?: "Fifaninanana") + " - " + stageLabel(m.stage) } ?: "KAJY - Match amicale"
        val date = if (gameId != 0L) gameId else System.currentTimeMillis()
        return buildPgn(played.map { it.toString() }, w, bl, we, be, result, baseMs, incMs, date, event, startFen)
    }

    /** FEN an'ny toerana ankehitriny (na ny toerana jerena amin'ny fijerena tantara). */
    fun exportFen(): String = if (viewPly >= 0) boardAtPly(viewPly).fen else board.fen

    // ---------- Hetsika aloha / manaraka, flip ----------
    fun flipBoard() { flipped = !flipped }

    fun navPrev() {
        val cur = if (viewPly < 0) played.size else viewPly
        if (cur > 0) viewPly = cur - 1
    }

    fun navNext() {
        if (viewPly < 0) return
        val n = viewPly + 1
        viewPly = if (n >= played.size) -1 else n
    }

    fun navFirst() { if (played.isNotEmpty()) viewPly = 0 }
    fun navLast() { viewPly = -1 }

    /** Toe-javatra aorian'ny hetsika faha-n (ho an'ny fijerena). */
    fun boardAtPly(n: Int): Board {
        val b = Board().also { if (startFen != START_FEN) it.loadFromFen(startFen) }
        for (i in 0 until minOf(n, played.size)) b.doMove(played[i])
        return b
    }

    // ---------- Draw / Resign ----------
    val canOfferDraw: Boolean
        get() = !over && played.size >= 2 && !thinking && promoMoves == null && (!vsBot || humanTurn())

    val canResign: Boolean get() = !over && played.isNotEmpty() && !thinking

    private fun finishForced(r: String, msg: String) {
        forced = r; forcedMsg = msg
        botJob?.cancel(); thinking = false
        drawDialog = false; resignDialog = false
        selected = null; viewPly = -1
        refresh()
        gameEndSound()
        saveGame()
        syncTour()
    }

    fun offerDraw() {
        if (!canOfferDraw) return
        val b = bot
        if (vsBot && b != null) {
            thinking = true
            message = b.name + " mandinika ny tolo-pitenenana draw..."
            botJob?.cancel()
            botJob = viewModelScope.launch {
                val ls = engine.analyze(board.fen, 12, 2500, 1)
                thinking = false
                // cp = araka ny mpilalao mihetsika (olona); ny bot = mifanohitra
                val botCp = -(ls.firstOrNull()?.stmCp() ?: 0)
                val accept = botCp <= -30 || (botCp <= 30 && played.size >= 60)
                if (accept) finishForced("1/2-1/2", "Draw - nankatoavin'i ${b.name}")
                else message = b.name + " tsy manaiky draw"
            }
        } else {
            drawDialog = true
        }
    }

    fun answerDraw(accept: Boolean) {
        drawDialog = false
        if (accept) finishForced("1/2-1/2", "Draw - nifanaiky ny roa tonta")
        else message = "Tsy nanaiky ny draw ny mpilalao faharoa"
    }

    fun resign() {
        resignDialog = false
        if (!canResign) return
        val s = if (vsBot) (if (humanWhite) Side.WHITE else Side.BLACK) else board.sideToMove
        val winner = if (s == Side.WHITE) Side.BLACK else Side.WHITE
        finishForced(if (s == Side.WHITE) "0-1" else "1-0", sideName(s) + " nitsoaka - " + sideName(winner) + " no nahazo")
    }

    // ---------- Review / Analyse ----------
    private fun defaultPuzzleSrc(): PuzzleSrc {
        val b = bot
        return if (vsBot && b != null) {
            if (humanWhite) PuzzleSrc(PlayerProfile.name, b.name, "Lalao amin'ny bot")
            else PuzzleSrc(b.name, PlayerProfile.name, "Lalao amin'ny bot")
        } else PuzzleSrc("Fotsy", "Mainty", "Lalao")
    }

    fun startReview() {
        if (played.isEmpty()) return
        botJob?.cancel(); reviewJob?.cancel()
        thinking = false
        screen = Screen.REVIEW
        review = null; reviewError = null; reviewProgress = 0f
        val moves = played.toList()
        val startPly = reviewStartPly
        reviewStartPly = -1
        // Miseho avy hatrany ny board amin'ny toerana nangatahana (tsy miandry ny analyse)
        reviewPly = if (startPly in 0..moves.size) startPly else moves.size
        val src = reviewSrc ?: defaultPuzzleSrc()
        reviewSrc = null
        reviewJob = viewModelScope.launch {
            try {
                val dep = if (PowerSaver.active) min(reviewDepth, 10) else reviewDepth
                val r = runReview(
                    engine, startFen, moves, dep,
                    extra = if (PowerSaver.active) emptyList() else reviewHelpers(), maxMs = reviewMsFor(dep)
                ) { i, n -> reviewProgress = i.toFloat() / n }
                review = r
                puzzles.addFrom(r, src)
                if (reviewPly > moves.size) reviewPly = moves.size
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                reviewError = e.message ?: "Hadisoana"
            }
        }
    }

    /** Jereo ny lalao iray ao anatin'ny PGN (board + hetsika + review Stockfish). */
    fun viewPgnGame(g: PgnGame) {
        if (g.moves.isEmpty()) return
        botJob?.cancel(); reviewJob?.cancel(); pgnJob?.cancel(); pgnProgress = null
        startFen = START_FEN
        val b = Board()
        val list = ArrayList<Move>()
        for (u in g.moves) {
            val mv = b.legalMoves().firstOrNull { it.toString().equals(u, true) } ?: break
            b.doMove(mv); list.add(mv)
        }
        board = b
        played.clear(); played.addAll(list)
        tourMatch = null
        bot = null; vsBot = false; humanWhite = true
        gameId = 0L
        reviewReturn = Screen.PGN
        reviewStartPly = 0
        reviewSrc = PuzzleSrc(g.white, g.black, g.event.ifBlank { "PGN" })
        startReview()
    }

    /** Analyse ho an'ny "Why?": alohan'ny hetsika (MultiPV 3) sy aorian'ny hetsika (PV), miaraka amin'ny andalana. */
    suspend fun whyAnalysis(fenBefore: String, fenAfter: String): Pair<List<Line>, List<Line>> {
        val depth = if (PowerSaver.active) 12 else 18
        val b = engine.analyze(fenBefore, depth, 2500, 3)
        val a = engine.analyze(fenAfter, depth, 2500, 1)
        return b to a
    }

    fun leaveReview() {
        reviewJob?.cancel()
        if (reviewReturn == Screen.PGN) {
            reviewReturn = Screen.GAME
            screen = Screen.PGN
            return
        }
        if (reviewReturn == Screen.TOURNAMENT) {
            reviewReturn = Screen.GAME
            screen = Screen.TOURNAMENT
            return
        }
        screen = Screen.GAME
        if (vsBot && !humanTurn() && !over && !thinking) botMove()
    }

    // ================= PGN -> BOT =================

    fun toPgn() { botJob?.cancel(); screen = Screen.PGN }

    fun cancelPgn() { pgnJob?.cancel(); pgnProgress = null }

    fun loadPgn(text: String) {
        pgnDraft = null
        val g = try { Pgn.parse(text) } catch (e: Exception) { emptyList() }
        pgnGames = g
        pgnError = if (g.isEmpty()) "Tsy nahita lalao azo vakiana ao amin'ny PGN (hetsika 3 farafahakeliny)." else null
    }

    /** Mandinika ny lalao nilalaovan'ny mpilalao amin'ny Stockfish, avy eo mamorona drafitra bot. */
    fun analyzePgnPlayer(player: String) {
        // Lalao 2 ihany no andinihina: 1 amin'ny Fotsy + 1 amin'ny Mainty (raha tsy ampy, lalao faharoa amin'ny loko mitovy)
        val all = pgnGames.filter {
            it.moves.size >= 8 && (it.white.equals(player, true) || it.black.equals(player, true))
        }
        val asW = all.firstOrNull { it.white.equals(player, true) }
        val asB = all.firstOrNull { it !== asW && it.black.equals(player, true) }
        val mine = ArrayList<PgnGame>()
        asW?.let { mine.add(it) }
        asB?.let { mine.add(it) }
        if (mine.size < 2) all.firstOrNull { it !in mine }?.let { mine.add(it) }
        if (mine.isEmpty()) { pgnError = "Tsy ampy hetsika ny lalao (8 farafahakeliny)."; return }
        botJob?.cancel(); reviewJob?.cancel(); pgnJob?.cancel()
        pgnError = null; pgnDraft = null; pgnProgress = 0f
        pgnJob = viewModelScope.launch {
            try {
                engine.newGame()
                val depth = min(reviewDepth, 12)
                val ratings = ArrayList<Int>(); val accs = ArrayList<Double>()
                val tally = HashMap<String, Int>(); val lines = ArrayList<String>()
                val styles = ArrayList<Style>(); val tagElos = ArrayList<Int>()
                for ((gi, g) in mine.withIndex()) {
                    val white = g.white.equals(player, true)
                    val uci = g.moves.take(70)
                    val b = Board(); val ml = ArrayList<Move>()
                    for (u in uci) {
                        val m = b.legalMoves().firstOrNull { it.toString().equals(u, true) } ?: break
                        b.doMove(m); ml.add(m)
                    }
                    val r = runReview(engine, START_FEN, ml, depth, extra = reviewHelpers(), maxMs = 300, multiPv = 1) { i, n -> pgnProgress = (gi + i.toFloat() / n) / mine.size }
                    val side = if (white) r.white else r.black
                    ratings.add(side.rating); accs.add(side.accuracy)
                    (if (white) g.whiteElo else g.blackElo)?.let { tagElos.add(it) }
                    for (o in Personality.detectOpenings(uci, white)) tally[o] = (tally[o] ?: 0) + 1
                    val line = Personality.gameLine(uci, white)
                    if (line !in lines) lines.add(line)
                    styles.add(Personality.deriveStyle(uci, white))
                }
                val rating = ratings.average().roundToInt()
                val tag = if (tagElos.isEmpty()) null else tagElos.average().roundToInt()
                val est = if (tag != null) (rating + tag) / 2 else rating
                val elo = ((est / 50.0).roundToInt() * 50).coerceIn(100, 3200)
                fun avg(f: (Style) -> Int) = styles.map(f).average().roundToInt()
                val style = Style(avg { it.aggression }, avg { it.sacrifice }, avg { it.defense }, avg { it.queen }, avg { it.trades })
                pgnDraft = PgnBotDraft(
                    player, mine.size, rating, tag, accs.average(), elo,
                    tally.entries.sortedByDescending { it.value }.take(3).map { it.key },
                    lines.take(6), style
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                pgnError = e.message ?: "Hadisoana tamin'ny fandinihana"
            } finally {
                pgnProgress = null
            }
        }
    }

    override fun onCleared() {
        sfx.release()
        saveGame()
        autoJob?.cancel(); analysisJob?.cancel()
        simJobs.values.forEach { it.cancel() }
        enginePool.forEach { it.stop() }
        analysisEngine?.stop()
        reviewExtra.forEach { it.stop() }
        engine.stop()
    }

    // ================= FIFANINANANA =================

    fun toTourList() {
        botJob?.cancel()
        tourMatch = null
        screen = Screen.TOUR_LIST
    }
    fun toTourNew() { screen = Screen.TOUR_NEW }
    fun toArchive() { tourVersion++; screen = Screen.ARCHIVE }
    fun toChronicle() { tourVersion++; screen = Screen.CHRONICLE }

    fun openTour(t: Tournament) {
        if (tour?.id != t.id) { stopSim(); sims.clear() }
        tour = t; tourVersion++
        screen = Screen.TOURNAMENT
        analyseAllPending()
    }

    fun deleteTour(t: Tournament) {
        if (tour?.id == t.id) { stopSim(); tour = null }
        analysisQueue.removeAll { it.first.id == t.id }
        AutoBackup.snapshot(getApplication(), "before-delete")
        tourStore.delete(t.id)
        tournaments = tournaments.filter { it.id != t.id }
    }

    fun createTour(name: String, players: List<Participant>, baseMs: Long, incMs: Long, wantGroups: Boolean, swiss: Boolean = false, double: Boolean = false) {
        stopSim()
        val t = Tournament.create(System.currentTimeMillis(), name, players, baseMs, incMs, wantGroups, swiss, double)
        tourStore.save(t)
        tournaments = listOf(t) + tournaments
        openTour(t)
    }

    private fun tourSave() {
        val t = tour ?: return
        if (t.champion != null && !t.botsRated) {
            t.botsRated = true
            val ch = try { BotProgress.applyTournament(getApplication(), t) } catch (e: Exception) { emptyList() }
            if (ch.isNotEmpty()) eloChanges = ch.sortedByDescending { it.new }
        }
        t.updated = System.currentTimeMillis()
        tourStore.save(t)
        tourVersion++
    }

    fun isBotMatch(m: TMatch): Boolean {
        val t = tour ?: return false
        return t.player(m.whiteId)?.bot != null && t.player(m.blackId)?.bot != null
    }

    fun tourPlayer(side: Side): Participant? {
        val m = tourMatch ?: return null
        return tour?.player(if (side == Side.WHITE) m.whiteId else m.blackId)
    }

    /** Knockout: rehefa vita ny round (ohatra demi-finale) dia mivoatra avy hatrany ny Finale + lalao faha-3, tsy miandry bokotra. */
    private fun autoAdvanceKo(t: Tournament) {
        if (!t.isSwiss && !t.isDouble && t.stage.startsWith("KO") && t.stageComplete()) t.advance()
    }

    fun advanceTour() {
        val t = tour ?: return
        if (t.advance()) tourSave()
    }

    // ---------- Lalao olona ao anaty fifaninanana ----------
    fun playTourMatch(m: TMatch) {
        val t = tour ?: return
        if (m.result != null) return
        val wp = t.player(m.whiteId) ?: return
        val bp = t.player(m.blackId) ?: return
        if (wp.bot != null && bp.bot != null) return
        botJob?.cancel(); reviewJob?.cancel()
        startFen = START_FEN
        val b = Board()
        played.clear()
        for (u in m.moves) {
            val mv = b.legalMoves().firstOrNull { it.toString().equals(u, true) } ?: break
            b.doMove(mv); played.add(mv)
        }
        board = b
        review = null; reviewError = null; promoMoves = null
        forced = null; forcedMsg = ""; viewPly = -1; flipped = false; drawDialog = false; resignDialog = false
        clearIntents(); ratingNote = ""
        tourMatch = m
        bot = wp.bot ?: bp.bot
        vsBot = bot != null
        humanWhite = wp.bot == null
        baseMs = t.baseMs; incMs = t.incMs
        clockOn = baseMs > 0
        whiteMs = if (played.isEmpty()) baseMs else m.whiteMs
        blackMs = if (played.isEmpty()) baseMs else m.blackMs
        flagged = when {
            clockOn && played.isNotEmpty() && whiteMs <= 0L -> Side.WHITE
            clockOn && played.isNotEmpty() && blackMs <= 0L -> Side.BLACK
            else -> null
        }
        result = null
        selected = null; thinking = false
        gameId = 0L
        reviewReturn = Screen.GAME
        screen = Screen.GAME
        refresh(); startTicker()
        syncTour()
        val label = matchStageLabel(m)
        val sub = t.name + (if (m.game >= ARMAGEDDON_GAME) " · Armageddon" else if (m.game > 0) " · Lalao fanampiny ${m.game}" else "")
        matchInfo = MatchIntroData(
            label, sub,
            IntroSide(wp.name, wp.elo, wp.bot, wp.bot == null, true),
            IntroSide(bp.name, bp.elo, bp.bot, bp.bot == null, false),
            clockText()
        )
        pendingBotMove = false
        introShown = m.moves.isEmpty()
        if (vsBot && !humanTurn() && !over) { if (introShown) pendingBotMove = true else botMove() }
    }

    private fun syncTour() {
        val m = tourMatch ?: return
        val t = tour ?: return
        m.moves = played.map { it.toString() }
        m.whiteMs = whiteMs; m.blackMs = blackMs
        val r = result
        if (over && r != null && m.result == null) { t.recordResult(m, r); autoAdvanceKo(t) }
        tourSave()
        if (m.result != null) queueAnalysis(t, m)
    }

    // ---------- Simulation bot vs bot (maromaro miaraka) ----------
    private fun acquireEngine(): Engine = enginePool.removeFirstOrNull() ?: Engine(getApplication(), 1, 32)
    private fun releaseEngine(e: Engine) { enginePool.addLast(e) }

    fun isSimRunning(id: Int) = id in simRunningIds
    fun isSimWaiting(id: Int) = id in simWaitingIds

    fun chooseSimParallel(n: Int) {
        simParallel = n.coerceIn(1, 4)
        prefs.edit().putInt("sim_parallel", simParallel).apply()
    }

    /** Alefaso ny lalao: tsy mila miandry lalao hafa vita. Miandry ihany raha mihoatra ny [simParallel]. */
    private fun launchSim(t: Tournament, m: TMatch, force: Boolean) {
        if (m.result != null || !isBotMatch(m)) return
        if (m.id in simJobs) {
            if (force) simForced.add(m.id)
            return
        }
        val token = Any()
        simTokens[m.id] = token
        if (force) simForced.add(m.id)
        simWaitingIds = simWaitingIds + m.id
        simJobs[m.id] = viewModelScope.launch {
            var eng: Engine? = null
            var counted = false
            try {
                while (activeSims >= simParallel && m.id !in simForced) delay(200)
                activeSims++; counted = true
                if (simTokens[m.id] === token) {
                    simWaitingIds = simWaitingIds - m.id
                    simRunningIds = simRunningIds + m.id
                }
                eng = acquireEngine()
                try {
                    runSim(t, m, eng)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    tourMsg = "Hadisoana: " + (e.message ?: "")
                }
            } finally {
                if (eng != null) releaseEngine(eng)
                if (counted) activeSims--
                if (simTokens[m.id] === token) {
                    simTokens.remove(m.id); simJobs.remove(m.id); simForced.remove(m.id)
                    simWaitingIds = simWaitingIds - m.id
                    simRunningIds = simRunningIds - m.id
                }
            }
        }
    }

    fun simOne(m: TMatch, watch: Boolean) {
        val t = tour ?: return
        if (m.result != null || !isBotMatch(m)) return
        launchSim(t, m, true)
        if (watch) {
            watchId = m.id; screen = Screen.WATCH
        }
    }

    /** Alefaso miaraka ny lalao bot rehetra ao amin'ny round (araka ny [simParallel]). */
    fun simAllPending() {
        val t = tour ?: return
        for (m in t.stageMatches()) launchSim(t, m, false)
    }

    fun runAuto() {
        val t = tour ?: return
        autoMode = true
        if (autoJob?.isActive == true) return
        autoJob = viewModelScope.launch {
            try {
                while (autoMode) {
                    val tt = tour ?: break
                    if (tt.champion != null) break
                    for (m in tt.stageMatches()) launchSim(tt, m, false)
                    while (simJobs.isNotEmpty()) delay(300)
                    if (!autoMode) break
                    val pendingBots = tt.stageMatches().any { it.result == null && isBotMatch(it) }
                    if (pendingBots) continue
                    if (tt.stageComplete()) { tt.advance(); tourSave() } else break
                }
            } finally {
                autoMode = false
            }
        }
    }

    fun stopSim() {
        autoMode = false
        autoJob?.cancel()
        simJobs.values.forEach { it.cancel() }
        simJobs.clear(); simTokens.clear(); simForced.clear()
        simWaitingIds = emptySet(); simRunningIds = emptySet()
        tourSave()
    }

    fun leaveWatch() { screen = Screen.TOURNAMENT }

    var tourMsg by mutableStateOf("")

    /** Fiovan'ny Elo bot aorian'ny fifaninanana vita (aseho ao anaty dialog hatramin'ny fanidiana). */
    var eloChanges by mutableStateOf<List<EloChange>>(emptyList())

    private suspend fun runSim(t: Tournament, m: TMatch, eng: Engine) {
        val wb = t.player(m.whiteId)?.bot ?: return
        val bb = t.player(m.blackId)?.bot ?: return
        val b = Board()
        val moves = ArrayList<String>()
        for (u in m.moves) {
            val mv = b.legalMoves().firstOrNull { it.toString().equals(u, true) } ?: break
            b.doMove(mv); moves.add(u)
        }
        val clock = t.baseMs > 0
        var wMs = if (moves.isEmpty() || !clock) t.baseMs else m.whiteMs
        var bMs = if (moves.isEmpty() || !clock) t.baseMs else m.blackMs
        val st = SimState(m.id, b, wMs, bMs)
        st.plies = moves.size
        sims[m.id] = st
        var res: String? = null
        // Live: Stockfish tena izy isaky ny andaniny (toy ny olona vs bot), tsy simulation haingana
        var liveW: Engine? = null
        var liveB: Engine? = null
        try {
        while (res == null) {
            res = gameResult(b)
            if (res != null) break
            if (moves.size >= 500) { res = "1/2-1/2"; break }
            val white = b.sideToMove == Side.WHITE
            val pb = if (white) wb else bb
            val remaining = if (white) wMs else bMs
            val live = screen == Screen.WATCH && watchId == m.id && !PowerSaver.active
            val mt = ThinkTime.budget(pb, remaining, t.incMs, t.baseMs, moves.size, clock)
            val useEng: Engine = if (live) {
                if (white) (liveW ?: Engine(getApplication()).also { liveW = it })
                else (liveB ?: Engine(getApplication()).also { liveB = it })
            } else eng
            val t0 = SystemClock.elapsedRealtime()
            st.thinkingWhite = white
            st.thinkStart = t0
            var uci = useEng.bestMove(b.fen, pb.copy(movetimeMs = mt), moves)
            val spent0 = SystemClock.elapsedRealtime() - t0
            // Ny ora dia isaina araka ny fotoana nomena ny bot (mt), fa tsy araka ny CPU / lalao miaraka:
            // raha tsy izany dia very ora ny lalao noho ny finday miadana, tsy noho ny kalitaon'ny filalaovana.
            val spent = minOf(spent0, mt.toLong() + 120L)
            st.thinkStart = 0L
            if (clock) {
                if (white) wMs = max(0L, wMs - spent) else bMs = max(0L, bMs - spent)
                if ((white && wMs <= 0L) || (!white && bMs <= 0L)) {
                    st.whiteMs = wMs; st.blackMs = bMs
                    res = if (white) "0-1" else "1-0"
                    break
                }
            }
            val legal = b.legalMoves()
            var mvOrNull = legal.firstOrNull { it.toString().equals(uci, true) }
            if (mvOrNull == null) {
                // Tsy namaly ny motera (timeout / maty / hetsika tsy mety): avereno ny Stockfish (averina atomboka ho azy)
                uci = useEng.bestMove(b.fen, pb.copy(movetimeMs = pb.movetimeMs.coerceAtLeast(300)), moves)
                mvOrNull = legal.firstOrNull { it.toString().equals(uci, true) }
            }
            if (mvOrNull == null) {
                // Farany: Stockfish feno hery fohy (tsy hetsika kisendrasendra afa-tsy raha tsy mandeha mihitsy ny motera)
                val ln = useEng.analyze(b.fen, 10, 800, 1).firstOrNull()?.move
                mvOrNull = legal.firstOrNull { it.toString().equals(ln, true) }
            }
            val mv = mvOrNull ?: legal.random()
            val baseKind = baseMoveKind(b, mv)
            b.doMove(mv)
            moves.add(mv.toString())
            if (screen == Screen.WATCH && watchId == m.id) moveFeedback(finalMoveKind(baseKind, b))
            if (clock) { if (white) wMs += t.incMs else bMs += t.incMs }
            st.whiteMs = wMs; st.blackMs = bMs
            st.last = mv.from to mv.to
            st.plies = moves.size
            st.version++
            m.moves = moves.toList(); m.whiteMs = wMs; m.blackMs = bMs
            if (moves.size % 12 == 0) tourSave()
        }
        } finally {
            liveW?.stop(); liveB?.stop()
        }
        m.moves = moves.toList(); m.whiteMs = wMs; m.blackMs = bMs
        st.result = res
        st.version++
        t.recordResult(m, res ?: "1/2-1/2")
        autoAdvanceKo(t)
        tourSave()
        queueAnalysis(t, m)
    }

    // ---------- Review lalao fifaninanana ----------
    fun reviewTourMatch(m: TMatch, ply: Int = -1) {
        if (m.moves.isEmpty()) return
        botJob?.cancel(); reviewJob?.cancel()
        startFen = START_FEN
        val b = Board()
        val list = ArrayList<Move>()
        for (u in m.moves) {
            val mv = b.legalMoves().firstOrNull { it.toString().equals(u, true) } ?: break
            b.doMove(mv); list.add(mv)
        }
        board = b
        played.clear(); played.addAll(list)
        tourMatch = null
        bot = null; vsBot = false; humanWhite = true
        gameId = 0L
        reviewReturn = Screen.TOURNAMENT
        reviewStartPly = ply
        reviewSrc = tour?.let { t -> PuzzleSrc(t.name(m.whiteId), t.name(m.blackId), t.name) }
        startReview()
    }

    // ---------- Analyse ho an'ny classement (ao ambadika, motera manokana) ----------
    fun toggleAnalysis(on: Boolean) {
        analysisOn = on
        prefs.edit().putBoolean("tour_analysis", on).apply()
        if (on) analyseAllPending()
    }

    private fun queueAnalysis(t: Tournament, m: TMatch) {
        if (!analysisOn || m.analysis != null || m.moves.size < 4) return
        val r = m.result
        if (r != "1-0" && r != "0-1" && r != "1/2-1/2") return
        if (!analysisKeys.add("${t.id}:${m.id}")) return
        analysisQueue.addLast(t to m.id)
        analysisPending = analysisQueue.size
        ensureAnalysisLoop()
    }

    fun analyseAllPending() {
        val t = tour ?: return
        for (m in t.matches) queueAnalysis(t, m)
    }

    private fun ensureAnalysisLoop() {
        if (analysisJob?.isActive == true) return
        analysisJob = viewModelScope.launch {
            try {
                val eng = analysisEngine ?: Engine(getApplication(), 1, 32).also { analysisEngine = it }
                while (true) {
                    val item = analysisQueue.removeFirstOrNull() ?: break
                    val t = item.first
                    analysisPending = analysisQueue.size + 1
                    val m = t.matches.firstOrNull { it.id == item.second } ?: continue
                    if (m.analysis != null) continue
                    try {
                        val b = Board()
                        val list = ArrayList<Move>()
                        for (u in m.moves) {
                            val mv = b.legalMoves().firstOrNull { it.toString().equals(u, true) } ?: break
                            b.doMove(mv); list.add(mv)
                        }
                        val r = runReview(eng, START_FEN, list, ANALYSIS_DEPTH, maxMs = 260) { _, _ -> }
                        m.analysis = analysisOf(r)
                        puzzles.addFrom(r, PuzzleSrc(t.name(m.whiteId), t.name(m.blackId), t.name))
                        if (tournaments.any { it.id == t.id }) tourStore.save(t)
                        tourVersion++
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        analysisKeys.remove("${t.id}:${m.id}")
                    }
                }
            } finally {
                analysisPending = 0
            }
        }
    }
}
