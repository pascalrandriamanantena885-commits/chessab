package mg.chess.offline

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.github.bhlangonijr.chesslib.Board
import kotlinx.coroutines.delay

/**
 * Pejy "Why?": replay mandeha ho azy (hetsika 6 teo aloha → ilay hetsika → andalana manaraka), tab "Tsara kokoa / Safidy hafa"
 * ary fanazavana soratra. Ny replay dia miseho avy hatrany; ny analyse Stockfish (PV) dia tonga aorian'izay ary manampy ny soratra sy ny andalana.
 */
@Composable
fun WhyDialog(vm: ChessViewModel, r: ReviewResult, ply: Int, flip: Boolean, onDismiss: () -> Unit) {
    val mv = r.moves[ply - 1]
    val cs = MaterialTheme.colorScheme
    var loading by remember(ply) { mutableStateOf(true) }
    var before by remember(ply) { mutableStateOf<List<Line>>(emptyList()) }
    var after by remember(ply) { mutableStateOf<List<Line>>(emptyList()) }
    LaunchedEffect(ply) {
        loading = true
        try {
            val (b, a) = vm.whyAnalysis(r.fens[ply - 1], r.fens[ply])
            before = b; after = a
        } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (_: Exception) { }
        loading = false
    }
    val report = remember(ply, before, after) { buildWhyReport(r, ply, before, after) }

    val altIsSecond = mv.cls == Cls.GREAT || mv.cls == Cls.BRILLIANT ||
        before.firstOrNull()?.move.equals(mv.uci, true)
    val altPv = (if (altIsSecond) before.getOrNull(1) else before.firstOrNull())?.pv ?: emptyList()
    val altLabel = if (mv.cls == Cls.BLUNDER || mv.cls == Cls.MISTAKE || mv.cls == Cls.MISS) "Hetsika tsara kokoa" else "Raha hetsika hafa"

    var tab by remember(ply) { mutableIntStateOf(0) }
    val played = remember(ply, after) { playedFrames(r, ply, afterTopPv(after)) }
    val alt = remember(ply, before) { altFrames(r, ply, altPv) }
    val frames = if (tab == 1 && alt.size > 1) alt else played
    var idx by remember(ply, tab) { mutableIntStateOf(0) }
    var playing by remember(ply, tab) { mutableStateOf(true) }

    LaunchedEffect(playing, idx, tab, frames.size) {
        if (!playing) return@LaunchedEffect
        if (idx >= frames.lastIndex) { playing = false; return@LaunchedEffect }
        delay(if (frames[idx].kind == 1) 1500L else 950L)
        idx++
    }

    val f = frames[idx.coerceIn(0, frames.lastIndex)]
    val board = remember(f.fen) { Board().also { it.loadFromFen(f.fen) } }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = cs.background) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ClsDot(mv.cls, 28.dp)
                    Spacer(Modifier.width(8.dp))
                    Text(report.headline, Modifier.weight(1f), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    TextButton(onDismiss) { Text("Akatony") }
                }
                if (loading) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                    Text("Mandinika ny toerana amin'ny Stockfish... (azonao jerena ny replay mandritra izay)", fontSize = 11.sp, color = cs.onSurfaceVariant)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(tab == 0, { tab = 0 }, { Text("Ny nitranga") })
                    if (alt.size > 1) FilterChip(tab == 1, { tab = 1 }, { Text(altLabel) })
                }
                BoardView(
                    pieceAt = { board.getPiece(it) }, flip = flip, last = f.last,
                    badge = if (f.cls != null && f.last != null) f.last.second to f.cls else null
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(f.label, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(
                        when (f.kind) { 1 -> "Hetsika lehibe"; 2 -> "Andalana manaraka"; else -> "Teo aloha" } + "  ${idx + 1}/${frames.size}",
                        fontSize = 12.sp, color = cs.onSurfaceVariant
                    )
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    OutlinedButton({ playing = false; idx = 0 }) { Text("|<") }
                    OutlinedButton({ playing = false; if (idx > 0) idx-- }) { Text("<") }
                    Button({
                        if (idx >= frames.lastIndex) idx = 0
                        playing = !playing
                    }) { Text(if (playing) "⏸" else "▶") }
                    OutlinedButton({ playing = false; if (idx < frames.lastIndex) idx++ }) { Text(">") }
                    OutlinedButton({ playing = false; idx = frames.lastIndex }) { Text(">|") }
                }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Fanazavana", fontWeight = FontWeight.Bold)
                        for (p in report.points) Text("• $p", fontSize = 14.sp)
                    }
                }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Ny fizotry ny lalao", fontWeight = FontWeight.Bold)
                        for (s in report.story) Text(s, fontSize = 13.sp, color = cs.onSurfaceVariant)
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

private fun afterTopPv(after: List<Line>): List<String> = after.firstOrNull()?.pv ?: emptyList()
