# Bot pack (`.kbot`) - endrika ho an'ny mod

Rakitra ZIP (azo avadika `.zip` raha ilaina; ny votoatiny no jerena fa tsy ny anarana) misy:

```
manifest.json
avatars/0.png      (tsy voatery; sary kare, PNG/JPG, <= 3 MB)
avatars/1.png
```

Azo ampiasaina koa ny **JSON tsotra** (`.json`): bot tokana na manifest feno, ary ny sary dia azo asiana `"avatarB64"` (base64).

## manifest.json

```json
{
  "format": "kajy-bot-pack",
  "version": 1,
  "bots": [
    {
      "name": "Fenitra",
      "elo": 2100,
      "bio": "Mpanafika: tia gambit.",
      "color": 4294198070,
      "openings": ["kingsgambit", "evans", "morra"],
      "lines": ["W|e2e4 e7e5 f2f4 e5f4 g1f3 g7g5"],
      "style": { "a": 85, "s": 90, "d": 25, "q": 50, "t": 30 },
      "avatar": "avatars/0.png"
    }
  ]
}
```

| Saha | Fepetra |
|---|---|
| `name` | tsy foana, hatramin'ny 20 litera (raha efa misy dia asiana " (2)") |
| `elo` | 100..3200 (**ilaina**) |
| `bio` | tsy voatery, <= 200 litera |
| `color` | tsy voatery, ARGB (raha tsy misy sary dia ity no loko avatar) |
| `openings` | id ao amin'ny katalaogy `Openings.kt` (italian, ruy, scotch, kingsgambit, evans, morra, wsicilian, london, qgambit, english, french, caro, scandi, najdorf, dragon, kid, grunfeld, nimzo, qgd, slav ...). Ny tsy fantatra dia esorina. |
| `lines` | "W|" na "B|" + hetsika UCI mifanalavitra amin'ny espace, hatramin'ny 40 hetsika; ≤ 12 andalana |
| `style` | `a` fanafihana, `s` sacrifice, `d` fiarovana, `q` queen aloha, `t` fifanakalozana; 0..100 (50 = mahazatra) |
| `avatar` | lalana ao anaty zip |

Fandriam-pahalemana: fetra habe (24 MB / 300 rakitra / 100 bot), fanamarinana ny sary, ary tsy misy code mandeha: data fotsiny ny pack. Ny bot rehetra ampidirina dia "nataoko" ary hita ao amin'ny Settings (azo ovaina na fafana).

## Fampiasana
- **Export**: Settings > Bot pack (na ny pejy "Fidio ny bot") > Export bot > fidio ny bot > Zarao (WhatsApp, Drive...) na Tehirizo.
- **Import**: Import bot > fidio ny rakitra .kbot / .json > hita ny lisitra > Ampidiro.
