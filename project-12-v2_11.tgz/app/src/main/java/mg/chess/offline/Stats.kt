package mg.chess.offline

import android.content.Context
import android.util.Log
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.material3.FilterChip
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

/** Lalao iray vita (amin'ny bot) ao amin'ny statistika. */
data class StatGame(
    val id: Long, val botId: String, val botName: String, val botElo: Int,
    val humanWhite: Boolean, val score: Double,
    val before: Int, val after: Int, val plies: Int, val time: Long
)

data class RatingChange(val before: Int, val after: Int) {
    val delta get() = after - before
}

data class Tally(val w: Int, val d: Int, val l: Int) {
    val n get() = w + d + l
    val winPct get() = if (n == 0) 0 else ((w + 0.5 * d) * 100.0 / n).roundToInt()
}

fun tallyOf(list: List<StatGame>) = Tally(
    list.count { it.score == 1.0 }, list.count { it.score == 0.5 }, list.count { it.score == 0.0 }
)

/**
 * Rating + statistika an'ny mpilalao olona amin'ny bot (lalao Play tsotra).
 * Tehirizina ao amin'ny filesDir/stats.json; lalao tsirairay dia voaisa indray mandeha ihany (araka ny id).
 */
object PlayerStats {
    var rating by mutableStateOf(START_RATING); private set
    var peak by mutableStateOf(START_RATING); private set
    val games = mutableStateListOf<StatGame>()
    private val seen = HashSet<Long>()

    val ratingInt: Int get() = rating.roundToInt()
    val peakInt: Int get() = peak.roundToInt()

    private fun file(ctx: Context) = File(ctx.filesDir, "stats.json")
    fun exists(ctx: Context) = file(ctx).exists()

    fun load(ctx: Context) {
        games.clear(); seen.clear()
        rating = START_RATING; peak = START_RATING
        val f = file(ctx)
        if (!f.exists()) return
        try {
            val o = JSONObject(f.readText())
            rating = o.optDouble("rating", START_RATING)
            peak = o.optDouble("peak", rating)
            val a = o.optJSONArray("games") ?: JSONArray()
            for (i in 0 until a.length()) {
                val g = a.getJSONObject(i)
                val sg = StatGame(
                    g.getLong("id"), g.getString("botId"), g.optString("botName", g.getString("botId")),
                    g.getInt("botElo"), g.optBoolean("hw", true), g.getDouble("score"),
                    g.getInt("before"), g.getInt("after"), g.optInt("plies", 0), g.optLong("time", g.getLong("id"))
                )
                games.add(sg); seen.add(sg.id)
            }
        } catch (e: Exception) {
            Log.w("PlayerStats", "stats.json simba, averina ho foana", e)
            games.clear(); seen.clear(); rating = START_RATING; peak = START_RATING
        }
    }

    private fun save(ctx: Context) {
        try {
            val o = JSONObject()
            o.put("rating", rating); o.put("peak", peak)
            val a = JSONArray()
            for (g in games) {
                val j = JSONObject()
                j.put("id", g.id); j.put("botId", g.botId); j.put("botName", g.botName); j.put("botElo", g.botElo)
                j.put("hw", g.humanWhite); j.put("score", g.score)
                j.put("before", g.before); j.put("after", g.after); j.put("plies", g.plies); j.put("time", g.time)
                a.put(j)
            }
            o.put("games", a)
            val f = file(ctx)
            val tmp = File(f.parentFile, "stats.tmp")
            tmp.writeText(o.toString())
            if (!tmp.renameTo(f)) f.writeText(o.toString())
        } catch (e: Exception) {
            Log.w("PlayerStats", "tsy voatahiry ny statistika", e)
        }
    }

    private fun applyResult(id: Long, bot: Bot, humanWhite: Boolean, result: String, plies: Int, time: Long): RatingChange? {
        if (id in seen) return null
        val s = scoreOf(result, humanWhite) ?: return null
        val before = rating
        val after = eloNext(before, games.size, bot.elo, s)
        games.add(StatGame(id, bot.id, bot.name, bot.elo, humanWhite, s, before.roundToInt(), after.roundToInt(), plies, time))
        seen.add(id)
        rating = after
        peak = max(peak, after)
        return RatingChange(before.roundToInt(), after.roundToInt())
    }

    /** Antsoina rehefa vita ny lalao. Mamerina null raha efa voaisa na tsy azo isaina. */
    fun record(ctx: Context, id: Long, bot: Bot, humanWhite: Boolean, result: String, plies: Int): RatingChange? {
        val ch = applyResult(id, bot, humanWhite, result, plies, System.currentTimeMillis())
        if (ch != null) save(ctx)
        return ch
    }

    /** Mamoron'ny statistika avy amin'ny lalao efa voatahiry (indray mandeha, rehefa tsy mbola misy stats.json). */
    fun backfill(ctx: Context, recs: List<GameRecord>, find: (String?) -> Bot?) {
        var any = false
        for (r in recs.sortedBy { it.id }) {
            val res = r.result ?: continue
            val b = find(r.botId) ?: continue
            if (r.moves.size < 2) continue
            if (applyResult(r.id, b, r.humanWhite, res, r.moves.size, r.updated) != null) any = true
        }
        if (any || !exists(ctx)) save(ctx)
    }

    fun reset(ctx: Context) {
        games.clear(); seen.clear()
        rating = START_RATING; peak = START_RATING
        try { file(ctx).delete() } catch (_: Exception) {}
    }
}

// ---------------- UI ----------------

private val WIN = Color(0xFF66BB6A)
private val DRAW = Color(0xFF9E9E9E)
private val LOSS = Color(0xFFEF5350)

/** Card fohy ao amin'ny Tantara: Elo + W/D/L + bokotra hamoha ny statistika. */
@Composable
fun StatsSummaryCard(onOpen: () -> Unit) {
    val t = tallyOf(PlayerStats.games)
    Card(
        Modifier.fillMaxWidth().padding(bottom = 8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Elo-nao: ${PlayerStats.ratingInt}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(
                    if (t.n == 0) "Mbola tsy misy lalao voaisa" else "${t.w} nahazo - ${t.d} draw - ${t.l} resy",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Button(onOpen) { Text("Statistika") }
        }
    }
}

@Composable
private fun RatingGraph(points: List<Int>, startLabel: String, endLabel: String, modifier: Modifier) {
    val line = MaterialTheme.colorScheme.primary
    val peakC = MaterialTheme.colorScheme.tertiary
    val grid = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
    val sub = MaterialTheme.colorScheme.onSurfaceVariant
    Column(modifier) {
        Row(Modifier.fillMaxWidth()) {
            Column(Modifier.width(40.dp).height(110.dp), verticalArrangement = Arrangement.SpaceBetween) {
                Text("${points.max()}", fontSize = 10.sp, color = sub)
                Text("${points.min()}", fontSize = 10.sp, color = sub)
            }
            Canvas(Modifier.weight(1f).height(110.dp)) {
                val w = size.width
                val h = size.height
                drawLine(grid, Offset(0f, h / 2), Offset(w, h / 2), 1f)
                if (points.size < 2) return@Canvas
                val lo = (points.min() - 20).toFloat()
                val hi = (points.max() + 20).toFloat()
                val span = (hi - lo).coerceAtLeast(1f)
                fun x(i: Int) = w * i / (points.size - 1)
                fun y(v: Int) = h - h * (v - lo) / span
                for (i in 1 until points.size) {
                    drawLine(line, Offset(x(i - 1), y(points[i - 1])), Offset(x(i), y(points[i])), 4f)
                }
                val pk = points.indexOf(points.max())
                drawCircle(peakC, 7f, Offset(x(pk), y(points[pk])))
                drawCircle(line, 7f, Offset(x(points.size - 1), y(points.last())))
            }
        }
        Row(Modifier.fillMaxWidth().padding(start = 40.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(startLabel, fontSize = 10.sp, color = sub)
            Text(endLabel, fontSize = 10.sp, color = sub)
        }
    }
}

@Composable
private fun TallyRow(t: Tally) {
    Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("${t.w} W", color = WIN, fontWeight = FontWeight.Bold)
        Text("${t.d} D", color = DRAW, fontWeight = FontWeight.Bold)
        Text("${t.l} L", color = LOSS, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun StatsScreen(vm: ChessViewModel) {
    BackHandler { vm.toHistory() }
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var confirmReset by remember { mutableStateOf(false) }
    val fmt = remember { SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()) }
    val games = PlayerStats.games.toList()
    val total = tallyOf(games)
    var range by remember { mutableIntStateOf(1) }
    val shown = when (range) { 0 -> games.takeLast(30); 1 -> games.takeLast(60); else -> games }
    val points = remember(games.size, PlayerStats.rating, range) {
        if (shown.isEmpty()) emptyList()
        else listOf(if (shown.size == games.size) START_RATING.roundToInt() else shown.first().before) + shown.map { it.after }
    }
    val dayFmt = remember { SimpleDateFormat("dd/MM/yy", Locale.getDefault()) }
    val whiteTally = tallyOf(games.filter { it.humanWhite })
    val blackTally = tallyOf(games.filter { !it.humanWhite })
    var curStreak = 0
    for (g in games.reversed()) { if (g.score == 1.0) curStreak++ else break }
    var bestStreak = 0; var run = 0
    for (g in games) { if (g.score == 1.0) { run++; if (run > bestStreak) bestStreak = run } else run = 0 }
    val netByBot = games.groupBy { it.botId }.mapValues { e -> e.value.sumOf { g -> g.after - g.before } }
    val perBot = games.groupBy { it.botId }.map { (id, list) ->
        Triple(id, list.last(), tallyOf(list))
    }.sortedByDescending { it.third.n }
    val cardColors = CardDefaults.cardColors(containerColor = cs.surfaceContainer)

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { ScreenTitle("Statistika sy Elo", onBack = { vm.toHistory() }) }
        item {
            Card(Modifier.fillMaxWidth(), colors = cardColors) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text("${PlayerStats.ratingInt}", fontSize = 44.sp, fontWeight = FontWeight.Bold, color = cs.primary)
                        Spacer(Modifier.width(10.dp))
                        Text("Elo ankehitriny\n(ambony indrindra ${PlayerStats.peakInt})", fontSize = 12.sp, color = cs.onSurfaceVariant)
                    }
                    TallyRow(total)
                    Text(
                        "Lalao ${total.n} - isan'ny fandresena ${total.winPct}%",
                        fontSize = 12.sp, color = cs.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(range == 0, { range = 0 }, { Text("30 farany", fontSize = 12.sp) })
                        FilterChip(range == 1, { range = 1 }, { Text("60 farany", fontSize = 12.sp) })
                        FilterChip(range == 2, { range = 2 }, { Text("Rehetra", fontSize = 12.sp) })
                    }
                    if (points.size >= 2) RatingGraph(
                        points,
                        if (shown.isNotEmpty()) dayFmt.format(Date(shown.first().time)) else "",
                        if (shown.isNotEmpty()) dayFmt.format(Date(shown.last().time)) else "",
                        Modifier.fillMaxWidth()
                    ) else Text("Milalaova lalao vitsivitsy hiseho ny curve.", fontSize = 12.sp, color = cs.onSurfaceVariant)
                    if (games.isNotEmpty()) {
                        Text(
                            "Fotsy: ${whiteTally.winPct}% (${whiteTally.n} lalao) - Mainty: ${blackTally.winPct}% (${blackTally.n} lalao)",
                            fontSize = 12.sp, color = cs.onSurfaceVariant
                        )
                        Text(
                            "Andalana fandresena: $curStreak (tsara indrindra $bestStreak)",
                            fontSize = 12.sp, color = cs.onSurfaceVariant
                        )
                    }
                    Text(
                        "Elo kajiana araka ny Elo an'ny bot (K 40 → 20). Voaisa ny lalao Play amin'ny bot ihany; tsy ao ny fifaninanana sy ny lalao olona-olona.",
                        fontSize = 11.sp, color = cs.onSurfaceVariant
                    )
                }
            }
        }
        if (perBot.isNotEmpty()) {
            item { Text("Isaky ny bot", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            items(perBot, key = { it.first }) { (id, last, t) ->
                val bot = BotRegistry.find(id)
                Card(Modifier.fillMaxWidth(), colors = cardColors) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (bot != null) BotAvatar(bot, 40.dp)
                        else Box(
                            Modifier.size(40.dp).clip(CircleShape).background(cs.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) { Text(last.botName.take(1), fontWeight = FontWeight.Bold) }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(last.botName, fontWeight = FontWeight.Bold)
                            val net = netByBot[id] ?: 0
                            Text(
                                "Elo ${last.botElo} - ${t.n} lalao - ${t.winPct}% - " + (if (net >= 0) "+" else "") + "$net Elo",
                                fontSize = 12.sp, color = if (net >= 0) WIN else LOSS
                            )
                        }
                        TallyRow(t)
                    }
                }
            }
        }
        if (games.isNotEmpty()) {
            item { Text("Lalao farany", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            items(games.takeLast(15).reversed(), key = { "g" + it.id }) { g ->
                val (txt, col) = when (g.score) {
                    1.0 -> "Nahazo" to WIN
                    0.5 -> "Draw" to DRAW
                    else -> "Resy" to LOSS
                }
                Card(Modifier.fillMaxWidth(), colors = cardColors) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("vs ${g.botName} (${g.botElo})", fontWeight = FontWeight.Bold)
                            Text(fmt.format(Date(g.time)) + " - ${g.plies} hetsika", fontSize = 12.sp, color = cs.onSurfaceVariant)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(txt, color = col, fontWeight = FontWeight.Bold)
                            val d = g.after - g.before
                            Text("${g.before} → ${g.after} (${if (d >= 0) "+" else ""}$d)", fontSize = 12.sp, color = cs.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        item {
            OutlinedButton({ confirmReset = true }, Modifier.fillMaxWidth(), enabled = games.isNotEmpty()) {
                Text("Averina ho foana ny statistika")
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Hafafana ny statistika?") },
            text = { Text("Hiverina ${START_RATING.roundToInt()} ny Elo ary hafafana ny tantaran'ny W/D/L. Tsy fafana ny lalao voatahiry.") },
            confirmButton = { Button({ AutoBackup.snapshot(ctx, "before-reset"); PlayerStats.reset(ctx); confirmReset = false }) { Text("Fafao") } },
            dismissButton = { TextButton({ confirmReset = false }) { Text("Foano") } }
        )
    }
}
