package mg.chess.offline

import android.content.Context
import kotlinx.coroutines.CancellationException
import com.github.bhlangonijr.chesslib.Board
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlin.math.exp
import kotlin.random.Random

/** Isan'ny line analyse: score (cp na mate) araka ny fijerin'ny mpilalao mihetsika, ary ny hetsika voalohany. */
data class Line(val cp: Int?, val mate: Int?, val move: String)

/** Sentinel apetraka ao anaty filaharana rehefa maty ny process Stockfish. */
private const val EOF_LINE = "\u0000EOF"
private const val POLL_MS = 200L
private const val START_TIMEOUT_MS = 15_000L
private const val STOP_TIMEOUT_MS = 2_000L
/** Raha tsy misy andalana avy amin'ny motera mandritra izao fotoana izao mandritra ny fikarohana = mihantona. */
private const val SEARCH_IDLE_TIMEOUT_MS = 15_000L

/**
 * Stockfish (UCI) amin'ny process: thread mamaky manokana + filaharana, ka misy timeout rehetra.
 * Raha mihantona na maty ny motera dia vonoina ary averina atomboka ho azy amin'ny antso manaraka.
 */
class Engine(
    private val ctx: Context,
    /** null = araka ny CPU; ho an'ny lalao miaraka (simulation) dia 1. */
    private val threadsOpt: Int? = null,
    private val hashMb: Int = 128
) {
    private var proc: Process? = null
    private var out: OutputStreamWriter? = null
    private var lines: LinkedBlockingQueue<String>? = null
    private val mutex = Mutex()

    private fun alive(p: Process?): Boolean =
        p != null && try { p.exitValue(); false } catch (e: IllegalThreadStateException) { true }

    private fun send(s: String) {
        try {
            out?.write(s + "\n")
            out?.flush()
        } catch (e: Exception) {
            killProc()
        }
    }

    /** Andalana manaraka (miandry ms fara-fahabetsany): null = tapitra ny fotoana, EOF_LINE = maty ny motera. */
    private fun nextLine(ms: Long): String? {
        val q = lines ?: return EOF_LINE
        return try { q.poll(ms, TimeUnit.MILLISECONDS) } catch (e: InterruptedException) { null }
    }

    private fun waitFor(token: String, ms: Long): Boolean {
        val end = System.currentTimeMillis() + ms
        while (true) {
            val left = end - System.currentTimeMillis()
            if (left <= 0) return false
            val l = nextLine(left) ?: return false
            if (l == EOF_LINE) return false
            if (l.startsWith(token)) return true
        }
    }

    private fun killProc() {
        try { out?.close() } catch (_: Exception) {}
        try { proc?.destroy() } catch (_: Exception) {}
        proc = null; out = null; lines = null
    }

    private fun ensureStarted(): Boolean {
        if (alive(proc) && lines != null) return true
        killProc()
        val f = File(ctx.applicationInfo.nativeLibraryDir, "libstockfish.so")
        if (!f.exists()) return false
        return try {
            val p = ProcessBuilder(f.absolutePath).redirectErrorStream(true).start()
            val q = LinkedBlockingQueue<String>()
            proc = p
            out = OutputStreamWriter(p.outputStream)
            lines = q
            val rd = BufferedReader(InputStreamReader(p.inputStream))
            thread(isDaemon = true, name = "kajy-sf-reader") {
                try {
                    while (true) {
                        val l = rd.readLine() ?: break
                        q.put(l)
                    }
                } catch (_: Exception) {}
                q.put(EOF_LINE)
            }
            send("uci")
            if (!waitFor("uciok", START_TIMEOUT_MS)) { killProc(); return false }
            val threads = threadsOpt ?: (Runtime.getRuntime().availableProcessors() / 2).coerceIn(1, 4)
            send("setoption name Threads value $threads")
            send("setoption name Hash value $hashMb")
            send("isready")
            if (!waitFor("readyok", START_TIMEOUT_MS)) { killProc(); return false }
            true
        } catch (e: Exception) {
            killProc()
            false
        }
    }

    /** Alefaso ny fikarohana ary miandry "bestmove". Raha mihantona dia vonoina ny motera (miverina null). */
    private suspend fun search(go: String, onInfo: (String) -> Unit): String? = withContext(Dispatchers.IO) {
        send(go)
        var result: String? = null
        var idle = 0L
        try {
            while (true) {
                val l = nextLine(POLL_MS)
                ensureActive()
                if (l == null) {
                    idle += POLL_MS
                    if (idle >= SEARCH_IDLE_TIMEOUT_MS) { killProc(); break }
                    continue
                }
                idle = 0L
                if (l == EOF_LINE) { killProc(); break }
                if (l.startsWith("bestmove")) {
                    val m = l.split(" ").getOrNull(1)
                    result = if (m == null || m == "(none)") null else m
                    break
                }
                onInfo(l)
            }
        } catch (e: CancellationException) {
            // Sakanana ny fikarohana: "stop", ary miandry bestmove (na vonoina raha tsy tonga)
            send("stop")
            if (!waitFor("bestmove", STOP_TIMEOUT_MS)) killProc()
            throw e
        }
        result
    }

    fun newGame() {
        if (alive(proc)) send("ucinewgame")
    }

    /**
     * Hetsika ho an'ny bot araka ny Elo tena izy + personalité.
     * 1) Opening book (repertoire / andalana avy amin'ny lalao) raha mifanaraka ny tantara.
     * 2) 1320..3190 : Stockfish 19 UCI_LimitStrength + UCI_Elo; > 3190 : hery feno;
     *    < 1320 : fikarohana voafetra + safidy hetsika araka ny "temperature".
     * 3) Raha misy fomba filalaovana (style): MultiPV, ary safidiana araka ny fomba ny hetsika mitovy lanja
     *    (tsy mihoatra ny tolérance centipawn araka ny Elo), ka tsy simba ny Elo.
     */
    suspend fun bestMove(fen: String, bot: Bot, history: List<String> = emptyList()): String? = mutex.withLock {
        try {
            val pre = Board()
            pre.loadFromFen(fen)
            val legalSet = pre.legalMoves().map { it.toString().lowercase() }.toSet()
            val book = Personality.bookMove(bot, history, legalSet)
            if (book != null) {
                delay(250)
                return@withLock book
            }
            val elo = bot.elo + ELO_CALIB
            val weak = elo < SF_MIN_ELO
            val styled = !bot.style.neutral
            val ok = withContext(Dispatchers.IO) {
                if (ensureStarted()) {
                    val mpv = if (weak) 8 else if (styled) 5 else 1
                    if (elo in SF_MIN_ELO..SF_MAX_ELO) {
                        send("setoption name UCI_LimitStrength value true")
                        send("setoption name UCI_Elo value $elo")
                    } else {
                        send("setoption name UCI_LimitStrength value false")
                    }
                    send("setoption name MultiPV value $mpv")
                    send("position fen $fen")
                    true
                } else false
            }
            if (!ok) null
            else if (weak) {
                val nodes = (30.0 * Math.pow(elo.coerceAtLeast(100) / 100.0, 1.7)).toLong().coerceAtLeast(150L)
                val lines = HashMap<Int, Line>()
                val best = search("go nodes $nodes") { l ->
                    val p = parseInfo(l)
                    if (p != null) lines[p.first] = p.second
                }
                pickWeak(lines.toSortedMap().values.toList(), elo, best, pre, bot, history.size)
            } else if (styled) {
                val lines = HashMap<Int, Line>()
                val best = search("go movetime ${bot.movetimeMs}") { l ->
                    val p = parseInfo(l)
                    if (p != null) lines[p.first] = p.second
                }
                pickStyled(lines.toSortedMap().values.toList(), best, elo, pre, bot, history.size)
            } else {
                search("go movetime ${bot.movetimeMs}") { }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }

    private fun featOf(pre: Board, uci: String, ply: Int): MoveFeat? {
        val mv = pre.legalMoves().firstOrNull { it.toString().equals(uci, true) } ?: return null
        return Personality.feat(pre, mv, ply)
    }

    private fun roulette(items: List<String>, ws: List<Double>): String? {
        val sum = ws.sum()
        if (sum <= 0.0) return null
        var r = Random.nextDouble() * sum
        for ((i, w) in ws.withIndex()) {
            r -= w
            if (r <= 0.0) return items[i]
        }
        return items.last()
    }

    private fun pickStyled(lines: List<Line>, best: String?, elo: Int, pre: Board, bot: Bot, ply: Int): String? {
        val ls = lines.filter { it.move.isNotEmpty() }
        if (ls.isEmpty()) return best
        val cps = ls.map { it.stmCp().coerceIn(-1500, 1500) }
        val top = cps.max()
        val scale = Personality.toleranceScale(pre)
        val baseTol = (25.0 + (3200 - elo).coerceIn(0, 2800) / 25.0) * scale
        val sacTol = Personality.sacTolerance(bot.style) * scale
        val ws = ls.mapIndexed { i, l ->
            val f = featOf(pre, l.move, ply)
            val tol = baseTol + (if (f != null && f.sacrifice) sacTol else 0.0)
            if (top - cps[i] > tol) 0.0
            else {
                val sw = if (f != null) Personality.styleWeight(f, bot.style) else 1.0
                sw * (if (l.move.equals(best, true)) 2.0 else 1.0)
            }
        }
        return roulette(ls.map { it.move }, ws) ?: best ?: ls.first().move
    }

    private fun pickWeak(lines: List<Line>, elo: Int, fallback: String?, pre: Board, bot: Bot, ply: Int): String? {
        val ls = lines.filter { it.move.isNotEmpty() }
        if (ls.isEmpty()) return fallback
        val deficit = (SF_MIN_ELO - elo).coerceIn(0, 1220)
        val cps = ls.map { it.stmCp().coerceIn(-1500, 1500) }
        val top = cps.max()
        val temp = 15.0 + deficit * 0.22
        val pRandom = (deficit / 1220.0).let { it * it * 0.30 }
        if (Random.nextDouble() < pRandom) return ls.random().move
        val styled = !bot.style.neutral
        val ws = cps.mapIndexed { i, cp ->
            var w = exp((cp - top) / temp)
            if (styled) {
                val f = featOf(pre, ls[i].move, ply)
                if (f != null) w *= Personality.styleWeight(f, bot.style)
            }
            w
        }
        return roulette(ls.map { it.move }, ws) ?: ls.first().move
    }

    /** Analyse feno hery (tsy voafetra) miaraka amin'ny MultiPV, mijanona amin'ny depth na fotoana farany. */
    suspend fun analyze(fen: String, depth: Int, maxMs: Int, multiPv: Int = 2): List<Line> = mutex.withLock {
        try {
            val ok = withContext(Dispatchers.IO) {
                if (ensureStarted()) {
                    send("setoption name UCI_LimitStrength value false")
                    send("setoption name MultiPV value $multiPv")
                    send("position fen $fen")
                    true
                } else false
            }
            if (!ok) emptyList()
            else {
                val lines = HashMap<Int, Line>()
                search("go depth $depth movetime $maxMs") { l ->
                    val p = parseInfo(l)
                    if (p != null) lines[p.first] = p.second
                }
                lines.toSortedMap().values.toList()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun parseInfo(l: String): Pair<Int, Line>? {
        if (!l.startsWith("info") || " score " !in l || " pv " !in l) return null
        if (" lowerbound" in l || " upperbound" in l) return null
        val t = l.split(" ")
        val mi = t.indexOf("multipv")
        val mpv = if (mi >= 0) (t.getOrNull(mi + 1)?.toIntOrNull() ?: 1) else 1
        val si = t.indexOf("score")
        val kind = t.getOrNull(si + 1) ?: return null
        val v = t.getOrNull(si + 2)?.toIntOrNull() ?: return null
        val pi = t.indexOf("pv")
        val mv = t.getOrNull(pi + 1) ?: return null
        return mpv to Line(if (kind == "cp") v else null, if (kind == "mate") v else null, mv)
    }

    fun stop() {
        send("quit")
        killProc()
    }
}
