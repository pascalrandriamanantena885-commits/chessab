package mg.chess.offline

import android.os.SystemClock
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.Side
import kotlinx.coroutines.delay
import kotlin.math.max

private fun clockLabel(baseMs: Long, incMs: Long) =
    if (baseMs <= 0) "Tsy misy ora" else "${baseMs / 60000}+${incMs / 1000}"

// ---------------- LISITRA ----------------

@Composable
fun TourListScreen(vm: ChessViewModel) {
    BackHandler { vm.toMenu() }
    vm.tourVersion
    var deleting by remember { mutableStateOf<Tournament?>(null) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("🏆 Fifaninanana", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.padding(4.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ vm.toTourNew() }, Modifier.weight(1f)) { Text("+ Fifaninanana vaovao") }
            OutlinedButton({ vm.toArchive() }) { Text("🏅 Archive") }
        }
        if (vm.tournaments.isEmpty()) Text("Mbola tsy misy fifaninanana.", Modifier.padding(top = 16.dp))
        LazyColumn(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.tournaments, key = { it.id }) { t ->
                Card(Modifier.fillMaxWidth().clickable { vm.openTour(t) }) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(t.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            val champ = t.player(t.champion)
                            Text(
                                if (champ != null) "🥇 ${champ.name}" + (t.podium()?.second?.let { s -> "   🥈 ${t.name(s)}" } ?: "")
                                else stageLabel(t.stage),
                                fontSize = 13.sp
                            )
                            Text("${t.players.size} mpilalao - ${clockLabel(t.baseMs, t.incMs)}", fontSize = 12.sp)
                        }
                        OutlinedButton({ deleting = t }) { Text("Fafao") }
                    }
                }
            }
        }
    }
    val d = deleting
    if (d != null) {
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Fafana ny \"${d.name}\"?") },
            confirmButton = { Button({ vm.deleteTour(d); deleting = null }) { Text("Fafao") } },
            dismissButton = { TextButton({ deleting = null }) { Text("Foano") } }
        )
    }
}

// ---------------- FIFANINANANA VAOVAO ----------------

private val BASE_OPTIONS = listOf(0, 1, 2, 3, 5, 10, 15, 20, 30, 45, 60, 90)
private val INC_OPTIONS = listOf(0, 1, 2, 3, 5, 10, 15, 30)

@Composable
fun TourNewScreen(vm: ChessViewModel) {
    BackHandler { vm.toTourList() }
    val bots = BotRegistry.visible
    var name by remember { mutableStateOf("Fifaninanana ${vm.tournaments.size + 1}") }
    val picked = remember {
        mutableStateListOf<String>().also { l -> l.addAll(BotRegistry.visible.take(32).map { it.id }) }
    }
    val humans = remember { mutableStateListOf<String>() }
    var humanInput by remember { mutableStateOf("") }
    var wantGroups by remember { mutableStateOf(false) }
    var swiss by remember { mutableStateOf(false) }
    var dbl by remember { mutableStateOf(false) }
    var baseMin by remember { mutableIntStateOf(5) }
    var incSec by remember { mutableIntStateOf(0) }

    val n = picked.size + humans.size
    val forced = n > 16
    val canGroups = n >= 3
    val canSwiss = n in 4..16
    val dblOn = dbl && canSwiss
    val swissOn = swiss && canSwiss && !dblOn
    val groupsOn = !swissOn && !dblOn && (forced || (wantGroups && canGroups))
    val valid = (if (swissOn || dblOn) n in 4..16 else n in 2..32) && name.isNotBlank()

    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("Fifaninanana vaovao", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        item {
            OutlinedTextField(
                name, { name = it.take(30) }, label = { Text("Anaran'ny fifaninanana") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Bot (${picked.size})", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton({ picked.clear(); picked.addAll(bots.take(32).map { it.id }) }) { Text("Daholo") }
                TextButton({ picked.clear() }) { Text("Tsy misy") }
            }
        }
        items(bots, key = { it.id }) { b ->
            val on = b.id in picked
            val toggle = {
                if (on) picked.remove(b.id) else if (n < 32) picked.add(b.id)
                Unit
            }
            Row(Modifier.fillMaxWidth().clickable { toggle() }, verticalAlignment = Alignment.CenterVertically) {
                Checkbox(on, { toggle() })
                BotAvatar(b, 32.dp)
                Spacer(Modifier.width(8.dp))
                Text(b.name, Modifier.weight(1f))
                Text("Elo ~${b.elo}", fontSize = 12.sp)
            }
        }
        item { Text("Olona (${humans.size})", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    humanInput, { humanInput = it.take(20) }, label = { Text("Anaran'ny olona") },
                    singleLine = true, modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                Button({
                    val nm = humanInput.trim()
                    if (nm.isNotEmpty() && nm !in humans && n < 32) { humans.add(nm); humanInput = "" }
                }) { Text("Ampio") }
            }
        }
        items(humans.toList(), key = { it }) { h ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("👤 $h", Modifier.weight(1f))
                TextButton({ humans.remove(h) }) { Text("Esory") }
            }
        }
        item { Text("Format", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(swissOn, { swiss = it; if (it) dbl = false }, enabled = canSwiss)
                Spacer(Modifier.width(8.dp))
                Text("Swiss (mpilalao 4-16)", Modifier.weight(1f))
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(dblOn, { dbl = it; if (it) swiss = false }, enabled = canSwiss)
                Spacer(Modifier.width(8.dp))
                Text("Double elimination (mpilalao 4-16)", Modifier.weight(1f))
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(groupsOn, { wantGroups = it }, enabled = canGroups && !forced && !swissOn && !dblOn)
                Spacer(Modifier.width(8.dp))
                Text("Phase de poule aloha", Modifier.weight(1f))
            }
        }
        item { Text(if (dblOn) describeDouble(n) else if (swissOn) describeSwiss(n) else describeFormat(n, groupsOn), fontSize = 13.sp) }
        item { Text("Ora iombonana (lalao rehetra)", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                Text("Minitra: ")
                for (v in BASE_OPTIONS) {
                    FilterChip(baseMin == v, { baseMin = v }, { Text(if (v == 0) "Tsy misy" else "$v") })
                    Spacer(Modifier.width(6.dp))
                }
            }
        }
        if (baseMin > 0) {
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                    Text("Increment (s): ")
                    for (v in INC_OPTIONS) {
                        FilterChip(incSec == v, { incSec = v }, { Text("$v") })
                        Spacer(Modifier.width(6.dp))
                    }
                }
            }
        }
        item { Text("Ora: " + clockLabel(baseMin * 60_000L, incSec * 1000L), fontSize = 13.sp) }
        item {
            Button({
                val players = ArrayList<Participant>()
                for (b in bots) if (b.id in picked) players.add(Participant("b_" + b.id, b.name, b.elo, b))
                humans.forEachIndexed { i, h -> players.add(Participant("h$i", h, 1000, null)) }
                vm.createTour(name.trim(), players, baseMin * 60_000L, if (baseMin > 0) incSec * 1000L else 0L, wantGroups, swissOn, dblOn)
            }, Modifier.fillMaxWidth(), enabled = valid) { Text("Hamorona ny fifaninanana ($n mpilalao)") }
        }
    }
}

// ---------------- FIFANINANANA ----------------

@Composable
private fun PartLabel(p: Participant?, white: Boolean, modifier: Modifier, end: Boolean = false) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = if (end) Arrangement.End else Arrangement.Start) {
        if (!end && p?.bot != null) { BotAvatar(p.bot, 28.dp); Spacer(Modifier.width(6.dp)) }
        Text(
            (if (white) "⚪ " else "⚫ ") + (p?.name ?: "—"),
            maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold,
            textAlign = if (end) TextAlign.End else TextAlign.Start
        )
        if (end && p?.bot != null) { Spacer(Modifier.width(6.dp)); BotAvatar(p.bot, 28.dp) }
    }
}

@Composable
fun MatchCard(vm: ChessViewModel, t: Tournament, m: TMatch) {
    val wp = t.player(m.whiteId)
    val bp = t.player(m.blackId)
    val botMatch = vm.isBotMatch(m)
    val running = vm.isSimRunning(m.id)
    val waiting = vm.isSimWaiting(m.id)
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            val tag = when {
                m.stage == "G" -> groupName(m.group)
                m.stage.startsWith("D") -> matchStageLabel(m)
                m.game > 0 -> "Lalao fanampiny ${m.game} (draw teo aloha)"
                else -> ""
            }
            if (tag.isNotEmpty()) Text(tag, fontSize = 12.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                PartLabel(wp, true, Modifier.weight(1f))
                Text(m.result ?: "vs", fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp))
                PartLabel(bp, false, Modifier.weight(1f), end = true)
            }
            if (m.result == "bye") {
                Text("${t.name(m.winner)} dia miakatra mivantana (bye)", fontSize = 12.sp)
            }
            if (m.result != null && m.result != "bye" && m.moves.isNotEmpty()) {
                OutlinedButton({ vm.reviewTourMatch(m) }) { Text("Review") }
            }
            if (m.result == null && botMatch) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button({ vm.simOne(m, true) }) { Text("Jereo live") }
                    when {
                        running -> Text("Mandeha...", fontSize = 12.sp)
                        waiting -> Text("Miandry toerana...", fontSize = 12.sp)
                        else -> OutlinedButton({ vm.simOne(m, false) }) { Text("Simule") }
                    }
                }
            }
            if (m.result == null && !botMatch) {
                Button({ vm.playTourMatch(m) }) { Text(if (m.moves.isEmpty()) "Lalao" else "Tohizo") }
            }
        }
    }
}

private fun fmtPts(p: Double): String = if (p % 1.0 == 0.0) "${p.toInt()}" else "$p"

@Composable
fun TournamentScreen(vm: ChessViewModel) {
    BackHandler { vm.toTourList() }
    vm.tourVersion
    val t = vm.tour
    if (t == null) {
        LaunchedEffect(Unit) { vm.toTourList() }
        return
    }
    var tab by remember { mutableIntStateOf(0) }
    val champ = t.player(t.champion)
    val ms = t.stageMatches()
    val pendingBots = ms.filter { it.result == null && vm.isBotMatch(it) }
    val humanPending = ms.any { it.result == null && !vm.isBotMatch(it) }

    Column(Modifier.fillMaxSize().padding(10.dp)) {
        Text(t.name, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(
            (if (champ != null) "Vita" else stageLabel(t.stage)) + " - ${t.players.size} mpilalao - " + clockLabel(t.baseMs, t.incMs),
            fontSize = 13.sp
        )
        if (champ != null) PodiumCard(t)
        ExportButtons(t)
        Row(Modifier.padding(vertical = 6.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(tab == 0, { tab = 0 }, { Text("Round") })
            if (t.groups.isNotEmpty() || t.isSwiss) FilterChip(tab == 1, { tab = 1 }, { Text(if (t.isSwiss) "Tabilao" else "Poule") })
            FilterChip(tab == 2, { tab = 2 }, { Text("Rehetra") })
            if (!t.isSwiss) FilterChip(tab == 3, { tab = 3 }, { Text("Schema") })
            FilterChip(tab == 4, { tab = 4 }, { Text("Classement") })
        }
        if (vm.tourMsg.isNotEmpty()) Text(vm.tourMsg, color = androidx.compose.material3.MaterialTheme.colorScheme.error)

        when (if ((tab == 1 && t.groups.isEmpty() && !t.isSwiss) || (tab == 3 && t.isSwiss)) 0 else tab) {
            3 -> TourSchemaTab(vm, t, Modifier.weight(1f))
            4 -> TourLeadersTab(vm, t, Modifier.weight(1f))
            0 -> LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (t.champion == null) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Button(
                                    { vm.simAllPending() }, Modifier.weight(1f),
                                    enabled = pendingBots.isNotEmpty() && !vm.autoMode,
                                    contentPadding = PaddingValues(6.dp)
                                ) { Text("Simule ny bot (round)", fontSize = 13.sp) }
                                if (vm.autoMode || vm.simRunningIds.isNotEmpty() || vm.simWaitingIds.isNotEmpty()) {
                                    OutlinedButton({ vm.stopSim() }, Modifier.weight(1f), contentPadding = PaddingValues(6.dp)) {
                                        Text("Ajanony", fontSize = 13.sp)
                                    }
                                } else {
                                    Button({ vm.runAuto() }, Modifier.weight(1f), contentPadding = PaddingValues(6.dp)) {
                                        Text("Auto hatramin'ny farany", fontSize = 13.sp)
                                    }
                                }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Lalao miaraka:", fontSize = 12.sp)
                                for (n in 1..4) FilterChip(vm.simParallel == n, { vm.chooseSimParallel(n) }, { Text("$n") })
                            }
                            if (t.stageComplete()) {
                                Button({ vm.advanceTour() }, Modifier.fillMaxWidth()) { Text("Round manaraka ▶") }
                            }
                            if (humanPending) Text("Misy lalao ho an'olona: tsindrio ny \"Lalao\".", fontSize = 12.sp)
                        }
                    }
                }
                items(ms, key = { it.id }) { m -> MatchCard(vm, t, m) }
            }
            1 -> if (t.isSwiss) SwissTab(t, Modifier.weight(1f)) else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(t.groups.size) { g ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(groupName(g), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Row {
                                Text("#", Modifier.width(24.dp), fontSize = 12.sp)
                                Text("Mpilalao", Modifier.weight(1f), fontSize = 12.sp)
                                for (h in listOf("J", "V", "N", "D")) Text(h, Modifier.width(26.dp), fontSize = 12.sp)
                                Text("Pts", Modifier.width(34.dp), fontSize = 12.sp)
                            }
                            t.standings(g).forEachIndexed { i, r ->
                                val w = if (i < 2) FontWeight.Bold else FontWeight.Normal
                                Row {
                                    Text("${i + 1}", Modifier.width(24.dp), fontWeight = w)
                                    Text(t.name(r.id), Modifier.weight(1f), fontWeight = w, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${r.played}", Modifier.width(26.dp))
                                    Text("${r.w}", Modifier.width(26.dp))
                                    Text("${r.d}", Modifier.width(26.dp))
                                    Text("${r.l}", Modifier.width(26.dp))
                                    Text(fmtPts(r.pts), Modifier.width(34.dp), fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
            else -> {
                val entries = ArrayList<Any>()
                var lastKey = ""
                for (m in t.matches) {
                    val key = matchStageLabel(m)
                    if (key != lastKey) { entries.add(key); lastKey = key }
                    entries.add(m)
                }
                LazyColumn(Modifier.weight(1f)) {
                    items(entries) { e ->
                        if (e is String) {
                            Text(e, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))
                        } else {
                            val mm = e as TMatch
                            val ok = mm.result != null && mm.result != "bye" && mm.moves.isNotEmpty()
                            Row(
                                Modifier.fillMaxWidth().clickable(enabled = ok) { vm.reviewTourMatch(mm) }.padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(t.name(mm.whiteId), Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(mm.result ?: "-", fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp))
                                Text(t.name(mm.blackId), Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.End)
                                if (ok) Text("  ▶")
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------- LIVE ----------------

private fun liveMs(st: SimState, white: Boolean, now: Long): Long {
    val base = if (white) st.whiteMs else st.blackMs
    return if (st.thinkStart != 0L && st.thinkingWhite == white) max(0L, base - (now - st.thinkStart)) else base
}

@Composable
private fun LiveBar(p: Participant?, side: Side, st: SimState?, clockOn: Boolean, now: Long) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        if (p?.bot != null) { BotAvatar(p.bot, 36.dp); Spacer(Modifier.width(8.dp)) }
        Column {
            Text(p?.name ?: "—", fontWeight = FontWeight.Bold)
            if (p?.bot != null) Text("Elo ~${p.bot.elo}", fontSize = 12.sp)
        }
        Spacer(Modifier.weight(1f))
        if (clockOn && st != null) {
            ClockBox(liveMs(st, side == Side.WHITE, now), st.result == null && st.board.sideToMove == side)
        }
    }
}

@Composable
fun WatchScreen(vm: ChessViewModel) {
    BackHandler { vm.leaveWatch() }
    vm.tourVersion
    val t = vm.tour
    val m = t?.matches?.firstOrNull { it.id == vm.watchId }
    if (t == null || m == null) {
        Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            Text("Tsy hita ny lalao.")
            Button({ vm.leaveWatch() }) { Text("Miverina") }
        }
        return
    }
    var now by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(Unit) {
        while (true) { delay(100); now = SystemClock.elapsedRealtime() }
    }
    val wp = t.player(m.whiteId)
    val bp = t.player(m.blackId)
    val st = vm.sims[m.id]
    val clockOn = t.baseMs > 0

    Column(Modifier.fillMaxSize().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            matchStageLabel(m),
            fontSize = 14.sp, fontWeight = FontWeight.Bold
        )
        if (st == null) {
            Spacer(Modifier.padding(16.dp))
            Text(
                if (m.result != null) "Vita ity lalao ity: ${m.result}" else "Miandry toerana (efa feno ny lalao miaraka)... Tsindrio \"Jereo live\" indray raha hanery ny fanombohana.",
                fontSize = 16.sp
            )
            Spacer(Modifier.padding(8.dp))
            if (m.result != null && m.moves.isNotEmpty()) Button({ vm.reviewTourMatch(m) }) { Text("Review") }
        } else {
            val ver = st.version
            LiveBar(bp, Side.BLACK, st, clockOn, now)
            BoardView(
                pieceAt = { sq -> if (ver >= 0) st.board.getPiece(sq) else Piece.NONE },
                flip = false, last = st.last
            )
            LiveBar(wp, Side.WHITE, st, clockOn, now)
            val res = st.result
            Text(
                when {
                    res != null -> "Vita: $res"
                    else -> "Hetsika ${st.plies} - " + (if (st.board.sideToMove == Side.WHITE) "Fotsy" else "Mainty") + " no mihetsika"
                },
                fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.padding(vertical = 6.dp)
            )
            CommentaryBar(vm)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Hafainganam-pandehana: ", fontSize = 12.sp)
                FilterChip(vm.watchDelay == 120L, { vm.watchDelay = 120L }, { Text("Haingana") })
                FilterChip(vm.watchDelay == 600L, { vm.watchDelay = 600L }, { Text("Antonony") })
                FilterChip(vm.watchDelay == 1500L, { vm.watchDelay = 1500L }, { Text("Miadana") })
            }
            Spacer(Modifier.padding(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (res != null && m.moves.isNotEmpty()) Button({ vm.reviewTourMatch(m) }) { Text("Review") }
                OutlinedButton({ vm.leaveWatch() }) { Text("Fifaninanana") }
            }
        }
    }
}
