# Chess Offline
Kotlin + Compose, chesslib, Stockfish (UCI, NDK). Push amin'ny GitHub -> Actions -> Artifacts -> APK.
Stockfish: GPLv3 -> ampiasao ho open source ny app.
