# Chess Offline
Kotlin + Compose, chesslib, Stockfish (UCI, NDK). Push amin'ny GitHub -> Actions -> Artifacts -> APK.
Stockfish: GPLv3 -> ampiasao ho open source ny app.

## Sprites
Pieces + board tiles: "Cburnett Chess set" (JohnPablok remaster v2), ao amin'ny app/src/main/assets/.
Credit: Colin M.L. Burnett (Cburnett) / JohnPablok - GPLv2+ / CC BY-SA 3.0.
Avatar bot: apetaho ao amin'ny app/src/main/assets/bots/<id>.png (ravao, rakoto, soa, ...). Raha tsy misy dia fallback no miseho.

## Fiasa vaovao
- Settings: theme (Light/Dark) mahaleo tena (tsy manaraka ny findainao), fampidirana / fanovana / famafana bot (anarana, sary, Elo).
- Fifaninanana: bot vs bot, olona + bot; poule (raha >16 mpilalao na safidy) avy eo 8ème de finale -> finale; ora iombonana; live; review.
