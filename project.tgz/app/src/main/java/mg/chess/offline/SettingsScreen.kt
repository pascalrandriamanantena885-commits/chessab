package mg.chess.offline

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(vm: ChessViewModel) {
    BackHandler { vm.toMenu() }
    val ctx = LocalContext.current
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Bot?>(null) }
    var deleting by remember { mutableStateOf<Bot?>(null) }
    val all = BotRegistry.visible

    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("Settings", fontSize = 26.sp, fontWeight = FontWeight.Bold) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Endrika (theme)", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    FilterChip(!vm.darkMode, { vm.setDark(false) }, { Text("Mazava (Light)") })
                    Spacer(Modifier.width(8.dp))
                    FilterChip(vm.darkMode, { vm.setDark(true) }, { Text("Maizina (Dark)") })
                }
                Text("Tsy manaraka ny theme an'ny findainao ny app: ity safidy ity ihany no manapaka.", fontSize = 12.sp)
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Bot (${all.size})", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Button({ adding = true }) { Text("+ Bot vaovao") }
            }
        }
        items(all, key = { it.id }) { b ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    BotAvatar(b, 44.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(b.name, fontWeight = FontWeight.Bold)
                        Text("Elo ~${b.elo}" + if (b.custom) " - nataonao" else "", fontSize = 12.sp)
                    }
                    if (b.custom) {
                        TextButton({ editing = b }) { Text("Ovay") }
                    }
                    OutlinedButton({ deleting = b }) { Text("Fafao") }
                }
            }
        }
        if (BotRegistry.hidden.isNotEmpty()) {
            item {
                OutlinedButton({ BotRegistry.restoreDefaults(ctx) }, Modifier.fillMaxWidth()) {
                    Text("Averina ny bot default voafafa (${BotRegistry.hidden.size})")
                }
            }
        }
    }

    if (adding) BotEditDialog(null) { adding = false }
    val ed = editing
    if (ed != null) BotEditDialog(ed) { editing = null }
    val del = deleting
    if (del != null) {
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Fafana ny ${del.name}?") },
            text = { Text("Tsy fafana ny lalao efa voatahiry sy ny fifaninanana efa nisy azy, fa tsy ho hita intsony ao amin'ny lisitra.") },
            confirmButton = { Button({ BotRegistry.delete(ctx, del); deleting = null }) { Text("Fafao") } },
            dismissButton = { TextButton({ deleting = null }) { Text("Foano") } }
        )
    }
}

@Composable
fun BotEditDialog(existing: Bot?, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var eloText by remember { mutableStateOf((existing?.elo ?: 1200).toString()) }
    var avatar by remember { mutableStateOf<Bitmap?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) avatar = decodeAvatar(ctx, uri)
    }
    val elo = eloText.toIntOrNull()
    val valid = name.isNotBlank() && elo != null && elo in 100..3200
    val av = avatar

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Bot vaovao" else "Ovay ny bot") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (av != null) {
                        Image(av.asImageBitmap(), null, Modifier.size(64.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                    } else if (existing != null) {
                        BotAvatar(existing, 64.dp)
                    } else {
                        Box(Modifier.size(64.dp).clip(CircleShape).background(Color(0xFF90A4AE)), contentAlignment = Alignment.Center) {
                            Text("?", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    OutlinedButton({ picker.launch("image/*") }) { Text("Fidio sary") }
                }
                OutlinedTextField(
                    name, { name = it.take(20) }, label = { Text("Anarana") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    eloText, { eloText = it.filter { c -> c.isDigit() }.take(4) },
                    label = { Text("Elo (100-3200)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Ny hery dia kajiana araka ny Elo (Stockfish Skill Level + fotoana fisainana).", fontSize = 12.sp)
            }
        },
        confirmButton = {
            Button(
                onClick = { BotRegistry.save(ctx, existing, name, elo ?: 1200, avatar); onDismiss() },
                enabled = valid
            ) { Text("Tehirizo") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Foano") } }
    )
}
