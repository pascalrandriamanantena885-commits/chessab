package mg.chess.offline

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {
    private val vm: ChessViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Sprites.init(this)
        setContent {
            MaterialTheme(colorScheme = if (vm.darkMode) DarkScheme else LightScheme) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    when (vm.screen) {
                        Screen.MENU -> MenuScreen(vm)
                        Screen.BOTS -> BotsScreen(vm)
                        Screen.GAME -> GameScreen(vm)
                        Screen.REVIEW -> ReviewScreen(vm)
                        Screen.HISTORY -> HistoryScreen(vm)
                        Screen.SETTINGS -> SettingsScreen(vm)
                        Screen.TOUR_LIST -> TourListScreen(vm)
                        Screen.TOUR_NEW -> TourNewScreen(vm)
                        Screen.TOURNAMENT -> TournamentScreen(vm)
                        Screen.WATCH -> WatchScreen(vm)
                    }
                }
            }
        }
    }

    override fun onStart() { super.onStart(); vm.setPaused(false) }

    override fun onStop() {
        vm.setPaused(true)
        vm.saveGame()
        super.onStop()
    }
}
