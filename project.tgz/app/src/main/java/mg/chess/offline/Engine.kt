package mg.chess.offline

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter

/** Stockfish UCI wrapper. Ny binary dia libstockfish.so ao amin'ny nativeLibraryDir. */
class Engine(private val ctx: Context) {
    private var proc: Process? = null
    private var out: OutputStreamWriter? = null
    private var inp: BufferedReader? = null

    private fun send(s: String) { out?.write(s + "\n"); out?.flush() }

    private fun waitFor(token: String) {
        while (true) {
            val l = inp?.readLine() ?: return
            if (l.startsWith(token)) return
        }
    }

    private fun ensureStarted(): Boolean {
        if (proc?.isAlive == true) return true
        val f = File(ctx.applicationInfo.nativeLibraryDir, "libstockfish.so")
        if (!f.exists()) return false
        proc = ProcessBuilder(f.absolutePath).redirectErrorStream(true).start()
        out = OutputStreamWriter(proc!!.outputStream)
        inp = BufferedReader(InputStreamReader(proc!!.inputStream))
        send("uci"); waitFor("uciok")
        send("isready"); waitFor("readyok")
        return true
    }

    suspend fun bestMove(fen: String, skill: Int, movetimeMs: Int): String? =
        withContext(Dispatchers.IO) {
            try {
                if (!ensureStarted()) return@withContext null
                send("setoption name Skill Level value $skill")
                send("position fen $fen")
                send("go movetime $movetimeMs")
                while (true) {
                    val l = inp?.readLine() ?: return@withContext null
                    if (l.startsWith("bestmove")) {
                        val m = l.split(" ").getOrNull(1)
                        return@withContext if (m == null || m == "(none)") null else m
                    }
                }
                @Suppress("UNREACHABLE_CODE") null
            } catch (e: Exception) { null }
        }

    fun stop() { try { send("quit") } catch (_: Exception) {}; proc?.destroy(); proc = null }
}
