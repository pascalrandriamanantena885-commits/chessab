package mg.chess.offline

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter

/** Isan'ny line analyse: score (cp na mate) araka ny fijerin'ny mpilalao mihetsika, ary ny hetsika voalohany. */
data class Line(val cp: Int?, val mate: Int?, val move: String)

class Engine(private val ctx: Context) {
    private var proc: Process? = null
    private var out: OutputStreamWriter? = null
    private var inp: BufferedReader? = null
    private val mutex = Mutex()

    private fun send(s: String) { out?.write(s + "\n"); out?.flush() }

    private fun waitFor(token: String) {
        while (true) {
            val l = inp?.readLine() ?: return
            if (l.startsWith(token)) return
        }
    }

    private fun ensureStarted(): Boolean {
        if (proc?.isAlive == true) return true
        val f = File(ctx.applicationInfo.nativeLibraryDir, "libstockfish.so")
        if (!f.exists()) return false
        proc = ProcessBuilder(f.absolutePath).redirectErrorStream(true).start()
        out = OutputStreamWriter(proc!!.outputStream)
        inp = BufferedReader(InputStreamReader(proc!!.inputStream))
        send("uci"); waitFor("uciok")
        send("isready"); waitFor("readyok")
        return true
    }

    private suspend fun search(go: String, onInfo: (String) -> Unit): String? = withContext(Dispatchers.IO) {
        send(go)
        var result: String? = null
        try {
            var done = false
            while (!done) {
                val l = inp?.readLine()
                if (l == null) {
                    done = true
                } else if (l.startsWith("bestmove")) {
                    val m = l.split(" ").getOrNull(1)
                    result = if (m == null || m == "(none)") null else m
                    done = true
                } else {
                    onInfo(l)
                    ensureActive()
                }
            }
        } catch (e: CancellationException) {
            send("stop")
            var d = false
            while (!d) {
                val l = inp?.readLine()
                if (l == null || l.startsWith("bestmove")) d = true
            }
            throw e
        }
        result
    }

    /** Hetsika ho an'ny bot. */
    suspend fun bestMove(fen: String, bot: Bot): String? = mutex.withLock {
        try {
            val ok = withContext(Dispatchers.IO) {
                if (ensureStarted()) {
                    send("setoption name MultiPV value 1")
                    send("setoption name Skill Level value ${bot.skill}")
                    send("position fen $fen")
                    true
                } else false
            }
            if (!ok) null
            else {
                val go = buildString {
                    append("go movetime ${bot.movetimeMs}")
                    if (bot.depth > 0) append(" depth ${bot.depth}")
                }
                search(go) { }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }

    /** Analyse feno hery (Skill 20) miaraka amin'ny MultiPV. */
    suspend fun analyze(fen: String, movetimeMs: Int, multiPv: Int = 2): List<Line> = mutex.withLock {
        try {
            val ok = withContext(Dispatchers.IO) {
                if (ensureStarted()) {
                    send("setoption name Skill Level value 20")
                    send("setoption name MultiPV value $multiPv")
                    send("position fen $fen")
                    true
                } else false
            }
            if (!ok) emptyList()
            else {
                val lines = HashMap<Int, Line>()
                search("go movetime $movetimeMs") { l ->
                    val p = parseInfo(l)
                    if (p != null) lines[p.first] = p.second
                }
                lines.toSortedMap().values.toList()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun parseInfo(l: String): Pair<Int, Line>? {
        if (!l.startsWith("info") || " score " !in l || " pv " !in l) return null
        if (" lowerbound" in l || " upperbound" in l) return null
        val t = l.split(" ")
        val mi = t.indexOf("multipv")
        val mpv = if (mi >= 0) (t.getOrNull(mi + 1)?.toIntOrNull() ?: 1) else 1
        val si = t.indexOf("score")
        val kind = t.getOrNull(si + 1) ?: return null
        val v = t.getOrNull(si + 2)?.toIntOrNull() ?: return null
        val pi = t.indexOf("pv")
        val mv = t.getOrNull(pi + 1) ?: return null
        return mpv to Line(if (kind == "cp") v else null, if (kind == "mate") v else null, mv)
    }

    fun stop() {
        try { send("quit") } catch (_: Exception) {}
        proc?.destroy(); proc = null
    }
}
