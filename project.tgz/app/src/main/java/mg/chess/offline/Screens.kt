package mg.chess.offline

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Side
import kotlin.random.Random
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.AlertDialog
import androidx.compose.ui.text.font.FontFamily
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

@Composable
fun BotAvatar(bot: Bot, size: Dp) {
    val ctx = LocalContext.current
    val img = remember(bot.id) { Sprites.avatar(ctx, bot.id) }
    if (img != null) {
        Image(img, null, Modifier.size(size).clip(CircleShape), contentScale = ContentScale.Crop)
    } else {
        Box(Modifier.size(size).clip(CircleShape).background(Color(bot.color)), contentAlignment = Alignment.Center) {
            Text(bot.name.take(1), color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.45f).sp)
        }
    }
}

private fun tcLabel(base: Long, inc: Long) = if (base <= 0) "Tsy misy ora" else "${base / 60000}+${inc / 1000}"

fun fmtClock(ms: Long): String {
    val t = max(0L, ms)
    val s = t / 1000
    val m = s / 60
    return if (t < 20_000) String.format(Locale.US, "%d:%02d.%d", m, s % 60, (t % 1000) / 100)
    else String.format(Locale.US, "%d:%02d", m, s % 60)
}

@Composable
fun TimeControlPicker(vm: ChessViewModel) {
    Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
        Text("Ora: ")
        for (t in TIME_CONTROLS) {
            FilterChip(vm.tc == t, { vm.tc = t }, { Text(t.label) })
            Spacer(Modifier.width(6.dp))
        }
    }
}

@Composable
fun ClockBox(ms: Long, active: Boolean) {
    val bg = when {
        !active -> Color(0xFF444444)
        ms < 20_000 -> Color(0xFFCA3431)
        else -> Color(0xFF2E7D32)
    }
    Box(Modifier.clip(RoundedCornerShape(8.dp)).background(bg).padding(horizontal = 12.dp, vertical = 6.dp)) {
        Text(fmtClock(ms), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun MenuScreen(vm: ChessViewModel) {
    val unfinished = vm.saved.firstOrNull { it.result == null }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        Arrangement.Center, Alignment.CenterHorizontally
    ) {
        Text("♞ Chess Offline", fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        TimeControlPicker(vm)
        Spacer(Modifier.height(16.dp))
        Button({ vm.startHumanGame() }, Modifier.fillMaxWidth()) { Text("Olona vs Olona") }
        Spacer(Modifier.height(12.dp))
        Button({ vm.toBots() }, Modifier.fillMaxWidth()) { Text("Olona vs Bot") }
        if (unfinished != null) {
            Spacer(Modifier.height(12.dp))
            Button({ vm.loadGame(unfinished) }, Modifier.fillMaxWidth()) { Text("Tohizo ny lalao farany") }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton({ vm.toHistory() }, Modifier.fillMaxWidth()) { Text("Lalao voatahiry (${vm.saved.size})") }
    }
}

@Composable
fun BotsScreen(vm: ChessViewModel) {
    BackHandler { vm.toMenu() }
    var choice by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Fidio ny bot", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Loko: ")
            FilterChip(choice == 0, { choice = 0 }, { Text("Fotsy") })
            Spacer(Modifier.width(6.dp))
            FilterChip(choice == 1, { choice = 1 }, { Text("Mainty") })
            Spacer(Modifier.width(6.dp))
            FilterChip(choice == 2, { choice = 2 }, { Text("Kisendrasendra") })
        }
        TimeControlPicker(vm)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(BOTS) { b ->
                Card(Modifier.fillMaxWidth().clickable {
                    val white = when (choice) { 0 -> true; 1 -> false; else -> Random.nextBoolean() }
                    vm.startBotGame(b, white)
                }) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        BotAvatar(b, 56.dp)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(b.name, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Text("Elo ~${b.elo}", fontSize = 14.sp)
                            Text(b.bio, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PlayerBar(vm: ChessViewModel, side: Side, bot: Bot?, you: Boolean) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        if (bot != null) {
            BotAvatar(bot, 36.dp)
            Spacer(Modifier.width(8.dp))
            Column {
                Text(bot.name, fontWeight = FontWeight.Bold)
                Text("Elo ~${bot.elo}", fontSize = 12.sp)
            }
        } else {
            val c = if (side == Side.WHITE) "Fotsy" else "Mainty"
            Text(if (you) "Ianao ($c)" else c, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.weight(1f))
        if (vm.clockOn) {
            ClockBox(if (side == Side.WHITE) vm.whiteMs else vm.blackMs, !vm.over && vm.board.sideToMove == side)
        }
    }
}

@Composable
fun GameScreen(vm: ChessViewModel) {
    BackHandler { vm.toMenu() }
    vm.version
    val flip = vm.vsBot && !vm.humanWhite
    val board = vm.board
    val targets = vm.selected?.let { s -> vm.legalFrom(s).map { it.to } } ?: emptyList()
    val last = vm.played.lastOrNull()?.let { it.from to it.to }
    val topSide = if (flip) Side.WHITE else Side.BLACK
    val bottomSide = if (flip) Side.BLACK else Side.WHITE
    val b = vm.bot

    val pm = vm.promoMoves
    if (pm != null) {
        AlertDialog(
            onDismissRequest = { vm.cancelPromotion() },
            confirmButton = {},
            title = { Text("Fidio ny piece") },
            text = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (m in pm) {
                        Box(
                            Modifier.size(64.dp).clip(RoundedCornerShape(8.dp))
                                .background(Color(0x33888888)).clickable { vm.choosePromotion(m) },
                            contentAlignment = Alignment.Center
                        ) { PieceIcon(m.promotion, 56.dp) }
                    }
                }
            }
        )
    }

    Column(Modifier.fillMaxSize().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        PlayerBar(vm, topSide, b, false)
        BoardView(
            pieceAt = { board.getPiece(it) }, flip = flip,
            selected = vm.selected, targets = targets, last = last,
            onSquare = { vm.onSquare(it) }
        )
        PlayerBar(vm, bottomSide, null, vm.vsBot)
        Text(
            when {
                vm.message.isNotEmpty() -> vm.message
                vm.thinking -> "${b?.name ?: "Stockfish"} mieritreritra..."
                board.sideToMove == Side.WHITE -> "Fotsy no mihetsika"
                else -> "Mainty no mihetsika"
            },
            color = if (vm.over || vm.message.isNotEmpty()) Color(0xFFB00020) else Color.Unspecified,
            fontWeight = FontWeight.Bold, fontSize = 18.sp,
            modifier = Modifier.padding(vertical = 8.dp)
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            val pad = PaddingValues(4.dp)
            Button({ vm.undo() }, Modifier.weight(1f), contentPadding = pad) { Text("Undo", fontSize = 13.sp) }
            Button({ vm.restart() }, Modifier.weight(1f), contentPadding = pad) { Text("Vaovao", fontSize = 13.sp) }
            Button({ vm.startReview() }, Modifier.weight(1f), enabled = vm.played.isNotEmpty(), contentPadding = pad) {
                Text("Review", fontSize = 13.sp)
            }
            OutlinedButton({ vm.toMenu() }, Modifier.weight(1f), contentPadding = pad) { Text("Menu", fontSize = 13.sp) }
        }
    }
}

@Composable
fun HistoryScreen(vm: ChessViewModel) {
    BackHandler { vm.toMenu() }
    val fmt = remember { SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Lalao voatahiry", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        if (vm.saved.isEmpty()) Text("Mbola tsy misy lalao voatahiry.", Modifier.padding(top = 16.dp))
        LazyColumn(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.saved, key = { it.id }) { g ->
                val bot = BOTS.firstOrNull { it.id == g.botId }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (bot != null) { BotAvatar(bot, 40.dp); Spacer(Modifier.width(10.dp)) }
                            Column {
                                Text(if (bot != null) "Olona vs ${bot.name}" else "Olona vs Olona", fontWeight = FontWeight.Bold)
                                Text("${fmt.format(Date(g.updated))} - ${g.moves.size} hetsika - ${tcLabel(g.baseMs, g.incMs)}", fontSize = 12.sp)
                                Text(g.result ?: "Mbola mitohy", fontSize = 12.sp)
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button({ vm.loadGame(g, true) }) { Text("Review") }
                            if (g.result == null) Button({ vm.loadGame(g) }) { Text("Tohizo") }
                            OutlinedButton({ vm.deleteGame(g.id) }) { Text("Fafao") }
                        }
                    }
                }
            }
        }
    }
}

// ---------------- REVIEW ----------------

@Composable
fun ReviewScreen(vm: ChessViewModel) {
    BackHandler { vm.leaveReview() }
    val r = vm.review
    val err = vm.reviewError
    when {
        err != null -> Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            Text("Hadisoana: $err", color = Color(0xFFB00020))
            Spacer(Modifier.height(16.dp))
            Button({ vm.leaveReview() }) { Text("Miverina") }
        }
        r == null -> Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            Text("Mandinika ny lalao...", fontSize = 18.sp)
            Spacer(Modifier.height(16.dp))
            LinearProgressIndicator(progress = { vm.reviewProgress }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Text("${(vm.reviewProgress * 100).toInt()}%")
        }
        else -> ReviewContent(vm, r)
    }
}

@Composable
fun ClsDot(c: Cls, size: Dp = 20.dp) {
    Box(Modifier.size(size).clip(CircleShape).background(Color(c.color)), contentAlignment = Alignment.Center) {
        Text(c.sym, color = Color.White, fontSize = (size.value * 0.5f).sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SideCard(title: String, s: SideSummary, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text("${"%.1f".format(s.accuracy)}%", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Accuracy", fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            Text("Game rating ~${s.rating}", fontSize = 14.sp)
            Text("ACPL ${s.acpl}", fontSize = 12.sp)
        }
    }
}

@Composable
fun EvalBar(cp: Int) {
    val w = (winPct(cp) / 100.0).toFloat().coerceIn(0.03f, 0.97f)
    Row(Modifier.fillMaxWidth().height(18.dp).clip(RoundedCornerShape(4.dp))) {
        Box(Modifier.weight(w).fillMaxHeight().background(Color.White))
        Box(Modifier.weight(1f - w).fillMaxHeight().background(Color(0xFF333333)))
    }
}

@Composable
fun EvalGraph(evals: List<Int>, ply: Int) {
    Canvas(Modifier.fillMaxWidth().height(70.dp).background(Color(0xFF2B2B2B))) {
        val n = evals.size
        if (n < 2) return@Canvas
        val dx = size.width / (n - 1)
        fun y(cp: Int): Float = size.height * (1f - (winPct(cp) / 100.0).toFloat())
        drawLine(Color(0x55FFFFFF), Offset(0f, size.height / 2), Offset(size.width, size.height / 2), 1f)
        for (i in 0 until n - 1) {
            drawLine(Color.White, Offset(i * dx, y(evals[i])), Offset((i + 1) * dx, y(evals[i + 1])), 3f)
        }
        drawLine(Color(0xFFCA3431), Offset(ply * dx, 0f), Offset(ply * dx, size.height), 2f)
    }
}

@Composable
fun MoveChip(m: MoveReview, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier.clip(RoundedCornerShape(6.dp))
            .background(if (selected) Color(0x33888888) else Color.Transparent)
            .clickable { onClick() }.padding(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ClsDot(m.cls, 20.dp)
        Spacer(Modifier.width(6.dp))
        Text(m.san, fontSize = 15.sp)
    }
}

@Composable
fun ReviewContent(vm: ChessViewModel, r: ReviewResult) {
    val ply = vm.reviewPly
    val flip = vm.vsBot && !vm.humanWhite
    val board = remember(ply, r) { Board().also { it.loadFromFen(r.fens[ply]) } }
    val last = if (ply > 0) r.squares[ply - 1] else null
    val hint = uciSquares(r.bestUci[ply])
    val mv = if (ply > 0) r.moves[ply - 1] else null
    val pairCount = (r.moves.size + 1) / 2

    LazyColumn(Modifier.fillMaxSize().padding(8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Game Review", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SideCard("Fotsy", r.white, Modifier.weight(1f))
                SideCard("Mainty", r.black, Modifier.weight(1f))
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row {
                        Spacer(Modifier.weight(2f))
                        Text("Fotsy", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                        Text("Mainty", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    }
                    for (c in Cls.values()) {
                        val w = r.white.counts[c] ?: 0
                        val bl = r.black.counts[c] ?: 0
                        if (w > 0 || bl > 0) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Row(Modifier.weight(2f), verticalAlignment = Alignment.CenterVertically) {
                                    ClsDot(c, 18.dp); Spacer(Modifier.width(8.dp)); Text(c.label)
                                }
                                Text("$w", Modifier.weight(1f))
                                Text("$bl", Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }
        item {
            Column {
                EvalBar(r.evalsWhite[ply])
                Spacer(Modifier.height(6.dp))
                BoardView(pieceAt = { board.getPiece(it) }, flip = flip, last = last, hint = hint)
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Button({ vm.reviewPly = 0 }) { Text("|<") }
                Button({ if (ply > 0) vm.reviewPly = ply - 1 }) { Text("<") }
                Button({ if (ply < r.moves.size) vm.reviewPly = ply + 1 }) { Text(">") }
                Button({ vm.reviewPly = r.moves.size }) { Text(">|") }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (mv != null) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            ClsDot(mv.cls, 24.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("${mv.san} - ${mv.cls.label}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }
                        val bestBefore = r.bestSan[ply - 1]
                        if (bestBefore != null && mv.loss > 5) Text("Tsara kokoa: $bestBefore")
                    } else {
                        Text("Toerana fanombohana", fontWeight = FontWeight.Bold)
                    }
                    Text("Eval: ${r.evalTexts[ply]}")
                    val nxt = r.bestSan[ply]
                    if (nxt != null) Text("Stockfish manoro: $nxt")
                }
            }
        }
        item { EvalGraph(r.evalsWhite, ply) }
        items(pairCount) { i ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${i + 1}.", Modifier.width(32.dp), color = Color.Gray)
                MoveChip(r.moves[2 * i], ply == 2 * i + 1, Modifier.weight(1f)) { vm.reviewPly = 2 * i + 1 }
                if (2 * i + 1 < r.moves.size) {
                    MoveChip(r.moves[2 * i + 1], ply == 2 * i + 2, Modifier.weight(1f)) { vm.reviewPly = 2 * i + 2 }
                } else Spacer(Modifier.weight(1f))
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
