package mg.chess.offline

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

/** Theme mahaleo tena: tsy manaraka ny dark/light an'ny findainao. Contrast avo. */
val LightScheme = lightColorScheme(
    primary = Color(0xFF0B57A4), onPrimary = Color.White,
    primaryContainer = Color(0xFFD3E4FA), onPrimaryContainer = Color(0xFF00203F),
    secondary = Color(0xFF3F5873), onSecondary = Color.White,
    secondaryContainer = Color(0xFFCFE0F3), onSecondaryContainer = Color(0xFF0A1E33),
    background = Color(0xFFFFFFFF), onBackground = Color(0xFF111111),
    surface = Color(0xFFFFFFFF), onSurface = Color(0xFF111111),
    surfaceVariant = Color(0xFFE6E9EE), onSurfaceVariant = Color(0xFF2A2F36),
    surfaceContainerHighest = Color(0xFFEAEDF2),
    outline = Color(0xFF5B6168),
    error = Color(0xFFB00020), onError = Color.White
)

val DarkScheme = darkColorScheme(
    primary = Color(0xFF9CC4FF), onPrimary = Color(0xFF00213F),
    primaryContainer = Color(0xFF1F4A7A), onPrimaryContainer = Color(0xFFFFFFFF),
    secondary = Color(0xFFB7CBE3), onSecondary = Color(0xFF0A1E33),
    secondaryContainer = Color(0xFF34506F), onSecondaryContainer = Color(0xFFFFFFFF),
    background = Color(0xFF101216), onBackground = Color(0xFFF2F2F2),
    surface = Color(0xFF101216), onSurface = Color(0xFFF2F2F2),
    surfaceVariant = Color(0xFF2B3038), onSurfaceVariant = Color(0xFFE3E6EA),
    surfaceContainerHighest = Color(0xFF262A31),
    outline = Color(0xFF9AA1AA),
    error = Color(0xFFFF8A80), onError = Color(0xFF3B0004)
)
