package mg.chess.offline

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap

/** Mamaky sprite avy ao amin'ny assets. Raha tsy hita dia null (ny UI no mampiasa fallback). */
object Sprites {
    var pieces: Map<String, ImageBitmap> = emptyMap(); private set
    var board: ImageBitmap? = null; private set
    var light: ImageBitmap? = null; private set
    var dark: ImageBitmap? = null; private set

    private fun load(ctx: Context, path: String): Bitmap? = try {
        ctx.assets.open(path).use { BitmapFactory.decodeStream(it) }
    } catch (e: Exception) { null }

    fun init(ctx: Context) {
        val map = HashMap<String, ImageBitmap>()
        val names = listOf("k", "q", "b", "n", "r", "p")
        for (side in listOf("w", "b")) for (n in names) {
            load(ctx, "pieces/$side$n.png")?.let { map["$side$n"] = it.asImageBitmap() }
        }
        if (map.size < 12) {
            load(ctx, "pieces/sheet.png")?.let { sheet ->
                val cw = sheet.width / 6
                val ch = sheet.height / 2
                for ((r, side) in listOf("w", "b").withIndex()) for ((c, n) in names.withIndex()) {
                    val key = "$side$n"
                    if (key !in map) map[key] = Bitmap.createBitmap(sheet, c * cw, r * ch, cw, ch).asImageBitmap()
                }
            }
        }
        pieces = map
        board = load(ctx, "board/board.png")?.asImageBitmap()
        light = load(ctx, "board/light.png")?.asImageBitmap()
        dark = load(ctx, "board/dark.png")?.asImageBitmap()
    }

    fun avatar(ctx: Context, id: String): ImageBitmap? = load(ctx, "bots/$id.png")?.asImageBitmap()
}
