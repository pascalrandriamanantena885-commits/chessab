package mg.chess.offline

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs
import kotlin.math.roundToInt

/** skill = Stockfish "Skill Level" (0-20), depth = fetra halalin'ny fikarohana (0 = tsy misy), movetimeMs = fotoana. */
data class Bot(
    val id: String, val name: String, val elo: Int, val bio: String,
    val skill: Int, val depth: Int, val movetimeMs: Int, val color: Long,
    val custom: Boolean = false, val rev: Long = 0L
)

// Elo dia tombana fotsiny. Ovay eto raha te hanitsy.
val BOTS = listOf(
    Bot("ravao", "Ravao", 400, "Vao mianatra milalao. Mora diso.", 0, 1, 50, 0xFFE57373),
    Bot("rakoto", "Rakoto", 700, "Mazoto fa tsy mijery lavitra.", 1, 2, 100, 0xFFFFB74D),
    Bot("soa", "Soa", 1000, "Milalao tsara fa mety hadino ny fandrika.", 3, 3, 150, 0xFFFFD54F),
    Bot("tojo", "Tojo", 1300, "Mahay tactic fohy.", 5, 5, 200, 0xFF81C784),
    Bot("fara", "Fara", 1600, "Mpilalao club matanjaka.", 8, 8, 300, 0xFF4DB6AC),
    Bot("hery", "Hery", 1900, "Mahay mijery lavitra ary tsy mora diso.", 12, 0, 400, 0xFF64B5F6),
    Bot("andry", "Andry", 2300, "Ambaratonga master.", 16, 0, 800, 0xFF9575CD),
    Bot("max", "Stockfish", 2800, "Ny hery feno an'ny Stockfish 11.", 20, 0, 2000, 0xFF455A64),
)

private val PALETTE = listOf(
    0xFFE57373, 0xFFFFB74D, 0xFFFFD54F, 0xFF81C784, 0xFF4DB6AC,
    0xFF64B5F6, 0xFF9575CD, 0xFFF06292, 0xFFA1887F, 0xFF90A4AE
)

/** Mamaritra ny hery (skill, depth, movetime) avy amin'ny Elo, amin'ny alalan'ny interpolation eo amin'ny bot default. */
fun strengthForElo(elo: Int): Triple<Int, Int, Int> {
    val l = BOTS.sortedBy { it.elo }
    val e = elo.coerceIn(l.first().elo, l.last().elo)
    val hi = l.firstOrNull { it.elo >= e } ?: l.last()
    val lo = l.lastOrNull { it.elo <= e } ?: l.first()
    if (hi.elo == lo.elo) return Triple(lo.skill, lo.depth, lo.movetimeMs)
    val t = (e - lo.elo).toDouble() / (hi.elo - lo.elo)
    val skill = (lo.skill + (hi.skill - lo.skill) * t).roundToInt().coerceIn(0, 20)
    val mt = (lo.movetimeMs + (hi.movetimeMs - lo.movetimeMs) * t).roundToInt()
    val depth = if (t < 0.5) lo.depth else hi.depth
    return Triple(skill, depth, mt)
}

fun Bot.toJson(): JSONObject {
    val o = JSONObject()
    o.put("id", id); o.put("name", name); o.put("elo", elo); o.put("bio", bio)
    o.put("skill", skill); o.put("depth", depth); o.put("mt", movetimeMs)
    o.put("color", color); o.put("custom", custom); o.put("rev", rev)
    return o
}

fun botFromJson(o: JSONObject): Bot = Bot(
    o.getString("id"), o.getString("name"), o.getInt("elo"), o.optString("bio", ""),
    o.getInt("skill"), o.getInt("depth"), o.getInt("mt"), o.getLong("color"),
    o.optBoolean("custom", false), o.optLong("rev", 0L)
)

/** Sary boribory 256x256 avy amin'ny Uri (kare afovoany). */
fun decodeAvatar(ctx: Context, uri: Uri): Bitmap? {
    try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 512 && bounds.outHeight / (sample * 2) >= 512) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return null
        val side = minOf(bmp.width, bmp.height)
        val sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
        return Bitmap.createScaledBitmap(sq, 256, 256, true)
    } catch (e: Exception) {
        return null
    }
}

/** Lisitry ny bot: default (azo afenina) + ireo nataon'ny mpampiasa (tehirizina ao amin'ny filesDir). */
object BotRegistry {
    var custom by mutableStateOf<List<Bot>>(emptyList())
        private set
    var hidden by mutableStateOf<Set<String>>(emptySet())
        private set
    private var loaded = false

    val visible: List<Bot>
        get() = (BOTS.filter { it.id !in hidden } + custom).sortedBy { it.elo }

    fun find(id: String?): Bot? = if (id == null) null else (BOTS + custom).firstOrNull { it.id == id }

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        try {
            val f = File(ctx.filesDir, "custom_bots.json")
            if (f.exists()) {
                val a = JSONArray(f.readText())
                custom = List(a.length()) { botFromJson(a.getJSONObject(it)) }
            }
        } catch (e: Exception) { /* tsy mandika */ }
        val set = ctx.getSharedPreferences("chess_prefs", Context.MODE_PRIVATE).getStringSet("hidden", null)
        hidden = set?.toSet() ?: emptySet()
    }

    private fun persist(ctx: Context) {
        try {
            val a = JSONArray()
            for (b in custom) a.put(b.toJson())
            File(ctx.filesDir, "custom_bots.json").writeText(a.toString())
        } catch (e: Exception) { /* tsy mandika */ }
    }

    private fun persistHidden(ctx: Context) {
        ctx.getSharedPreferences("chess_prefs", Context.MODE_PRIVATE)
            .edit().putStringSet("hidden", hidden.toSet()).apply()
    }

    fun save(ctx: Context, existing: Bot?, name: String, elo: Int, avatar: Bitmap?) {
        val e = elo.coerceIn(100, 3200)
        val s = strengthForElo(e)
        val id = existing?.id ?: ("c" + System.currentTimeMillis())
        val clean = name.trim().ifEmpty { "Bot" }
        val b = Bot(
            id, clean, e, "Bot nataonao (Elo $e)", s.first, s.second, s.third,
            existing?.color ?: PALETTE[abs(clean.hashCode()) % PALETTE.size],
            true, System.currentTimeMillis()
        )
        if (avatar != null) {
            try {
                val dir = File(ctx.filesDir, "avatars").apply { mkdirs() }
                File(dir, "$id.png").outputStream().use { avatar.compress(Bitmap.CompressFormat.PNG, 100, it) }
            } catch (ex: Exception) { /* tsy mandika */ }
        }
        custom = if (existing != null) custom.map { if (it.id == id) b else it } else custom + b
        persist(ctx)
    }

    fun delete(ctx: Context, b: Bot) {
        if (b.custom) {
            custom = custom.filter { it.id != b.id }
            try { File(File(ctx.filesDir, "avatars"), "${b.id}.png").delete() } catch (_: Exception) {}
            persist(ctx)
        } else {
            hidden = hidden + b.id
            persistHidden(ctx)
        }
    }

    fun restoreDefaults(ctx: Context) {
        hidden = emptySet()
        persistHidden(ctx)
    }
}
