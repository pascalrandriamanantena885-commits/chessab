package mg.chess.offline

/** skill = Stockfish "Skill Level" (0-20), depth = fetra halalin'ny fikarohana (0 = tsy misy), movetimeMs = fotoana. */
data class Bot(
    val id: String, val name: String, val elo: Int, val bio: String,
    val skill: Int, val depth: Int, val movetimeMs: Int, val color: Long
)

// Elo dia tombana fotsiny. Ovay eto raha te hanitsy.
val BOTS = listOf(
    Bot("ravao", "Ravao", 400, "Vao mianatra milalao. Mora diso.", 0, 1, 50, 0xFFE57373),
    Bot("rakoto", "Rakoto", 700, "Mazoto fa tsy mijery lavitra.", 1, 2, 100, 0xFFFFB74D),
    Bot("soa", "Soa", 1000, "Milalao tsara fa mety hadino ny fandrika.", 3, 3, 150, 0xFFFFD54F),
    Bot("tojo", "Tojo", 1300, "Mahay tactic fohy.", 5, 5, 200, 0xFF81C784),
    Bot("fara", "Fara", 1600, "Mpilalao club matanjaka.", 8, 8, 300, 0xFF4DB6AC),
    Bot("hery", "Hery", 1900, "Mahay mijery lavitra ary tsy mora diso.", 12, 0, 400, 0xFF64B5F6),
    Bot("andry", "Andry", 2300, "Ambaratonga master.", 16, 0, 800, 0xFF9575CD),
    Bot("max", "Stockfish", 2800, "Ny hery feno an'ny Stockfish 11.", 20, 0, 2000, 0xFF455A64),
)
