package mg.chess.offline

import android.app.Application
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.PieceType
import com.github.bhlangonijr.chesslib.Side
import com.github.bhlangonijr.chesslib.Square
import com.github.bhlangonijr.chesslib.move.Move
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min

enum class Screen { MENU, BOTS, GAME, REVIEW, HISTORY }

private val PROMO_ORDER = listOf(PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT)

class ChessViewModel(app: Application) : AndroidViewModel(app) {
    private val engine = Engine(app)
    private val store = GameStore(app)

    var board = Board(); private set
    var version by mutableIntStateOf(0); private set
    var screen by mutableStateOf(Screen.MENU)
    var bot by mutableStateOf<Bot?>(null); private set
    var vsBot by mutableStateOf(false); private set
    var humanWhite by mutableStateOf(true); private set
    var selected by mutableStateOf<Square?>(null)
    var thinking by mutableStateOf(false); private set
    var message by mutableStateOf("")
    var over by mutableStateOf(false); private set
    val played = mutableStateListOf<Move>()

    // Promotion
    var promoMoves by mutableStateOf<List<Move>?>(null); private set

    // Clock
    var tc by mutableStateOf(TIME_CONTROLS[0])
    var clockOn by mutableStateOf(false); private set
    var whiteMs by mutableLongStateOf(0L); private set
    var blackMs by mutableLongStateOf(0L); private set
    private var baseMs = 0L
    private var incMs = 0L
    private var flagged: Side? = null
    private var paused = false
    private var tickJob: Job? = null

    // Fitehirizana
    var saved by mutableStateOf<List<GameRecord>>(emptyList()); private set
    private var gameId = 0L
    private var result: String? = null

    // Review
    var review by mutableStateOf<ReviewResult?>(null); private set
    var reviewProgress by mutableStateOf(0f); private set
    var reviewError by mutableStateOf<String?>(null); private set
    var reviewPly by mutableIntStateOf(0)

    private var botJob: Job? = null
    private var reviewJob: Job? = null

    init { saved = store.list() }

    // ---------- Fanombohana lalao ----------
    fun startHumanGame() = startGame(null, true)
    fun startBotGame(b: Bot, white: Boolean) = startGame(b, white)
    fun restart() {
        TIME_CONTROLS.firstOrNull { it.baseMin * 60_000L == baseMs && it.incSec * 1000L == incMs }?.let { tc = it }
        startGame(bot, humanWhite)
    }
    fun toBots() { screen = Screen.BOTS }
    fun toHistory() { saved = store.list(); screen = Screen.HISTORY }

    private fun startGame(b: Bot?, white: Boolean) {
        botJob?.cancel(); reviewJob?.cancel()
        board = Board()
        played.clear(); review = null; reviewError = null; promoMoves = null
        bot = b; vsBot = b != null; humanWhite = white
        selected = null; thinking = false; flagged = null
        gameId = System.currentTimeMillis()
        baseMs = tc.baseMin * 60_000L; incMs = tc.incSec * 1000L
        clockOn = baseMs > 0; whiteMs = baseMs; blackMs = baseMs
        screen = Screen.GAME
        refresh(); startTicker()
        if (vsBot && !humanWhite) botMove()
    }

    fun loadGame(rec: GameRecord, thenReview: Boolean = false) {
        botJob?.cancel(); reviewJob?.cancel()
        val b = Board()
        val list = ArrayList<Move>()
        for (u in rec.moves) {
            val m = b.legalMoves().firstOrNull { it.toString().equals(u, true) } ?: break
            b.doMove(m); list.add(m)
        }
        board = b
        played.clear(); played.addAll(list)
        review = null; reviewError = null; promoMoves = null
        gameId = rec.id
        bot = BOTS.firstOrNull { it.id == rec.botId }
        vsBot = bot != null; humanWhite = rec.humanWhite
        baseMs = rec.baseMs; incMs = rec.incMs
        clockOn = baseMs > 0; whiteMs = rec.whiteMs; blackMs = rec.blackMs
        flagged = when {
            clockOn && whiteMs <= 0L -> Side.WHITE
            clockOn && blackMs <= 0L -> Side.BLACK
            else -> null
        }
        selected = null; thinking = false
        screen = Screen.GAME
        refresh(); startTicker()
        if (thenReview) startReview()
        else if (vsBot && !humanTurn() && !over) botMove()
    }

    fun deleteGame(id: Long) { store.delete(id); saved = store.list() }

    fun saveGame() {
        if (played.isEmpty() || gameId == 0L) return
        store.save(
            GameRecord(
                gameId, bot?.id, humanWhite, baseMs, incMs,
                played.map { it.toString() }, whiteMs, blackMs, result, System.currentTimeMillis()
            )
        )
        saved = store.list()
    }

    fun toMenu() {
        botJob?.cancel(); reviewJob?.cancel()
        thinking = false
        saveGame()
        screen = Screen.MENU
    }

    // ---------- Clock ----------
    fun setPaused(p: Boolean) { paused = p }

    private fun startTicker() {
        tickJob?.cancel()
        if (!clockOn) return
        var last = SystemClock.elapsedRealtime()
        tickJob = viewModelScope.launch {
            while (true) {
                delay(100)
                val now = SystemClock.elapsedRealtime()
                val dt = now - last
                last = now
                if (paused || screen != Screen.GAME || played.isEmpty() || over) continue
                if (board.sideToMove == Side.WHITE) {
                    whiteMs = max(0L, whiteMs - dt)
                    if (whiteMs == 0L) flag(Side.WHITE)
                } else {
                    blackMs = max(0L, blackMs - dt)
                    if (blackMs == 0L) flag(Side.BLACK)
                }
            }
        }
    }

    private fun flag(s: Side) {
        flagged = s
        refresh()
        saveGame()
    }

    // ---------- Lalao ----------
    private fun humanTurn() = !vsBot || (board.sideToMove == Side.WHITE) == humanWhite

    fun legalFrom(sq: Square): List<Move> = board.legalMoves().filter { it.from == sq }

    fun onSquare(sq: Square) {
        if (thinking || over || promoMoves != null || !humanTurn()) return
        val sel = selected
        val piece = board.getPiece(sq)
        val own = piece != Piece.NONE && piece.pieceSide == board.sideToMove
        if (sel == null || own) {
            selected = if (own) sq else null
            return
        }
        val cands = legalFrom(sel).filter { it.to == sq }
        if (cands.isEmpty()) { selected = null; return }
        val promos = cands.filter { it.promotion != Piece.NONE }
        if (promos.isNotEmpty()) {
            promoMoves = promos.sortedBy { PROMO_ORDER.indexOf(it.promotion.pieceType) }
            return
        }
        selected = null
        applyMove(cands[0])
        if (vsBot && !over) botMove()
    }

    fun choosePromotion(m: Move) {
        promoMoves = null
        applyMove(m)
        if (vsBot && !over) botMove()
    }

    fun cancelPromotion() { promoMoves = null; selected = null }

    private fun applyMove(mv: Move) {
        val mover = board.sideToMove
        board.doMove(mv)
        played.add(mv)
        if (clockOn) {
            if (mover == Side.WHITE) whiteMs += incMs else blackMs += incMs
        }
        selected = null
        refresh()
        saveGame()
    }

    private fun botMove() {
        val b = bot ?: return
        thinking = true
        botJob?.cancel()
        botJob = viewModelScope.launch {
            val remaining = if (board.sideToMove == Side.WHITE) whiteMs else blackMs
            val mt = if (clockOn) min(b.movetimeMs.toLong(), max(50L, remaining / 25)).toInt() else b.movetimeMs
            val uci = engine.bestMove(board.fen, b.copy(movetimeMs = mt))
            thinking = false
            if (over) return@launch
            val mv = board.legalMoves().firstOrNull { it.toString().equals(uci, true) }
            if (mv != null) applyMove(mv) else message = "Stockfish tsy namaly"
        }
    }

    fun undo() {
        if (thinking || played.isEmpty() || flagged != null) return
        board.undoMove(); played.removeAt(played.lastIndex)
        if (vsBot && !humanTurn() && played.isNotEmpty()) {
            board.undoMove(); played.removeAt(played.lastIndex)
        }
        selected = null; promoMoves = null
        refresh()
        saveGame()
        if (vsBot && !humanTurn() && !over) botMove()
    }

    private fun refresh() {
        val noMoves = board.legalMoves().isEmpty()
        val mated = board.isMated
        val draw = !mated && (board.isDraw || noMoves)
        val f = flagged
        result = when {
            f == Side.WHITE -> "0-1"
            f == Side.BLACK -> "1-0"
            mated -> if (board.sideToMove == Side.WHITE) "0-1" else "1-0"
            draw -> "1/2-1/2"
            else -> null
        }
        over = result != null
        message = when {
            f != null -> "Lany ora ny " + (if (f == Side.WHITE) "Fotsy" else "Mainty") + " - " +
                (if (f == Side.WHITE) "Mainty" else "Fotsy") + " no nahazo"
            mated -> "Checkmate! " + (if (board.sideToMove == Side.WHITE) "Mainty" else "Fotsy") + " no nahazo"
            draw -> "Draw"
            board.isKingAttacked -> "Check!"
            else -> ""
        }
        version++
    }

    // ---------- Review / Analyse ----------
    fun startReview() {
        if (played.isEmpty()) return
        botJob?.cancel(); reviewJob?.cancel()
        thinking = false
        screen = Screen.REVIEW
        review = null; reviewError = null; reviewProgress = 0f
        val moves = played.toList()
        reviewJob = viewModelScope.launch {
            try {
                val r = runReview(engine, START_FEN, moves, 300) { i, n -> reviewProgress = i.toFloat() / n }
                review = r
                reviewPly = moves.size
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                reviewError = e.message ?: "Hadisoana"
            }
        }
    }

    fun leaveReview() {
        reviewJob?.cancel()
        screen = Screen.GAME
        if (vsBot && !humanTurn() && !over && !thinking) botMove()
    }

    override fun onCleared() { saveGame(); engine.stop() }
}
