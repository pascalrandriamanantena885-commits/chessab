package mg.chess.offline

import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.PieceType
import com.github.bhlangonijr.chesslib.Side
import com.github.bhlangonijr.chesslib.Square
import com.github.bhlangonijr.chesslib.move.Move
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min

/**
 * Karazana endgame (jereo [Endgame.classify]):
 * BARE_KING = ny fahavalo dia mpanjaka irery ary ny iray hafa mahazo mate (Q, R, pion hiova, B+B, B+N, N+N).
 * PAWNS     = mpanjaka + pion fotsiny (K+P vs K, fanamiana, opposition, fiarovana pion hiova).
 * SMALL     = piece <= 7 (R+P vs R, Q vs P, minor vs pion...).
 */
enum class EgKind { NONE, BARE_KING, PAWNS, SMALL }

/** strong = ny miaramila mahazo mate amin'ny BARE_KING; hard = tsy misy Q/R/pion (B+B, B+N, N+N). */
class EgInfo(val kind: EgKind, val strong: Side?, val hard: Boolean, val pieces: Int)

/**
 * "Brain" ho an'ny endgame sy ny fampitaovana ny mate (fototra: pure Kotlin + chesslib, azo atao unit test).
 *
 * Fomba fiasa: Stockfish (lalina, MultiPV) no manamarina ny hetsika tsy diso (tsy very ny tombony, tsy stalemate);
 * ity module ity no mifidy AMIN'IZY HETSIKA TSARA izay mitondra mankany amin'ny fandresena (mop-up: mpanjaka
 * fahavalo mankany amin'ny sisiny / zoro, mpanjaka akaiky, pion mandroso miaraka amin'ny mpanjaka...) ary rehefa
 * mahantra ny bot dia mitady stalemate / repetition / draw.
 * Ny fahalalana (knowledge) dia miankina amin'ny Elo: ny bot malemy dia tsy mahay foana ny endgame sarotra (B+N).
 */
object Endgame {

    // ---------- Fahalalana araka ny Elo (hanova eto raha mila bot mahay kokoa / malemy kokoa) ----------
    /** Mate mora (Q, R, pion hiova): [elo, probabilité hampiasa ny teknika]. */
    private val EASY = arrayOf(doubleArrayOf(400.0, 0.55), doubleArrayOf(800.0, 0.80), doubleArrayOf(1200.0, 1.0))
    /** Mate sarotra (B+B, B+N, N+N). */
    private val HARD = arrayOf(doubleArrayOf(400.0, 0.10), doubleArrayOf(1000.0, 0.25), doubleArrayOf(1600.0, 0.65), doubleArrayOf(2200.0, 1.0))
    /** Endgame hafa (pion, rook, minor): fanamiana, opposition, fiarovana, stalemate. */
    private val TECH = arrayOf(doubleArrayOf(400.0, 0.20), doubleArrayOf(1000.0, 0.45), doubleArrayOf(1600.0, 0.75), doubleArrayOf(2200.0, 1.0))

    private fun interp(x: Double, pts: Array<DoubleArray>): Double {
        if (x <= pts.first()[0]) return pts.first()[1]
        if (x >= pts.last()[0]) return pts.last()[1]
        for (i in 0 until pts.size - 1) {
            val a = pts[i]; val b = pts[i + 1]
            if (x <= b[0]) return a[1] + (b[1] - a[1]) * (x - a[0]) / (b[0] - a[0])
        }
        return pts.last()[1]
    }

    /** 0..1: probabilité hampiasa ny teknika endgame amin'ity hetsika ity (raha tsy izany: fomba olombelona taloha). */
    fun knowledge(elo: Int, info: EgInfo): Double {
        val tbl = when {
            info.kind == EgKind.BARE_KING && info.hard -> HARD
            info.kind == EgKind.BARE_KING -> EASY
            else -> TECH
        }
        return interp(elo.toDouble(), tbl)
    }

    /** Depth fikarohana (10..24) araka ny fahalalana. Endgame <= 7 piece dia mora ho an'ny Stockfish. */
    fun searchDepth(know: Double): Int = 10 + Math.round(14.0 * know).toInt()

    // ---------- Fanisana material ----------
    private class Mat(val p: Int, val n: Int, val bl: Int, val bd: Int, val r: Int, val q: Int) {
        val b: Int get() = bl + bd
        val total: Int get() = p + n + bl + bd + r + q
    }

    private fun other(s: Side): Side = if (s == Side.WHITE) Side.BLACK else Side.WHITE

    private fun countMat(b: Board, side: Side): Mat {
        var p = 0; var n = 0; var bl = 0; var bd = 0; var r = 0; var q = 0
        for (sq in Square.values()) {
            if (sq == Square.NONE) continue
            val pc = b.getPiece(sq)
            if (pc == Piece.NONE || pc.pieceSide != side) continue
            when (pc.pieceType) {
                PieceType.PAWN -> p++
                PieceType.KNIGHT -> n++
                PieceType.BISHOP -> if ((sq.file.ordinal + sq.rank.ordinal) % 2 == 1) bl++ else bd++   // a1 = maizina
                PieceType.ROOK -> r++
                PieceType.QUEEN -> q++
                else -> {}
            }
        }
        return Mat(p, n, bl, bd, r, q)
    }

    /** Mate (na fanandramana mate) amin'ny mpanjaka irery. N+N dia tsy tapaka fa tsy misy mate voatery: "fanandramana" ihany. */
    private fun canMateBare(m: Mat): Boolean =
        m.q > 0 || m.r > 0 || m.p > 0 || (m.bl > 0 && m.bd > 0) || (m.b > 0 && m.n > 0) || m.n >= 2

    private fun isHard(m: Mat): Boolean = m.q == 0 && m.r == 0 && m.p == 0

    fun classify(b: Board): EgInfo {
        val w = countMat(b, Side.WHITE)
        val k = countMat(b, Side.BLACK)
        val pieces = w.total + k.total
        if (pieces == 0) return EgInfo(EgKind.NONE, null, false, 0)
        if (k.total == 0 && canMateBare(w)) return EgInfo(EgKind.BARE_KING, Side.WHITE, isHard(w), pieces)
        if (w.total == 0 && canMateBare(k)) return EgInfo(EgKind.BARE_KING, Side.BLACK, isHard(k), pieces)
        val nonPawn = (w.total - w.p) + (k.total - k.p)
        if (nonPawn == 0 && pieces <= 10) return EgInfo(EgKind.PAWNS, null, false, pieces)
        if (pieces <= 7) return EgInfo(EgKind.SMALL, null, false, pieces)
        return EgInfo(EgKind.NONE, null, false, pieces)
    }

    // ---------- Fiasa kely ----------
    private fun centerDist(sq: Square): Int {
        val f = sq.file.ordinal; val r = sq.rank.ordinal
        return max(3 - f, f - 4) + max(3 - r, r - 4)   // 0 (afovoany) .. 6 (zoro)
    }

    private fun manhattan(a: Square, b: Square): Int =
        abs(a.file.ordinal - b.file.ordinal) + abs(a.rank.ordinal - b.rank.ordinal)

    private fun cheb(f1: Int, r1: Int, f2: Int, r2: Int): Int = max(abs(f1 - f2), abs(r1 - r2))

    /** Zoro misy loko mitovy amin'ny bishop (light = lavitra: a8/h1; maizina = a1/h8): halavirana kely indrindra. */
    private fun cornerDist(sq: Square, lightBishop: Boolean): Int {
        val f = sq.file.ordinal; val r = sq.rank.ordinal
        // light: a8 (0,7) + h1 (7,0); maizina: a1 (0,0) + h8 (7,7)
        val c1r = if (lightBishop) 7 else 0
        val c2r = if (lightBishop) 0 else 7
        return min(abs(f - 0) + abs(r - c1r), abs(f - 7) + abs(r - c2r))
    }

    private fun key(b: Board): String = b.fen.split(" ").take(4).joinToString(" ")

    private fun findMove(b: Board, uci: String): Move? =
        b.legalMoves().firstOrNull { it.toString().equals(uci, true) }

    /** Isan'ny fisehoan'ny toerana (hatramin'ny fiandohan'ny lalao) - ho an'ny fisorohana / fitadiavana repetition. */
    fun seenCounts(history: List<String>): Map<String, Int> {
        val m = HashMap<String, Int>()
        if (history.isEmpty()) return m
        try {
            val rb = Board()
            m[key(rb)] = 1
            for (u in history) {
                val mv = rb.legalMoves().firstOrNull { it.toString().equals(u, true) } ?: break
                rb.doMove(mv)
                val k = key(rb)
                m[k] = (m[k] ?: 0) + 1
            }
        } catch (e: Exception) {
            m.clear()
        }
        return m
    }

    /** Marina raha mahatonga stalemate ny hetsika (ny mpilalao faharoa tsy manana hetsika ary tsy check). */
    fun stalemates(pre: Board, mv: Move): Boolean {
        pre.doMove(mv)
        try {
            return pre.legalMoves().isEmpty() && !pre.isKingAttacked
        } finally {
            pre.undoMove()
        }
    }

    // ---------- Mop-up / fandrosoana ho an'ny miaramila mahery ----------
    /**
     * Isa ho an'ny [strong] AMIN'NY TOERANA AORIAN'NY HETSIKA (ny fahavalo no hihetsika).
     * Ambony kokoa = akaiky kokoa ny mate / ny promotion. mate = +100000, stalemate = -100000.
     */
    fun progress(after: Board, strong: Side, kind: EgKind): Double {
        val weak = other(strong)
        val moves = after.legalMoves()
        if (moves.isEmpty()) return if (after.isKingAttacked) 100000.0 else -100000.0
        val ks = after.getKingSquare(strong)
        val kw = after.getKingSquare(weak)
        val m = countMat(after, strong)
        val wm = countMat(after, weak)
        var s = 0.0

        if (wm.total == 0) {
            // Mpanjaka irery: mankany amin'ny sisiny / zoro, mpanjaka akaiky, hetsika vitsy ho an'ny fahavalo
            val bnOnly = m.q == 0 && m.r == 0 && m.p == 0 && m.b == 1 && m.n == 1
            s += if (bnOnly) 12.0 * (14 - cornerDist(kw, m.bl > 0)) else 14.0 * centerDist(kw)
            s += 4.0 * (14 - manhattan(ks, kw))
            s -= 3.0 * moves.size
        } else {
            s += 2.0 * (6 - centerDist(ks))   // mpanjaka mavitrika
        }

        if (m.p > 0) {
            var maxRel = -1; var pf = 0; var pr = 0
            for (sq in Square.values()) {
                if (sq == Square.NONE) continue
                val pc = after.getPiece(sq)
                if (pc == Piece.NONE || pc.pieceSide != strong || pc.pieceType != PieceType.PAWN) continue
                val rel = if (strong == Side.WHITE) sq.rank.ordinal else 7 - sq.rank.ordinal
                s += 6.0 * rel
                if (rel > maxRel) { maxRel = rel; pf = sq.file.ordinal; pr = sq.rank.ordinal }
            }
            if (maxRel >= 0) {
                val dir = if (strong == Side.WHITE) 1 else -1
                // Mpanjaka manaraka / miaro ny pion mandroso indrindra (kare eo alohany)
                s -= 2.0 * cheb(ks.file.ordinal, ks.rank.ordinal, pf, (pr + dir).coerceIn(0, 7))
            }
        }
        // Piece vaovao avy amin'ny promotion
        s += 45.0 * m.q + 28.0 * m.r
        return s
    }

    // ---------- Fisorohana ny very (miaro) : fandrika stalemate ----------
    /**
     * Ho an'ny mpiaro: manakaiky ny 0..~4 raha misy valiny azon'ny fahavalo atao izay mahatonga stalemate (na maro ny valiny diso).
     * Raha ny hetsika mihitsy no mahatonga stalemate ho an'ny fahavalo => 10 (draw!).
     */
    fun trapScore(pre: Board, mv: Move): Double {
        pre.doMove(mv)
        try {
            val rs = pre.legalMoves()
            if (rs.isEmpty()) return if (pre.isKingAttacked) 0.0 else 10.0
            var c = 0
            for (r in rs) {
                pre.doMove(r)
                val stale = pre.legalMoves().isEmpty() && !pre.isKingAttacked
                pre.undoMove()
                if (stale) c++
            }
            if (c == 0) return 0.0
            return 0.5 + 3.0 * c / rs.size
        } finally {
            pre.undoMove()
        }
    }

    // ---------- Fikarohana mate amin'ny piece hafa (middlegame, queen = fitaovana) ----------
    /**
     * Isa (0..~5) ho an'ny hetsika amin'ny fanafihana mpanjaka: mihena ny toerana azon'ny mpanjaka fahavalo ialana,
     * check amin'ny piece tsy queen (rook/bishop/knight/pion) no tsara kokoa, ary ny piece tsy queen akaiky ny mpanjaka.
     * Ny queen dia manapaka ny lalana fa ny piece hafa no mamita (mate amin'ny pion, mpanjaka, bishop, knight, rook...).
     */
    fun huntScore(pre: Board, mv: Move): Double {
        val mover = pre.sideToMove
        val movedType = pre.getPiece(mv.from).pieceType
        pre.doMove(mv)
        try {
            val moves = pre.legalMoves()
            if (moves.isEmpty()) return if (pre.isKingAttacked) 6.0 else -6.0
            val ok = pre.getKingSquare(pre.sideToMove)
            var kingMoves = 0
            for (x in moves) if (pre.getPiece(x.from).pieceType == PieceType.KING) kingMoves++
            val check = pre.isKingAttacked
            var near = 0.0
            for (sq in Square.values()) {
                if (sq == Square.NONE) continue
                val pc = pre.getPiece(sq)
                if (pc == Piece.NONE || pc.pieceSide != mover) continue
                val d = cheb(sq.file.ordinal, sq.rank.ordinal, ok.file.ordinal, ok.rank.ordinal)
                when (pc.pieceType) {
                    PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT -> if (d <= 3) near += 1.0
                    PieceType.QUEEN -> if (d <= 3) near += 0.5
                    PieceType.PAWN, PieceType.KING -> if (d <= 2) near += 0.5
                    else -> {}
                }
            }
            return (4 - min(kingMoves, 4)) * 0.5 +
                (if (check) (if (movedType != PieceType.QUEEN) 1.0 else 0.5) else 0.0) +
                min(near, 4.0) * 0.3
        } finally {
            pre.undoMove()
        }
    }

    // ---------- Safidy hetsika amin'ny endgame ----------
    /**
     * [ls] = MultiPV avy amin'ny Stockfish (lalina). Miverina hetsika UCI.
     * - mate hita: lalaina foana.
     * - mandroso (>= +1.50): mifidy ny hetsika tsara indrindra araka ny [progress] (tsy stalemate, tsy repetition, 50 hetsika).
     * - mahantra (<= -1.50 na mate ho an'ny fahavalo): mitady stalemate / repetition / hetsika mampijanona ela ny mate.
     * - mitovy: hetsika tsara indrindra; raha kely kokoa ny toerana dia mitady repetition (draw).
     */
    fun choose(pre: Board, ls: List<Line>, eg: EgInfo, history: List<String>, fen: String, best: String?): String? {
        if (ls.isEmpty()) return best
        val cps = ls.map { it.stmCp().coerceIn(-MATE_CP, MATE_CP) }
        val bestCp = cps.max()
        val top = ls[cps.indexOf(bestCp).coerceAtLeast(0)]
        val tm = top.mate
        if (tm != null && tm > 0) return top.move
        val seen = seenCounts(history)
        val halfmove = fen.split(" ").getOrNull(4)?.toIntOrNull() ?: 0
        // Mpanjaka irery vs mpanjaka manana material mate: ny tompon'ny material foana no manandrana mamita (na dia 0.00 aza ny isa, ohatra N+N)
        val sure = eg.kind == EgKind.BARE_KING && eg.strong == pre.sideToMove
        return when {
            bestCp >= 150 || sure -> convert(pre, ls, cps, bestCp, top, eg, seen, halfmove)
            bestCp <= -150 || (tm != null && tm < 0) -> defend(pre, ls, cps, bestCp, top, seen)
            else -> hold(pre, ls, cps, bestCp, top, seen)
        }
    }

    private fun convert(
        pre: Board, ls: List<Line>, cps: List<Int>, bestCp: Int, top: Line,
        eg: EgInfo, seen: Map<String, Int>, halfmove: Int
    ): String {
        val stm = pre.sideToMove
        val tol = if (eg.kind == EgKind.BARE_KING) 150 else 25
        var bestMv = top.move
        var bestScore = -Double.MAX_VALUE
        for ((i, l) in ls.withIndex()) {
            val loss = bestCp - cps[i]
            if (loss > tol) continue
            val mv = findMove(pre, l.move) ?: continue
            val movedPawn = pre.getPiece(mv.from).pieceType == PieceType.PAWN
            val capture = pre.getPiece(mv.to) != Piece.NONE
            pre.doMove(mv)
            var sc = try {
                var v = progress(pre, stm, eg.kind)
                val cnt = seen[key(pre)] ?: 0
                if (cnt >= 2) v -= 1_000_000.0 else if (cnt == 1) v -= 30.0
                v
            } finally {
                pre.undoMove()
            }
            if (halfmove >= 40 && (movedPawn || capture)) sc += 50.0   // mamerina ny lamina 50 hetsika
            sc -= 0.02 * loss
            if (sc > bestScore) { bestScore = sc; bestMv = l.move }
        }
        return bestMv
    }

    private fun defend(
        pre: Board, ls: List<Line>, cps: List<Int>, bestCp: Int, top: Line, seen: Map<String, Int>
    ): String {
        val tm = top.mate
        val dist = if (tm != null && tm < 0) -tm else 0
        var bestMv = top.move
        var bestW = -1.0
        for ((i, l) in ls.withIndex()) {
            val lm = l.mate
            val ok = if (dist > 0) (lm == null || (lm < 0 && -lm >= dist - 1))
                     else moveLossPts(bestCp, cps[i]) <= 4.0
            if (!ok) continue
            val mv = findMove(pre, l.move) ?: continue
            val trap = trapScore(pre, mv)
            var w = (1.0 + 4.0 * trap) * exp(-moveLossPts(bestCp, cps[i]) / 2.0)
            if (l.move == top.move) w *= 1.5
            pre.doMove(mv)
            val cnt = seen[key(pre)] ?: 0
            pre.undoMove()
            if (cnt >= 2) w *= 6.0 else if (cnt == 1) w *= 2.0   // repetition = draw
            if (w > bestW) { bestW = w; bestMv = l.move }
        }
        return bestMv
    }

    private fun hold(
        pre: Board, ls: List<Line>, cps: List<Int>, bestCp: Int, top: Line, seen: Map<String, Int>
    ): String {
        var bestMv = top.move
        var bestScore = -Double.MAX_VALUE
        for ((i, l) in ls.withIndex()) {
            if (bestCp - cps[i] > 15) continue
            val mv = findMove(pre, l.move) ?: continue
            var sc = -0.02 * (bestCp - cps[i])
            pre.doMove(mv)
            val cnt = seen[key(pre)] ?: 0
            pre.undoMove()
            if (bestCp <= -40 && cnt >= 1) sc += 20.0       // pejy kely kokoa: mitady repetition
            if (bestCp >= 40 && cnt >= 2) sc -= 100.0       // mpandresy kely: tsy mandeha amin'ny draw
            if (bestCp <= -40) sc += 5.0 * trapScore(pre, mv)
            if (sc > bestScore) { bestScore = sc; bestMv = l.move }
        }
        return bestMv
    }
}
