package mg.chess.offline

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val F_ALL = 0
private const val F_CUSTOM = 1
private const val F_DEFAULT = 2
private const val F_HIDDEN = 3

/**
 * Fitantanana bot (Settings > Bot): fikarohana, sivana, filaharana, tsipika kely azo sokafana,
 * fisafidianana maro (tsindrio maharitra) hamafana / hanaovana export, ary fanarenana ny bot default afenina.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun BotManager(vm: ChessViewModel) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableIntStateOf(F_ALL) }
    var sort by rememberSaveable { mutableIntStateOf(0) }       // 0 Elo miakatra, 1 Elo midina, 2 A-Z
    var expanded by remember { mutableStateOf<String?>(null) }
    val selected = remember { mutableStateListOf<String>() }
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Bot?>(null) }
    var copying by remember { mutableStateOf<Bot?>(null) }
    var deleting by remember { mutableStateOf<List<Bot>?>(null) }
    var msg by remember { mutableStateOf("") }

    val all = BotRegistry.visible
    val hidden = BotRegistry.hiddenBots()
    val base = when (filter) {
        F_CUSTOM -> all.filter { it.custom }
        F_DEFAULT -> all.filter { !it.custom }
        F_HIDDEN -> hidden
        else -> all
    }
    val q = query.trim().lowercase()
    val list = base
        .filter { q.isEmpty() || it.name.lowercase().contains(q) || it.elo.toString().contains(q) || tierOf(it.elo).label.lowercase().contains(q) }
        .let {
            when (sort) {
                1 -> it.sortedByDescending { b -> b.elo }
                2 -> it.sortedBy { b -> b.name.lowercase() }
                else -> it.sortedBy { b -> b.elo }
            }
        }
    val selMode = selected.isNotEmpty()
    BackHandler(enabled = selMode) { selected.clear() }

    Column(Modifier.fillMaxSize()) {
        // ---- Lohateny + hetsika lehibe ----
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("${all.size} bot · ${all.count { it.custom }} nataoko", Modifier.weight(1f), color = cs.onSurfaceVariant, fontSize = 13.sp)
            Button({ adding = true }) { Text("+ Bot vaovao") }
        }
        Spacer(Modifier.padding(top = 6.dp))
        BotPackRow()
        Spacer(Modifier.padding(top = 8.dp))

        // ---- Fikarohana + sivana + filaharana ----
        OutlinedTextField(
            query, { query = it.take(30) }, Modifier.fillMaxWidth(), singleLine = true,
            placeholder = { Text("Hikaroka (anarana, Elo, sokajy)") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            trailingIcon = { if (query.isNotEmpty()) IconButton({ query = "" }) { Icon(Icons.Rounded.Close, "Fafao ny fikarohana") } }
        )
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(filter == F_ALL, { filter = F_ALL }, { Text("Rehetra (${all.size})", fontSize = 12.sp) })
            FilterChip(filter == F_CUSTOM, { filter = F_CUSTOM }, { Text("Nataoko (${all.count { it.custom }})", fontSize = 12.sp) })
            FilterChip(filter == F_DEFAULT, { filter = F_DEFAULT }, { Text("Default (${all.count { !it.custom }})", fontSize = 12.sp) })
            if (hidden.isNotEmpty()) FilterChip(filter == F_HIDDEN, { filter = F_HIDDEN }, { Text("Afenina (${hidden.size})", fontSize = 12.sp) })
            Spacer(Modifier.width(8.dp))
            FilterChip(sort == 0, { sort = 0 }, { Text("Elo ↑", fontSize = 12.sp) })
            FilterChip(sort == 1, { sort = 1 }, { Text("Elo ↓", fontSize = 12.sp) })
            FilterChip(sort == 2, { sort = 2 }, { Text("A-Z", fontSize = 12.sp) })
        }

        // ---- Bara fisafidianana maro ----
        if (selMode) {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(cs.primaryContainer).padding(horizontal = 10.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("${selected.size} voafidy", Modifier.weight(1f), fontWeight = FontWeight.Bold, color = cs.onPrimaryContainer)
                TextButton({ selected.clear(); selected.addAll(list.map { it.id }) }) { Text("Rehetra") }
                TextButton({
                    val bots = BotRegistry.visible.filter { it.id in selected && !it.isMax }
                    try {
                        ShareUtil.share(ctx, BotPack.exportForShare(ctx, bots), "application/octet-stream", "Zarao ny bot")
                    } catch (e: Exception) { msg = "Tsy lasa ny fizarana: " + (e.message ?: "") }
                }, enabled = all.any { it.id in selected && !it.isMax }) { Text("Zarao") }
                TextButton({ deleting = all.filter { it.id in selected } }) { Text("Fafao", color = cs.error) }
                IconButton({ selected.clear() }) { Icon(Icons.Rounded.Close, "Foano ny safidy") }
            }
        }
        if (msg.isNotEmpty()) Text(msg, fontSize = 12.sp, color = cs.error)

        if (list.isEmpty()) {
            Text(
                if (q.isNotEmpty()) "Tsy misy bot mifanaraka amin'ny \"$query\"." else "Tsy misy bot amin'ity sivana ity.",
                Modifier.padding(top = 16.dp), color = cs.onSurfaceVariant
            )
        }

        // ---- Lisitra kely ----
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (filter == F_HIDDEN && hidden.isNotEmpty()) item {
                OutlinedButton({ BotRegistry.restoreDefaults(ctx) }, Modifier.fillMaxWidth()) { Text("Averina daholo (${hidden.size})") }
            }
            items(list, key = { it.id }) { b ->
                val isSel = b.id in selected
                val open = expanded == b.id && !selMode
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(if (isSel) cs.primaryContainer else cs.surfaceContainer)
                        .combinedClickable(
                            onClick = {
                                if (selMode) { if (isSel) selected.remove(b.id) else selected.add(b.id) }
                                else expanded = if (expanded == b.id) null else b.id
                            },
                            onLongClick = { if (filter != F_HIDDEN && !isSel) selected.add(b.id) }
                        )
                        .padding(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (selMode) Checkbox(isSel, { on -> if (on) selected.add(b.id) else selected.remove(b.id) })
                        BotAvatar(b, 40.dp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(b.name, fontWeight = FontWeight.Bold, maxLines = 1)
                                Spacer(Modifier.width(6.dp))
                                TierChip(tierOf(b.elo))
                            }
                            val spec = b.specialty()
                            Text(
                                (if (b.isMax) "MAX" else "Elo ${b.elo}") + (if (b.custom) " · nataoko" else "") +
                                    (if (spec.isNotEmpty()) " · $spec" else ""),
                                fontSize = 11.sp, color = cs.onSurfaceVariant, maxLines = 1
                            )
                        }
                        if (filter == F_HIDDEN) TextButton({ BotRegistry.restore(ctx, b.id) }) { Text("Averina") }
                        else if (!selMode) Text(if (open) "▲" else "▼", fontSize = 12.sp, color = cs.onSurfaceVariant)
                    }
                    if (open) {
                        Spacer(Modifier.padding(top = 6.dp))
                        if (b.bio.isNotBlank()) Text(b.bio, fontSize = 12.sp)
                        val tags = b.style.describe()
                        if (tags.isNotEmpty()) Text("Fomba: " + tags.joinToString(", "), fontSize = 12.sp, color = cs.primary)
                        val ops = b.openings.mapNotNull { OPENING_MAP[it]?.name }
                        if (ops.isNotEmpty()) Text("Opening: " + ops.joinToString(", "), fontSize = 12.sp, color = cs.onSurfaceVariant)
                        val games = BotProgress.map[b.id]?.games ?: 0
                        if (games > 0) Text("$games lalao ao amin'ny fifaninanana", fontSize = 11.sp, color = cs.onSurfaceVariant)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (b.custom) OutlinedButton({ editing = b }) { Text("Ovay") }
                            OutlinedButton({ copying = b }) { Text("Kopia") }
                            if (!b.isMax) OutlinedButton({
                                try {
                                    ShareUtil.share(ctx, BotPack.exportForShare(ctx, listOf(b)), "application/octet-stream", "Zarao ny bot")
                                } catch (e: Exception) { msg = "Tsy lasa ny fizarana: " + (e.message ?: "") }
                            }) { Text("Export") }
                            OutlinedButton({ deleting = listOf(b) }) { Text(if (b.custom) "Fafao" else "Afeno", color = cs.error) }
                        }
                    }
                }
            }
            item { Spacer(Modifier.padding(bottom = 16.dp)) }
        }
    }

    if (adding) BotEditDialog(null) { adding = false }
    val ed = editing
    if (ed != null) BotEditDialog(ed) { editing = null }
    val cp = copying
    if (cp != null) BotEditDialog(cp, asCopy = true) { copying = null }
    val del = deleting
    if (del != null) {
        val defaults = del.count { !it.custom }
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text(if (del.size == 1) "Fafana ny ${del[0].name}?" else "Fafana ny bot ${del.size}?") },
            text = {
                Text(
                    (if (defaults > 0) "Ny bot default ($defaults) dia afenina fotsiny (azo averina ao amin'ny \"Afenina\"). " else "") +
                        "Tsy fafana ny lalao efa voatahiry sy ny fifaninanana efa nisy azy, fa tsy ho hita intsony ao amin'ny lisitra."
                )
            },
            confirmButton = {
                Button({
                    for (b in del) BotRegistry.delete(ctx, b)
                    selected.clear(); expanded = null; deleting = null
                }) { Text(if (defaults == del.size) "Afeno" else "Fafao") }
            },
            dismissButton = { TextButton({ deleting = null }) { Text("Foano") } }
        )
    }
}
