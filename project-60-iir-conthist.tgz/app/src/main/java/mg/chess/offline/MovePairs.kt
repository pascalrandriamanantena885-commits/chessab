package mg.chess.offline

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.Composable

/**
 * Lisitry ny hetsika amin'ny andalana roa (Fotsy | Mainty). Mifanaraka amin'ny [startFen]:
 * raha Mainty no mihetsika voalohany (Edit board) dia foana ny sela Fotsy amin'ny andalana voalohany,
 * ary manomboka amin'ny laharana ao amin'ny FEN ny isa.
 * [cell] = sela ho an'ny hetsika laharana [idx] (0-based ao amin'ny lisitra played).
 */
fun LazyListScope.movePairs(
    total: Int,
    startFen: String,
    cell: @Composable (idx: Int, modifier: Modifier) -> Unit
) {
    val off = if (blackFirst(startFen)) 1 else 0
    val no0 = startMoveNo(startFen)
    items((total + off + 1) / 2) { i ->
        val a = 2 * i - off
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("${no0 + i}.", Modifier.width(36.dp), color = Color.Gray)
            if (a in 0 until total) cell(a, Modifier.weight(1f)) else Spacer(Modifier.weight(1f))
            if (a + 1 in 0 until total) cell(a + 1, Modifier.weight(1f)) else Spacer(Modifier.weight(1f))
        }
    }
}
