package mg.chess.offline.own;

import java.util.List;

/**
 * Toerana filalaovana (0x88) ho an'ny motera manokana: fanamboarana hetsika, make/unmake, zobrist.
 * Tsy miankina amin'ny Android na chesslib.
 * Piece = type | (color << 3); type: 1=P 2=N 3=B 4=R 5=Q 6=K; color: 0=fotsy 1=mainty.
 * Hetsika (int): from | to<<8 | promo<<16 | flag<<20 ; flag: 1=capture 2=ep 4=castle 8=double push.
 */
public final class Pos {
    public static final int P = 1, N = 2, B = 3, R = 4, Q = 5, K = 6;
    public static final int F_CAP = 1, F_EP = 2, F_CASTLE = 4, F_DBL = 8;

    static final int[] KN = {33, 31, 18, 14, -14, -18, -31, -33};
    static final int[] KG = {1, -1, 16, -16, 17, 15, -15, -17};
    static final int[] BD = {17, 15, -15, -17};
    static final int[] RD = {16, -16, 1, -1};

    static final long[][] Z = new long[16][128];
    static final long[] ZC = new long[16];
    static final long[] ZE = new long[8];
    static final long ZS;
    static final int[] MASK = new int[128];

    static {
        long s = 0x9E3779B97F4A7C15L;
        for (int i = 0; i < 16; i++) for (int j = 0; j < 128; j++) { s = next(s); Z[i][j] = s; }
        for (int i = 0; i < 16; i++) { s = next(s); ZC[i] = s; }
        for (int i = 0; i < 8; i++) { s = next(s); ZE[i] = s; }
        s = next(s); ZS = s;
        for (int i = 0; i < 128; i++) MASK[i] = 15;
        MASK[0x00] = 15 & ~2; MASK[0x07] = 15 & ~1; MASK[0x04] = 15 & ~3;
        MASK[0x70] = 15 & ~8; MASK[0x77] = 15 & ~4; MASK[0x74] = 15 & ~12;
    }

    private static long next(long x) {
        x ^= x << 13; x ^= x >>> 7; x ^= x << 17; // xorshift64
        return x * 0x2545F4914F6CDD1DL;
    }

    public final int[] b = new int[128];
    public int side;
    public int castle;      // 1=WK 2=WQ 4=BK 8=BQ
    public int ep = -1;
    public int half;
    public long key;
    public final int[] ksq = new int[2];

    private static final int CAP = 2048;
    final int[] uMove = new int[CAP], uCap = new int[CAP], uCastle = new int[CAP], uEp = new int[CAP], uHalf = new int[CAP];
    final long[] uKey = new long[CAP];
    public int sp = 0;

    public static int from(int m) { return m & 0xFF; }
    public static int to(int m) { return (m >> 8) & 0xFF; }
    public static int promo(int m) { return (m >> 16) & 15; }
    public static int flag(int m) { return (m >> 20) & 15; }
    public static int mk(int from, int to, int promo, int flag) { return from | (to << 8) | (promo << 16) | (flag << 20); }
    public static int type(int p) { return p & 7; }
    public static int color(int p) { return p >> 3; }

    public static String sqName(int s) { return "" + (char) ('a' + (s & 7)) + (char) ('1' + (s >> 4)); }

    public static String moveStr(int m) {
        String r = sqName(from(m)) + sqName(to(m));
        int pr = promo(m);
        if (pr != 0) r += "nbrq".charAt(pr - 2);
        return r;
    }

    public boolean setFen(String fen) {
        try {
            for (int i = 0; i < 128; i++) b[i] = 0;
            String[] t = fen.trim().split("\\s+");
            String[] rows = t[0].split("/");
            if (rows.length != 8) return false;
            ksq[0] = ksq[1] = -1;
            for (int r = 0; r < 8; r++) {
                int rank = 7 - r, f = 0;
                for (char c : rows[r].toCharArray()) {
                    if (c >= '1' && c <= '8') { f += c - '0'; continue; }
                    int col = Character.isUpperCase(c) ? 0 : 1;
                    int ty;
                    switch (Character.toLowerCase(c)) {
                        case 'p': ty = P; break; case 'n': ty = N; break; case 'b': ty = B; break;
                        case 'r': ty = R; break; case 'q': ty = Q; break; case 'k': ty = K; break;
                        default: return false;
                    }
                    if (f > 7) return false;
                    int sq = rank * 16 + f;
                    b[sq] = ty | (col << 3);
                    if (ty == K) ksq[col] = sq;
                    f++;
                }
            }
            if (ksq[0] < 0 || ksq[1] < 0) return false;
            side = t.length > 1 && t[1].equals("b") ? 1 : 0;
            castle = 0;
            String cs = t.length > 2 ? t[2] : "-";
            if (cs.indexOf('K') >= 0) castle |= 1;
            if (cs.indexOf('Q') >= 0) castle |= 2;
            if (cs.indexOf('k') >= 0) castle |= 4;
            if (cs.indexOf('q') >= 0) castle |= 8;
            ep = -1;
            if (t.length > 3 && t[3].length() == 2 && t[3].charAt(0) >= 'a' && t[3].charAt(0) <= 'h')
                ep = (t[3].charAt(1) - '1') * 16 + (t[3].charAt(0) - 'a');
            half = t.length > 4 ? Integer.parseInt(t[4]) : 0;
            sp = 0;
            key = computeKey();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public void startPos() { setFen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"); }

    long computeKey() {
        long k = 0;
        for (int s = 0; s < 128; s++) { if ((s & 0x88) != 0) { s += 7; continue; } if (b[s] != 0) k ^= Z[b[s]][s]; }
        if (side == 1) k ^= ZS;
        k ^= ZC[castle];
        if (ep >= 0) k ^= ZE[ep & 7];
        return k;
    }

    public boolean attacked(int sq, int by) {
        // pawns
        if (by == 0) {
            int s1 = sq - 15, s2 = sq - 17;
            if ((s1 & 0x88) == 0 && b[s1] == P) return true;
            if ((s2 & 0x88) == 0 && b[s2] == P) return true;
        } else {
            int s1 = sq + 15, s2 = sq + 17;
            if ((s1 & 0x88) == 0 && b[s1] == (P | 8)) return true;
            if ((s2 & 0x88) == 0 && b[s2] == (P | 8)) return true;
        }
        int off = by << 3;
        for (int d : KN) { int s = sq + d; if ((s & 0x88) == 0 && b[s] == (N | off)) return true; }
        for (int d : KG) { int s = sq + d; if ((s & 0x88) == 0 && b[s] == (K | off)) return true; }
        for (int d : BD) {
            int s = sq + d;
            while ((s & 0x88) == 0) {
                int p = b[s];
                if (p != 0) { if (p == (B | off) || p == (Q | off)) return true; break; }
                s += d;
            }
        }
        for (int d : RD) {
            int s = sq + d;
            while ((s & 0x88) == 0) {
                int p = b[s];
                if (p != 0) { if (p == (R | off) || p == (Q | off)) return true; break; }
                s += d;
            }
        }
        return false;
    }

    public boolean inCheck() { return attacked(ksq[side], side ^ 1); }

    /** Hetsika pseudo-legal. caps=true: fakana + promotion queen ihany. Miverina ny isan'ny hetsika. */
    public int gen(int[] m, boolean caps) {
        int n = 0;
        final int us = side, them = us ^ 1;
        final int dir = us == 0 ? 16 : -16;
        final int startRank = us == 0 ? 1 : 6;
        final int promoRank = us == 0 ? 6 : 1;
        for (int s = 0; s < 128; s++) {
            if ((s & 0x88) != 0) { s += 7; continue; }
            int p = b[s];
            if (p == 0 || (p >> 3) != us) continue;
            int ty = p & 7;
            if (ty == P) {
                int rank = s >> 4;
                int to = s + dir;
                if (b[to] == 0) {
                    if (rank == promoRank) {
                        n = addPromos(m, n, s, to, 0);
                        if (caps) { /* queen only handled in addPromos */ }
                    } else if (!caps) {
                        m[n++] = mk(s, to, 0, 0);
                        if (rank == startRank && b[to + dir] == 0) m[n++] = mk(s, to + dir, 0, F_DBL);
                    }
                }
                for (int k = 0; k < 2; k++) {
                    int t2 = s + dir + (k == 0 ? 1 : -1);
                    if ((t2 & 0x88) != 0) continue;
                    int tp = b[t2];
                    if (tp != 0 && (tp >> 3) == them) {
                        if (rank == promoRank) n = addPromos(m, n, s, t2, F_CAP);
                        else m[n++] = mk(s, t2, 0, F_CAP);
                    } else if (tp == 0 && t2 == ep) {
                        m[n++] = mk(s, t2, 0, F_CAP | F_EP);
                    }
                }
            } else if (ty == N || ty == K) {
                int[] ds = ty == N ? KN : KG;
                for (int d : ds) {
                    int t2 = s + d;
                    if ((t2 & 0x88) != 0) continue;
                    int tp = b[t2];
                    if (tp == 0) { if (!caps) m[n++] = mk(s, t2, 0, 0); }
                    else if ((tp >> 3) == them) m[n++] = mk(s, t2, 0, F_CAP);
                }
            } else {
                for (int di = 0; di < 8; di++) {
                    int d;
                    if (di < 4) { if (ty == B) continue; d = RD[di]; }
                    else { if (ty == R) continue; d = BD[di - 4]; }
                    int t2 = s + d;
                    while ((t2 & 0x88) == 0) {
                        int tp = b[t2];
                        if (tp == 0) { if (!caps) m[n++] = mk(s, t2, 0, 0); }
                        else { if ((tp >> 3) == them) m[n++] = mk(s, t2, 0, F_CAP); break; }
                        t2 += d;
                    }
                }
            }
        }
        if (!caps) {
            if (us == 0) {
                if ((castle & 1) != 0 && b[4] == K && b[7] == R && b[5] == 0 && b[6] == 0
                        && !attacked(4, 1) && !attacked(5, 1) && !attacked(6, 1)) m[n++] = mk(4, 6, 0, F_CASTLE);
                if ((castle & 2) != 0 && b[4] == K && b[0] == R && b[3] == 0 && b[2] == 0 && b[1] == 0
                        && !attacked(4, 1) && !attacked(3, 1) && !attacked(2, 1)) m[n++] = mk(4, 2, 0, F_CASTLE);
            } else {
                int kk = K | 8, rr = R | 8;
                if ((castle & 4) != 0 && b[0x74] == kk && b[0x77] == rr && b[0x75] == 0 && b[0x76] == 0
                        && !attacked(0x74, 0) && !attacked(0x75, 0) && !attacked(0x76, 0)) m[n++] = mk(0x74, 0x76, 0, F_CASTLE);
                if ((castle & 8) != 0 && b[0x74] == kk && b[0x70] == rr && b[0x73] == 0 && b[0x72] == 0 && b[0x71] == 0
                        && !attacked(0x74, 0) && !attacked(0x73, 0) && !attacked(0x72, 0)) m[n++] = mk(0x74, 0x72, 0, F_CASTLE);
            }
        }
        return n;
    }

    private int addPromos(int[] m, int n, int from, int to, int fl) {
        m[n++] = mk(from, to, Q, fl);
        return n; // queen only in caps mode; underpromotions added by genAll
    }

    /** Hetsika rehetra (anisan'ny underpromotion). */
    public int genAll(int[] m) {
        int n = gen(m, false);
        int extra = n;
        for (int i = 0; i < n; i++) {
            int mv = m[i];
            if (promo(mv) == Q) {
                int f = from(mv), t = to(mv), fl = flag(mv);
                if (extra + 3 > m.length) break;
                m[extra++] = mk(f, t, R, fl);
                m[extra++] = mk(f, t, B, fl);
                m[extra++] = mk(f, t, N, fl);
            }
        }
        return extra;
    }

    public boolean make(int m) {
        final int from = from(m), to = to(m), pr = promo(m), fl = flag(m);
        final int p = b[from];
        int cap = b[to];
        uMove[sp] = m; uCastle[sp] = castle; uEp[sp] = ep; uHalf[sp] = half; uKey[sp] = key;
        key ^= ZC[castle];
        if (ep >= 0) key ^= ZE[ep & 7];
        key ^= Z[p][from];
        b[from] = 0;
        if ((fl & F_EP) != 0) {
            int cs = to + (side == 0 ? -16 : 16);
            cap = b[cs];
            key ^= Z[cap][cs];
            b[cs] = 0;
        } else if (cap != 0) {
            key ^= Z[cap][to];
        }
        uCap[sp] = cap;
        int placed = pr != 0 ? (pr | (side << 3)) : p;
        b[to] = placed;
        key ^= Z[placed][to];
        if ((fl & F_CASTLE) != 0) {
            int rf, rt;
            if ((to & 7) == 6) { rf = to + 1; rt = to - 1; } else { rf = to - 2; rt = to + 1; }
            int rook = b[rf];
            key ^= Z[rook][rf]; key ^= Z[rook][rt];
            b[rt] = rook; b[rf] = 0;
        }
        if ((p & 7) == K) ksq[side] = to;
        castle &= MASK[from] & MASK[to];
        ep = (fl & F_DBL) != 0 ? (from + to) >> 1 : -1;
        half = ((p & 7) == P || cap != 0) ? 0 : half + 1;
        side ^= 1;
        key ^= ZS;
        key ^= ZC[castle];
        if (ep >= 0) key ^= ZE[ep & 7];
        sp++;
        // ilay nanao hetsika: ny mpanjaka dia tsy tokony ho voakapoka
        if (attacked(ksq[side ^ 1], side)) { unmake(); return false; }
        return true;
    }

    public void unmake() {
        sp--;
        int m = uMove[sp];
        final int from = from(m), to = to(m), pr = promo(m), fl = flag(m);
        side ^= 1;
        int placed = b[to];
        int p = pr != 0 ? (P | (side << 3)) : placed;
        b[from] = p;
        int cap = uCap[sp];
        if ((fl & F_EP) != 0) {
            b[to] = 0;
            b[to + (side == 0 ? -16 : 16)] = cap;
        } else {
            b[to] = cap;
        }
        if ((fl & F_CASTLE) != 0) {
            int rf, rt;
            if ((to & 7) == 6) { rf = to + 1; rt = to - 1; } else { rf = to - 2; rt = to + 1; }
            b[rf] = b[rt]; b[rt] = 0;
        }
        if ((p & 7) == K) ksq[side] = from;
        castle = uCastle[sp]; ep = uEp[sp]; half = uHalf[sp]; key = uKey[sp];
    }

    public void makeNull() {
        uMove[sp] = 0; uCastle[sp] = castle; uEp[sp] = ep; uHalf[sp] = half; uKey[sp] = key; uCap[sp] = 0;
        if (ep >= 0) key ^= ZE[ep & 7];
        ep = -1; half++;
        side ^= 1; key ^= ZS;
        sp++;
    }

    public void unmakeNull() {
        sp--;
        side ^= 1;
        castle = uCastle[sp]; ep = uEp[sp]; half = uHalf[sp]; key = uKey[sp];
    }

    /** Toerana efa hita teo amin'ny tantara (hatramin'ny half-move farany). */
    public boolean repeated() {
        int lim = Math.min(half, sp);
        for (int i = 4; i <= lim; i += 2) if (uKey[sp - i] == key) return true;
        return false;
    }

    public boolean hasNonPawn(int c) {
        for (int s = 0; s < 128; s++) {
            if ((s & 0x88) != 0) { s += 7; continue; }
            int p = b[s];
            if (p != 0 && (p >> 3) == c) { int t = p & 7; if (t != P && t != K) return true; }
        }
        return false;
    }

    public int parseMove(String u) {
        if (u == null || u.length() < 4) return 0;
        int f = (u.charAt(1) - '1') * 16 + (u.charAt(0) - 'a');
        int t = (u.charAt(3) - '1') * 16 + (u.charAt(2) - 'a');
        int pr = 0;
        if (u.length() > 4) {
            switch (Character.toLowerCase(u.charAt(4))) { case 'n': pr = N; break; case 'b': pr = B; break; case 'r': pr = R; break; case 'q': pr = Q; break; default: break; }
        }
        int[] ms = new int[256];
        int n = genAll(ms);
        for (int i = 0; i < n; i++) {
            int mv = ms[i];
            if (from(mv) == f && to(mv) == t && promo(mv) == pr) {
                if (make(mv)) { unmake(); return mv; }
            }
        }
        return 0;
    }

    /** Fametrahana avy amin'ny FEN + tantara UCI avy amin'ny fiandohan'ny lalao (ho an'ny repetition). */
    public void setFenWithHistory(String fen, List<String> hist) {
        if (!setFen(fen)) throw new IllegalArgumentException("bad fen");
        if (hist == null || hist.isEmpty() || hist.size() > 1500) return;
        long target = key;
        int sideT = side;
        Pos q = new Pos();
        q.startPos();
        for (String u : hist) {
            int mv = q.parseMove(u);
            if (mv == 0 || !q.make(mv)) return;
        }
        if (q.key == target && q.side == sideT) {
            // adika ny stack ho an'ity toerana ity
            System.arraycopy(q.uKey, 0, uKey, 0, q.sp);
            System.arraycopy(q.uMove, 0, uMove, 0, q.sp);
            sp = q.sp;
            half = q.half;
            ep = q.ep; castle = q.castle;
        }
    }

    public long perft(int depth) {
        if (depth == 0) return 1;
        int[] ms = new int[256];
        int n = genAll(ms);
        long t = 0;
        for (int i = 0; i < n; i++) {
            if (!make(ms[i])) continue;
            t += depth == 1 ? 1 : perft(depth - 1);
            unmake();
        }
        return t;
    }
}
