package mg.chess.offline

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Bot iray ao anaty pack (aorian'ny fanamarinana); ny id dia atao vaovao rehefa ampidirina. */
data class PackBot(
    val name: String, val elo: Int, val bio: String, val color: Long?,
    val openings: List<String>, val lines: List<String>, val style: Style, val avatar: ByteArray?,
    val book: List<String> = emptyList()
)

/**
 * Pack bot (.kbot): rakitra ZIP misy `manifest.json` + `avatars/<n>.png` (azo zaraina toy ny mod).
 * Azo ampidirina koa ny JSON tsotra (bot tokana na manifest) - jereo BOT_FORMAT.md.
 * Fanamarinana feno rehetra: fetra habe, anarana, Elo, opening (ao amin'ny katalaogy ihany), andalana UCI, sary.
 */
object BotPack {
    const val FORMAT = "kajy-bot-pack"
    const val VERSION = 1
    const val EXT = "kbot"
    private const val MAX_BOTS = 100
    private const val MAX_ENTRY = 3L * 1024 * 1024
    private const val MAX_TOTAL = 24L * 1024 * 1024
    private const val MAX_ENTRIES = 300
    private val LINE_RE = Regex("^[WB]\\|[a-h][1-8][a-h][1-8][qrbn]?( [a-h][1-8][a-h][1-8][qrbn]?){0,39}$")

    /** Bot azo alaina (afa-tsy Stockfish MAX). Ny Elo ankehitriny (aorian'ny fifaninanana) no alaina. */
    fun exportable(): List<Bot> = BotRegistry.visible.filter { !it.isMax }

    private fun avatarBytes(ctx: Context, b: Bot): ByteArray? = try {
        if (b.custom) File(ctx.filesDir, "avatars/${b.id}.png").takeIf { it.exists() }?.readBytes()
        else ctx.assets.open("bots/${b.id}.png").use { it.readBytes() }
    } catch (_: Exception) { null }

    fun suggestedName(bots: List<Bot>): String =
        (if (bots.size == 1) "kajy-bot-" + ShareUtil.safeName(bots[0].name)
        else "kajy-bots-" + SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())) + ".$EXT"

    fun write(ctx: Context, bots: List<Bot>, os: OutputStream) {
        val arr = JSONArray()
        val avatars = ArrayList<Pair<String, ByteArray>>()
        bots.forEachIndexed { i, b ->
            val o = JSONObject()
            o.put("name", b.name); o.put("elo", b.elo); o.put("bio", b.bio); o.put("color", b.color)
            o.put("openings", JSONArray(b.openings)); o.put("lines", JSONArray(b.lines))
            if (b.book.isNotEmpty()) o.put("book", JSONArray(b.book))
            o.put("style", JSONObject().put("a", b.style.aggression).put("s", b.style.sacrifice)
                .put("d", b.style.defense).put("q", b.style.queen).put("t", b.style.trades))
            avatarBytes(ctx, b)?.let { o.put("avatar", "avatars/$i.png"); avatars.add("avatars/$i.png" to it) }
            arr.put(o)
        }
        val manifest = JSONObject().put("format", FORMAT).put("version", VERSION)
            .put("created", SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())).put("bots", arr)
        ZipOutputStream(os).use { z ->
            z.putNextEntry(ZipEntry("manifest.json")); z.write(manifest.toString(2).toByteArray()); z.closeEntry()
            for ((n, d) in avatars) { z.putNextEntry(ZipEntry(n)); z.write(d); z.closeEntry() }
        }
    }

    fun exportForShare(ctx: Context, bots: List<Bot>): File {
        val f = File(ShareUtil.sharedDir(ctx), suggestedName(bots))
        f.outputStream().use { write(ctx, bots, it) }
        return f
    }

    private fun readLimited(input: InputStream, limit: Long): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(16 * 1024)
        var total = 0L
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            total += n
            if (total > limit) throw IllegalArgumentException("Lehibe loatra ny rakitra")
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }

    /** Mamerina (lisitra, hadisoana). Raha misy hadisoana dia foana ny lisitra. */
    fun parse(input: InputStream): Pair<List<PackBot>, String?> {
        return try {
            val bytes = readLimited(input, MAX_TOTAL)
            if (bytes.isEmpty()) return emptyList<PackBot>() to "Foana ny rakitra"
            val files = HashMap<String, ByteArray>()
            val json: String
            if (bytes.size > 3 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()) {
                ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
                    var n = 0
                    while (true) {
                        val e = z.nextEntry ?: break
                        if (++n > MAX_ENTRIES) break
                        if (e.isDirectory) continue
                        files[e.name.replace('\\', '/')] = readLimited(z, MAX_ENTRY)
                        z.closeEntry()
                    }
                }
                val m = files["manifest.json"]
                    ?: files.entries.firstOrNull { it.key.endsWith(".json") && !it.key.contains('/') }?.value
                    ?: return emptyList<PackBot>() to "Tsy hita ny manifest.json ao anaty pack"
                json = String(m, Charsets.UTF_8)
            } else {
                json = String(bytes, Charsets.UTF_8).trim().removePrefix("﻿")
            }
            val root = JSONObject(json)
            val arr: JSONArray = when {
                root.has("bots") -> root.getJSONArray("bots")
                root.has("name") && root.has("elo") -> JSONArray().put(root)   // bot tokana
                else -> return emptyList<PackBot>() to "Tsy fantatra ny endrika (tsy misy \"bots\")"
            }
            if (arr.length() > MAX_BOTS) return emptyList<PackBot>() to "Be loatra ny bot (fetra $MAX_BOTS)"
            val out = ArrayList<PackBot>()
            for (i in 0 until arr.length()) parseBot(arr.optJSONObject(i), files)?.let { out.add(it) }
            if (out.isEmpty()) emptyList<PackBot>() to "Tsy nahita bot manan-kery ao anaty rakitra" else out to null
        } catch (e: Exception) {
            emptyList<PackBot>() to ("Rakitra tsy mety: " + (e.message ?: e.javaClass.simpleName))
        }
    }

    private fun parseBot(o: JSONObject?, files: Map<String, ByteArray>): PackBot? {
        if (o == null) return null
        val name = o.optString("name", "").trim().take(20)
        val elo = o.optInt("elo", -1)
        if (name.isEmpty() || elo !in 100..3200) return null
        fun strs(a: JSONArray?): List<String> = if (a == null) emptyList() else List(a.length()) { a.optString(it, "") }
        val openings = strs(o.optJSONArray("openings")).filter { OPENING_MAP.containsKey(it) }.distinct().take(12)
        val lines = strs(o.optJSONArray("lines")).filter { LINE_RE.matches(it) }.take(12)
        val book = strs(o.optJSONArray("book")).filter { mg.chess.offline.own.PgnBot.validEntry(it) }.take(mg.chess.offline.own.PgnBot.MAX_BOOK)
        val st = o.optJSONObject("style")
        fun v(k: String) = (st?.optInt(k, 50) ?: 50).coerceIn(0, 100)
        val style = Style(v("a"), v("s"), v("d"), v("q"), v("t"))
        val color = if (o.has("color")) (0xFF000000L or (o.optLong("color", 0L) and 0xFFFFFFL)) else null
        var avatar: ByteArray? = null
        val ref = o.optString("avatar", "").replace('\\', '/')
        if (ref.isNotEmpty()) avatar = files[ref]
        if (avatar == null) {
            val b64 = o.optString("avatarB64", "")
            if (b64.isNotEmpty() && b64.length <= 4_000_000) avatar = try { Base64.decode(b64, Base64.DEFAULT) } catch (_: Exception) { null }
        }
        return PackBot(name, elo, o.optString("bio", "").take(200), color, openings, lines, style, avatar, book)
    }

    private fun uniqueName(base: String, taken: MutableSet<String>): String {
        var n = base.take(20); var k = 2
        while (n.lowercase() in taken) { val suf = " ($k)"; n = base.take(20 - suf.length) + suf; k++ }
        taken.add(n.lowercase())
        return n
    }

    /** Ampidirina ho bot "nataonao". Mamerina ny isan'ny bot nampidirina. */
    fun commit(ctx: Context, list: List<PackBot>): Int {
        val taken = BotRegistry.visible.map { it.name.lowercase() }.toMutableSet()
        var n = 0
        for (p in list) {
            val bmp = p.avatar?.let { avatarFromBytes(it) }
            BotRegistry.save(ctx, null, uniqueName(p.name, taken), p.elo, bmp, p.openings, p.lines, p.style, p.color, p.bio, p.book)
            n++
        }
        return n
    }
}
