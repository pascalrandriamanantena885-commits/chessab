package mg.chess.offline

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.move.MoveList

/**
 * Miseho avy hatrany ny board sy ny lalao (tsy miandry ny analyse Stockfish) raha mbola mandeha ny review.
 * Rehefa vita ny analyse dia soloina ny ReviewContent feno (eval, hetsika Brilliant/Blunder...).
 */
@Composable
fun ReviewPreview(vm: ChessViewModel) {
    val n = vm.played.size
    val moves = remember(n) { vm.played.toList() }
    val sf = vm.startFen
    val fens = remember(moves, sf) {
        val b = Board().also { it.loadFromFen(sf) }
        val l = ArrayList<String>(); l.add(b.fen)
        for (m in moves) { b.doMove(m); l.add(b.fen) }
        l
    }
    val sans = remember(moves, sf) {
        val ml = MoveList(sf)
        for (m in moves) ml.add(m)
        ml.toSanArray().toList()
    }
    val ply = vm.reviewPly.coerceIn(0, moves.size)
    val board = remember(ply, fens) { Board().also { it.loadFromFen(fens[ply]) } }
    var flipView by remember { mutableStateOf(false) }
    val flip = (vm.vsBot && !vm.humanWhite) != flipView
    val last = if (ply > 0) moves[ply - 1].from to moves[ply - 1].to else null
    val cs = MaterialTheme.colorScheme

    LazyColumn(Modifier.fillMaxSize().padding(8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Game Review", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                LinearProgressIndicator(progress = { vm.reviewProgress }, modifier = Modifier.fillMaxWidth())
                Text(
                    "Mandinika ny lalao... ${(vm.reviewProgress * 100).toInt()}% (azonao jerena ny lalao mandritra izay)",
                    fontSize = 12.sp, color = cs.onSurfaceVariant
                )
            }
        }
        item { BoardView(pieceAt = { board.getPiece(it) }, flip = flip, last = last) }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Button({ vm.reviewPly = 0 }) { Text("|<") }
                Button({ if (ply > 0) vm.reviewPly = ply - 1 }) { Text("<") }
                Button({ flipView = !flipView }) { Icon(Icons.Rounded.SwapVert, "Flip board") }
                Button({ if (ply < moves.size) vm.reviewPly = ply + 1 }) { Text(">") }
                Button({ vm.reviewPly = moves.size }) { Text(">|") }
            }
        }
        movePairs(moves.size, sf) { idx, mod ->
            PlainMoveChip(sans.getOrElse(idx) { "" }, ply == idx + 1, mod) { vm.reviewPly = idx + 1 }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun PlainMoveChip(san: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Text(
        san, fontSize = 15.sp,
        modifier = modifier.clip(RoundedCornerShape(6.dp))
            .background(if (selected) Color(0x33888888) else Color.Transparent)
            .clickable { onClick() }.padding(8.dp)
    )
}
