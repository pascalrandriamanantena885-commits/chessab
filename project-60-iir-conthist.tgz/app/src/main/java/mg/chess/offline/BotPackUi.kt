package mg.chess.offline

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Bokotra "Import bot" / "Export bot" (rakitra .kbot) miaraka amin'ny dialog rehetra.
 * Ampiasaina ao amin'ny Settings sy ny lisitry ny bot.
 */
@Composable
fun BotPackRow(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var msg by remember { mutableStateOf("") }
    var preview by remember { mutableStateOf<List<PackBot>?>(null) }
    var showExport by remember { mutableStateOf(false) }
    val sel = remember { mutableStateListOf<String>() }
    val cs = MaterialTheme.colorScheme

    val opener = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val (list, err) = withContext(Dispatchers.IO) {
                try {
                    ctx.contentResolver.openInputStream(uri)?.use { BotPack.parse(it) }
                        ?: (emptyList<PackBot>() to "Tsy azo vakiana ny rakitra")
                } catch (e: Exception) { emptyList<PackBot>() to ("Tsy azo vakiana: " + (e.message ?: "")) }
            }
            if (err != null) { msg = err; preview = null } else { msg = ""; preview = list }
        }
    }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        val bots = BotPack.exportable().filter { it.id in sel }
        msg = try {
            ctx.contentResolver.openOutputStream(uri)?.use { BotPack.write(ctx, bots, it) }
            showExport = false
            "Voatahiry ny bot ${bots.size}."
        } catch (e: Exception) { "Tsy voatahiry: " + (e.message ?: "") }
    }

    Column(modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ opener.launch(arrayOf("*/*")) }) { Text("Import bot") }
            OutlinedButton({
                sel.clear()
                val all = BotPack.exportable()
                sel.addAll((all.filter { it.custom }.ifEmpty { all }).map { it.id })
                showExport = true
            }) { Text("Export bot") }
        }
        if (msg.isNotEmpty()) Text(msg, fontSize = 12.sp, color = cs.primary)
    }

    val pv = preview
    if (pv != null) {
        AlertDialog(
            onDismissRequest = { preview = null },
            title = { Text("Ampidirina ny bot ${pv.size}?") },
            text = {
                LazyColumn(Modifier.height(260.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(pv) { p ->
                        Column {
                            Text(p.name + "  ·  Elo ${p.elo}", fontWeight = FontWeight.Bold)
                            val ops = p.openings.mapNotNull { OPENING_MAP[it]?.name }
                            Text(
                                (if (ops.isEmpty()) "" else ops.joinToString(", ") + " · ") +
                                    (if (p.avatar != null) "misy sary" else "tsy misy sary"),
                                fontSize = 11.sp, color = cs.onSurfaceVariant
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button({
                    val n = BotPack.commit(ctx, pv)
                    msg = "Nampidirina ny bot $n. Hita ao amin'ny \"Nataoko\"."
                    preview = null
                }) { Text("Ampidiro") }
            },
            dismissButton = { TextButton({ preview = null }) { Text("Foano") } }
        )
    }

    if (showExport) {
        val all = BotPack.exportable()
        val chosen = all.filter { it.id in sel }
        AlertDialog(
            onDismissRequest = { showExport = false },
            title = { Text("Export bot (.kbot)") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Fidio ny bot (miaraka amin'ny sary sy ny fomba filalaovana):", fontSize = 12.sp, color = cs.onSurfaceVariant)
                    LazyColumn(Modifier.height(220.dp)) {
                        items(all, key = { it.id }) { b ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(b.id in sel, { on -> if (on) sel.add(b.id) else sel.remove(b.id) })
                                Text(b.name, Modifier.weight(1f), fontWeight = FontWeight.Bold, maxLines = 1)
                                Text("${b.elo}", fontSize = 12.sp, color = cs.primary)
                            }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button({
                            try {
                                val f = BotPack.exportForShare(ctx, chosen)
                                ShareUtil.share(ctx, f, "application/octet-stream", "Zarao ny bot")
                            } catch (e: Exception) { msg = "Tsy lasa ny fizarana: " + (e.message ?: "") }
                        }, enabled = chosen.isNotEmpty()) { Text("Zarao") }
                        OutlinedButton({ saver.launch(BotPack.suggestedName(chosen)) }, enabled = chosen.isNotEmpty()) { Text("Tehirizo") }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton({ showExport = false }) { Text("Akatony") } }
        )
    }
}
