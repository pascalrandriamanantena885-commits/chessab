package mg.chess.offline

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

/** Feo ao amin'ny lalao (toy ny chess.com: hetsika, capture, castling, check, checkmate...). */
enum class Sfx { MOVE, CAPTURE, CASTLE, CHECK, PROMOTE, MATE, START, END }

fun MoveKind.sfx(): Sfx = when (this) {
    MoveKind.MOVE -> Sfx.MOVE
    MoveKind.CAPTURE -> Sfx.CAPTURE
    MoveKind.CASTLE -> Sfx.CASTLE
    MoveKind.CHECK -> Sfx.CHECK
    MoveKind.PROMOTE -> Sfx.PROMOTE
    MoveKind.MATE -> Sfx.MATE
}

/**
 * Feo noforonina amin'ny code (tsy mila rakitra audio ary tsy mampiasa feo an'olon-kafa):
 * "tok" kitay (feo + resaka manify), mizara roa ny castling, kintana avo ny check, hira midina ny mate.
 * Voatahiry ao anaty AudioTrack static (miaina ho azy, tsy misy latency).
 */
class SoundFx {
    private val tracks = HashMap<Sfx, AudioTrack>()
    @Volatile private var ready = false

    init {
        // Foronina ao amin'ny thread hafa mba tsy hanakana ny fanokafana ny app
        thread(name = "sfx-init", isDaemon = true) {
            try {
                for (s in Sfx.values()) {
                    val pcm = synth(s)
                    val t = AudioTrack.Builder()
                        .setAudioAttributes(
                            AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_GAME)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
                        )
                        .setAudioFormat(
                            AudioFormat.Builder().setSampleRate(RATE)
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                        )
                        .setBufferSizeInBytes(pcm.size * 2)
                        .setTransferMode(AudioTrack.MODE_STATIC).build()
                    t.write(pcm, 0, pcm.size)
                    synchronized(tracks) { tracks[s] = t }
                }
                ready = true
            } catch (_: Exception) { /* tsy misy feo fa tsy mandrava ny app */ }
        }
    }

    fun play(s: Sfx) {
        if (!ready) return
        try {
            val t = synchronized(tracks) { tracks[s] } ?: return
            if (t.playState != AudioTrack.PLAYSTATE_STOPPED) t.stop()
            t.reloadStaticData()
            t.play()
        } catch (_: Exception) {}
    }

    fun release() {
        ready = false
        synchronized(tracks) { tracks.values.forEach { try { it.release() } catch (_: Exception) {} }; tracks.clear() }
    }

    companion object {
        const val RATE = 22050

        /** "Tok" kitay: feo miha-mitsika + resaka kely ny fiandohana. */
        private fun knock(buf: FloatArray, startMs: Int, amp: Float, f: Float, decayMs: Float, noise: Float) {
            val s0 = startMs * RATE / 1000
            val n = min(buf.size - s0, (decayMs * 6f * RATE / 1000f).toInt())
            if (n <= 0) return
            val rnd = java.util.Random(7L + startMs)
            var lp = 0f
            for (i in 0 until n) {
                val t = i / RATE.toFloat()
                val env = exp(-t / (decayMs / 1000f))
                val body = sin(2.0 * PI * f * t).toFloat() * 0.65f +
                    sin(2.0 * PI * f * 2.4 * t).toFloat() * 0.25f * exp(-t / (decayMs / 2000f))
                lp += 0.35f * ((rnd.nextFloat() * 2f - 1f) - lp)
                val click = lp * exp(-t / 0.004f) * noise
                buf[s0 + i] += amp * (body * env + click)
            }
        }

        /** Kintana: sine + harmonika, fiandohana malefaka. */
        private fun bell(buf: FloatArray, startMs: Int, f: Float, decayMs: Float, amp: Float) {
            val s0 = startMs * RATE / 1000
            val n = min(buf.size - s0, (decayMs * 5f * RATE / 1000f).toInt())
            for (i in 0 until n) {
                val t = i / RATE.toFloat()
                val att = min(1f, t / 0.004f)
                val env = att * exp(-t / (decayMs / 1000f))
                val v = sin(2.0 * PI * f * t).toFloat() + 0.3f * sin(2.0 * PI * f * 2.0 * t).toFloat()
                buf[s0 + i] += amp * env * v
            }
        }

        private fun pcm(buf: FloatArray): ShortArray {
            // Fanamaivanana: tsy hihoatra ny 0.9 (tsy misy clipping)
            var peak = 0f
            for (v in buf) peak = maxOf(peak, kotlin.math.abs(v))
            val g = if (peak > 0.9f) 0.9f / peak else 1f
            // Fanalefahana ny farany (tsy misy "click")
            val fade = (0.01f * RATE).toInt().coerceAtMost(buf.size)
            return ShortArray(buf.size) { i ->
                val k = if (i >= buf.size - fade) (buf.size - i) / fade.toFloat() else 1f
                (buf[i] * g * k * 32767f).toInt().coerceIn(-32767, 32767).toShort()
            }
        }

        fun synth(s: Sfx): ShortArray {
            fun b(ms: Int) = FloatArray(ms * RATE / 1000)
            return when (s) {
                Sfx.MOVE -> b(160).also { knock(it, 0, 0.8f, 190f, 55f, 0.5f) }
                Sfx.CAPTURE -> b(260).also {
                    knock(it, 0, 1.0f, 150f, 80f, 1.0f); knock(it, 35, 0.7f, 215f, 60f, 0.8f)
                }
                Sfx.CASTLE -> b(340).also {
                    knock(it, 0, 0.8f, 185f, 55f, 0.5f); knock(it, 125, 0.85f, 235f, 55f, 0.5f)
                }
                Sfx.CHECK -> b(520).also {
                    knock(it, 0, 0.9f, 170f, 60f, 0.6f)
                    bell(it, 70, 880f, 90f, 0.30f); bell(it, 70, 1318f, 70f, 0.18f)
                }
                Sfx.PROMOTE -> b(700).also {
                    knock(it, 0, 0.8f, 190f, 55f, 0.5f)
                    bell(it, 90, 660f, 70f, 0.28f); bell(it, 190, 880f, 70f, 0.28f); bell(it, 290, 1318f, 120f, 0.30f)
                }
                Sfx.MATE -> b(1500).also {
                    knock(it, 0, 1.0f, 140f, 90f, 1.0f)
                    bell(it, 120, 784f, 110f, 0.30f); bell(it, 330, 622f, 110f, 0.30f); bell(it, 540, 523f, 260f, 0.32f)
                }
                Sfx.START -> b(380).also {
                    knock(it, 0, 0.55f, 260f, 40f, 0.4f); knock(it, 150, 0.7f, 300f, 45f, 0.4f)
                }
                Sfx.END -> b(1000).also {
                    bell(it, 0, 523f, 150f, 0.30f); bell(it, 220, 392f, 250f, 0.32f)
                }
            }.let { pcm(it) }
        }
    }
}
