package mg.chess.offline

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import kotlin.math.roundToInt
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Settings = hub misy sokajy (jereo SettingsHub.kt); ny fitantanana bot dia ao amin'ny SettingsBots.kt. */
@Composable
fun SettingsScreen(vm: ChessViewModel) = SettingsHub(vm)

@Composable
private fun StyleSlider(label: String, low: String, high: String, value: Int, onChange: (Int) -> Unit) {
    Column {
        Row {
            Text(label, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text("$value", fontSize = 13.sp)
        }
        Slider(value.toFloat(), { onChange(it.roundToInt()) }, valueRange = 0f..100f)
        Row {
            Text(low, fontSize = 10.sp, modifier = Modifier.weight(1f))
            Text(high, fontSize = 10.sp)
        }
    }
}

private val STYLE_PRESETS = listOf(
    "Mpanao sacrifice" to Style(aggression = 85, sacrifice = 100, defense = 25, queen = 60, trades = 30),
    "Mpiaro" to Style(aggression = 20, sacrifice = 10, defense = 100, queen = 30, trades = 65),
    "Queen aloha" to Style(aggression = 65, queen = 100),
    "Mpanafika" to Style(aggression = 95, sacrifice = 65, defense = 30, trades = 35),
    "Positional" to Style(aggression = 35, sacrifice = 15, defense = 60, queen = 25, trades = 60),
    "Mahazatra" to Style(),
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BotEditDialog(existing: Bot?, asCopy: Boolean = false, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val target = if (asCopy) null else existing
    var name by remember { mutableStateOf(if (asCopy) (existing?.name ?: "") + " 2" else existing?.name ?: "") }
    var eloText by remember { mutableStateOf((existing?.elo ?: 1200).toString()) }
    var avatar by remember { mutableStateOf<Bitmap?>(null) }
    var openings by remember { mutableStateOf(existing?.openings ?: emptyList()) }
    var lines by remember { mutableStateOf(existing?.lines ?: emptyList()) }
    var style by remember { mutableStateOf(existing?.style ?: Style()) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) avatar = decodeAvatar(ctx, uri)
    }
    val elo = eloText.toIntOrNull()
    val valid = name.isNotBlank() && elo != null && elo in 100..3200
    val av = avatar

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (asCopy) "Kopia an'ny bot" else if (existing == null) "Bot vaovao" else "Ovay ny bot") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (av != null) {
                        Image(av.asImageBitmap(), null, Modifier.size(64.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                    } else if (existing != null) {
                        BotAvatar(existing, 64.dp)
                    } else {
                        Box(Modifier.size(64.dp).clip(CircleShape).background(Color(0xFF90A4AE)), contentAlignment = Alignment.Center) {
                            Text("?", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    OutlinedButton({ picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text("Fidio sary (gallerie)") }
                }
                OutlinedTextField(
                    name, { name = it.take(20) }, label = { Text("Anarana") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    eloText, { eloText = it.filter { c -> c.isDigit() }.take(4) },
                    label = { Text("Elo (100-3200)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Stockfish 19 no mampihatra ny Elo (UCI_Elo 1320-3190). Ambanin'ny 1320: fikarohana voafetra + hadisoana mitovy amin'ny olona. 3200 = hery feno.", fontSize = 12.sp)

                Text("Fomba filalaovana", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for ((label, st) in STYLE_PRESETS) {
                        FilterChip(style == st, { style = st }, { Text(label, fontSize = 12.sp) })
                    }
                }
                StyleSlider("Fanafihana", "milamina", "mpanafika", style.aggression) { style = style.copy(aggression = it) }
                StyleSlider("Sacrifice (gambit)", "tsy manao", "tia be", style.sacrifice) { style = style.copy(sacrifice = it) }
                StyleSlider("Fiarovana", "tsy miaro", "tia midefendre", style.defense) { style = style.copy(defense = it) }
                StyleSlider("Queen aloha", "tsy mamoaka", "mamoaka aloha", style.queen) { style = style.copy(queen = it) }
                StyleSlider("Fifanakalozana", "misoroka", "tia", style.trades) { style = style.copy(trades = it) }

                Text("Opening (repertoire)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("Fotsy", fontSize = 13.sp)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (o in OPENINGS.filter { it.white }) {
                        FilterChip(o.id in openings, {
                            openings = if (o.id in openings) openings - o.id else openings + o.id
                        }, { Text(o.name, fontSize = 12.sp) })
                    }
                }
                Text("Mainty", fontSize = 13.sp)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (o in OPENINGS.filter { !it.white }) {
                        FilterChip(o.id in openings, {
                            openings = if (o.id in openings) openings - o.id else openings + o.id
                        }, { Text(o.name, fontSize = 12.sp) })
                    }
                }
                if (lines.isNotEmpty()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Opening avy amin'ny lalao: ${lines.size}", fontSize = 13.sp, modifier = Modifier.weight(1f))
                        TextButton({ lines = emptyList() }) { Text("Esory") }
                    }
                }
                Text("Ny Stockfish ihany no misafidy ny hetsika; ny opening sy ny fomba no manosika azy hisafidy hetsika mitovy lanja, ka tsy simba ny Elo.", fontSize = 11.sp)
            }
        },
        confirmButton = {
            Button(
                onClick = { BotRegistry.save(ctx, target, name, elo ?: 1200, avatar, openings, lines, style); onDismiss() },
                enabled = valid
            ) { Text("Tehirizo") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Foano") } }
    )
}
