package mg.chess.offline

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.border
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.PieceType
import com.github.bhlangonijr.chesslib.Rank
import com.github.bhlangonijr.chesslib.Side
import com.github.bhlangonijr.chesslib.Square
import kotlin.math.roundToInt

private fun pieceLetter(p: Piece): String = when (p.pieceType) {
    PieceType.KING -> "k"
    PieceType.QUEEN -> "q"
    PieceType.ROOK -> "r"
    PieceType.BISHOP -> "b"
    PieceType.KNIGHT -> "n"
    else -> "p"
}

private fun pieceKey(p: Piece) = (if (p.pieceSide == Side.WHITE) "w" else "b") + pieceLetter(p)

private fun glyph(p: Piece): String = when (p.pieceType) {
    PieceType.KING -> "♚"
    PieceType.QUEEN -> "♛"
    PieceType.ROOK -> "♜"
    PieceType.BISHOP -> "♝"
    PieceType.KNIGHT -> "♞"
    else -> "♟"
} + "\uFE0E"

/** Kare eo ambanin'ny porofo (px) -> Square, araka ny flip. null raha ivelan'ny board. */
private fun squareAt(p: Offset, cellPx: Float, flip: Boolean): Square? {
    if (cellPx <= 0f || p.x < 0f || p.y < 0f) return null
    val col = (p.x / cellPx).toInt()
    val row = (p.y / cellPx).toInt()
    if (col !in 0..7 || row !in 0..7) return null
    val rank = if (flip) row else 7 - row
    val file = if (flip) 7 - col else col
    return Square.encode(Rank.allRanks[rank], com.github.bhlangonijr.chesslib.File.allFiles[file])
}

/** Famaritana an-tsoratra ho an'ny TalkBack: toerana ny piece rehetra. */
private fun describeBoard(pieceAt: (Square) -> Piece): String {
    val w = ArrayList<String>()
    val b = ArrayList<String>()
    for (sq in Square.values()) {
        if (sq == Square.NONE) continue
        val p = pieceAt(sq)
        if (p == Piece.NONE) continue
        val s = pieceLetter(p).uppercase() + sq.toString().lowercase()
        if (p.pieceSide == Side.WHITE) w.add(s) else b.add(s)
    }
    return "Chess board. Fotsy: ${w.joinToString(" ")}. Mainty: ${b.joinToString(" ")}"
}

/**
 * Board. Tsindrio ny kare (onSquare) na tarazo ny piece (onDragStart -> true raha azo tarazina,
 * onDrop(from, to) rehefa avela). premove = hetsika voasokajy, pending = hetsika miandry fanamafisana.
 */
@Composable
fun BoardView(
    pieceAt: (Square) -> Piece,
    flip: Boolean,
    modifier: Modifier = Modifier,
    selected: Square? = null,
    targets: List<Square> = emptyList(),
    last: Pair<Square, Square>? = null,
    hint: Pair<Square, Square>? = null,
    premove: Pair<Square, Square>? = null,
    pending: Pair<Square, Square>? = null,
    onSquare: ((Square) -> Unit)? = null,
    onDragStart: ((Square) -> Boolean)? = null,
    onDrop: ((Square, Square) -> Unit)? = null,
    /** Badge sokajy (brilliant, blunder...) eo amin'ny piece nandeha: toy ny chess.com. */
    badge: Pair<Square, Cls>? = null,
) {
    val theme = BoardStyle.board
    val useImages = theme.light == null
    val boardImg = if (useImages) Sprites.board else null
    val lightColor = theme.light ?: Color(0xFFEEEED2)
    val darkColor = theme.dark ?: Color(0xFF769656)

    var dragFrom by remember { mutableStateOf<Square?>(null) }
    var dragPos by remember { mutableStateOf<Offset?>(null) }
    val curSquare by rememberUpdatedState(onSquare)
    val curStart by rememberUpdatedState(onDragStart)
    val curDrop by rememberUpdatedState(onDrop)
    val curFlip by rememberUpdatedState(flip)

    BoxWithConstraints(
        modifier.fillMaxWidth().aspectRatio(1f)
            .semantics { contentDescription = describeBoard(pieceAt) }
    ) {
        val cell = maxWidth / 8
        val cellPx = constraints.maxWidth / 8f
        val gesture = if (onSquare != null) {
            Modifier.pointerInput(cellPx) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val startSq = squareAt(down.position, cellPx, curFlip)
                    var dragging = false
                    var moved = false
                    while (true) {
                        val event = awaitPointerEvent()
                        val ch = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (!ch.pressed) {
                            if (dragging) {
                                val from = dragFrom
                                val to = squareAt(ch.position, cellPx, curFlip)
                                dragFrom = null; dragPos = null
                                if (from != null && to != null) curDrop?.invoke(from, to)
                            } else if (!moved && startSq != null) {
                                curSquare?.invoke(startSq)
                            }
                            break
                        }
                        if (!dragging && !moved && (ch.position - down.position).getDistance() > viewConfiguration.touchSlop) {
                            moved = true
                            if (startSq != null && curStart?.invoke(startSq) == true) {
                                dragging = true
                                dragFrom = startSq
                            }
                        }
                        if (dragging) {
                            dragPos = ch.position
                            ch.consume()
                        }
                    }
                    dragFrom = null; dragPos = null
                }
            }
        } else Modifier

        Box(Modifier.fillMaxSize().then(gesture)) {
            if (boardImg != null) {
                Image(boardImg, null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
            }
            val hover = dragPos?.let { squareAt(it, cellPx, flip) }
            Column {
                for (r in 0..7) Row {
                    for (f in 0..7) {
                        val rank = if (flip) r else 7 - r
                        val file = if (flip) 7 - f else f
                        val sq = Square.encode(Rank.allRanks[rank], com.github.bhlangonijr.chesslib.File.allFiles[file])
                        val dark = (rank + file) % 2 == 0
                        val tile = if (useImages) (if (dark) Sprites.dark else Sprites.light) else null
                        val bg = when {
                            boardImg != null || tile != null -> Color.Transparent
                            dark -> darkColor
                            else -> lightColor
                        }
                        Box(Modifier.size(cell).background(bg), contentAlignment = Alignment.Center) {
                            if (boardImg == null && tile != null) {
                                Image(tile, null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                            }
                            if (sq == selected) {
                                Box(Modifier.fillMaxSize().background(Color(0x99F6F669)))
                            } else if (last != null && (sq == last.first || sq == last.second)) {
                                Box(Modifier.fillMaxSize().background(Color(0x66F6F669)))
                            }
                            if (hint != null && (sq == hint.first || sq == hint.second)) {
                                Box(Modifier.fillMaxSize().background(Color(0x6600A0FF)))
                            }
                            if (premove != null && (sq == premove.first || sq == premove.second)) {
                                Box(Modifier.fillMaxSize().background(Color(0x88E53935)))
                            }
                            if (pending != null && (sq == pending.first || sq == pending.second)) {
                                Box(Modifier.fillMaxSize().background(Color(0x8866BB6A)))
                            }
                            if (hover != null && sq == hover && dragFrom != null) {
                                Box(Modifier.fillMaxSize().background(Color(0x44FFFFFF)))
                            }
                            val p = pieceAt(sq)
                            if (p != Piece.NONE && sq != dragFrom) PieceIcon(p, cell * 0.92f)
                            if (badge != null && sq == badge.first) {
                                Box(
                                    Modifier.align(Alignment.TopEnd).offset(y = -(cell * 0.06f)).size(cell * 0.46f)
                                        .clip(CircleShape).background(Color(badge.second.color))
                                        .border(1.5.dp, Color.White, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        badge.second.sym, color = Color.White, fontWeight = FontWeight.Black,
                                        fontSize = (cell.value * 0.46f * 0.52f).sp, maxLines = 1
                                    )
                                }
                            }
                            if (sq in targets) {
                                Box(Modifier.size(cell / 3).clip(CircleShape).background(Color(0x88000000)))
                            }
                        }
                    }
                }
            }
            // Piece voatarika: manaraka ny rantsantanana, miakatra kely mba ho hita
            val df = dragFrom
            val dp = dragPos
            if (df != null && dp != null) {
                val p = pieceAt(df)
                if (p != Piece.NONE) {
                    val sizePx = cellPx * 1.35f
                    Box(
                        Modifier
                            .offset { IntOffset((dp.x - sizePx / 2f).roundToInt(), (dp.y - sizePx * 0.85f).roundToInt()) }
                            .size(cell * 1.35f)
                    ) { PieceIcon(p, cell * 1.35f) }
                }
            }
        }
    }
}

@Composable
fun PieceIcon(p: Piece, size: Dp) {
    val style = BoardStyle.piece
    val white = p.pieceSide == Side.WHITE
    val bmp = if (style.glyph) null else Sprites.pieces[pieceKey(p)]
    if (bmp != null) {
        Image(
            bmp, null, Modifier.size(size), contentScale = ContentScale.Fit,
            colorFilter = if (white) style.whiteFilter else style.blackFilter
        )
    } else {
        Text(
            glyph(p), fontSize = (size.value * 0.85f).sp,
            color = if (white) Color.White else Color.Black,
            style = TextStyle(shadow = Shadow(if (white) Color.Black else Color.White, Offset(0f, 0f), 6f))
        )
    }
}
