package mg.chess.offline

import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.PieceType
import com.github.bhlangonijr.chesslib.Side
import com.github.bhlangonijr.chesslib.Square
import com.github.bhlangonijr.chesslib.move.Move
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.random.Random

/** Fomba filalaovana: 0..100, 50 = tsy miandany. 100 = tena tia, 0 = misoroka. */
data class Style(
    val aggression: Int = 50,   // check, fandraisana, fandroaka mankany amin'ny mpanohitra
    val sacrifice: Int = 50,    // sombin-javatra atao sorona (gambit)
    val defense: Int = 50,      // castle, fihemorana, fiarovana
    val queen: Int = 50,        // mamoaka queen aloha
    val trades: Int = 50        // fifanakalozana piece
) {
    val neutral: Boolean get() = aggression == 50 && sacrifice == 50 && defense == 50 && queen == 50 && trades == 50
}

/** white = true: opening ho an'ny Fotsy; false: ho an'ny Mainty. lines = hetsika UCI (fotsy+mainty miandalana). */
class Opening(val id: String, val name: String, val white: Boolean, vararg raw: String) {
    val lines: List<List<String>> = raw.map { it.trim().split(" ") }
}

val OPENINGS: List<Opening> = listOf(
    // ---------- Fotsy ----------
    Opening("italian", "Italian Game", true,
        "e2e4 e7e5 g1f3 b8c6 f1c4 f8c5 c2c3 g8f6 d2d3 d7d6",
        "e2e4 e7e5 g1f3 b8c6 f1c4 g8f6 d2d3 f8c5 c2c3 d7d6",
        "e2e4 e7e5 g1f3 b8c6 f1c4 g8f6 f3g5 d7d5 e4d5 c6a5 c4b5 c7c6"),
    Opening("ruy", "Ruy Lopez", true,
        "e2e4 e7e5 g1f3 b8c6 f1b5 a7a6 b5a4 g8f6 e1g1 f8e7 f1e1 b7b5 a4b3 d7d6 c2c3 e8g8",
        "e2e4 e7e5 g1f3 b8c6 f1b5 g8f6 e1g1 f6e4 d2d4 e4d6 b5c6 d7c6 d4e5 d6f5"),
    Opening("scotch", "Scotch Game", true,
        "e2e4 e7e5 g1f3 b8c6 d2d4 e5d4 f3d4 g8f6 d4c6 b7c6 e4e5 d8e7 d1e2 f6d5"),
    Opening("kingsgambit", "King's Gambit", true,
        "e2e4 e7e5 f2f4 e5f4 g1f3 g7g5 h2h4 g5g4 f3e5 g8f6",
        "e2e4 e7e5 f2f4 e5f4 f1c4 d8h4 e1f1 g8f6",
        "e2e4 e7e5 f2f4 d7d5 e4d5 e5e4 d2d3 g8f6 d3e4 f6e4"),
    Opening("vienna", "Vienna Gambit", true,
        "e2e4 e7e5 b1c3 g8f6 f2f4 d7d5 f4e5 f6e4 g1f3 f8e7"),
    Opening("evans", "Evans Gambit", true,
        "e2e4 e7e5 g1f3 b8c6 f1c4 f8c5 b2b4 c5b4 c2c3 b4a5 d2d4 e5d4 e1g1 d4c3"),
    Opening("danish", "Danish Gambit", true,
        "e2e4 e7e5 d2d4 e5d4 c2c3 d4c3 f1c4 c3b2 c1b2"),
    Opening("morra", "Smith-Morra Gambit", true,
        "e2e4 c7c5 d2d4 c5d4 c2c3 d4c3 b1c3 b8c6 g1f3 d7d6 f1c4 e7e6"),
    Opening("wsicilian", "Open Sicilian", true,
        "e2e4 c7c5 g1f3 d7d6 d2d4 c5d4 f3d4 g8f6 b1c3 a7a6",
        "e2e4 c7c5 g1f3 b8c6 d2d4 c5d4 f3d4 g8f6 b1c3 e7e5",
        "e2e4 c7c5 c2c3 g8f6 e4e5 f6d5 d2d4 c5d4 g1f3 b8c6"),
    Opening("london", "London System", true,
        "d2d4 d7d5 c1f4 g8f6 e2e3 c7c5 c2c3 b8c6 g1f3 e7e6",
        "d2d4 g8f6 c1f4 e7e6 e2e3 f8e7 g1f3 e8g8"),
    Opening("qgambit", "Queen's Gambit", true,
        "d2d4 d7d5 c2c4 e7e6 b1c3 g8f6 c1g5 f8e7 e2e3 e8g8 g1f3 b8d7",
        "d2d4 d7d5 c2c4 d5c4 g1f3 g8f6 e2e3 e7e6 f1c4 c7c5",
        "d2d4 d7d5 c2c4 c7c6 g1f3 g8f6 b1c3 d5c4 a2a4 c8f5"),
    Opening("english", "English Opening", true,
        "c2c4 e7e5 b1c3 g8f6 g1f3 b8c6 g2g3 d7d5 c4d5 f6d5",
        "c2c4 g8f6 b1c3 e7e6 g1f3 d7d5 d2d4 f8e7",
        "c2c4 c7c5 g1f3 g8f6 b1c3 b8c6 g2g3 g7g6 f1g2 f8g7"),
    Opening("reti", "Réti Opening", true,
        "g1f3 d7d5 g2g3 g8f6 f1g2 e7e6 e1g1 f8e7 d2d4 e8g8"),

    // ---------- Mainty ----------
    Opening("french", "French Defence", false,
        "e2e4 e7e6 d2d4 d7d5 b1c3 g8f6 c1g5 f8e7 e4e5 f6d7 g5e7 d8e7",
        "e2e4 e7e6 d2d4 d7d5 b1c3 f8b4 e4e5 c7c5 a2a3 b4c3 b2c3 g8e7",
        "e2e4 e7e6 d2d4 d7d5 e4e5 c7c5 c2c3 b8c6 g1f3 d8b6",
        "e2e4 e7e6 d2d4 d7d5 b1d2 g8f6 e4e5 f6d7 f1d3 c7c5"),
    Opening("caro", "Caro-Kann", false,
        "e2e4 c7c6 d2d4 d7d5 b1c3 d5e4 c3e4 c8f5 e4g3 f5g6 h2h4 h7h6 g1f3 b8d7",
        "e2e4 c7c6 d2d4 d7d5 e4e5 c8f5 g1f3 e7e6 f1e2 c6c5"),
    Opening("scandi", "Scandinavian", false,
        "e2e4 d7d5 e4d5 d8d5 b1c3 d5a5 d2d4 g8f6 g1f3 c7c6 f1c4 c8f5",
        "e2e4 d7d5 e4d5 g8f6 d2d4 f6d5 g1f3 g7g6 f1e2 f8g7"),
    Opening("najdorf", "Sicilian Najdorf", false,
        "e2e4 c7c5 g1f3 d7d6 d2d4 c5d4 f3d4 g8f6 b1c3 a7a6 c1e3 e7e5 d4b3 c8e6"),
    Opening("dragon", "Sicilian Dragon", false,
        "e2e4 c7c5 g1f3 d7d6 d2d4 c5d4 f3d4 g8f6 b1c3 g7g6 c1e3 f8g7 f2f3 e8g8"),
    Opening("taimanov", "Sicilian Taimanov", false,
        "e2e4 c7c5 g1f3 e7e6 d2d4 c5d4 f3d4 b8c6 b1c3 d8c7 c1e3 a7a6"),
    Opening("pirc", "Pirc / Modern", false,
        "e2e4 d7d6 d2d4 g8f6 b1c3 g7g6 g1f3 f8g7 f1e2 e8g8 e1g1 c7c6",
        "e2e4 g7g6 d2d4 f8g7 b1c3 d7d6 g1f3 g8f6"),
    Opening("alekhine", "Alekhine's Defence", false,
        "e2e4 g8f6 e4e5 f6d5 d2d4 d7d6 g1f3 c8g4 f1e2 e7e6"),
    Opening("petroff", "Petroff Defence", false,
        "e2e4 e7e5 g1f3 g8f6 f3e5 d7d6 e5f3 f6e4 d2d4 d6d5 f1d3 f8e7"),
    Opening("e5", "Open Game (1...e5)", false,
        "e2e4 e7e5 g1f3 b8c6 f1b5 a7a6 b5a4 g8f6 e1g1 f8e7",
        "e2e4 e7e5 g1f3 b8c6 f1c4 f8c5 c2c3 g8f6 d2d3 d7d6",
        "e2e4 e7e5 g1f3 b8c6 d2d4 e5d4 f3d4 g8f6 d4c6 b7c6 e4e5 d8e7"),
    Opening("kid", "King's Indian", false,
        "d2d4 g8f6 c2c4 g7g6 b1c3 f8g7 e2e4 d7d6 g1f3 e8g8 f1e2 e7e5",
        "c2c4 g8f6 b1c3 g7g6 e2e4 d7d6 d2d4 f8g7 g1f3 e8g8",
        "g1f3 g8f6 c2c4 g7g6 b1c3 f8g7 e2e4 d7d6 d2d4 e8g8"),
    Opening("grunfeld", "Grünfeld Defence", false,
        "d2d4 g8f6 c2c4 g7g6 b1c3 d7d5 c4d5 f6d5 e2e4 d5c3 b2c3 f8g7"),
    Opening("nimzo", "Nimzo-Indian", false,
        "d2d4 g8f6 c2c4 e7e6 b1c3 f8b4 e2e3 e8g8 f1d3 d7d5 g1f3 c7c5"),
    Opening("qid", "Queen's Indian", false,
        "d2d4 g8f6 c2c4 e7e6 g1f3 b7b6 g2g3 c8b7 f1g2 f8e7 e1g1 e8g8"),
    Opening("qgd", "Queen's Gambit Declined", false,
        "d2d4 d7d5 c2c4 e7e6 b1c3 g8f6 c1g5 f8e7 e2e3 e8g8 g1f3 h7h6"),
    Opening("slav", "Slav Defence", false,
        "d2d4 d7d5 c2c4 c7c6 g1f3 g8f6 b1c3 d5c4 a2a4 c8f5 e2e3 e7e6 f1c4 f8b4"),
    Opening("dutch", "Dutch Defence", false,
        "d2d4 f7f5 g2g3 g8f6 f1g2 e7e6 g1f3 f8e7 e1g1 e8g8"),
    Opening("budapest", "Budapest Gambit", false,
        "d2d4 g8f6 c2c4 e7e5 d4e5 f6g4 c1f4 b8c6 g1f3 f8b4"),
    Opening("albin", "Albin Countergambit", false,
        "d2d4 d7d5 c2c4 e7e5 d4e5 d5d4 g1f3 b8c6 g2g3 c8e6"),
)

val OPENING_MAP: Map<String, Opening> = OPENINGS.associateBy { it.id }

data class MoveFeat(
    val capture: Boolean, val check: Boolean, val sacrifice: Boolean, val queenEarly: Boolean,
    val defensive: Boolean, val trade: Boolean, val advance: Boolean,
    /** Piece (tsy pion/mpanjaka) mankany akaikin'ny mpanjakan'ny mpanohitra (<= 2 kare). */
    val kingAttack: Boolean = false,
    /** Pion miroso mankany amin'ny mpanjaka mpanohitra efa nanao castle (avo >= rank 4). */
    val pawnStorm: Boolean = false
)

object Personality {
    private fun t(v: Int): Double = (v.coerceIn(0, 100) - 50) / 50.0

    /** Opening book: hetsika manaraka raha mifanaraka amin'ny tantara ny andalana iray. */
    fun bookMove(bot: Bot, history: List<String>, legal: Set<String>): String? {
        if (bot.openings.isEmpty() && bot.lines.isEmpty()) return null
        if (history.size > 30) return null
        val white = history.size % 2 == 0
        val cands = ArrayList<String>()
        fun consider(line: List<String>) {
            if (line.size > history.size) {
                var ok = true
                for (i in history.indices) if (!line[i].equals(history[i], true)) { ok = false; break }
                if (ok) cands.add(line[history.size].lowercase())
            }
        }
        for (id in bot.openings) {
            val o = OPENING_MAP[id] ?: continue
            if (o.white != white) continue
            for (l in o.lines) consider(l)
        }
        for (raw in bot.lines) {
            // "W|e2e4 e7e5 ..." na "B|..."
            val p = raw.split("|")
            if (p.size != 2) continue
            if ((p[0] == "W") != white) continue
            consider(p[1].trim().split(" "))
        }
        val good = cands.filter { it in legal }
        if (good.isEmpty()) return null
        return good[Random.nextInt(good.size)]
    }

    /** Toetran'ny hetsika (alohan'ny hetsika): board = toe-javatra alohan'ny hetsika. */
    fun feat(pre: Board, mv: Move, ply: Int): MoveFeat {
        val moved = pre.getPiece(mv.from)
        val target = pre.getPiece(mv.to)
        val mover = pre.sideToMove
        val pawn = moved.pieceType == PieceType.PAWN
        val capture = target != Piece.NONE || (pawn && mv.from.file != mv.to.file)
        val fromR = mv.from.rank.ordinal
        val toR = mv.to.rank.ordinal
        val fwd = if (mover == Side.WHITE) toR - fromR else fromR - toR
        val ownR = if (mover == Side.WHITE) toR else 7 - toR
        val castle = moved.pieceType == PieceType.KING && abs(mv.to.file.ordinal - mv.from.file.ordinal) == 2
        val advance = fwd > 0 && ownR >= 4
        val defensive = castle || (fwd < 0 && !pawn && !capture)
        val trade = capture && pv(target) >= 3 && pv(moved) >= 3 && abs(pv(target) - pv(moved)) <= 1
        val queenEarly = moved.pieceType == PieceType.QUEEN && ply < 16
        val sac = isSacrifice(pre, mv)
        val oppKing = pre.getKingSquare(if (mover == Side.WHITE) Side.BLACK else Side.WHITE)
        val dFile = abs(mv.to.file.ordinal - oppKing.file.ordinal)
        val dRank = abs(mv.to.rank.ordinal - oppKing.rank.ordinal)
        val heavy = moved.pieceType != PieceType.PAWN && moved.pieceType != PieceType.KING
        val kingAttack = heavy && max(dFile, dRank) <= 2
        val oppKFile = oppKing.file.ordinal
        val oppCastledWing = oppKFile <= 2 || oppKFile >= 5
        val pawnStorm = pawn && fwd > 0 && ownR >= 3 && oppCastledWing && dFile <= 2
        pre.doMove(mv)
        val check = pre.isKingAttacked
        pre.undoMove()
        return MoveFeat(capture, check, sac, queenEarly, defensive, trade, advance, kingAttack, pawnStorm)
    }

    fun styleScore(f: MoveFeat, s: Style): Double {
        var x = 0.0
        x += t(s.aggression) * ((if (f.check) 1.0 else 0.0) + (if (f.capture) 0.6 else 0.0) + (if (f.advance) 0.4 else 0.0))
        if (f.kingAttack) x += t(s.aggression) * 0.7
        if (f.pawnStorm) x += (t(s.aggression) - 0.5 * t(s.defense)) * 0.8
        if (f.sacrifice) x += t(s.sacrifice) * 2.0
        if (f.defensive) x += t(s.defense) * 1.2
        if (f.queenEarly) x += t(s.queen) * 1.5
        if (f.trade) x += t(s.trades) * 1.2
        return x
    }

    fun styleWeight(f: MoveFeat, s: Style): Double = exp(1.5 * styleScore(f, s))

    /**
     * Dingan'ny lalao: 1.0 = fiandohana (piece rehetra), 0.0 = endgame fotsiny (pion + mpanjaka).
     * Isaina ny piece tsy pion/mpanjaka (N,B=3 R=5 Q=9) / 62 (lanja voalohany roa tonta).
     */
    fun phase(b: Board): Double {
        var m = 0
        for (sq in Square.values()) {
            if (sq == Square.NONE) continue
            val p = b.getPiece(sq)
            if (p == Piece.NONE) continue
            val t = p.pieceType
            if (t == PieceType.PAWN || t == PieceType.KING) continue
            m += pv(p)
        }
        return (m / 62.0).coerceIn(0.0, 1.0)
    }

    /** Mihena ny tolérance rehefa mankany amin'ny endgame (0.45x), 1.0x amin'ny fiandohana. */
    fun toleranceScale(b: Board): Double = 0.45 + 0.55 * phase(b)

    fun sacTolerance(s: Style): Double = if (t(s.sacrifice) > 0) 90.0 * t(s.sacrifice) else 0.0

    // ---------- Fahatakarana ny fomba filalaovan'ny mpilalao avy amin'ny lalao ----------
    fun deriveStyle(moves: List<String>, white: Boolean, startFen: String = START_FEN): Style {
        val b = Board().also { if (startFen != START_FEN) it.loadFromFen(startFen) }
        var n = 0; var checks = 0; var caps = 0; var adv = 0; var sacs = 0
        var def = 0; var qEarly = 0; var trades = 0
        for ((i, u) in moves.withIndex()) {
            val mv = b.legalMoves().firstOrNull { it.toString().equals(u, true) } ?: break
            if ((b.sideToMove == Side.WHITE) == white) {
                val f = feat(b, mv, i)
                n++
                if (f.check) checks++
                if (f.capture) caps++
                if (f.advance) adv++
                if (f.sacrifice) sacs++
                if (f.defensive) def++
                if (f.queenEarly) qEarly++
                if (f.trade) trades++
            }
            b.doMove(mv)
        }
        if (n < 4) return Style()
        fun scale(rate: Double, base: Double, gain: Double): Int = (50 + (rate - base) / base * gain).toInt().coerceIn(5, 95)
        val aggrRate = (checks + 0.6 * caps + 0.4 * adv) / n
        return Style(
            aggression = scale(aggrRate, 0.26, 45.0),
            sacrifice = if (sacs == 0) 40 else (60 + 20 * sacs).coerceAtMost(95),
            defense = scale(def.toDouble() / n, 0.12, 40.0),
            queen = if (qEarly == 0) 35 else (55 + 15 * qEarly).coerceAtMost(95),
            trades = scale(trades.toDouble() / n, 0.06, 40.0)
        )
    }

    /** Opening hita: id catalog misy ny hetsika voalohany mitovy (>= 5 ply). */
    fun detectOpenings(moves: List<String>, white: Boolean, startFen: String = START_FEN): List<String> {
        if (startFen != START_FEN) return emptyList()   // toerana namboarina: tsy misy opening ao amin'ny katalaogy
        val found = ArrayList<Pair<String, Int>>()
        for (o in OPENINGS) {
            if (o.white != white) continue
            var best = 0
            for (l in o.lines) {
                var k = 0
                while (k < l.size && k < moves.size && l[k].equals(moves[k], true)) k++
                best = max(best, k)
            }
            if (best >= 5) found.add(o.id to best)
        }
        return found.sortedByDescending { it.second }.take(2).map { it.first }
    }

    /** Andalana manokana avy amin'ny lalao (hetsika voalohany) ho an'ny loko voafidy. */
    fun gameLine(moves: List<String>, white: Boolean): String {
        val k = moves.take(14).joinToString(" ")
        return (if (white) "W|" else "B|") + k
    }
}

fun Style.describe(): List<String> {
    val l = ArrayList<String>()
    if (sacrifice >= 70) l.add("Mpanao sacrifice")
    if (sacrifice <= 25) l.add("Tsy manao sacrifice")
    if (aggression >= 70) l.add("Mpanafika")
    if (aggression <= 30) l.add("Milalao milamina")
    if (defense >= 70) l.add("Tia midefendre")
    if (queen >= 70) l.add("Mamoaka queen aloha")
    if (queen <= 25) l.add("Tsy mamoaka queen aloha")
    if (trades >= 70) l.add("Tia mifanakalozana")
    if (trades <= 30) l.add("Misoroka ny fifanakalozana")
    return l
}

/** Famintinana ny specialité: opening + fomba. */
fun Bot.specialty(): String {
    val parts = ArrayList<String>()
    val names = openings.mapNotNull { OPENING_MAP[it]?.name }
    if (names.isNotEmpty()) parts.add(names.take(3).joinToString(", ") + if (names.size > 3) "..." else "")
    if (lines.isNotEmpty() || book.isNotEmpty()) parts.add("Opening avy amin'ny lalao")
    parts.addAll(style.describe())
    return parts.joinToString(" - ")
}
