package mg.chess.offline.own;

/**
 * Fandrefesana hafainganana ho an'ny app (Settings > Filalaovana > Benchmark motera).
 * Mitovy amin'ny tools/Bench.java: depth raikitra (nodes mitovy amin'ny runner => dikan-teny mitovy)
 * sy fotoana raikitra (depth salanisa). Alefa ao amin'ny thread ao ambadika, tsy mikasika ny lalao.
 */
public final class OwnBench {
    private OwnBench() {}

    private static final String[] FENS = {
        "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
        "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1",
        "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1",
        "r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1",
        "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8",
        "r4rk1/1pp1qppp/p1np1n2/2b1p1B1/2B1P1b1/P1NP1N2/1PP1QPPP/R4RK1 w - - 0 10",
        "r1bq1rk1/pp2ppbp/2np1np1/8/3NP3/2N1BP2/PPPQ2PP/R3KB1R w KQ - 0 9",
        "2r2rk1/1bqnbpp1/1p1ppn1p/pP6/N1P1P3/P2B1N1P/1B2QPP1/R2R2K1 w - - 0 1",
        "8/5pk1/6p1/8/8/6P1/5PK1/8 w - - 0 1",
        "4k3/8/8/3p4/3P4/8/8/4K3 w - - 0 1",
        "r2q1rk1/ppp2ppp/2n1bn2/3pp3/1b1PP3/2NB1N2/PPP2PPP/R1BQ1RK1 b - - 0 8",
        "6k1/5ppp/8/8/8/8/5PPP/3R2K1 w - - 0 1",
    };

    private static Search fresh(String fen) {
        Search s = new Search(new Eval(50, 50, 50, 50, 50));
        s.setHash(Params.HASH_BITS.val);
        return s.pos.setFen(fen) ? s : null;
    }

    /** Miverina lahatsoratra mazava (andalana maromaro). Maharitra ~10-30 segondra araka ny finday. */
    public static synchronized String run() {
        StringBuilder sb = new StringBuilder();
        try {
            // fanamafisana (JIT/ART): tsy voaisa
            for (int i = 0; i < 4; i++) { Search s = fresh(FENS[i]); if (s != null) s.think(64, 250); }

            final int depth = 9;
            long bestNps = 0, nodes = 0;
            for (int rep = 0; rep < 2; rep++) {
                long n = 0, spent = 0;
                for (String f : FENS) {
                    Search s = fresh(f); if (s == null) continue;
                    long c0 = System.nanoTime();
                    Search.Result r = s.think(depth, 600_000);
                    spent += System.nanoTime() - c0;
                    n += r.nodes;
                }
                long ms = spent / 1_000_000L;
                long nps = ms > 0 ? n * 1000L / ms : 0;
                sb.append("Depth ").append(depth).append(" #").append(rep + 1).append(": ")
                  .append(nps / 1000).append(" knps (").append(ms).append(" ms)\n");
                if (nps > bestNps) bestNps = nps;
                nodes = n;
            }
            long tn = 0, tspent = 0; int td = 0, tc = 0;
            for (String f : FENS) {
                Search s = fresh(f); if (s == null) continue;
                long c0 = System.nanoTime();
                Search.Result r = s.think(64, 250);
                tspent += System.nanoTime() - c0;
                tn += r.nodes; td += r.depth; tc++;
            }
            long tms = tspent / 1_000_000L;
            long tnps = tms > 0 ? tn * 1000L / tms : 0;
            sb.append("Fotoana 250 ms/hetsika: depth salanisa ")
              .append(String.format(java.util.Locale.US, "%.1f", tc > 0 ? td / (double) tc : 0.0))
              .append(", ").append(tnps / 1000).append(" knps\n");
            sb.append("Nodes d").append(depth).append(" = ").append(nodes)
              .append(" (runner project-54: 505153)\n");
            sb.append("NPS tsara indrindra: ").append(bestNps).append("\n");
            sb.append("Core: ").append(Runtime.getRuntime().availableProcessors());
        } catch (Throwable t) {
            sb.append("Diso: ").append(t);
        }
        return sb.toString();
    }
}
