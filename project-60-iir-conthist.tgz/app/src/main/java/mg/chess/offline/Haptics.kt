package mg.chess.offline

import android.content.Context
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.PieceType
import com.github.bhlangonijr.chesslib.move.Move
import kotlin.math.abs

enum class MoveKind { MOVE, CAPTURE, CHECK, MATE, CASTLE, PROMOTE }

/** Karazan'ny hetsika alohan'ny "doMove" (capture, castle, promotion). Ny check dia hamarinina aorian'ny hetsika. */
fun baseMoveKind(b: Board, mv: Move): MoveKind {
    if (mv.promotion != Piece.NONE) return MoveKind.PROMOTE
    val p = b.getPiece(mv.from)
    if (p.pieceType == PieceType.KING && abs(mv.to.file.ordinal - mv.from.file.ordinal) == 2) return MoveKind.CASTLE
    if (b.getPiece(mv.to) != Piece.NONE) return MoveKind.CAPTURE
    if (p.pieceType == PieceType.PAWN && mv.from.file != mv.to.file) return MoveKind.CAPTURE // en passant
    return MoveKind.MOVE
}

/** Antsoina aorian'ny doMove: raha mahavita check ny hetsika dia CHECK (afa-tsy promotion). */
fun finalMoveKind(base: MoveKind, post: Board): MoveKind =
    when {
        post.isMated -> MoveKind.MATE
        base != MoveKind.PROMOTE && post.isKingAttacked -> MoveKind.CHECK
        else -> base
    }

/** Haptic fohy rehefa mihetsika (mila permission VIBRATE). */
class Haptics(context: Context) {
    private val vib: android.os.Vibrator? = try {
        @Suppress("DEPRECATION")
        context.applicationContext.getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator
    } catch (_: Exception) { null }

    fun tap(kind: MoveKind) {
        val v = vib ?: return
        try {
            if (!v.hasVibrator()) return
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                val eff = when (kind) {
                    MoveKind.MOVE -> android.os.VibrationEffect.createOneShot(10, 60)
                    MoveKind.CAPTURE -> android.os.VibrationEffect.createOneShot(22, 140)
                    MoveKind.CASTLE -> android.os.VibrationEffect.createWaveform(longArrayOf(0, 12, 60, 12), -1)
                    MoveKind.CHECK, MoveKind.MATE, MoveKind.PROMOTE -> android.os.VibrationEffect.createWaveform(longArrayOf(0, 18, 50, 28), -1)
                }
                v.vibrate(eff)
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(if (kind == MoveKind.MOVE) 10L else 22L)
            }
        } catch (_: Exception) {}
    }
}
