package mg.chess.offline

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.Rank
import com.github.bhlangonijr.chesslib.Square

/** Edit board (toy ny chess.com): mametraka/manala piece, misafidy mpilalao hanao hetsika, castling, dia manomboka lalao. */
private val PALETTE = listOf(
    "K", "Q", "R", "B", "N", "P", "k", "q", "r", "b", "n", "p"
)

private fun pieceOf(c: Char): Piece? {
    if (c == ' ') return null
    val side = if (c.isUpperCase()) "WHITE" else "BLACK"
    val t = when (c.uppercaseChar()) {
        'K' -> "KING"; 'Q' -> "QUEEN"; 'R' -> "ROOK"; 'B' -> "BISHOP"; 'N' -> "KNIGHT"; else -> "PAWN"
    }
    return Piece.valueOf("${side}_$t")
}

private fun idxOf(sq: Square): Int = sq.rank.ordinal * 8 + sq.file.ordinal

private fun squareOf(i: Int): Square =
    Square.encode(Rank.allRanks[i / 8], com.github.bhlangonijr.chesslib.File.allFiles[i % 8])

private fun fenOf(cells: List<Char>, whiteToMove: Boolean, wk: Boolean, wq: Boolean, bk: Boolean, bq: Boolean): String {
    val sb = StringBuilder()
    for (r in 7 downTo 0) {
        var empty = 0
        for (f in 0..7) {
            val c = cells[r * 8 + f]
            if (c == ' ') empty++ else { if (empty > 0) { sb.append(empty); empty = 0 }; sb.append(c) }
        }
        if (empty > 0) sb.append(empty)
        if (r > 0) sb.append('/')
    }
    var cr = ""
    if (wk) cr += "K"; if (wq) cr += "Q"; if (bk) cr += "k"; if (bq) cr += "q"
    if (cr.isEmpty()) cr = "-"
    return "$sb ${if (whiteToMove) "w" else "b"} $cr - 0 1"
}

private fun cellsFromFen(fen: String): List<Char>? {
    return try {
        val rows = fen.trim().split(" ")[0].split("/")
        if (rows.size != 8) return null
        val out = CharArray(64) { ' ' }
        for ((i, row) in rows.withIndex()) {
            val r = 7 - i
            var f = 0
            for (ch in row) {
                if (ch.isDigit()) f += ch - '0' else { if (f > 7) return null; out[r * 8 + f] = ch; f++ }
            }
            if (f != 8) return null
        }
        out.toList()
    } catch (e: Exception) { null }
}

/** null = ara-dalàna; raha tsy izany dia hafatra hadisoana. */
private fun validate(cells: List<Char>, whiteToMove: Boolean, fen: String): String? {
    if (cells.count { it == 'K' } != 1 || cells.count { it == 'k' } != 1) return "Mila mpanjaka 1 fotsy sy 1 mainty."
    for (f in 0..7) {
        val a = cells[f]; val b = cells[56 + f]
        if (a == 'P' || a == 'p' || b == 'P' || b == 'p') return "Tsy mety ny pion amin'ny rank voalohany/farany."
    }
    if (cells.count { it == 'P' } > 8 || cells.count { it == 'p' } > 8) return "Pion maherin'ny 8."
    return try {
        val b = Board(); b.loadFromFen(fen)
        // ny mpilalao tsy hanao hetsika dia tsy tokony ho eo ambanin'ny check
        val other = Board(); other.loadFromFen(fenOf(cells, !whiteToMove, false, false, false, false))
        if (other.isKingAttacked) "Ny mpanjaka an'ny mpilalao tsy hanao hetsika dia tafiditra check (toerana tsy ara-dalàna)."
        else if (b.legalMoves().isEmpty()) "Tsy misy hetsika azo atao (mat/pat) - misafidiana toerana hafa."
        else null
    } catch (e: Exception) { "FEN tsy mety." }
}

@Composable
fun BoardEditorScreen(vm: ChessViewModel) {
    BackHandler { vm.screen = Screen.MENU }
    val cs = MaterialTheme.colorScheme
    val cells = remember { mutableStateListOf<Char>().also { l -> l.addAll(cellsFromFen(START_FEN)!!) } }
    var whiteToMove by remember { mutableStateOf(true) }
    var wk by remember { mutableStateOf(true) }
    var wq by remember { mutableStateOf(true) }
    var bk by remember { mutableStateOf(true) }
    var bq by remember { mutableStateOf(true) }
    var tool by remember { mutableStateOf("P") }      // piece na "X" (fafana)
    var flip by remember { mutableStateOf(false) }
    var fenText by remember { mutableStateOf("") }
    var showStart by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun curFen() = fenOf(cells, whiteToMove, wk, wq, bk, bq)

    fun applyFen(f: String): Boolean {
        val c = cellsFromFen(f) ?: return false
        cells.clear(); cells.addAll(c)
        val parts = f.trim().split(" ")
        whiteToMove = parts.getOrNull(1) != "b"
        val cr = parts.getOrNull(2) ?: "-"
        wk = 'K' in cr; wq = 'Q' in cr; bk = 'k' in cr; bq = 'q' in cr
        error = null
        return true
    }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { ScreenTitle("Edit board", onBack = { vm.screen = Screen.MENU }) }
        item {
            BoardView(
                pieceAt = { sq -> if (sq == Square.NONE) Piece.NONE else pieceOf(cells[idxOf(sq)]) ?: Piece.NONE },
                flip = flip,
                onSquare = { sq ->
                    if (sq != Square.NONE) {
                        val i = idxOf(sq)
                        cells[i] = if (tool == "X" || cells[i] == tool[0]) ' ' else tool[0]
                        error = null
                    }
                }
            )
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Piece (tsindrio dia tsindrio ny kare):", fontSize = 12.sp, color = cs.onSurfaceVariant)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (p in PALETTE) {
                        val sel = tool == p
                        Box(
                            Modifier.size(46.dp).clip(RoundedCornerShape(10.dp))
                                .background(if (sel) cs.primaryContainer else cs.surfaceContainer)
                                .border(if (sel) 2.dp else 1.dp, if (sel) cs.primary else cs.outlineVariant, RoundedCornerShape(10.dp))
                                .clickable { tool = p },
                            contentAlignment = Alignment.Center
                        ) { PieceIcon(pieceOf(p[0])!!, 38.dp) }
                    }
                    Box(
                        Modifier.size(46.dp).clip(RoundedCornerShape(10.dp))
                            .background(if (tool == "X") cs.errorContainer else cs.surfaceContainer)
                            .border(if (tool == "X") 2.dp else 1.dp, if (tool == "X") cs.error else cs.outlineVariant, RoundedCornerShape(10.dp))
                            .clickable { tool = "X" },
                        contentAlignment = Alignment.Center
                    ) { Text("🗑", fontSize = 22.sp) }
                }
            }
        }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ for (i in 0 until 64) cells[i] = ' '; wk = false; wq = false; bk = false; bq = false; error = null }) { Text("Foano") }
                OutlinedButton({
                    cells.clear(); cells.addAll(cellsFromFen(START_FEN)!!)
                    whiteToMove = true; wk = true; wq = true; bk = true; bq = true; error = null
                }) { Text("Toerana fototra") }
                OutlinedButton({ flip = !flip }) { Text("Flip") }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Hetsika voalohany", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(whiteToMove, { whiteToMove = true }, { Text("Fotsy") })
                    FilterChip(!whiteToMove, { whiteToMove = false }, { Text("Mainty") })
                }
                Text("Castling", fontWeight = FontWeight.Bold)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(wk, { wk = !wk }, { Text("Fotsy O-O") })
                    FilterChip(wq, { wq = !wq }, { Text("Fotsy O-O-O") })
                    FilterChip(bk, { bk = !bk }, { Text("Mainty O-O") })
                    FilterChip(bq, { bq = !bq }, { Text("Mainty O-O-O") })
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    fenText, { fenText = it }, Modifier.fillMaxWidth(),
                    label = { Text("FEN") }, placeholder = { Text("Apetaho eto ny FEN") }, singleLine = true
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton({
                        if (!applyFen(fenText)) error = "FEN tsy mety."
                    }) { Text("Ampidiro") }
                    OutlinedButton({ fenText = curFen() }) { Text("Haka FEN") }
                }
            }
        }
        item {
            error?.let { Text(it, color = cs.error, fontSize = 13.sp) }
            Spacer(Modifier.height(4.dp))
            Button({
                val msg = validate(cells, whiteToMove, curFen())
                if (msg != null) error = msg else showStart = true
            }, Modifier.fillMaxWidth()) { Text("Ombao ny lalao avy amin'ity toerana ity") }
        }
        // ---- Lalao nalalaovina avy amin'ny Edit board: azo atao review na averina ny toerana ----
        val past = vm.saved.filter { it.startFen != START_FEN }.take(8)
        if (past.isNotEmpty()) {
            item { Text("Lalao teo aloha avy amin'ny Edit board", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
            items(past, key = { it.id }) { g ->
                val bot = BotRegistry.find(g.botId)
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(cs.surfaceContainer).padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        (if (bot != null) "vs ${bot.name} (${bot.elo})" else "Olona vs Olona") + " · ${g.moves.size} hetsika" +
                            (g.result?.let { " · " + it.replace("1/2-1/2", "½-½") } ?: " · mitohy"),
                        fontWeight = FontWeight.Bold, fontSize = 14.sp
                    )
                    Text(g.startFen.split(" ").take(2).joinToString(" "), fontSize = 10.sp, color = cs.onSurfaceVariant, maxLines = 1)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button({ vm.loadGame(g, true) }, enabled = g.moves.isNotEmpty()) { Text("Review") }
                        OutlinedButton({ if (!applyFen(g.startFen)) error = "FEN tsy mety." }) { Text("Ampiasao ny toerana") }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(12.dp)) }
    }

    if (showStart) {
        var white by remember { mutableStateOf(true) }
        AlertDialog(
            onDismissRequest = { showStart = false },
            title = { Text("Hilalao amin'iza?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(white, { white = true }, { Text("Fotsy aho") })
                        FilterChip(!white, { white = false }, { Text("Mainty aho") })
                    }
                    Button({ showStart = false; vm.startFromEditor(curFen(), null, true) }, Modifier.fillMaxWidth()) { Text("Olona vs Olona") }
                    Text("Bot:", fontWeight = FontWeight.Bold)
                    Column(Modifier.height(220.dp)) {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            items(BotRegistry.visible, key = { it.id }) { b ->
                                Row(
                                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(cs.surfaceContainer)
                                        .clickable { showStart = false; vm.startFromEditor(curFen(), b, white) }.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    BotAvatar(b, 34.dp)
                                    Spacer(Modifier.width(10.dp))
                                    Text(b.name, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                                    Text(if (b.isMax) "MAX" else "${b.elo}", fontSize = 12.sp, color = cs.primary)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton({ showStart = false }) { Text("Foano") } }
        )
    }
}
