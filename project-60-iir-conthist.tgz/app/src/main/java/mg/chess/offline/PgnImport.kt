package mg.chess.offline

import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.PieceType
import com.github.bhlangonijr.chesslib.move.Move

/** Lalao iray avy ao amin'ny PGN. moves = hetsika UCI (e2e4...). */
data class PgnGame(
    val white: String, val black: String,
    val whiteElo: Int?, val blackElo: Int?,
    val result: String, val event: String,
    val moves: List<String>,
    /** Toerana fiandohana (tag FEN): lalao manomboka antenatenany (middlegame, endgame, puzzle). START_FEN = lalao mahazatra. */
    val startFen: String = START_FEN
) {
    val fromPosition: Boolean get() = startFen != START_FEN
}

data class PgnPlayer(val name: String, val games: Int, val asWhite: Int, val asBlack: Int, val tagElo: Int?)

/** Bot ho voaforona avy amin'ny lalao PGN (azo ovaina alohan'ny fitehirizana). */
data class PgnBotDraft(
    val player: String, val games: Int, val gameRating: Int, val tagElo: Int?, val accuracy: Double,
    val elo: Int, val openings: List<String>, val lines: List<String>, val style: Style,
    val fromPosition: Boolean = false,
    /** Motera manokana: book avy amin'ny lalao rehetra, famintinana ("opening favorite") ary isan'ny hetsika nodinihina. */
    val book: List<String> = emptyList(),
    val summary: List<String> = emptyList(),
    val analysedMoves: Int = 0
)

object Pgn {
    private val RESULTS = setOf("1-0", "0-1", "1/2-1/2", "*")

    fun parse(text: String): List<PgnGame> {
        val games = ArrayList<PgnGame>()
        var tags = LinkedHashMap<String, String>()
        val body = StringBuilder()
        var inBrace = false
        fun flush() {
            if (body.isNotBlank()) toGame(tags, body.toString())?.let { games.add(it) }
            tags = LinkedHashMap(); body.setLength(0)
        }
        for (raw in text.lineSequence()) {
            var line = raw.trim().removePrefix("\uFEFF")
            val isTag = !inBrace && line.startsWith("[") && line.endsWith("]") && line.contains("\"")
            if (isTag) {
                if (body.isNotBlank()) flush()
                val sp = line.indexOf(' '); val q1 = line.indexOf('"'); val q2 = line.lastIndexOf('"')
                if (sp > 1 && q2 > q1) tags[line.substring(1, sp)] = line.substring(q1 + 1, q2)
                continue
            }
            if (!inBrace) {
                val semi = line.indexOf(';'); val br = line.indexOf('{')
                if (semi >= 0 && (br < 0 || semi < br)) line = line.substring(0, semi)
            }
            for (c in line) { if (c == '{') inBrace = true else if (c == '}') inBrace = false }
            body.append(line).append(' ')
        }
        flush()
        return games
    }

    private fun toGame(tags: Map<String, String>, movetext: String): PgnGame? {
        // Lalao manomboka antenatenany: tag FEN (+ SetUp "1"). Raha SetUp=1 nefa tsy misy FEN dia tsy azo vakiana.
        val fenTag = tags["FEN"]?.trim().orEmpty()
        if (tags["SetUp"] == "1" && fenTag.isEmpty()) return null
        val b = Board()
        var startFen = START_FEN
        if (fenTag.isNotEmpty()) {
            try {
                b.loadFromFen(fenTag)
                if (b.fen != START_FEN) startFen = b.fen
            } catch (e: Exception) { return null }
        }
        val uci = ArrayList<String>()
        try {
            for (tok in tokens(movetext)) {
                val m = sanToMove(b, tok) ?: break
                b.doMove(m)
                uci.add(m.toString())
            }
        } catch (e: Exception) { if (startFen == START_FEN) throw e }
        // Lalao feno: 6 hetsika (ply) farafahakeliny; avy amin'ny toerana: 2 ihany no ampy (puzzle, endgame)
        if (uci.size < (if (startFen != START_FEN) 2 else 6)) return null
        fun name(k: String, d: String): String = tags[k]?.trim()?.takeIf { it.isNotEmpty() && it != "?" } ?: d
        return PgnGame(
            name("White", "Fotsy"), name("Black", "Mainty"),
            tags["WhiteElo"]?.trim()?.toIntOrNull(), tags["BlackElo"]?.trim()?.toIntOrNull(),
            tags["Result"] ?: "*", tags["Event"] ?: "", uci, startFen
        )
    }

    /** Manala {komantera}, (variation), $NAG, laharan'ny hetsika ary valiny. */
    private fun tokens(s: String): List<String> {
        val o = StringBuilder()
        var brace = false; var depth = 0; var i = 0
        while (i < s.length) {
            val c = s[i]
            when {
                brace -> if (c == '}') brace = false
                c == '{' -> brace = true
                c == '(' -> depth++
                c == ')' -> if (depth > 0) depth--
                depth > 0 -> {}
                c == '$' -> { while (i + 1 < s.length && s[i + 1].isDigit()) i++ }
                else -> o.append(c)
            }
            i++
        }
        val out = ArrayList<String>()
        val num = Regex("^\\d+\\.+")
        for (raw in o.toString().split(Regex("\\s+"))) {
            val t = raw.replace(num, "")
            if (t.isEmpty() || t.all { it == '.' } || t in RESULTS) continue
            out.add(t)
        }
        return out
    }

    private fun letterType(c: Char): PieceType? = when (c) {
        'K' -> PieceType.KING; 'Q' -> PieceType.QUEEN; 'R' -> PieceType.ROOK
        'B' -> PieceType.BISHOP; 'N' -> PieceType.KNIGHT; else -> null
    }

    /** SAN -> hetsika legal (tsy miankina amin'ny SAN an'ny chesslib). */
    fun sanToMove(b: Board, san: String): Move? {
        var s = san.replace('0', 'O').trimEnd('+', '#', '!', '?')
        if (s.isEmpty()) return null
        val legal = b.legalMoves()
        if (s == "O-O" || s == "O-O-O") {
            val d = if (s == "O-O") 2 else -2
            return legal.firstOrNull {
                b.getPiece(it.from).pieceType == PieceType.KING && it.to.file.ordinal - it.from.file.ordinal == d
            }
        }
        var promo: PieceType? = null
        val eq = s.indexOf('=')
        if (eq >= 0 && eq + 1 < s.length) {
            promo = letterType(s[eq + 1]); s = s.substring(0, eq)
        } else if (s.length >= 3 && s.last().isUpperCase() && s[s.length - 2].isDigit()) {
            promo = letterType(s.last()); s = s.dropLast(1)
        }
        s = s.replace("x", "").replace("-", "")
        if (s.length < 2) return null
        val to = s.takeLast(2)
        var rest = s.dropLast(2)
        var pt = PieceType.PAWN
        if (rest.isNotEmpty() && rest[0] in "KQRBN") {
            pt = letterType(rest[0]) ?: return null
            rest = rest.drop(1)
        }
        val cands = legal.filter { m ->
            val p = b.getPiece(m.from)
            if (p.pieceType != pt) return@filter false
            if (m.to.name.lowercase() != to) return@filter false
            val from = m.from.name.lowercase()
            for (c in rest) {
                if (c in 'a'..'h' && from[0] != c) return@filter false
                if (c in '1'..'8' && from[1] != c) return@filter false
            }
            if (promo != null) m.promotion != Piece.NONE && m.promotion.pieceType == promo
            else m.promotion == Piece.NONE
        }
        return cands.firstOrNull()
    }

    fun players(games: List<PgnGame>): List<PgnPlayer> {
        val map = LinkedHashMap<String, MutableList<Triple<Boolean, Int?, PgnGame>>>()
        for (g in games) {
            map.getOrPut(g.white) { ArrayList() }.add(Triple(true, g.whiteElo, g))
            map.getOrPut(g.black) { ArrayList() }.add(Triple(false, g.blackElo, g))
        }
        return map.map { (n, l) ->
            val elos = l.mapNotNull { it.second }
            PgnPlayer(n, l.size, l.count { it.first }, l.count { !it.first }, if (elos.isEmpty()) null else elos.average().toInt())
        }.sortedByDescending { it.games }
    }
}
