package mg.chess.offline

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Square

/** Settings: premove sy fanamafisana hetsika. */
@Composable
fun GameplayCard(vm: ChessViewModel) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Fomba filalaovana", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Feo:", fontSize = 14.sp)
                FilterChip(vm.soundOn, { vm.setSound(true) }, { Text("Alefa") })
                FilterChip(!vm.soundOn, { vm.setSound(false) }, { Text("Atsahatra") })
            }
            Text(
                "Feo hetsika, capture, castling, check ary checkmate (mivoaka amin'ny volume media; noforonina ao anaty app, tsy mila rakitra).",
                fontSize = 12.sp
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Premove:", fontSize = 14.sp)
                FilterChip(vm.premoveOn, { vm.setPremove(true) }, { Text("Alefa") })
                FilterChip(!vm.premoveOn, { vm.setPremove(false) }, { Text("Atsahatra") })
            }
            Text(
                "Rehefa mieritreritra ny bot dia azonao atao ny misafidy ny hetsika manaraka (tsindrio na tarazo ny piece, avy eo ny kare). " +
                    "Atao ho azy izy rehefa tonga ny anjaranao raha mbola ara-dalàna; tsindrio ny piece hafa na ny kare foana hanafoana. Queen foana ny promotion.",
                fontSize = 12.sp
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Fanamafisana:", fontSize = 14.sp)
                FilterChip(vm.confirmOn, { vm.setConfirm(true) }, { Text("Alefa") })
                FilterChip(!vm.confirmOn, { vm.setConfirm(false) }, { Text("Atsahatra") })
            }
            Text(
                "Rehefa alefa dia miseho ny bokotra \"Ekena\" / \"Foano\" alohan'ny hetsika vao tena atao (misoroka ny diso tanana).",
                fontSize = 12.sp
            )
        }
    }
}

/** Settings: loko ny board sy fomba ny piece, miaraka amin'ny sary aloha. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StyleCard() {
    val ctx = LocalContext.current
    val demo = remember { Board() }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Board sy piece", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                BoardView(
                    pieceAt = { demo.getPiece(it) }, flip = false,
                    modifier = Modifier.width(240.dp).clip(RoundedCornerShape(8.dp)),
                    last = Square.E2 to Square.E4
                )
            }
            Text("Loko ny board", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (t in BOARD_THEMES) {
                    FilterChip(
                        BoardStyle.boardId == t.id, { BoardStyle.setBoard(ctx, t.id) }, { Text(t.label) },
                        leadingIcon = {
                            Row {
                                Box(Modifier.size(12.dp).background(t.light ?: Color(0xFFEEEED2)))
                                Box(Modifier.size(12.dp).background(t.dark ?: Color(0xFF769656)))
                            }
                        }
                    )
                }
            }
            Text("Fomba ny piece", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (t in PIECE_THEMES) {
                    FilterChip(BoardStyle.pieceId == t.id, { BoardStyle.setPiece(ctx, t.id) }, { Text(t.label) })
                }
            }
            Text(
                "\"Sary (default)\" sy \"Klasika\" dia mampiasa ny sary ao amin'ny assets raha misy; ny hafa dia loko voasoritra ao amin'ny app.",
                fontSize = 12.sp
            )
        }
    }
}
