package mg.chess.offline

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val UP = Color(0xFF81B64C)
private val DOWN = Color(0xFFCA3431)

/** Soratra fiovan'ny Elo: "▲ +43" maitso, "▼ -12" mena, "=" volondavenona. */
fun eloDeltaLabel(d: Int): String = when {
    d > 0 -> "▲ +$d"
    d < 0 -> "▼ $d"          // $d efa misy "-"
    else -> "="
}

@Composable
fun EloDelta(d: Int, fontSize: TextUnit = 12.sp) {
    Text(
        eloDeltaLabel(d), fontSize = fontSize, fontWeight = FontWeight.Bold,
        color = when { d > 0 -> UP; d < 0 -> DOWN; else -> MaterialTheme.colorScheme.onSurfaceVariant }
    )
}

/** Classement ny bot rehetra araka ny Elo (avo indrindra aloha); ny fiovana farany dia avy amin'ny fifaninanana farany. */
@Composable
fun BotRankingTab(modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    // BotRegistry.visible mamaky ny state (BotProgress.map) -> mivaingana ho azy aorian'ny fifaninanana
    val ranked = BotRegistry.visible.sortedWith(compareByDescending<Bot> { it.elo }.thenBy { it.name })
    val prog = BotProgress.map
    Column(modifier) {
        Text(
            "Arakaraky ny Elo ankehitriny. Miova aorian'ny fifaninanana tsirairay (▲ +Elo / ▼ -Elo).",
            fontSize = 12.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(bottom = 8.dp)
        )
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            itemsIndexed(ranked, key = { _, b -> b.id }) { i, b ->
                val p = prog[b.id]
                val delta = if (b.isMax) 0 else (p?.last ?: 0)
                val tier = remember(b.elo) { tierOf(b.elo) }
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(cs.surfaceContainer).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        when (i) { 0 -> "🥇"; 1 -> "🥈"; 2 -> "🥉"; else -> "${i + 1}" },
                        Modifier.width(34.dp), fontWeight = FontWeight.Bold, fontSize = if (i < 3) 20.sp else 15.sp,
                        color = if (i < 3) Color.Unspecified else cs.onSurfaceVariant
                    )
                    BotAvatar(b, 40.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(b.name, fontWeight = FontWeight.Bold, maxLines = 1)
                            Spacer(Modifier.width(6.dp))
                            TierChip(tier)
                        }
                        val games = p?.games ?: 0
                        val persona = p?.persona.orEmpty()
                        Text(
                            listOf(persona, if (games > 0) "$games lalao" else "").filter { it.isNotBlank() }.joinToString(" · ")
                                .ifBlank { "Mbola tsy nandray anjara tao amin'ny fifaninanana" },
                            fontSize = 11.sp, color = cs.onSurfaceVariant, maxLines = 1
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(if (b.isMax) "MAX" else "${b.elo}", fontWeight = FontWeight.Black, fontSize = 18.sp, color = Color(tier.color))
                        if (!b.isMax) EloDelta(delta)
                    }
                }
            }
        }
    }
}

/** Dialog aorian'ny fifaninanana vita: ny fiovan'ny Elo an'ny bot tsirairay (ohatra 2450  ▲ +43). */
@Composable
fun EloChangesDialog(vm: ChessViewModel) {
    val list = vm.eloChanges
    if (list.isEmpty()) return
    AlertDialog(
        onDismissRequest = { vm.eloChanges = emptyList() },
        title = { Text("Elo bot nohavaozina") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                itemsIndexed(list, key = { _, c -> c.id }) { _, c ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(c.name, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text(
                                "${c.old} → ${c.new}" + if (c.persona.isNotBlank()) " · ${c.persona}" else "",
                                fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1
                            )
                        }
                        Text("${c.new}", fontWeight = FontWeight.Black, fontSize = 18.sp)
                        Spacer(Modifier.width(8.dp))
                        EloDelta(c.delta, 14.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton({ vm.eloChanges = emptyList() }) { Text("Eny") } }
    )
}
