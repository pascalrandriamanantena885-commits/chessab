package mg.chess.offline

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class EloMathTest {
    @Test fun expectedIsHalfWhenEqual() {
        assertEquals(0.5, eloExpected(1200.0, 1200.0), 1e-9)
    }

    @Test fun expectedFavoursStrongerPlayer() {
        assertTrue(eloExpected(1600.0, 1200.0) > 0.9)
        assertTrue(eloExpected(1200.0, 1600.0) < 0.1)
    }

    @Test fun winAgainstEqualGivesHalfK() {
        // K = 40 ho an'ny lalao voalohany => +20
        assertEquals(1220.0, eloNext(1200.0, 0, 1200, 1.0), 1e-9)
    }

    @Test fun drawAgainstEqualChangesNothing() {
        assertEquals(1200.0, eloNext(1200.0, 5, 1200, 0.5), 1e-9)
    }

    @Test fun lossLowersRating() {
        assertTrue(eloNext(1200.0, 40, 1200, 0.0) < 1200.0)
    }

    @Test fun kShrinksWithExperience() {
        assertTrue(eloK(0) > eloK(15))
        assertTrue(eloK(15) > eloK(50))
    }

    @Test fun scoreMapping() {
        assertEquals(1.0, scoreOf("1-0", true)!!, 0.0)
        assertEquals(0.0, scoreOf("1-0", false)!!, 0.0)
        assertEquals(1.0, scoreOf("0-1", false)!!, 0.0)
        assertEquals(0.5, scoreOf("1/2-1/2", true)!!, 0.0)
        assertNull(scoreOf(null, true))
        assertNull(scoreOf("*", true))
    }
}

class MoveLossTest {
    @org.junit.Test fun mateInFiveVsPlainWinIsBigLoss() {
        // mate haingana (2995) vs +8.00 fotsiny: win% saturé nefa tsy tokony ho "mitovy"
        org.junit.Assert.assertTrue(moveLossPts(2995, 800) > 20.0)
    }

    @org.junit.Test fun equalPositionSmallLossIsSmall() {
        org.junit.Assert.assertTrue(moveLossPts(0, -50) in 3.0..6.0)
        org.junit.Assert.assertEquals(0.0, moveLossPts(120, 150), 1e-9)
    }

    @org.junit.Test fun mateDetection() {
        org.junit.Assert.assertTrue(isMateForUs(MATE_CP - 7))
        org.junit.Assert.assertFalse(isMateForUs(1500))
    }
}
