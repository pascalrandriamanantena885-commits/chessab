package mg.chess.offline

import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Side
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EndgameTest {
    private fun cls(fen: String): EgInfo {
        val b = Board(); b.loadFromFen(fen)
        return Endgame.classify(b)
    }

    @Test fun rookVsBareKingIsEasyMate() {
        val i = cls("8/8/8/4k3/8/8/4K3/R7 w - - 0 1")
        assertEquals(EgKind.BARE_KING, i.kind)
        assertEquals(Side.WHITE, i.strong)
        assertFalse(i.hard)
    }

    @Test fun bishopKnightIsHardMate() {
        val i = cls("8/8/8/4k3/8/8/4K3/1BN5 w - - 0 1")
        assertEquals(EgKind.BARE_KING, i.kind)
        assertTrue(i.hard)
    }

    @Test fun lonePawnVsBareKingCanPromote() {
        val i = cls("8/8/8/4k3/8/4P3/4K3/8 w - - 0 1")
        assertEquals(EgKind.BARE_KING, i.kind)
        assertFalse(i.hard)
    }

    @Test fun singleBishopCannotMate() = assertEquals(EgKind.SMALL, cls("8/8/8/4k3/8/8/4K3/1B6 w - - 0 1").kind)

    @Test fun pawnEnding() = assertEquals(EgKind.PAWNS, cls("8/p7/8/4k3/8/4P3/4K3/8 w - - 0 1").kind)

    @Test fun startPositionIsNotEndgame() = assertEquals(EgKind.NONE, Endgame.classify(Board()).kind)

    @Test fun knowledgeGrowsWithEloAndHardIsHarder() {
        val easy = EgInfo(EgKind.BARE_KING, Side.WHITE, false, 2)
        val hard = EgInfo(EgKind.BARE_KING, Side.WHITE, true, 3)
        assertTrue(Endgame.knowledge(400, hard) < Endgame.knowledge(400, easy))
        assertTrue(Endgame.knowledge(800, hard) < Endgame.knowledge(2000, hard))
        assertEquals(1.0, Endgame.knowledge(3000, hard), 1e-9)
        assertEquals(1.0, Endgame.knowledge(1500, easy), 1e-9)
        assertTrue(Endgame.searchDepth(1.0) > Endgame.searchDepth(0.2))
    }

    @Test fun matePositionScoresHighStalemateScoresLow() {
        val mate = Board(); mate.loadFromFen("R3k3/8/4K3/8/8/8/8/8 b - - 0 1")
        assertTrue(Endgame.progress(mate, Side.WHITE, EgKind.BARE_KING) > 50000.0)
        val stale = Board(); stale.loadFromFen("7k/5Q2/6K1/8/8/8/8/8 b - - 0 1")
        assertTrue(Endgame.progress(stale, Side.WHITE, EgKind.BARE_KING) < -50000.0)
    }

    @Test fun stalematingMoveDetectedAndBoardRestored() {
        val b = Board(); b.loadFromFen("7k/8/6K1/8/8/8/8/5Q2 w - - 0 1")
        val fenBefore = b.fen
        val mv = b.legalMoves().first { it.toString().equals("f1f7", true) }
        assertTrue(Endgame.stalemates(b, mv))
        assertEquals(fenBefore, b.fen)
    }
}
