package mg.chess.offline

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PgnFenTest {
    @Test fun gameFromPositionIsAccepted() {
        val pgn = """
            [White "A"]
            [Black "B"]
            [SetUp "1"]
            [FEN "4k3/8/8/8/8/8/4P3/4K3 w - - 0 1"]

            1. e4 Kd7 2. e5 Ke7 *
        """.trimIndent()
        val g = Pgn.parse(pgn)
        assertEquals(1, g.size)
        assertTrue(g[0].fromPosition)
        assertEquals(listOf("e2e4", "e8d7", "e4e5", "d7e7"), g[0].moves)
    }

    @Test fun shortStandardGameIsStillRejected() {
        val g = Pgn.parse("[White \"A\"]\n[Black \"B\"]\n\n1. e4 e5 *")
        assertTrue(g.isEmpty())
    }
}
