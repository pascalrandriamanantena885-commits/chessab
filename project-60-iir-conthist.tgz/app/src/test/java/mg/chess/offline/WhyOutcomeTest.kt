package mg.chess.offline

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WhyOutcomeTest {
    @Test fun stopsAtCheckmateWhateverTheLength() {
        val pv = listOf("f2f3", "e7e5", "g2g4", "d8h4", "a2a3")
        val p = pvPlan(START_FEN, pv)
        assertEquals(4, p.keep)
        assertTrue(p.resolved)
        val sim = simulatePv(START_FEN, pv, p.keep)
        val o = outcomeOf(START_FEN, sim)
        assertEquals(1, o.kind)
        assertNotNull(outcomeNote(o))
    }

    @Test fun stopsWhenExchangeIsSettled() {
        val fen = "rnbqkbnr/ppp1pppp/8/3p4/4P3/8/PPPP1PPP/RNBQKBNR w KQkq d6 0 2"
        val p = pvPlan(fen, listOf("e4d5", "d8d5", "b1c3", "d5a5", "d2d4"))
        assertEquals(2, p.keep)          // exd5 Qxd5 => mijanona rehefa milamina
        assertTrue(p.resolved)
        val o = outcomeOf(fen, simulatePv(fen, listOf("e4d5", "d8d5"), 2))
        assertEquals(4, o.kind)
        assertEquals("pion", o.blackLost)   // Mainty no very pion (d5) ; Fotsy no very pion (e4->d5)
        assertEquals("pion", o.whiteLost)
    }

    @Test fun quietLineFallsBackToShortPreview() {
        val pv = listOf("e2e4", "e7e5", "g1f3", "b8c6", "f1b5", "a7a6", "b5a4", "g8f6")
        val p = pvPlan(START_FEN, pv)
        assertFalse(p.resolved)
        assertEquals(6, p.keep)
    }
}
