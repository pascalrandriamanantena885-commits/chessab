package mg.chess.offline.own;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import org.junit.Test;

/** Bot avy amin'ny PGN amin'ny motera manokana: book (opening favorite), Elo avy amin'ny ACPL. */
public class PgnBotTest {
    private static List<String> mv(String s) { return Arrays.asList(s.split(" ")); }

    private static List<PgnBot.Game> sample() {
        List<PgnBot.Game> g = new ArrayList<PgnBot.Game>();
        g.add(new PgnBot.Game(null, mv("e2e4 e7e5 g1f3 b8c6 f1b5 a7a6"), true, 0, 1.0));
        g.add(new PgnBot.Game(null, mv("e2e4 c7c5 g1f3 d7d6 d2d4 c5d4"), true, 0, 0.5));
        g.add(new PgnBot.Game(null, mv("d2d4 d7d5 c2c4 e7e6 b1c3 g8f6"), true, 0, 0.0));
        g.add(new PgnBot.Game(null, mv("e2e4 c7c5 g1f3 d7d6 d2d4 c5d4"), false, 0, 1.0));
        return g;
    }

    @Test public void bookEntriesAreValidAndFavoriteWins() {
        List<String> book = PgnBot.buildBook(sample());
        assertFalse(book.isEmpty());
        for (String e : book) assertTrue(e, PgnBot.validEntry(e));
        Random r = new Random(1);
        Map<String, Integer> c = new HashMap<String, Integer>();
        for (int i = 0; i < 400; i++) {
            String m = PgnBot.bookMove(PgnBot.START_FEN, book, r);
            c.put(m, c.containsKey(m) ? c.get(m) + 1 : 1);
        }
        assertTrue(c.containsKey("e2e4") && c.containsKey("d2d4"));
        assertTrue(c.get("e2e4") > c.get("d2d4"));
    }

    @Test public void bookIgnoresEpFieldAndUnknownPositions() {
        List<String> book = PgnBot.buildBook(sample());
        Random r = new Random(2);
        assertEquals("c7c5", PgnBot.bookMove("rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1", book, r));
        assertEquals("c7c5", PgnBot.bookMove("rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1", book, r));
        assertNull(PgnBot.bookMove("8/8/8/4k3/8/8/4K3/8 w - - 0 1", book, r));
    }

    @Test public void rejectsBadEntries() {
        assertFalse(PgnBot.validEntry("zzzz"));
        assertFalse(PgnBot.validEntry("20417bce2d71ca09:e2e9:3"));
        assertFalse(PgnBot.validEntry("20417bce2d71ca09:e2e4:0"));
        assertTrue(PgnBot.validEntry("20417bce2d71ca09:e7e8q:2"));
    }

    @Test public void mateInOneHasZeroLossAndFenGameHasNoBook() {
        PgnBot.Game g = new PgnBot.Game("6k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1", mv("a1a8"), true, 0, 1.0);
        PgnBot.Result r = PgnBot.build(Arrays.asList(g), 5, 4, 100, null, null);
        assertTrue(r.book.isEmpty());
        assertEquals(1, r.analysed);
        assertEquals(0.0, r.acpl, 0.0001);
    }

    @Test public void weakGameRatedBelowGoodGameAndTagPullsElo() {
        // Lalao ratsy: very bishop (ply 8) ary knight (ply 10) aorian'ny opening: ACPL lehibe
        PgnBot.Game bad = new PgnBot.Game(null, mv("e2e4 e7e5 g1f3 b8c6 f1c4 g8f6 d2d3 f8c5 c4f7 e8f7 f3e5 c6e5"), true, 0, 0.0);
        PgnBot.Game good = new PgnBot.Game(null, mv("e2e4 e7e5 g1f3 b8c6 f1c4 g8f6 d2d3 f8c5 c2c3 d7d6 e1g1 e8g8"), true, 0, 1.0);
        PgnBot.Result rb = PgnBot.build(Arrays.asList(bad), 10, 3, 80, null, null);
        PgnBot.Result rg = PgnBot.build(Arrays.asList(good), 10, 3, 80, null, null);
        assertTrue(rb.analysed > 0 && rg.analysed > 0);
        assertTrue(rg.rating >= rb.rating);
        PgnBot.Game tagged = new PgnBot.Game(null, good.uci, true, 1000, 1.0);
        PgnBot.Result rt = PgnBot.build(Arrays.asList(tagged), 10, 3, 80, null, null);
        assertEquals(0, rt.elo % 50);
        assertTrue(rt.elo <= Math.max(rg.rating, 1000) + 50);
    }

    @Test public void cancelStopsAnalysis() {
        PgnBot.Result r = PgnBot.build(sample(), 20, 3, 50, () -> true, null);
        assertEquals(0, r.analysed);
        assertTrue(r.elo >= 100 && r.elo <= 3200);
    }
}
