package mg.chess.offline

import com.github.bhlangonijr.chesslib.Board
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PersonalityTest {
    private fun feat(fen: String, uci: String): MoveFeat {
        val b = Board(); b.loadFromFen(fen)
        val mv = b.legalMoves().first { it.toString().equals(uci, true) }
        return Personality.feat(b, mv, 10)
    }

    @Test fun phaseStartIsOne() = assertEquals(1.0, Personality.phase(Board()), 1e-9)

    @Test fun phaseEndgameIsLow() {
        val b = Board(); b.loadFromFen("8/8/8/4k3/8/8/4K3/R7 w - - 0 1")
        assertTrue(Personality.phase(b) < 0.2)
        assertTrue(Personality.toleranceScale(b) < Personality.toleranceScale(Board()))
    }

    @Test fun pawnStormDetected() {
        assertTrue(feat("r4rk1/ppp2ppp/8/8/8/8/PPPPPPPP/R3K2R w KQ - 0 1", "g2g4").pawnStorm)
        assertFalse(feat("r4rk1/ppp2ppp/8/8/8/8/PPPPPPPP/R3K2R w KQ - 0 1", "a2a3").pawnStorm)
    }

    @Test fun kingAttackDetected() {
        assertTrue(feat("6k1/5ppp/8/8/8/3Q4/5PPP/6K1 w - - 0 1", "d3g6").kingAttack)
        assertFalse(feat("6k1/5ppp/8/8/8/3Q4/5PPP/6K1 w - - 0 1", "d3d1").kingAttack)
    }
}

class EditBoardGameTest {
    private val blackToMove = "4k3/pppp4/8/8/8/8/4PPPP/4K3 b - - 0 1"

    @Test fun blackFirstAndMoveNo() {
        assertTrue(blackFirst(blackToMove))
        assertFalse(blackFirst(START_FEN))
        assertEquals(1, startMoveNo(blackToMove))
        assertEquals(12, startMoveNo("4k3/8/8/8/8/8/8/4K3 w - - 3 12"))
    }

    @Test fun deriveStyleUsesRealMoverOnCustomStart() {
        // Mainty no mihetsika voalohany: ny hetsika 0 dia an'ny Mainty, tsy ny Fotsy
        val moves = listOf("a7a5", "e2e3", "b7b5", "f2f3", "c7c5", "g2g3", "d7d5", "h2h3")
        val black = Personality.deriveStyle(moves, false, blackToMove)
        val white = Personality.deriveStyle(moves, true, blackToMove)
        // samy nahazo hetsika 4 (pion miandry ihany, tsy fanafihana) -> aggression 5; Style() mahazatra dia 50
        assertEquals(5, black.aggression)
        assertEquals(5, white.aggression)
    }

    @Test fun noOpeningsOnCustomStart() {
        assertTrue(Personality.detectOpenings(listOf("e2e4", "e7e5", "g1f3", "b8c6", "f1c4", "f8c5"), true, blackToMove).isEmpty())
    }
}

class BotRankingTest {
    @Test fun deltaLabels() {
        assertEquals("▲ +43", eloDeltaLabel(43))
        assertEquals("▼ -12", eloDeltaLabel(-12))
        assertEquals("=", eloDeltaLabel(0))
    }

    @Test fun eloChangeDelta() {
        assertEquals(43, EloChange("x", "X", 2407, 2450, 1, "").delta)
    }
}

class BotPackTest {
    private fun parse(s: String) = BotPack.parse(s.byteInputStream())

    @Test fun singleBotJson() {
        val (l, err) = parse("""{"name":"Test","elo":1500,"openings":["ruy","nope"],"style":{"a":999},"lines":["W|e2e4 e7e5","bad"]}""")
        assertEquals(null, err)
        assertEquals(1, l.size)
        assertEquals(listOf("ruy"), l[0].openings)
        assertEquals(100, l[0].style.aggression)
        assertEquals(listOf("W|e2e4 e7e5"), l[0].lines)
    }

    @Test fun rejectsBadElo() {
        val (l, err) = parse("""{"bots":[{"name":"X","elo":50},{"name":"","elo":1000}]}""")
        assertTrue(l.isEmpty()); assertTrue(err != null)
    }

    @Test fun rejectsUnknownFormat() = assertTrue(parse("""{"hello":1}""").second != null)
}

class WhyTest {
    private val sf = "4k3/pppp4/8/8/8/8/4PPPP/4K3 b - - 0 1"

    @Test fun plyLabelsFollowStartPosition() {
        assertEquals("1. e4", plyLabel(START_FEN, 0, "e4"))
        assertEquals("1…e5", plyLabel(START_FEN, 1, "e5"))
        assertEquals("1…a5", plyLabel(sf, 0, "a5"))      // Mainty no mihetsika voalohany
        assertEquals("2. e3", plyLabel(sf, 1, "e3"))
    }

    @Test fun pvTextAndSimulation() {
        val s = simulatePv(START_FEN, listOf("e2e4", "e7e5", "g1f3", "zz"), 6)   // "zz" tsy ara-dalàna: mijanona
        assertEquals(listOf("e4", "e5", "Nf3"), s.sans)
        assertEquals("1. e4 e5 2. Nf3", pvText(START_FEN, 0, s.sans))
        assertEquals("1…e5 2. Nf3", pvText(START_FEN, 1, s.sans.drop(1)))
    }

    @Test fun whyAppliesToKeyClasses() {
        assertTrue(whyApplies(Cls.BRILLIANT)); assertTrue(whyApplies(Cls.GREAT)); assertTrue(whyApplies(Cls.BLUNDER))
        assertFalse(whyApplies(Cls.GOOD))
    }

    @Test fun fmtCpFormats() {
        assertEquals("+0.50", fmtCp(50)); assertEquals("-1.20", fmtCp(-120)); assertEquals("+M3", fmtCp(MATE_CP - 3))
    }
}
