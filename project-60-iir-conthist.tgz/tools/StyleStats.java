package mg.chess.offline.own;

import java.util.*;

/**
 * Fandrefesana ny style: A vs B (safidy samihafa) ary isa isaky ny lalao:
 * sacrifice (very material >= 100 cp aorian'ny 3 ply fa tsy very araka ny motera: score >= -50), check, mate, rook-contact sacrifice.
 * Ampiasa: java -cp cls mg.chess.offline.own.StyleStats <pairs> <moveMs> "<optsA>" "<optsB>" [openPlies=8]
 */
public class StyleStats {
    static final int[] VAL = {0, 100, 320, 330, 500, 900, 0};

    static int material(Pos p, int c) {
        int m = 0;
        for (int sq = 0; sq < 128; sq++) {
            if ((sq & 0x88) != 0) { sq += 7; continue; }
            int pc = p.b[sq];
            if (pc != 0 && (pc >> 3) == c) m += VAL[pc & 7];
        }
        return m;
    }

    static final class Rec { int mover; int bal; int score; boolean rookC; boolean aMove; }

    static final class Stat {
        long moves, checks, sacs, rookSacs; int games, mates, wins;
    }

    public static void main(String[] a) {
        final int pairs = Integer.parseInt(a[0]);
        final long ms = Long.parseLong(a[1]);
        final String oa = a[2], ob = a[3];
        final int openPlies = a.length > 4 ? Integer.parseInt(a[4]) : 8;
        Eval ev = new Eval(50, 50, 50, 50, 50);
        Search sa = new Search(ev), sb = new Search(ev);
        Stat A = new Stat(), B = new Stat();
        for (int g = 0; g < pairs; g++) {
            for (int c = 0; c < 2; c++) {
                boolean aWhite = c == 0;
                play(g, aWhite, ms, openPlies, sa, sb, oa, ob, ev, A, B);
            }
        }
        report("A [" + oa + "]", A);
        report("B [" + ob + "]", B);
    }

    static void report(String name, Stat s) {
        double pm = Math.max(1, s.moves);
        System.out.printf("%s  lalao=%d  hetsika=%d  check/100=%.1f  sacrifice/100=%.2f  rookSac/100=%.2f  mate=%d  fandresena=%d%n",
                name, s.games, s.moves, 100.0 * s.checks / pm, 100.0 * s.sacs / pm, 100.0 * s.rookSacs / pm, s.mates, s.wins);
    }

    static void play(int g, boolean aWhite, long ms, int openPlies, Search sa, Search sb, String oa, String ob, Eval ev, Stat A, Stat B) {
        Pos p = sa.pos;
        Random rng = new Random(0x9E3779B97F4A7C15L * (g + 1));
        for (int attempt = 0; ; attempt++) {
            p.startPos();
            for (int i = 0; i < openPlies; i++) {
                int[] mv = new int[256]; int n = p.genAll(mv);
                List<Integer> legal = new ArrayList<>();
                for (int k = 0; k < n; k++) if (p.make(mv[k])) { p.unmake(); legal.add(mv[k]); }
                if (legal.isEmpty()) break;
                p.make(legal.get(rng.nextInt(legal.size())));
            }
            if (Math.abs(ev.evalRaw(p)) <= 150 || attempt >= 30) break;
        }
        sa.clear(); sb.clear();
        sb.pos.setFen(SelfPlay.fen(p));
        List<Rec> recs = new ArrayList<>();
        int ply = openPlies, big = 0, bigSign = 0, quiet = 0;
        boolean aWon = false, aMated = false, bMated = false;
        double res = 0.5;
        while (true) {
            if (!SelfPlay.hasLegal(p)) {
                if (p.inCheck()) { res = (p.side == 0 ? 0.0 : 1.0); }
                break;
            }
            if (p.half >= 100 || p.repeated() || SelfPlay.insufficient(p) || ply >= 300) break;
            boolean aMove = (p.side == 0) == aWhite;
            Search s = aMove ? sa : sb;
            Match.apply(aMove ? oa : ob);
            Search.Result r = s.think(64, ms);
            if (r.move == 0) break;
            int mover = p.side;
            Rec rc = new Rec();
            rc.mover = mover; rc.aMove = aMove; rc.bal = material(p, mover) - material(p, mover ^ 1);
            rc.score = r.score;
            if (!p.make(r.move)) break;
            if (!sb.pos.make(r.move)) break;
            rc.rookC = Eval.rookContact(p, mover);
            Stat st = aMove ? A : B;
            st.moves++;
            if (p.inCheck()) st.checks++;
            recs.add(rc);
            ply++;
            int sc = mover == 0 ? r.score : -r.score;
            if (Math.abs(sc) >= 900) {
                int sg = sc > 0 ? 1 : -1;
                big = (big > 0 && sg == bigSign) ? big + 1 : 1; bigSign = sg;
                if (big >= 6) { res = sg > 0 ? 1.0 : 0.0; break; }
            } else big = 0;
            quiet = Math.abs(sc) <= 15 ? quiet + 1 : 0;
            if (ply >= 160 && quiet >= 10) break;
            // sacrifice: balanse aorian'ny hetsika manaraka ny mover (3 ply)
            int n = recs.size();
            if (n >= 3) {
                Rec r0 = recs.get(n - 3);
                if (r0.mover == mover) {
                    int bal2 = material(p, mover) - material(p, mover ^ 1);
                    if (r0.bal - bal2 >= 100 && Math.abs(r0.score) < 900 && r0.score >= -50) {
                        Stat s0 = r0.aMove ? A : B;
                        s0.sacs++;
                        if (r0.rookC) s0.rookSacs++;
                    }
                }
            }
        }
        A.games++; B.games++;
        boolean whiteWon = res == 1.0, blackWon = res == 0.0;
        boolean aWin = (aWhite && whiteWon) || (!aWhite && blackWon);
        boolean bWin = (aWhite && blackWon) || (!aWhite && whiteWon);
        if (aWin) A.wins++;
        if (bWin) B.wins++;
        if (!SelfPlay.hasLegal(p) && p.inCheck()) { if (aWin) A.mates++; if (bWin) B.mates++; }
    }
}
