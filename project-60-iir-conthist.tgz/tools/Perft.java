package mg.chess.offline.own;

/**
 * Fitsapana hetsika marina (perft) - ampiasaina alohan'ny hanovana ny movegen/make/unmake.
 * Fampiasana: java -cp cls mg.chess.offline.own.Perft [deep]
 *   (tsy misy)  -> haingana (~segondra vitsy): perft hatramin'ny depth 4-5
 *   deep        -> mampiana depth iray ho an'ny toerana tsirairay (maharitra kokoa)
 * Exit code: 0 = marina rehetra, 1 = misy diso (ao anatin'izany ny "divide" ho an'ny toerana diso voalohany).
 * Soatoavina: chessprogramming.org/Perft_Results. Tsy ampiasain'ny app.
 */
public class Perft {
    static final class T {
        final String name, fen; final long[] exp; final int fast;
        T(String name, String fen, int fast, long... exp) { this.name = name; this.fen = fen; this.fast = fast; this.exp = exp; }
    }

    static final T[] SUITE = {
        new T("startpos", "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1", 5,
              20, 400, 8902, 197281, 4865609, 119060324L),
        new T("kiwipete", "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1", 4,
              48, 2039, 97862, 4085603, 193690690L),
        new T("pos3 (ep/endgame)", "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1", 5,
              14, 191, 2812, 43238, 674624, 11030083L),
        new T("pos4 (promo/castle)", "r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1", 4,
              6, 264, 9467, 422333, 15833292L),
        new T("pos4 mirror", "r2q1rk1/pP1p2pp/Q4n2/bbp1p3/Np6/1B3NBn/pPPP1PPP/R3K2R b KQ - 0 1", 4,
              6, 264, 9467, 422333, 15833292L),
        new T("pos5", "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8", 4,
              44, 1486, 62379, 2103487, 89941194L),
        new T("pos6", "r4rk1/1pp1qppp/p1np1n2/2b1p1B1/2B1P1b1/P1NP1N2/1PP1QPPP/R4RK1 w - - 0 10", 4,
              46, 2079, 89890, 3894594, 164075551L),
    };

    static void divide(Pos p, int depth) {
        int[] ms = new int[256];
        int n = p.genAll(ms);
        for (int i = 0; i < n; i++) {
            if (!p.make(ms[i])) continue;
            System.out.println("    " + Pos.moveStr(ms[i]) + ": " + p.perft(depth - 1));
            p.unmake();
        }
    }

    public static void main(String[] a) {
        boolean deep = a.length > 0 && a[0].equals("deep");
        // Fanamafisana JIT (tsy voaisa)
        for (T t : SUITE) { Pos p = new Pos(); if (p.setFen(t.fen)) p.perft(3); }

        int bad = 0; long total = 0, ns = 0;
        for (T t : SUITE) {
            int max = Math.min(t.exp.length, t.fast + (deep ? 1 : 0));
            for (int d = 1; d <= max; d++) {
                Pos p = new Pos();
                if (!p.setFen(t.fen)) { System.out.println("FEN diso: " + t.fen); bad++; break; }
                long c0 = System.nanoTime();
                long got = p.perft(d);
                long dt = System.nanoTime() - c0;
                boolean ok = got == t.exp[d - 1];
                if (d >= 3) { total += got; ns += dt; }
                if (d >= max - 1 || !ok)
                    System.out.printf("PERFT %-20s d%d %s got=%d exp=%d %dms%n",
                        t.name, d, ok ? "OK  " : "DISO", got, t.exp[d - 1], dt / 1_000_000L);
                if (!ok) {
                    bad++;
                    System.out.println("  divide " + t.fen + " depth " + d + ":");
                    Pos q = new Pos(); q.setFen(t.fen); divide(q, d);
                    break;
                }
            }
        }
        long ms = ns / 1_000_000L;
        System.out.printf("PERFT_SUMMARY %s nodes=%d time=%dms mnps=%.1f%n",
            bad == 0 ? "PASS" : "FAIL(" + bad + ")", total, ms, ms > 0 ? total / 1000.0 / ms : 0);
        System.exit(bad == 0 ? 0 : 1);
    }
}
