package mg.chess.offline.own;

import java.util.*;

/**
 * Match kely eto an-toerana: A vs B (safidy samihafa), thread 1, fotoana raikitra, opening mitovy ka miova xefa.
 * Ampiasa: java -cp cls mg.chess.offline.own.Match <pairs> <moveMs> "<optsA>" "<optsB>" [openPlies=8]
 * ohatra:  java -cp cls mg.chess.offline.own.Match 60 40 "Iir=1" ""
 * Natao ho fanamarinana haingana (tsy SPRT): mahita bug lehibe fa tsy mamaritra Elo kely.
 */
public class Match {
    static void apply(String opts) {
        for (Params.P p : Params.ALL.values()) p.val = p.def;
        Params.set("Eval2", 0);
        if (opts == null || opts.isBlank()) return;
        for (String kv : opts.split("[, ]+")) {
            if (kv.isBlank()) continue;
            String[] x = kv.split("=");
            if (!Params.set(x[0], Integer.parseInt(x[1]))) throw new IllegalArgumentException("safidy tsy fantatra: " + x[0]);
        }
        Search.rebuildLmr();
    }

    /** 1.0 = A resy... Miverina valin'ny fotsy (1/0.5/0). */
    static double game(int g, boolean aWhite, long ms, int openPlies, Search sa, Search sb, String oa, String ob, Eval ev) {
        Pos p = sa.pos;
        Random rng = new Random(0x9E3779B97F4A7C15L * (g + 1));
        for (int attempt = 0; ; attempt++) {
            p.startPos();
            for (int i = 0; i < openPlies; i++) {
                int[] mv = new int[256]; int n = p.genAll(mv);
                List<Integer> legal = new ArrayList<>();
                for (int k = 0; k < n; k++) if (p.make(mv[k])) { p.unmake(); legal.add(mv[k]); }
                if (legal.isEmpty()) break;
                p.make(legal.get(rng.nextInt(legal.size())));
            }
            if (Math.abs(ev.evalRaw(p)) <= 150 || attempt >= 30) break;
        }
        // Pos roa misaraka (iray isaky ny Search): ny hetsika dia atao amin'ny roa
        sa.clear(); sb.clear();
        sb.pos.setFen(SelfPlay.fen(p));
        int ply = openPlies, big = 0, bigSign = 0, quiet = 0;
        while (true) {
            if (!SelfPlay.hasLegal(p)) return p.inCheck() ? (p.side == 0 ? 0.0 : 1.0) : 0.5;
            if (p.half >= 100 || p.repeated() || SelfPlay.insufficient(p) || ply >= 300) return 0.5;
            boolean aMove = (p.side == 0) == aWhite;
            Search s = aMove ? sa : sb;
            apply(aMove ? oa : ob);
            Search.Result r = s.think(64, ms);
            if (r.move == 0) return 0.5;
            int sc = p.side == 0 ? r.score : -r.score;
            if (!p.make(r.move)) return 0.5;
            if (!sb.pos.make(r.move)) return 0.5;
            ply++;
            if (Math.abs(sc) >= 900) {
                int sg = sc > 0 ? 1 : -1;
                big = (big > 0 && sg == bigSign) ? big + 1 : 1; bigSign = sg;
                if (big >= 6) return sg > 0 ? 1.0 : 0.0;
            } else big = 0;
            quiet = Math.abs(sc) <= 15 ? quiet + 1 : 0;
            if (ply >= 160 && quiet >= 10) return 0.5;
        }
    }

    public static void main(String[] a) {
        final int pairs = Integer.parseInt(a[0]);
        final long ms = Long.parseLong(a[1]);
        final String oa = a[2], ob = a[3];
        final int openPlies = a.length > 4 ? Integer.parseInt(a[4]) : 8;
        Eval ev = new Eval(50, 50, 50, 50, 50);
        Search sa = new Search(ev), sb = new Search(ev);
        int w = 0, d = 0, l = 0;
        for (int g = 0; g < pairs; g++) {
            for (int c = 0; c < 2; c++) {
                boolean aWhite = c == 0;
                double wr = game(g, aWhite, ms, openPlies, sa, sb, oa, ob, ev);
                double aScore = aWhite ? wr : 1 - wr;
                if (aScore == 1.0) w++; else if (aScore == 0.0) l++; else d++;
            }
            if ((g + 1) % 10 == 0) System.out.println((2 * (g + 1)) + " lalao: +" + w + " =" + d + " -" + l);
        }
        int n = w + d + l;
        double sc = (w + 0.5 * d) / n;
        double elo = -400 * Math.log10(1 / Math.max(1e-3, Math.min(1 - 1e-3, sc)) - 1);
        double var = (w * Math.pow(1 - sc, 2) + d * Math.pow(0.5 - sc, 2) + l * Math.pow(sc, 2)) / n;
        double se = Math.sqrt(var / n);
        double eloHi = -400 * Math.log10(1 / Math.min(1 - 1e-3, sc + 1.96 * se) - 1), eloLo = -400 * Math.log10(1 / Math.max(1e-3, sc - 1.96 * se) - 1);
        System.out.printf("MATCH A=[%s] B=[%s] lalao=%d +%d =%d -%d score=%.1f%% Elo(A-B)=%+.0f [%+.0f, %+.0f]%n", oa, ob, n, w, d, l, sc * 100, elo, eloLo, eloHi);
    }
}
