#!/usr/bin/env python3
"""Manolo ny "Lanja voatombana" ao amin'ny Eval.java amin'ny vokatra Texel (tuned.txt).
Ampiasa: python3 tools/apply_tuned.py tuned.txt app/src/main/java/mg/chess/offline/own/Eval.java"""
import re, sys

tuned, evalf = sys.argv[1], sys.argv[2]
new = dict(re.findall(r"int\[\] (\w+) = (\{[^}]*\});", open(tuned).read()))
src = open(evalf).read()
a = src.index("// ---- Lanja voatombana")
b = src.index("// ---- farany ----")
blk = src[a:b]
done = []
for name, arr in new.items():
    blk, k = re.subn(r"(int\[\] %s = )\{[^}]*\};" % name, lambda m: m.group(1) + arr + ";", blk, count=1)
    if k: done.append(name)
missing = [n for n in new if n not in done]
if missing:
    sys.exit("TSY HITA ao amin'ny Eval: " + ", ".join(missing))
open(evalf, "w").write(src[:a] + blk + src[b:])
print("NOVAINA:", " ".join(done))
