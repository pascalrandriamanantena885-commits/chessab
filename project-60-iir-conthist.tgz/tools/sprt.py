#!/usr/bin/env python3
"""SPRT: dikan-teny vaovao vs taloha an'i JORO (lalao UCI, python-chess).

Ampiasa:
  python3 tools/sprt.py <cls_taloha> <cls_vaovao> [--games 2000] [--movetime 100]
                        [--elo0 0] [--elo1 5] [--workers 2] [--alpha 0.05] [--beta 0.05]

Vokatra: H1 (vaovao tsara kokoa >= elo1), H0 (tsy tsara kokoa), na tsy mbola vita (tapitra ny lalao).
Exit code: 0 = H1, 1 = H0, 2 = tsy mbola vita.
"""
import argparse, glob, json, math, os, random, sys
from multiprocessing import Pool


def elo_to_score(e):
    return 1.0 / (1.0 + 10 ** (-e / 400.0))


def llr(w, d, l, elo0, elo1):
    """LLR (fanatatehana Gaussian, mitovy amin'ny cutechess/fastchess tsy pentanomial)."""
    n = w + d + l
    if n == 0:
        return 0.0
    mean = (w + d / 2.0) / n
    var = (w * (1 - mean) ** 2 + d * (0.5 - mean) ** 2 + l * (0 - mean) ** 2) / n
    if var < 1e-9:
        return 0.0
    s0, s1 = elo_to_score(elo0), elo_to_score(elo1)
    return n * (s1 - s0) * (2 * mean - s0 - s1) / (2 * var)


def bounds(alpha, beta):
    return math.log(beta / (1 - alpha)), math.log((1 - beta) / alpha)  # lower (H0), upper (H1)


def elo_estimate(w, d, l):
    n = w + d + l
    if n == 0:
        return 0.0, 0.0
    s = min(max((w + d / 2.0) / n, 1e-3), 1 - 1e-3)
    var = (w * (1 - s) ** 2 + d * (0.5 - s) ** 2 + l * s ** 2) / n
    elo = -400 * math.log10(1 / s - 1)
    # fahadisoana 95% (delta method)
    se = math.sqrt(var / n)
    d_elo = 400 / math.log(10) / (s * (1 - s))
    return elo, 1.96 * se * d_elo


# ---------------------------------------------------------------- lalao
_A = {}


def parse_opts(txt):
    """'ProbCut=1,HashBits=21' -> {'ProbCut': 1, 'HashBits': 21}"""
    out = {}
    for kv in (txt or "").replace(" ", ",").split(","):
        if kv.strip():
            k, v = kv.split("=")
            out[k.strip()] = int(v)
    return out


def _init(old_cls, new_cls, movetime, opts_old="", opts_new=""):
    import chess.engine
    cmd = lambda c: ["java", "-cp", c, "mg.chess.offline.own.OwnUci"]
    _A["old"] = chess.engine.SimpleEngine.popen_uci(cmd(old_cls))
    _A["new"] = chess.engine.SimpleEngine.popen_uci(cmd(new_cls))
    for key, o in (("old", parse_opts(opts_old)), ("new", parse_opts(opts_new))):
        if o:
            _A[key].configure(o)
    _A["mt"] = movetime / 1000.0


def _opening(board, seed, plies=6):
    import chess
    rng = random.Random(seed)
    for _ in range(plies):
        moves = list(board.legal_moves)
        if not moves or board.is_game_over():
            break
        board.push(rng.choice(moves))
    return board


def _score_of(info):
    try:
        return info["score"].white().score(mate_score=10000)
    except Exception:
        return None


def play_game(g):
    """Miverina: (g, valiny amin'ny fomba fijerin'ny VAOVAO: 1, 0.5, 0, rows).
    rows = ["FEN;valiny_fotsy", ...] (toerana milamina ho an'ny Texel)."""
    import chess, chess.engine
    board = _opening(chess.Board(), seed=g // 2)
    new_white = (g % 2 == 0)
    for e in (_A["old"], _A["new"]):
        e.protocol.send_line("ucinewgame")
    lim = chess.engine.Limit(time=_A["mt"])
    big, big_sign, quiet = 0, None, 0   # fanamarinana ny valiny (adjudication)
    rng = random.Random(1_000_003 + g)
    fens = []                           # toerana voatahiry (mbola tsy fantatra ny valiny)
    white = None                        # valiny amin'ny fomba fijerin'ny Fotsy

    while white is None and not board.is_game_over(claim_draw=True) and len(board.move_stack) < 300:
        new_turn = (board.turn == chess.WHITE) == new_white
        eng = _A["new"] if new_turn else _A["old"]
        in_check = board.is_check()
        fen_before = board.fen()
        r = eng.play(board, lim, info=chess.engine.INFO_SCORE)
        # toerana milamina: tsy check, tsy fakana ny hetsika voafidy, tsy ao amin'ny fiandohana; sary 1/2
        if len(board.move_stack) >= 10 and not in_check and not board.is_capture(r.move) and rng.random() < 0.5:
            fens.append(fen_before)
        board.push(r.move)
        sc = _score_of(r.info)
        if sc is not None:
            if abs(sc) >= 900:
                sgn = sc > 0
                big = big + 1 if (big > 0 and sgn == big_sign) else 1
                big_sign = sgn
            else:
                big = 0
            quiet = quiet + 1 if abs(sc) <= 15 else 0
            if big >= 6 and abs(sc) >= 900:
                white = 1.0 if sc > 0 else 0.0            # amin'ny fomba fijerin'ny Fotsy
            elif len(board.move_stack) >= 160 and quiet >= 10:
                white = 0.5
    if white is None:
        res = board.result(claim_draw=True)
        white = {"1-0": 1.0, "0-1": 0.0}.get(res, 0.5)
    rows = [f"{f};{white}" for f in fens]
    return g, (white if new_white else 1.0 - white), rows


def aggregate(a, lo, hi):
    w = d = l = 0
    n_files = 0
    if a.prior:
        pw, pd, pl = (int(x) for x in a.prior.split(","))
        w, d, l = pw, pd, pl
    last = 0
    for f in sorted(glob.glob(os.path.join(a.aggregate, "**", "sprt-*.json"), recursive=True)):
        r = json.load(open(f)); w += r["w"]; d += r["d"]; l += r["l"]; n_files += 1
        last = max(last, r["first"] + r["games"])
    if n_files == 0:
        print("::error::Tsy hita ny sprt-*.json"); sys.exit(1)
    n = w + d + l
    x = llr(w, d, l, a.elo0, a.elo1)
    e, err = elo_estimate(w, d, l)
    verdict = "H1 (vaovao tsara kokoa)" if x >= hi else "H0 (tsy tsara kokoa)" if x <= lo else "TSY MBOLA MAZAVA"
    txt = (f"RESULT {verdict}\nlalao={n} (+{w} ={d} -{l})  Elo={e:+.1f} ±{err:.1f}\n"
           f"LLR={x:+.2f} sisin-tany=[{lo:.2f},{hi:.2f}]  SPRT[{a.elo0},{a.elo1}] alpha={a.alpha} beta={a.beta}")
    if x > lo and x < hi:
        txt += f"\nHitohy: start_game={last} prior={w},{d},{l}"
    print(txt)
    if os.environ.get("GITHUB_STEP_SUMMARY"):
        open(os.environ["GITHUB_STEP_SUMMARY"], "a").write("### SPRT " + (a.label or "") + "\n```\n" + txt + "\n```\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("old_cls", nargs="?"); ap.add_argument("new_cls", nargs="?")
    ap.add_argument("--games", type=int, default=2000)
    ap.add_argument("--movetime", type=int, default=100)
    ap.add_argument("--elo0", type=float, default=0.0)
    ap.add_argument("--elo1", type=float, default=5.0)
    ap.add_argument("--alpha", type=float, default=0.05)
    ap.add_argument("--beta", type=float, default=0.05)
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--first-game", type=int, default=0, help="laharana lalao voalohany (shard)")
    ap.add_argument("--out", default="", help="mode shard: lalao rehetra (tsy misy fijanonana), soratana ao JSON")
    ap.add_argument("--aggregate", default="", help="lahatahiry misy sprt-*.json: tambatra ary kajy ny LLR")
    ap.add_argument("--label", default="", help="lohateny ao amin'ny summary (aggregate)")
    ap.add_argument("--dump", default="", help="rakitra: toerana milamina + valiny (FEN;valiny_fotsy) ho an'ny Texel")
    ap.add_argument("--prior", default="", help="W,D,L teo aloha (run teo aloha) hampiana")
    ap.add_argument("--opts-base", default="", help="safidy UCI an'ny taloha: Name=val,Name2=val")
    ap.add_argument("--opts-new", default="", help="safidy UCI an'ny vaovao: Name=val,Name2=val")
    a = ap.parse_args()

    lo, hi = bounds(a.alpha, a.beta)
    if a.aggregate:
        aggregate(a, lo, hi)
        return
    w = d = l = 0
    verdict = None
    rows_all = []
    print(f"SPRT [{a.elo0}, {a.elo1}] alpha={a.alpha} beta={a.beta} bounds=({lo:.2f}, {hi:.2f}) "
          f"movetime={a.movetime}ms workers={a.workers} opts_base=[{a.opts_base}] opts_new=[{a.opts_new}]", flush=True)
    with Pool(a.workers, initializer=_init, initargs=(a.old_cls, a.new_cls, a.movetime, a.opts_base, a.opts_new)) as pool:
        first = a.first_game - a.first_game % 2            # mifandimby loko: laharana voalohany tsy maintsy ratsy
        games = a.games + a.games % 2
        for i, (g, sc, rows) in enumerate(pool.imap_unordered(play_game, range(first, first + games)), 1):
            rows_all.extend(rows)
            if sc == 1.0: w += 1
            elif sc == 0.0: l += 1
            else: d += 1
            x = llr(w, d, l, a.elo0, a.elo1)
            if a.out:                                       # mode shard: tsy mijanona, tapitra ny lalao rehetra
                if i % 20 == 0:
                    e, err = elo_estimate(w, d, l)
                    print(f"{i:5d} lalao  +{w} ={d} -{l}  Elo={e:+.1f} ±{err:.1f}", flush=True)
                continue
            if i % 20 == 0 or x <= lo or x >= hi:
                e, err = elo_estimate(w, d, l)
                print(f"{i:5d} lalao  +{w} ={d} -{l}  Elo={e:+.1f} ±{err:.1f}  LLR={x:+.2f} [{lo:.2f},{hi:.2f}]", flush=True)
            if x >= hi: verdict = "H1"; break
            if x <= lo: verdict = "H0"; break
        pool.terminate()
    if a.dump:
        with open(a.dump, "w") as fh:
            fh.write("\n".join(rows_all) + ("\n" if rows_all else ""))
        print(f"DUMP {len(rows_all)} toerana -> {a.dump}")
    if a.out:
        json.dump({"w": w, "d": d, "l": l, "first": first, "games": games}, open(a.out, "w"))
        print(f"SHARD +{w} ={d} -{l}")
        return
    e, err = elo_estimate(w, d, l)
    print(f"RESULT {verdict or 'TSY_VITA'}  +{w} ={d} -{l}  Elo={e:+.1f} ±{err:.1f}  LLR={llr(w, d, l, a.elo0, a.elo1):+.2f}")
    sys.exit({"H1": 0, "H0": 1}.get(verdict, 2))


if __name__ == "__main__":
    main()
