#!/bin/bash
for o in "CaptHist=1" "ContHist=1" "SeePrune=1" "HistPrune=1" "Sing2=1" "LmrTT=1" "QsTT=1" "Iir=1" "LmrCut=1" "LmrHist2=1" "NmpVerify=1" "TtEval=1" "Eval2=1"; do
  java -cp cls mg.chess.offline.own.Match 15 40 "$o" "" 2>&1 | grep "^MATCH"
done
echo DONE
