package mg.chess.offline.own;

import java.util.LinkedHashMap;

/**
 * Parameter azo ovaina (UCI setoption / SPSA) sy "switch" ho an'ny fikarohana vaovao.
 * Ny soatoavina default dia mitovy amin'ny fitondran-tena taloha: ny safidy vaovao (ProbCut, CaptHist, ContHist)
 * dia 0 (tsy mandeha) ka mitovy tanteraka ny node raha tsy novana.
 */
public final class Params {
    public static final class P {
        public final String name; public final int def, min, max; public volatile int val;
        P(String n, int d, int mn, int mx) { name = n; def = d; min = mn; max = mx; val = d; }
    }

    public static final LinkedHashMap<String, P> ALL = new LinkedHashMap<>();
    private static P reg(String n, int d, int mn, int mx) { P p = new P(n, d, mn, mx); ALL.put(n, p); return p; }

    // --- safidy / fanamafisana ---
    public static final P HASH_BITS     = reg("HashBits", 19, 16, 24);      // 2^bits entana TT
    public static final P PROBCUT       = reg("ProbCut", 0, 0, 1);
    public static final P PROBCUT_MARGIN = reg("ProbCutMargin", 200, 50, 500);
    public static final P CAPT_HIST     = reg("CaptHist", 0, 0, 1);
    public static final P CONT_HIST     = reg("ContHist", 1, 0, 1);
    public static final P EVAL2         = reg("Eval2", 0, 0, 1);              // toetra vaovao ao amin'ny Eval (piyon, tafio-drivotra)
    public static final P EVAL4         = reg("Eval4", 0, 0, 1);              // toetra vaovao: bishop ratsy, knight/rook araka ny piyon, rook voasakana, scaling endgame
    public static final P EVAL3         = reg("Eval3", 1, 0, 1);              // toetra fanafihana (king attack, sacrifice, tropism...)
    // --- fanatsarana fikarohana vaovao (default 0 = tsy mandeha; SPRT isaky ny iray) ---
    public static final P SEE_PRUNE     = reg("SeePrune", 0, 0, 1);          // esory ny quiet SEE ratsy amin'ny depth fohy
    public static final P SEE_QUIET     = reg("SeeQuiet", 30, 5, 100);
    public static final P HIST_PRUNE    = reg("HistPrune", 0, 0, 1);         // esory ny quiet history ratsy loatra
    public static final P HIST_PRUNE_MUL = reg("HistPruneMul", 1500, 500, 4000);
    public static final P SING2         = reg("Sing2", 0, 0, 1);             // singular: double ext + negative ext
    public static final P CONTEMPT      = reg("Contempt", 0, 0, 100);        // cp: ialana ny draw (fomba filalaovana mitoloko)
    public static final P LMR_TT        = reg("LmrTT", 0, 0, 1);             // LMR +1 raha capture ny ttMove
    public static final P QS_TT         = reg("QsTT", 0, 0, 1);              // tehirizina ao amin'ny TT ny qsearch
    public static final P IIR           = reg("Iir", 1, 0, 1);               // internal iterative reduction (solon'ny IID)
    public static final P LMR_CUT       = reg("LmrCut", 0, 0, 1);            // LMR +1 amin'ny cut node (miandry fail-high)
    public static final P LMR_HIST2     = reg("LmrHist2", 0, 0, 1);          // LMR miovaova tsy tapaka araka ny history (hs/5000, -2..+2)
    public static final P NMP_VERIFY    = reg("NmpVerify", 0, 0, 1);         // fanamarinana null move amin'ny depth lehibe (zugzwang)
    public static final P TT_EVAL       = reg("TtEval", 0, 0, 1);            // ampiasaina ny score TT ho eval amin'ny pruning
    // --- fomba JORO (gambit / sacrifice). Default 0 = tsy mandeha; SPRT/gauntlet alohan'ny hampandehanana ---
    public static final P JORO_STYLE    = reg("JoroStyle", 0, 0, 1);         // Eval: onitra sacrifice lehibe + initiative; Search: contempt
    public static final P JORO_SAC      = reg("JoroSac", 150, 100, 300);     // % an'ny bonus sacrifice (100 = mitovy amin'ny Eval3)
    public static final P JORO_DEV      = reg("JoroDev", 6, 0, 20);          // cp isaky ny kapiteny tsy mbola nivoaka an'ny mpifanandrina (ho an'ny miaramila very)
    public static final P JORO_CONTEMPT = reg("JoroContempt", 25, 0, 60);    // cp, raha JoroStyle=1 ary Contempt=0
    public static final P JORO_BOOK     = reg("JoroBook", 0, 0, 1);          // book gambit (OwnBot; tsy misy fiantraikany amin'ny UCI/SPRT)
    // --- Gambit JORO: sacrifice mamaky ny fiarovana / manokatra ny square manodidina ny mpanjaka mpifanandrina (default 0) ---
    public static final P JORO_HUNT        = reg("JoroHunt", 0, 0, 1);           // Eval: lasa mpanjaka (mating net) ; Search: tsy esorina/ahena ny sacrifice akaikin'ny mpanjaka + extension
    public static final P JORO_HUNT_HOLE   = reg("JoroHuntHole", 6, 0, 30);     // cp isaky ny file misy piyon fiarovana tsy ao
    public static final P JORO_HUNT_FLIGHT = reg("JoroHuntFlight", 8, 0, 30);   // cp isaky ny toerana handosirana very (<=2 sisa)
    public static final P JORO_HUNT_MAX    = reg("JoroHuntMax", 30, 0, 150);     // cp ambony indrindra
    // --- Rook gambit JORO: very material mba hisy contact ny rook amin'ny mpanjaka mpifanandrina (contact check / contact block). Default 0 ---
    public static final P JORO_ROOK         = reg("JoroRook", 0, 0, 1);          // Eval: onitra contact/open line ; Search: SEE ratsy tsy esorina raha manao rook contact
    public static final P JORO_ROOK_CONTACT = reg("JoroRookContact", 25, 0, 60); // cp: rook mifanakaiky (orthogonal) amin'ny mpanjaka mpifanandrina
    public static final P JORO_ROOK_OPEN    = reg("JoroRookOpen", 10, 0, 30);    // cp: rook amin'ny file/rank iray amin'ny mpanjaka, tsy misy sakana
    public static final P JORO_ROOK_MAX     = reg("JoroRookMax", 40, 0, 100);    // cp ambony indrindra
    // --- lanja azo tuning-na (SPSA); default = ny soatoavina taloha ---
    public static final P RFP_MARGIN    = reg("RfpMargin", 74, 40, 160);
    public static final P RFP_MARGIN_IMP = reg("RfpMarginImp", 70, 30, 140);
    public static final P RAZOR_MARGIN  = reg("RazorMargin", 179, 120, 500);
    public static final P FUT_BASE      = reg("FutBase", 90, 30, 200);
    public static final P FUT_MUL       = reg("FutMul", 90, 30, 200);
    public static final P NMP_BASE      = reg("NmpBase", 3, 2, 5);
    public static final P ASP_DELTA     = reg("AspDelta", 21, 10, 100);
    public static final P LMR_BASE      = reg("LmrBase", 75, 0, 150);        // /100
    public static final P LMR_DIV       = reg("LmrDiv", 225, 150, 350);      // /100

    /** Miverina true raha fantatra ny anarana. */
    public static boolean set(String name, int v) {
        P p = ALL.get(name);
        if (p == null) return false;
        p.val = Math.max(p.min, Math.min(p.max, v));
        if (p == LMR_BASE || p == LMR_DIV) Search.rebuildLmr();
        return true;
    }

    private Params() {}
}
