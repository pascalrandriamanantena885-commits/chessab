package mg.chess.offline

import com.github.bhlangonijr.chesslib.Board
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PersonalityTest {
    private fun feat(fen: String, uci: String): MoveFeat {
        val b = Board(); b.loadFromFen(fen)
        val mv = b.legalMoves().first { it.toString().equals(uci, true) }
        return Personality.feat(b, mv, 10)
    }

    @Test fun phaseStartIsOne() = assertEquals(1.0, Personality.phase(Board()), 1e-9)

    @Test fun phaseEndgameIsLow() {
        val b = Board(); b.loadFromFen("8/8/8/4k3/8/8/4K3/R7 w - - 0 1")
        assertTrue(Personality.phase(b) < 0.2)
        assertTrue(Personality.toleranceScale(b) < Personality.toleranceScale(Board()))
    }

    @Test fun pawnStormDetected() {
        assertTrue(feat("r4rk1/ppp2ppp/8/8/8/8/PPPPPPPP/R3K2R w KQ - 0 1", "g2g4").pawnStorm)
        assertFalse(feat("r4rk1/ppp2ppp/8/8/8/8/PPPPPPPP/R3K2R w KQ - 0 1", "a2a3").pawnStorm)
    }

    @Test fun kingAttackDetected() {
        assertTrue(feat("6k1/5ppp/8/8/8/3Q4/5PPP/6K1 w - - 0 1", "d3g6").kingAttack)
        assertFalse(feat("6k1/5ppp/8/8/8/3Q4/5PPP/6K1 w - - 0 1", "d3d1").kingAttack)
    }
}

class EditBoardGameTest {
    private val blackToMove = "4k3/pppp4/8/8/8/8/4PPPP/4K3 b - - 0 1"

    @Test fun blackFirstAndMoveNo() {
        assertTrue(blackFirst(blackToMove))
        assertFalse(blackFirst(START_FEN))
        assertEquals(1, startMoveNo(blackToMove))
        assertEquals(12, startMoveNo("4k3/8/8/8/8/8/8/4K3 w - - 3 12"))
    }

    @Test fun deriveStyleUsesRealMoverOnCustomStart() {
        // Mainty no mihetsika voalohany: ny hetsika 0 dia an'ny Mainty, tsy ny Fotsy
        val moves = listOf("a7a5", "e2e3", "b7b5", "f2f3", "c7c5", "g2g3", "d7d5", "h2h3")
        val black = Personality.deriveStyle(moves, false, blackToMove)
        val white = Personality.deriveStyle(moves, true, blackToMove)
        // samy nahazo hetsika 4 (pion miandry ihany, tsy fanafihana) -> aggression 5; Style() mahazatra dia 50
        assertEquals(5, black.aggression)
        assertEquals(5, white.aggression)
    }

    @Test fun noOpeningsOnCustomStart() {
        assertTrue(Personality.detectOpenings(listOf("e2e4", "e7e5", "g1f3", "b8c6", "f1c4", "f8c5"), true, blackToMove).isEmpty())
    }
}

class BotRankingTest {
    @Test fun deltaLabels() {
        assertEquals("▲ +43", eloDeltaLabel(43))
        assertEquals("▼ -12", eloDeltaLabel(-12))
        assertEquals("=", eloDeltaLabel(0))
    }

    @Test fun eloChangeDelta() {
        assertEquals(43, EloChange("x", "X", 2407, 2450, 1, "").delta)
    }
}
